(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_0c~0-f9._.js","static/chunks/node_modules_0tmy6ps._.js"],
    source: "dynamic"
});
