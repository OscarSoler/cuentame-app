(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/.pnpm/streamdown@2.5.0_react-dom@19.2.4_react@19.2.4__react@19.2.4/node_modules/streamdown/dist/highlighted-body-OFNGDK62.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/04y0_streamdown_dist_highlighted-body-OFNGDK62_0vk-_1w.js",
  "static/chunks/04y0_streamdown_dist_highlighted-body-OFNGDK62_0tnk36x.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/.pnpm/streamdown@2.5.0_react-dom@19.2.4_react@19.2.4__react@19.2.4/node_modules/streamdown/dist/highlighted-body-OFNGDK62.js [app-client] (ecmascript)");
    });
});
}),
"[project]/node_modules/.pnpm/streamdown@2.5.0_react-dom@19.2.4_react@19.2.4__react@19.2.4/node_modules/streamdown/dist/mermaid-GHXKKRXX.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/04y0_streamdown_dist_mermaid-GHXKKRXX_0v85wd0.js",
  "static/chunks/04y0_streamdown_dist_mermaid-GHXKKRXX_108~m4c.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/.pnpm/streamdown@2.5.0_react-dom@19.2.4_react@19.2.4__react@19.2.4/node_modules/streamdown/dist/mermaid-GHXKKRXX.js [app-client] (ecmascript)");
    });
});
}),
]);