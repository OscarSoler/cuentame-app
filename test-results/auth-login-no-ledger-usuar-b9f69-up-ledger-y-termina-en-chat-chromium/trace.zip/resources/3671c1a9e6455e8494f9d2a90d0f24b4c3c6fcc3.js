(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__0q46dgi._.css","static/chunks/0h_p_next_dist_0wxak0g._.js"],
    source: "dynamic"
});
