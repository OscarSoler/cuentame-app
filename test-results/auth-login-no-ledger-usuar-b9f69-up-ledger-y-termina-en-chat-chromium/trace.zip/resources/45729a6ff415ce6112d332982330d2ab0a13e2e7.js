(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/.pnpm/streamdown@2.5.0_react-dom@19.2.4_react@19.2.4__react@19.2.4/node_modules/streamdown/dist/chunk-BO2N2NFS.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "A",
    ()=>R,
    "B",
    ()=>Tn,
    "C",
    ()=>Qs,
    "a",
    ()=>be,
    "b",
    ()=>tt,
    "c",
    ()=>At,
    "d",
    ()=>ot,
    "e",
    ()=>rt,
    "f",
    ()=>Li,
    "g",
    ()=>st,
    "h",
    ()=>De,
    "i",
    ()=>Ae,
    "j",
    ()=>it,
    "k",
    ()=>Oe,
    "l",
    ()=>po,
    "m",
    ()=>ue,
    "n",
    ()=>ne,
    "o",
    ()=>dt,
    "p",
    ()=>je,
    "q",
    ()=>re,
    "r",
    ()=>Te,
    "s",
    ()=>Wr,
    "t",
    ()=>Pe,
    "u",
    ()=>$e,
    "v",
    ()=>on,
    "w",
    ()=>kt,
    "x",
    ()=>Js,
    "y",
    ()=>xt,
    "z",
    ()=>Ks
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@babel+core@7.29.0_@opentelemetry+api@1.9.0_@playwright+test@1.59.1_react-d_00302af571a966878a6c3f1b2db86a61/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$rehype$2d$harden$40$1$2e$1$2e$8$2f$node_modules$2f$rehype$2d$harden$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/rehype-harden@1.1.8/node_modules/rehype-harden/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$rehype$2d$raw$40$7$2e$0$2e$0$2f$node_modules$2f$rehype$2d$raw$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/rehype-raw@7.0.0/node_modules/rehype-raw/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$rehype$2d$sanitize$40$6$2e$0$2e$0$2f$node_modules$2f$rehype$2d$sanitize$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/rehype-sanitize@6.0.0/node_modules/rehype-sanitize/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$hast$2d$util$2d$sanitize$40$5$2e$0$2e$2$2f$node_modules$2f$hast$2d$util$2d$sanitize$2f$lib$2f$schema$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/hast-util-sanitize@5.0.2/node_modules/hast-util-sanitize/lib/schema.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$remark$2d$gfm$40$4$2e$0$2e$1$2f$node_modules$2f$remark$2d$gfm$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/remark-gfm@4.0.1/node_modules/remark-gfm/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$remend$40$1$2e$3$2e$0$2f$node_modules$2f$remend$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/remend@1.3.0/node_modules/remend/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$unist$2d$util$2d$visit$2d$parents$40$6$2e$0$2e$2$2f$node_modules$2f$unist$2d$util$2d$visit$2d$parents$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/unist-util-visit-parents@6.0.2/node_modules/unist-util-visit-parents/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/clsx@2.1.1/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tailwind$2d$merge$40$3$2e$5$2e$0$2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tailwind-merge@3.5.0/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@babel+core@7.29.0_@opentelemetry+api@1.9.0_@playwright+test@1.59.1_react-d_00302af571a966878a6c3f1b2db86a61/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.2_@babel+core@7.29.0_@opentelemetry+api@1.9.0_@playwright+test@1.59.1_react-d_00302af571a966878a6c3f1b2db86a61/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$hast$2d$util$2d$to$2d$jsx$2d$runtime$40$2$2e$3$2e$6$2f$node_modules$2f$hast$2d$util$2d$to$2d$jsx$2d$runtime$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/hast-util-to-jsx-runtime@2.3.6/node_modules/hast-util-to-jsx-runtime/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$html$2d$url$2d$attributes$40$3$2e$0$2e$1$2f$node_modules$2f$html$2d$url$2d$attributes$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/html-url-attributes@3.0.1/node_modules/html-url-attributes/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$remark$2d$parse$40$11$2e$0$2e$0$2f$node_modules$2f$remark$2d$parse$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/remark-parse@11.0.0/node_modules/remark-parse/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$remark$2d$rehype$40$11$2e$1$2e$2$2f$node_modules$2f$remark$2d$rehype$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/remark-rehype@11.1.2/node_modules/remark-rehype/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$unified$40$11$2e$0$2e$5$2f$node_modules$2f$unified$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/unified@11.0.5/node_modules/unified/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$unist$2d$util$2d$visit$40$5$2e$1$2e$0$2f$node_modules$2f$unist$2d$util$2d$visit$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/unist-util-visit@5.1.0/node_modules/unist-util-visit/lib/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$marked$40$17$2e$0$2e$6$2f$node_modules$2f$marked$2f$lib$2f$marked$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/marked@17.0.6/node_modules/marked/lib/marked.esm.js [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
var Bn = 300, An = "300px", On = 500;
function Rt(e = {}) {
    let { immediate: t = false, debounceDelay: o = Bn, rootMargin: n = An, idleTimeout: r = On } = e, [s, a] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false), l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), i = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), d = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), c = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Rt.useMemo[c]": ()=>({
                "Rt.useMemo[c]": (u)=>{
                    let f = Date.now();
                    return window.setTimeout({
                        "Rt.useMemo[c]": ()=>{
                            u({
                                didTimeout: false,
                                timeRemaining: {
                                    "Rt.useMemo[c]": ()=>Math.max(0, 50 - (Date.now() - f))
                                }["Rt.useMemo[c]"]
                            });
                        }
                    }["Rt.useMemo[c]"], 1);
                }
            })["Rt.useMemo[c]"]
    }["Rt.useMemo[c]"], []), p = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Rt.useMemo[p]": ()=>typeof window != "undefined" && window.requestIdleCallback ? ({
                "Rt.useMemo[p]": (u, f)=>window.requestIdleCallback(u, f)
            })["Rt.useMemo[p]"] : c
    }["Rt.useMemo[p]"], [
        c
    ]), m = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Rt.useMemo[m]": ()=>typeof window != "undefined" && window.cancelIdleCallback ? ({
                "Rt.useMemo[m]": (u)=>window.cancelIdleCallback(u)
            })["Rt.useMemo[m]"] : ({
                "Rt.useMemo[m]": (u)=>{
                    clearTimeout(u);
                }
            })["Rt.useMemo[m]"]
    }["Rt.useMemo[m]"], []);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Rt.useEffect": ()=>{
            if (t) {
                a(true);
                return;
            }
            let u = l.current;
            if (!u) return;
            i.current && (clearTimeout(i.current), i.current = null), d.current && (m(d.current), d.current = null);
            let f = {
                "Rt.useEffect.f": ()=>{
                    i.current && (clearTimeout(i.current), i.current = null), d.current && (m(d.current), d.current = null);
                }
            }["Rt.useEffect.f"], h = {
                "Rt.useEffect.h": (v)=>{
                    d.current = p({
                        "Rt.useEffect.h": (w)=>{
                            w.timeRemaining() > 0 || w.didTimeout ? (a(true), v.disconnect()) : d.current = p({
                                "Rt.useEffect.h": ()=>{
                                    a(true), v.disconnect();
                                }
                            }["Rt.useEffect.h"], {
                                timeout: r / 2
                            });
                        }
                    }["Rt.useEffect.h"], {
                        timeout: r
                    });
                }
            }["Rt.useEffect.h"], b = {
                "Rt.useEffect.b": (v)=>{
                    f(), i.current = window.setTimeout({
                        "Rt.useEffect.b": ()=>{
                            var M, H;
                            let w = v.takeRecords();
                            (w.length === 0 || (H = (M = w.at(-1)) == null ? void 0 : M.isIntersecting) != null && H) && h(v);
                        }
                    }["Rt.useEffect.b"], o);
                }
            }["Rt.useEffect.b"], g = {
                "Rt.useEffect.g": (v, w)=>{
                    v.isIntersecting ? b(w) : f();
                }
            }["Rt.useEffect.g"], T = new IntersectionObserver({
                "Rt.useEffect": (v)=>{
                    for (let w of v)g(w, T);
                }
            }["Rt.useEffect"], {
                rootMargin: n,
                threshold: 0
            });
            return T.observe(u), ({
                "Rt.useEffect": ()=>{
                    i.current && clearTimeout(i.current), d.current && m(d.current), T.disconnect();
                }
            })["Rt.useEffect"];
        }
    }["Rt.useEffect"], [
        t,
        o,
        n,
        r,
        m,
        p
    ]), {
        shouldRender: s,
        containerRef: l
    };
}
var St = /\s/, Fn = /^\s+$/, zn = new Set([
    "code",
    "pre",
    "svg",
    "math",
    "annotation"
]), _n = (e)=>typeof e == "object" && e !== null && "type" in e && e.type === "element", qn = (e)=>e.some((t)=>_n(t) && zn.has(t.tagName)), $n = (e)=>{
    let t = [], o = "", n = false;
    for (let r of e){
        let s = St.test(r);
        s !== n && o && (t.push(o), o = ""), o += r, n = s;
    }
    return o && t.push(o), t;
}, Wn = (e)=>{
    let t = [], o = "";
    for (let n of e)St.test(n) ? o += n : (o && (t.push(o), o = ""), t.push(n));
    return o && t.push(o), t;
}, Zn = (e, t, o, n, r, s)=>{
    let a = `--sd-animation:sd-${t};--sd-duration:${r ? 0 : o}ms;--sd-easing:${n}`;
    return s && (a += `;--sd-delay:${s}ms`), {
        type: "element",
        tagName: "span",
        properties: {
            "data-sd-animate": true,
            style: a
        },
        children: [
            {
                type: "text",
                value: e
            }
        ]
    };
}, Xn = (e, t, o, n, r)=>{
    let s = t.at(-1);
    if (!(s && "children" in s)) return;
    if (qn(t)) return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$unist$2d$util$2d$visit$2d$parents$40$6$2e$0$2e$2$2f$node_modules$2f$unist$2d$util$2d$visit$2d$parents$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SKIP"];
    let a = s, l = a.children.indexOf(e);
    if (l === -1) return;
    let i = e.value;
    if (!i.trim()) {
        r.count += i.length;
        return;
    }
    let d = o.sep === "char" ? Wn(i) : $n(i), c = n.prevContentLength, p = d.map((m)=>{
        let u = r.count;
        if (r.count += m.length, Fn.test(m)) return {
            type: "text",
            value: m
        };
        let f = c > 0 && u < c, h = f ? 0 : r.newIndex++ * o.stagger;
        return Zn(m, o.animation, o.duration, o.easing, f, h);
    });
    return a.children.splice(l, 1, ...p), l + p.length;
}, Jn = 0;
function be(e) {
    var s, a, l, i, d;
    let t = {
        animation: (s = e == null ? void 0 : e.animation) != null ? s : "fadeIn",
        duration: (a = e == null ? void 0 : e.duration) != null ? a : 150,
        easing: (l = e == null ? void 0 : e.easing) != null ? l : "ease",
        sep: (i = e == null ? void 0 : e.sep) != null ? i : "word",
        stagger: (d = e == null ? void 0 : e.stagger) != null ? d : 40
    }, o = {
        prevContentLength: 0,
        lastRenderCharCount: 0
    }, n = Jn++, r = ()=>(c)=>{
            let p = {
                count: 0,
                newIndex: 0
            };
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$unist$2d$util$2d$visit$2d$parents$40$6$2e$0$2e$2$2f$node_modules$2f$unist$2d$util$2d$visit$2d$parents$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["visitParents"])(c, "text", (m, u)=>Xn(m, u, t, o, p)), o.lastRenderCharCount = p.count, o.prevContentLength = 0;
        };
    return Object.defineProperty(r, "name", {
        value: `rehypeAnimate$${n}`
    }), {
        name: "animate",
        type: "animate",
        rehypePlugin: r,
        setPrevContentLength (c) {
            o.prevContentLength = c;
        },
        getLastRenderCharCount () {
            let c = o.lastRenderCharCount;
            return o.lastRenderCharCount = 0, c;
        }
    };
}
be();
var et = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(false), tt = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(et);
var he = (...e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tailwind$2d$merge$40$3$2e$5$2e$0$2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsx"])(e)), Gn = (e, t)=>{
    if (!e || !t) return t;
    let o = `${e}:`;
    return t.split(/\s+/).filter(Boolean).map((n)=>n.startsWith(o) ? n : `${e}:${n}`).join(" ");
}, Dt = (e)=>e ? (...t)=>Gn(e, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tailwind$2d$merge$40$3$2e$5$2e$0$2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsx"])(t))) : he, W = (e, t, o)=>{
    let n = typeof t == "string" && o.startsWith("text/csv") ? "\uFEFF" : "", r = typeof t == "string" ? new Blob([
        n + t
    ], {
        type: o
    }) : t, s = URL.createObjectURL(r), a = document.createElement("a");
    a.href = s, a.download = e, document.body.appendChild(a), a.click(), document.body.removeChild(a), URL.revokeObjectURL(s);
};
var Ee = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(he), y = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(Ee);
var tr = he("block", "before:content-[counter(line)]", "before:inline-block", "before:[counter-increment:line]", "before:w-6", "before:mr-4", "before:text-[13px]", "before:text-right", "before:text-muted-foreground/50", "before:font-mono", "before:select-none"), or = (e)=>{
    let t = {};
    for (let o of e.split(";")){
        let n = o.indexOf(":");
        if (n > 0) {
            let r = o.slice(0, n).trim(), s = o.slice(n + 1).trim();
            r && s && (t[r] = s);
        }
    }
    return t;
}, At = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(({ children: e, result: t, language: o, className: n, startLine: r, lineNumbers: s = true, ...a })=>{
    let l = y(), i = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "At.useMemo[i]": ()=>l(tr)
    }["At.useMemo[i]"], [
        l
    ]), d = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "At.useMemo[d]": ()=>{
            let c = {};
            return t.bg && (c["--sdm-bg"] = t.bg), t.fg && (c["--sdm-fg"] = t.fg), t.rootStyle && Object.assign(c, or(t.rootStyle)), c;
        }
    }["At.useMemo[d]"], [
        t.bg,
        t.fg,
        t.rootStyle
    ]);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
        className: l(n, "overflow-x-auto rounded-md border border-border bg-background p-4 text-sm"),
        "data-language": o,
        "data-streamdown": "code-block-body",
        ...a,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("pre", {
            className: l(n, "bg-[var(--sdm-bg,inherit]", "dark:bg-[var(--shiki-dark-bg,var(--sdm-bg,inherit)]"),
            style: d,
            children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("code", {
                className: s ? l("[counter-increment:line_0] [counter-reset:line]") : void 0,
                style: s && r && r > 1 ? {
                    counterReset: `line ${r - 1}`
                } : void 0,
                children: t.tokens.map((c, p)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
                        className: s ? i : void 0,
                        children: c.length === 0 || c.length === 1 && c[0].content === "" ? `
` : c.map((m, u)=>{
                            let f = {}, h = !!m.bgColor;
                            if (m.color && (f["--sdm-c"] = m.color), m.bgColor && (f["--sdm-tbg"] = m.bgColor), m.htmlStyle) for (let [b, g] of Object.entries(m.htmlStyle))b === "color" ? f["--sdm-c"] = g : b === "background-color" ? (f["--sdm-tbg"] = g, h = true) : f[b] = g;
                            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
                                className: l("text-[var(--sdm-c,inherit)]", "dark:text-[var(--shiki-dark,var(--sdm-c,inherit))]", h && "bg-[var(--sdm-tbg)]", h && "dark:bg-[var(--shiki-dark-bg,var(--sdm-tbg))]"),
                                style: f,
                                ...m.htmlAttrs,
                                children: m.content
                            }, u);
                        })
                    }, p))
            })
        })
    });
}, (e, t)=>e.result === t.result && e.language === t.language && e.className === t.className && e.startLine === t.startLine && e.lineNumbers === t.lineNumbers);
var ot = ({ className: e, language: t, style: o, isIncomplete: n, ...r })=>{
    let s = y();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
        className: s("my-4 flex w-full flex-col gap-2 rounded-xl border border-border bg-sidebar p-2", e),
        "data-incomplete": n || void 0,
        "data-language": t,
        "data-streamdown": "code-block",
        style: {
            contentVisibility: "auto",
            containIntrinsicSize: "auto 200px",
            ...o
        },
        ...r
    });
};
var nt = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])({
    code: ""
}), He = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(nt);
var rt = ({ language: e })=>{
    let t = y();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
        className: t("flex h-8 items-center text-muted-foreground text-xs"),
        "data-language": e,
        "data-streamdown": "code-block-header",
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
            className: t("ml-1 font-mono lowercase"),
            children: e
        })
    });
};
var lr = (e)=>{
    let t = e.length;
    for(; t > 0 && e[t - 1] === `
`;)t--;
    return e.slice(0, t);
}, cr = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lazy"])(()=>__turbopack_context__.A("[project]/node_modules/.pnpm/streamdown@2.5.0_react-dom@19.2.4_react@19.2.4__react@19.2.4/node_modules/streamdown/dist/highlighted-body-OFNGDK62.js [app-client] (ecmascript, async loader)").then((e)=>({
            default: e.HighlightedCodeBlockBody
        }))), st = ({ code: e, language: t, className: o, children: n, isIncomplete: r = false, startLine: s, lineNumbers: a, ...l })=>{
    let i = y(), d = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "st.useMemo[d]": ()=>lr(e)
    }["st.useMemo[d]"], [
        e
    ]), c = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "st.useMemo[c]": ()=>({
                bg: "transparent",
                fg: "inherit",
                tokens: d.split(`
`).map({
                    "st.useMemo[c]": (p)=>[
                            {
                                content: p,
                                color: "inherit",
                                bgColor: "transparent",
                                htmlStyle: {},
                                offset: 0
                            }
                        ]
                }["st.useMemo[c]"])
            })
    }["st.useMemo[c]"], [
        d
    ]);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(nt.Provider, {
        value: {
            code: e
        },
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(ot, {
            isIncomplete: r,
            language: t,
            children: [
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(rt, {
                    language: t
                }),
                n ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                    className: i("pointer-events-none sticky top-2 z-10 -mt-10 flex h-8 items-center justify-end"),
                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                        className: i("pointer-events-auto flex shrink-0 items-center gap-2 rounded-md border border-sidebar bg-sidebar/80 px-1.5 py-1 supports-[backdrop-filter]:bg-sidebar/70 supports-[backdrop-filter]:backdrop-blur"),
                        "data-streamdown": "code-block-actions",
                        children: n
                    })
                }) : null,
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Suspense"], {
                    fallback: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(At, {
                        className: o,
                        language: t,
                        lineNumbers: a,
                        result: c,
                        startLine: s,
                        ...l
                    }),
                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(cr, {
                        className: o,
                        code: d,
                        language: t,
                        lineNumbers: a,
                        raw: c,
                        startLine: s,
                        ...l
                    })
                })
            ]
        })
    });
};
var jt = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        color: "currentColor",
        height: 16,
        strokeLinejoin: "round",
        viewBox: "0 0 16 16",
        width: 16,
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            clipRule: "evenodd",
            d: "M15.5607 3.99999L15.0303 4.53032L6.23744 13.3232C5.55403 14.0066 4.44599 14.0066 3.76257 13.3232L4.2929 12.7929L3.76257 13.3232L0.969676 10.5303L0.439346 9.99999L1.50001 8.93933L2.03034 9.46966L4.82323 12.2626C4.92086 12.3602 5.07915 12.3602 5.17678 12.2626L13.9697 3.46966L14.5 2.93933L15.5607 3.99999Z",
            fill: "currentColor",
            fillRule: "evenodd"
        })
    }), Ft = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        color: "currentColor",
        height: 16,
        strokeLinejoin: "round",
        viewBox: "0 0 16 16",
        width: 16,
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            clipRule: "evenodd",
            d: "M2.75 0.5C1.7835 0.5 1 1.2835 1 2.25V9.75C1 10.7165 1.7835 11.5 2.75 11.5H3.75H4.5V10H3.75H2.75C2.61193 10 2.5 9.88807 2.5 9.75V2.25C2.5 2.11193 2.61193 2 2.75 2H8.25C8.38807 2 8.5 2.11193 8.5 2.25V3H10V2.25C10 1.2835 9.2165 0.5 8.25 0.5H2.75ZM7.75 4.5C6.7835 4.5 6 5.2835 6 6.25V13.75C6 14.7165 6.7835 15.5 7.75 15.5H13.25C14.2165 15.5 15 14.7165 15 13.75V6.25C15 5.2835 14.2165 4.5 13.25 4.5H7.75ZM7.5 6.25C7.5 6.11193 7.61193 6 7.75 6H13.25C13.3881 6 13.5 6.11193 13.5 6.25V13.75C13.5 13.8881 13.3881 14 13.25 14H7.75C7.61193 14 7.5 13.8881 7.5 13.75V6.25Z",
            fill: "currentColor",
            fillRule: "evenodd"
        })
    }), zt = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        color: "currentColor",
        height: 16,
        strokeLinejoin: "round",
        viewBox: "0 0 16 16",
        width: 16,
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            clipRule: "evenodd",
            d: "M8.75 1V1.75V8.68934L10.7197 6.71967L11.25 6.18934L12.3107 7.25L11.7803 7.78033L8.70711 10.8536C8.31658 11.2441 7.68342 11.2441 7.29289 10.8536L4.21967 7.78033L3.68934 7.25L4.75 6.18934L5.28033 6.71967L7.25 8.68934V1.75V1H8.75ZM13.5 9.25V13.5H2.5V9.25V8.5H1V9.25V14C1 14.5523 1.44771 15 2 15H14C14.5523 15 15 14.5523 15 14V9.25V8.5H13.5V9.25Z",
            fill: "currentColor",
            fillRule: "evenodd"
        })
    }), _t = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
        color: "currentColor",
        height: 16,
        strokeLinejoin: "round",
        viewBox: "0 0 16 16",
        width: 16,
        ...e,
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M8 0V4",
                stroke: "currentColor",
                strokeWidth: "1.5"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M8 16V12",
                opacity: "0.5",
                stroke: "currentColor",
                strokeWidth: "1.5"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M3.29773 1.52783L5.64887 4.7639",
                opacity: "0.9",
                stroke: "currentColor",
                strokeWidth: "1.5"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M12.7023 1.52783L10.3511 4.7639",
                opacity: "0.1",
                stroke: "currentColor",
                strokeWidth: "1.5"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M12.7023 14.472L10.3511 11.236",
                opacity: "0.4",
                stroke: "currentColor",
                strokeWidth: "1.5"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M3.29773 14.472L5.64887 11.236",
                opacity: "0.6",
                stroke: "currentColor",
                strokeWidth: "1.5"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M15.6085 5.52783L11.8043 6.7639",
                opacity: "0.2",
                stroke: "currentColor",
                strokeWidth: "1.5"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M0.391602 10.472L4.19583 9.23598",
                opacity: "0.7",
                stroke: "currentColor",
                strokeWidth: "1.5"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M15.6085 10.4722L11.8043 9.2361",
                opacity: "0.3",
                stroke: "currentColor",
                strokeWidth: "1.5"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M0.391602 5.52783L4.19583 6.7639",
                opacity: "0.8",
                stroke: "currentColor",
                strokeWidth: "1.5"
            })
        ]
    }), qt = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        color: "currentColor",
        height: 16,
        strokeLinejoin: "round",
        viewBox: "0 0 16 16",
        width: 16,
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            clipRule: "evenodd",
            d: "M1 5.25V6H2.5V5.25V2.5H5.25H6V1H5.25H2C1.44772 1 1 1.44772 1 2V5.25ZM5.25 14.9994H6V13.4994H5.25H2.5V10.7494V9.99939H1V10.7494V13.9994C1 14.5517 1.44772 14.9994 2 14.9994H5.25ZM15 10V10.75V14C15 14.5523 14.5523 15 14 15H10.75H10V13.5H10.75H13.5V10.75V10H15ZM10.75 1H10V2.5H10.75H13.5V5.25V6H15V5.25V2C15 1.44772 14.5523 1 14 1H10.75Z",
            fill: "currentColor",
            fillRule: "evenodd"
        })
    }), $t = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        color: "currentColor",
        height: 16,
        strokeLinejoin: "round",
        viewBox: "0 0 16 16",
        width: 16,
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            clipRule: "evenodd",
            d: "M13.5 8C13.5 4.96643 11.0257 2.5 7.96452 2.5C5.42843 2.5 3.29365 4.19393 2.63724 6.5H5.25H6V8H5.25H0.75C0.335787 8 0 7.66421 0 7.25V2.75V2H1.5V2.75V5.23347C2.57851 2.74164 5.06835 1 7.96452 1C11.8461 1 15 4.13001 15 8C15 11.87 11.8461 15 7.96452 15C5.62368 15 3.54872 13.8617 2.27046 12.1122L1.828 11.5066L3.03915 10.6217L3.48161 11.2273C4.48831 12.6051 6.12055 13.5 7.96452 13.5C11.0257 13.5 13.5 11.0336 13.5 8Z",
            fill: "currentColor",
            fillRule: "evenodd"
        })
    }), Wt = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        color: "currentColor",
        height: 16,
        strokeLinejoin: "round",
        viewBox: "0 0 16 16",
        width: 16,
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            clipRule: "evenodd",
            d: "M12.4697 13.5303L13 14.0607L14.0607 13L13.5303 12.4697L9.06065 7.99999L13.5303 3.53032L14.0607 2.99999L13 1.93933L12.4697 2.46966L7.99999 6.93933L3.53032 2.46966L2.99999 1.93933L1.93933 2.99999L2.46966 3.53032L6.93933 7.99999L2.46966 12.4697L1.93933 13L2.99999 14.0607L3.53032 13.5303L7.99999 9.06065L12.4697 13.5303Z",
            fill: "currentColor",
            fillRule: "evenodd"
        })
    }), Zt = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        color: "currentColor",
        height: 16,
        strokeLinejoin: "round",
        viewBox: "0 0 16 16",
        width: 16,
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            clipRule: "evenodd",
            d: "M13.5 10.25V13.25C13.5 13.3881 13.3881 13.5 13.25 13.5H2.75C2.61193 13.5 2.5 13.3881 2.5 13.25L2.5 2.75C2.5 2.61193 2.61193 2.5 2.75 2.5H5.75H6.5V1H5.75H2.75C1.7835 1 1 1.7835 1 2.75V13.25C1 14.2165 1.7835 15 2.75 15H13.25C14.2165 15 15 14.2165 15 13.25V10.25V9.5H13.5V10.25ZM9 1H9.75H14.2495C14.6637 1 14.9995 1.33579 14.9995 1.75V6.25V7H13.4995V6.25V3.56066L8.53033 8.52978L8 9.06011L6.93934 7.99945L7.46967 7.46912L12.4388 2.5H9.75H9V1Z",
            fill: "currentColor",
            fillRule: "evenodd"
        })
    }), Xt = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        color: "currentColor",
        height: 16,
        strokeLinejoin: "round",
        viewBox: "0 0 16 16",
        width: 16,
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            clipRule: "evenodd",
            d: "M1.5 6.5C1.5 3.73858 3.73858 1.5 6.5 1.5C9.26142 1.5 11.5 3.73858 11.5 6.5C11.5 9.26142 9.26142 11.5 6.5 11.5C3.73858 11.5 1.5 9.26142 1.5 6.5ZM6.5 0C2.91015 0 0 2.91015 0 6.5C0 10.0899 2.91015 13 6.5 13C8.02469 13 9.42677 12.475 10.5353 11.596L13.9697 15.0303L14.5 15.5607L15.5607 14.5L15.0303 13.9697L11.596 10.5353C12.475 9.42677 13 8.02469 13 6.5C13 2.91015 10.0899 0 6.5 0ZM4.125 5.875H4.75H5.875V4.75V4.125H7.125V4.75V5.875H8.25H8.875V7.125H8.25H7.125V8.25V8.875H5.875V8.25V7.125H4.75H4.125V5.875Z",
            fill: "currentColor",
            fillRule: "evenodd"
        })
    }), Jt = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        color: "currentColor",
        height: 16,
        strokeLinejoin: "round",
        viewBox: "0 0 16 16",
        width: 16,
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            clipRule: "evenodd",
            d: "M1.5 6.5C1.5 3.73858 3.73858 1.5 6.5 1.5C9.26142 1.5 11.5 3.73858 11.5 6.5C11.5 9.26142 9.26142 11.5 6.5 11.5C3.73858 11.5 1.5 9.26142 1.5 6.5ZM6.5 0C2.91015 0 0 2.91015 0 6.5C0 10.0899 2.91015 13 6.5 13C8.02469 13 9.42677 12.475 10.5353 11.596L13.9697 15.0303L14.5 15.5607L15.5607 14.5L15.0303 13.9697L11.596 10.5353C12.475 9.42677 13 8.02469 13 6.5C13 2.91015 10.0899 0 6.5 0ZM4.125 5.875H4.75H8.25H8.875V7.125H8.25H4.75H4.125V5.875Z",
            fill: "currentColor",
            fillRule: "evenodd"
        })
    });
var we = {
    CheckIcon: jt,
    CopyIcon: Ft,
    DownloadIcon: zt,
    ExternalLinkIcon: Zt,
    Loader2Icon: _t,
    Maximize2Icon: qt,
    RotateCcwIcon: $t,
    XIcon: Wt,
    ZoomInIcon: Xt,
    ZoomOutIcon: Jt
}, Ut = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(we), fr = (e, t)=>{
    if (e === t) return true;
    if (!(e && t)) return e === t;
    let o = Object.keys(e), n = Object.keys(t);
    return o.length !== n.length ? false : o.every((r)=>e[r] === t[r]);
}, at = ({ icons: e, children: t })=>{
    let o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(e), n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(e ? {
        ...we,
        ...e
    } : we);
    fr(o.current, e) || (o.current = e, n.current = e ? {
        ...we,
        ...e
    } : we);
    let r = n.current;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Ut.Provider, {
        value: r,
        children: t
    });
}, L = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(Ut);
var De = {
    copyCode: "Copy Code",
    downloadFile: "Download file",
    downloadDiagram: "Download diagram",
    downloadDiagramAsSvg: "Download diagram as SVG",
    downloadDiagramAsPng: "Download diagram as PNG",
    downloadDiagramAsMmd: "Download diagram as MMD",
    viewFullscreen: "View fullscreen",
    exitFullscreen: "Exit fullscreen",
    mermaidFormatSvg: "SVG",
    mermaidFormatPng: "PNG",
    mermaidFormatMmd: "MMD",
    copyTable: "Copy table",
    copyTableAsMarkdown: "Copy table as Markdown",
    copyTableAsCsv: "Copy table as CSV",
    copyTableAsTsv: "Copy table as TSV",
    downloadTable: "Download table",
    downloadTableAsCsv: "Download table as CSV",
    downloadTableAsMarkdown: "Download table as Markdown",
    tableFormatMarkdown: "Markdown",
    tableFormatCsv: "CSV",
    tableFormatTsv: "TSV",
    imageNotAvailable: "Image not available",
    downloadImage: "Download image",
    openExternalLink: "Open external link?",
    externalLinkWarning: "You're about to visit an external website.",
    close: "Close",
    copyLink: "Copy link",
    copied: "Copied",
    openLink: "Open link"
}, Be = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(De), D = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(Be);
var Ae = ({ onCopy: e, onError: t, timeout: o = 2e3, children: n, className: r, code: s, ...a })=>{
    let l = y(), [i, d] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false), c = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0), { code: p } = He(), { isAnimating: m } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(R), u = D(), f = s != null ? s : p, h = async ()=>{
        var T;
        if (typeof window == "undefined" || !((T = navigator == null ? void 0 : navigator.clipboard) != null && T.writeText)) {
            t == null || t(new Error("Clipboard API not available"));
            return;
        }
        try {
            i || (await navigator.clipboard.writeText(f), d(!0), e == null || e(), c.current = window.setTimeout(()=>d(!1), o));
        } catch (v) {
            t == null || t(v);
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Ae.useEffect": ()=>({
                "Ae.useEffect": ()=>{
                    window.clearTimeout(c.current);
                }
            })["Ae.useEffect"]
    }["Ae.useEffect"], []);
    let b = L(), g = i ? b.CheckIcon : b.CopyIcon;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
        className: l("cursor-pointer p-1 text-muted-foreground transition-all hover:text-foreground disabled:cursor-not-allowed disabled:opacity-50", r),
        "data-streamdown": "code-block-copy-button",
        disabled: m,
        onClick: h,
        title: u.copyCode,
        type: "button",
        ...a,
        children: n != null ? n : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(g, {
            size: 14
        })
    });
};
var Yt = {
    "1c": "1c",
    "1c-query": "1cq",
    abap: "abap",
    "actionscript-3": "as",
    ada: "ada",
    adoc: "adoc",
    "angular-html": "html",
    "angular-ts": "ts",
    apache: "conf",
    apex: "cls",
    apl: "apl",
    applescript: "applescript",
    ara: "ara",
    asciidoc: "adoc",
    asm: "asm",
    astro: "astro",
    awk: "awk",
    ballerina: "bal",
    bash: "sh",
    bat: "bat",
    batch: "bat",
    be: "be",
    beancount: "beancount",
    berry: "berry",
    bibtex: "bib",
    bicep: "bicep",
    blade: "blade.php",
    bsl: "bsl",
    c: "c",
    "c#": "cs",
    "c++": "cpp",
    cadence: "cdc",
    cairo: "cairo",
    cdc: "cdc",
    clarity: "clar",
    clj: "clj",
    clojure: "clj",
    "closure-templates": "soy",
    cmake: "cmake",
    cmd: "cmd",
    cobol: "cob",
    codeowners: "CODEOWNERS",
    codeql: "ql",
    coffee: "coffee",
    coffeescript: "coffee",
    "common-lisp": "lisp",
    console: "sh",
    coq: "v",
    cpp: "cpp",
    cql: "cql",
    crystal: "cr",
    cs: "cs",
    csharp: "cs",
    css: "css",
    csv: "csv",
    cue: "cue",
    cypher: "cql",
    d: "d",
    dart: "dart",
    dax: "dax",
    desktop: "desktop",
    diff: "diff",
    docker: "dockerfile",
    dockerfile: "dockerfile",
    dotenv: "env",
    "dream-maker": "dm",
    edge: "edge",
    elisp: "el",
    elixir: "ex",
    elm: "elm",
    "emacs-lisp": "el",
    erb: "erb",
    erl: "erl",
    erlang: "erl",
    f: "f",
    "f#": "fs",
    f03: "f03",
    f08: "f08",
    f18: "f18",
    f77: "f77",
    f90: "f90",
    f95: "f95",
    fennel: "fnl",
    fish: "fish",
    fluent: "ftl",
    for: "for",
    "fortran-fixed-form": "f",
    "fortran-free-form": "f90",
    fs: "fs",
    fsharp: "fs",
    fsl: "fsl",
    ftl: "ftl",
    gdresource: "tres",
    gdscript: "gd",
    gdshader: "gdshader",
    genie: "gs",
    gherkin: "feature",
    "git-commit": "gitcommit",
    "git-rebase": "gitrebase",
    gjs: "js",
    gleam: "gleam",
    "glimmer-js": "js",
    "glimmer-ts": "ts",
    glsl: "glsl",
    gnuplot: "plt",
    go: "go",
    gql: "gql",
    graphql: "graphql",
    groovy: "groovy",
    gts: "gts",
    hack: "hack",
    haml: "haml",
    handlebars: "hbs",
    haskell: "hs",
    haxe: "hx",
    hbs: "hbs",
    hcl: "hcl",
    hjson: "hjson",
    hlsl: "hlsl",
    hs: "hs",
    html: "html",
    "html-derivative": "html",
    http: "http",
    hxml: "hxml",
    hy: "hy",
    imba: "imba",
    ini: "ini",
    jade: "jade",
    java: "java",
    javascript: "js",
    jinja: "jinja",
    jison: "jison",
    jl: "jl",
    js: "js",
    json: "json",
    json5: "json5",
    jsonc: "jsonc",
    jsonl: "jsonl",
    jsonnet: "jsonnet",
    jssm: "jssm",
    jsx: "jsx",
    julia: "jl",
    kotlin: "kt",
    kql: "kql",
    kt: "kt",
    kts: "kts",
    kusto: "kql",
    latex: "tex",
    lean: "lean",
    lean4: "lean",
    less: "less",
    liquid: "liquid",
    lisp: "lisp",
    lit: "lit",
    llvm: "ll",
    log: "log",
    logo: "logo",
    lua: "lua",
    luau: "luau",
    make: "mak",
    makefile: "mak",
    markdown: "md",
    marko: "marko",
    matlab: "m",
    md: "md",
    mdc: "mdc",
    mdx: "mdx",
    mediawiki: "wiki",
    mermaid: "mmd",
    mips: "s",
    mipsasm: "s",
    mmd: "mmd",
    mojo: "mojo",
    move: "move",
    nar: "nar",
    narrat: "narrat",
    nextflow: "nf",
    nf: "nf",
    nginx: "conf",
    nim: "nim",
    nix: "nix",
    nu: "nu",
    nushell: "nu",
    objc: "m",
    "objective-c": "m",
    "objective-cpp": "mm",
    ocaml: "ml",
    pascal: "pas",
    perl: "pl",
    perl6: "p6",
    php: "php",
    plsql: "pls",
    po: "po",
    polar: "polar",
    postcss: "pcss",
    pot: "pot",
    potx: "potx",
    powerquery: "pq",
    powershell: "ps1",
    prisma: "prisma",
    prolog: "pl",
    properties: "properties",
    proto: "proto",
    protobuf: "proto",
    ps: "ps",
    ps1: "ps1",
    pug: "pug",
    puppet: "pp",
    purescript: "purs",
    py: "py",
    python: "py",
    ql: "ql",
    qml: "qml",
    qmldir: "qmldir",
    qss: "qss",
    r: "r",
    racket: "rkt",
    raku: "raku",
    razor: "cshtml",
    rb: "rb",
    reg: "reg",
    regex: "regex",
    regexp: "regexp",
    rel: "rel",
    riscv: "s",
    rs: "rs",
    rst: "rst",
    ruby: "rb",
    rust: "rs",
    sas: "sas",
    sass: "sass",
    scala: "scala",
    scheme: "scm",
    scss: "scss",
    sdbl: "sdbl",
    sh: "sh",
    shader: "shader",
    shaderlab: "shader",
    shell: "sh",
    shellscript: "sh",
    shellsession: "sh",
    smalltalk: "st",
    solidity: "sol",
    soy: "soy",
    sparql: "rq",
    spl: "spl",
    splunk: "spl",
    sql: "sql",
    "ssh-config": "config",
    stata: "do",
    styl: "styl",
    stylus: "styl",
    svelte: "svelte",
    swift: "swift",
    "system-verilog": "sv",
    systemd: "service",
    talon: "talon",
    talonscript: "talon",
    tasl: "tasl",
    tcl: "tcl",
    templ: "templ",
    terraform: "tf",
    tex: "tex",
    tf: "tf",
    tfvars: "tfvars",
    toml: "toml",
    ts: "ts",
    "ts-tags": "ts",
    tsp: "tsp",
    tsv: "tsv",
    tsx: "tsx",
    turtle: "ttl",
    twig: "twig",
    typ: "typ",
    typescript: "ts",
    typespec: "tsp",
    typst: "typ",
    v: "v",
    vala: "vala",
    vb: "vb",
    verilog: "v",
    vhdl: "vhdl",
    vim: "vim",
    viml: "vim",
    vimscript: "vim",
    vue: "vue",
    "vue-html": "html",
    "vue-vine": "vine",
    vy: "vy",
    vyper: "vy",
    wasm: "wasm",
    wenyan: "wy",
    wgsl: "wgsl",
    wiki: "wiki",
    wikitext: "wiki",
    wit: "wit",
    wl: "wl",
    wolfram: "wl",
    xml: "xml",
    xsl: "xsl",
    yaml: "yaml",
    yml: "yml",
    zenscript: "zs",
    zig: "zig",
    zsh: "zsh",
    文言: "wy"
}, it = ({ onDownload: e, onError: t, language: o, children: n, className: r, code: s, ...a })=>{
    let l = y(), { code: i } = He(), { isAnimating: d } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(R), c = D(), p = L(), m = s != null ? s : i, f = `file.${o && o in Yt ? Yt[o] : "txt"}`, h = "text/plain", b = ()=>{
        try {
            W(f, m, h), e == null || e();
        } catch (g) {
            t == null || t(g);
        }
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
        className: l("cursor-pointer p-1 text-muted-foreground transition-all hover:text-foreground disabled:cursor-not-allowed disabled:opacity-50", r),
        "data-streamdown": "code-block-download-button",
        disabled: d,
        onClick: b,
        title: c.downloadFile,
        type: "button",
        ...a,
        children: n != null ? n : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(p.DownloadIcon, {
            size: 14
        })
    });
};
var Oe = ()=>{
    let { Loader2Icon: e } = L(), t = y();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
        className: t("w-full divide-y divide-border overflow-hidden rounded-xl border border-border"),
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                className: t("h-[46px] w-full bg-muted/80")
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                className: t("flex w-full items-center justify-center p-4"),
                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(e, {
                    className: t("size-4 animate-spin")
                })
            })
        ]
    });
};
var Mr = /\.[^/.]+$/, oo = ({ node: e, className: t, src: o, alt: n, onLoad: r, onError: s, ...a })=>{
    let { DownloadIcon: l } = L(), i = y(), d = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), [c, p] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false), [m, u] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false), f = D(), h = a.width != null || a.height != null, b = (c || h) && !m, g = m && !h;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "oo.useEffect": ()=>{
            let P = d.current;
            if (P != null && P.complete) {
                let M = P.naturalWidth > 0;
                p(M), u(!M);
            }
        }
    }["oo.useEffect"], []);
    let T = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "oo.useCallback[T]": (P)=>{
            p(true), u(false), r == null || r(P);
        }
    }["oo.useCallback[T]"], [
        r
    ]), v = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "oo.useCallback[v]": (P)=>{
            p(false), u(true), s == null || s(P);
        }
    }["oo.useCallback[v]"], [
        s
    ]), w = async ()=>{
        if (o) try {
            let M = await (await fetch(o)).blob(), S = new URL(o, window.location.origin).pathname.split("/").pop() || "", F = S.split(".").pop(), j = S.includes(".") && F !== void 0 && F.length <= 4, z = "";
            if (j) z = S;
            else {
                let B = M.type, _ = "png";
                B.includes("jpeg") || B.includes("jpg") ? _ = "jpg" : B.includes("png") ? _ = "png" : B.includes("svg") ? _ = "svg" : B.includes("gif") ? _ = "gif" : B.includes("webp") && (_ = "webp"), z = `${(n || S || "image").replace(Mr, "")}.${_}`;
            }
            W(z, M, M.type);
        } catch (P) {
            window.open(o, "_blank");
        }
    };
    return o ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
        className: i("group relative my-4 inline-block"),
        "data-streamdown": "image-wrapper",
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("img", {
                alt: n,
                className: i("max-w-full rounded-lg", g && "hidden", t),
                "data-streamdown": "image",
                onError: v,
                onLoad: T,
                ref: d,
                src: o,
                ...a
            }),
            g && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
                className: i("text-muted-foreground text-xs italic"),
                "data-streamdown": "image-fallback",
                children: f.imageNotAvailable
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                className: i("pointer-events-none absolute inset-0 hidden rounded-lg bg-black/10 group-hover:block")
            }),
            b && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                className: i("absolute right-2 bottom-2 flex h-8 w-8 cursor-pointer items-center justify-center rounded-md border border-border bg-background/90 shadow-sm backdrop-blur-sm transition-all duration-200 hover:bg-background", "opacity-0 group-hover:opacity-100"),
                onClick: w,
                title: f.downloadImage,
                type: "button",
                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(l, {
                    size: 14
                })
            })
        ]
    }) : null;
};
var ke = 0, le = ()=>{
    ke += 1, ke === 1 && (document.body.style.overflow = "hidden");
}, ce = ()=>{
    ke = Math.max(0, ke - 1), ke === 0 && (document.body.style.overflow = "");
};
var so = ({ url: e, isOpen: t, onClose: o, onConfirm: n })=>{
    let { CheckIcon: r, CopyIcon: s, ExternalLinkIcon: a, XIcon: l } = L(), i = y(), [d, c] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false), p = D(), m = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "so.useCallback[m]": async ()=>{
            try {
                await navigator.clipboard.writeText(e), c(!0), setTimeout({
                    "so.useCallback[m]": ()=>c(!1)
                }["so.useCallback[m]"], 2e3);
            } catch (f) {}
        }
    }["so.useCallback[m]"], [
        e
    ]), u = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "so.useCallback[u]": ()=>{
            n(), o();
        }
    }["so.useCallback[u]"], [
        n,
        o
    ]);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "so.useEffect": ()=>{
            if (t) {
                le();
                let f = {
                    "so.useEffect.f": (h)=>{
                        h.key === "Escape" && o();
                    }
                }["so.useEffect.f"];
                return document.addEventListener("keydown", f), ({
                    "so.useEffect": ()=>{
                        document.removeEventListener("keydown", f), ce();
                    }
                })["so.useEffect"];
            }
        }
    }["so.useEffect"], [
        t,
        o
    ]), t ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
        className: i("fixed inset-0 z-50 flex items-center justify-center bg-background/50 backdrop-blur-sm"),
        "data-streamdown": "link-safety-modal",
        onClick: o,
        onKeyDown: (f)=>{
            f.key === "Escape" && o();
        },
        role: "button",
        tabIndex: 0,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
            className: i("relative mx-4 flex w-full max-w-md flex-col gap-4 rounded-xl border bg-background p-6 shadow-lg"),
            onClick: (f)=>f.stopPropagation(),
            onKeyDown: (f)=>f.stopPropagation(),
            role: "presentation",
            children: [
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                    className: i("absolute top-4 right-4 rounded-md p-1 text-muted-foreground transition-all hover:bg-muted hover:text-foreground"),
                    onClick: o,
                    title: p.close,
                    type: "button",
                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(l, {
                        size: 16
                    })
                }),
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                    className: i("flex flex-col gap-2"),
                    children: [
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                            className: i("flex items-center gap-2 font-semibold text-lg"),
                            children: [
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(a, {
                                    size: 20
                                }),
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
                                    children: p.openExternalLink
                                })
                            ]
                        }),
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("p", {
                            className: i("text-muted-foreground text-sm"),
                            children: p.externalLinkWarning
                        })
                    ]
                }),
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                    className: i("break-all rounded-md bg-muted p-3 font-mono text-sm", e.length > 100 && "max-h-32 overflow-y-auto"),
                    children: e
                }),
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                    className: i("flex gap-2"),
                    children: [
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                            className: i("flex flex-1 items-center justify-center gap-2 rounded-md border bg-background px-4 py-2 font-medium text-sm transition-all hover:bg-muted"),
                            onClick: m,
                            type: "button",
                            children: d ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                children: [
                                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(r, {
                                        size: 14
                                    }),
                                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
                                        children: p.copied
                                    })
                                ]
                            }) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                children: [
                                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(s, {
                                        size: 14
                                    }),
                                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
                                        children: p.copyLink
                                    })
                                ]
                            })
                        }),
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("button", {
                            className: i("flex flex-1 items-center justify-center gap-2 rounded-md bg-primary px-4 py-2 font-medium text-primary-foreground text-sm transition-all hover:bg-primary/90"),
                            onClick: u,
                            type: "button",
                            children: [
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(a, {
                                    size: 14
                                }),
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
                                    children: p.openLink
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    }) : null;
};
var Ve = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null), ct = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(Ve), Li = ()=>{
    var t;
    let e = ct();
    return (t = e == null ? void 0 : e.code) != null ? t : null;
}, de = ()=>{
    var t;
    let e = ct();
    return (t = e == null ? void 0 : e.mermaid) != null ? t : null;
};
var ao = (e)=>{
    var o;
    let t = ct();
    return t != null && t.renderers && e && (o = t.renderers.find((n)=>Array.isArray(n.language) ? n.language.includes(e) : n.language === e)) != null ? o : null;
};
var io = (e, t)=>{
    var n;
    let o = (n = void 0) != null ? n : 5;
    return new Promise((r, s)=>{
        let a = "data:image/svg+xml;base64," + btoa(unescape(encodeURIComponent(e))), l = new Image;
        l.crossOrigin = "anonymous", l.onload = ()=>{
            let i = document.createElement("canvas"), d = l.width * o, c = l.height * o;
            i.width = d, i.height = c;
            let p = i.getContext("2d");
            if (!p) {
                s(new Error("Failed to create 2D canvas context for PNG export"));
                return;
            }
            p.drawImage(l, 0, 0, d, c), i.toBlob((m)=>{
                if (!m) {
                    s(new Error("Failed to create PNG blob"));
                    return;
                }
                r(m);
            }, "image/png");
        }, l.onerror = ()=>s(new Error("Failed to load SVG image")), l.src = a;
    });
};
var co = ({ chart: e, children: t, className: o, onDownload: n, config: r, onError: s })=>{
    let a = y(), [l, i] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false), d = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), { isAnimating: c } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(R), p = L(), m = de(), u = D(), f = async (h)=>{
        try {
            if (h === "mmd") {
                W("diagram.mmd", e, "text/plain"), i(!1), n == null || n(h);
                return;
            }
            if (!m) {
                s == null || s(new Error("Mermaid plugin not available"));
                return;
            }
            let b = m.getMermaid(r), g = e.split("").reduce((w, P)=>(w << 5) - w + P.charCodeAt(0) | 0, 0), T = `mermaid-${Math.abs(g)}-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`, { svg: v } = await b.render(T, e);
            if (!v) {
                s == null || s(new Error("SVG not found. Please wait for the diagram to render."));
                return;
            }
            if (h === "svg") {
                W("diagram.svg", v, "image/svg+xml"), i(!1), n == null || n(h);
                return;
            }
            if (h === "png") {
                let w = await io(v);
                W("diagram.png", w, "image/png"), n == null || n(h), i(!1);
                return;
            }
        } catch (b) {
            s == null || s(b);
        }
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "co.useEffect": ()=>{
            let h = {
                "co.useEffect.h": (b)=>{
                    let g = b.composedPath();
                    d.current && !g.includes(d.current) && i(false);
                }
            }["co.useEffect.h"];
            return document.addEventListener("mousedown", h), ({
                "co.useEffect": ()=>{
                    document.removeEventListener("mousedown", h);
                }
            })["co.useEffect"];
        }
    }["co.useEffect"], []), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
        className: a("relative"),
        ref: d,
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                className: a("cursor-pointer p-1 text-muted-foreground transition-all hover:text-foreground disabled:cursor-not-allowed disabled:opacity-50", o),
                disabled: c,
                onClick: ()=>i(!l),
                title: u.downloadDiagram,
                type: "button",
                children: t != null ? t : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(p.DownloadIcon, {
                    size: 14
                })
            }),
            l ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                className: a("absolute top-full right-0 z-10 mt-1 min-w-[120px] overflow-hidden rounded-md border border-border bg-background shadow-lg"),
                children: [
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                        className: a("w-full px-3 py-2 text-left text-sm transition-colors hover:bg-muted/40"),
                        onClick: ()=>f("svg"),
                        title: u.downloadDiagramAsSvg,
                        type: "button",
                        children: u.mermaidFormatSvg
                    }),
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                        className: a("w-full px-3 py-2 text-left text-sm transition-colors hover:bg-muted/40"),
                        onClick: ()=>f("png"),
                        title: u.downloadDiagramAsPng,
                        type: "button",
                        children: u.mermaidFormatPng
                    }),
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                        className: a("w-full px-3 py-2 text-left text-sm transition-colors hover:bg-muted/40"),
                        onClick: ()=>f("mmd"),
                        title: u.downloadDiagramAsMmd,
                        type: "button",
                        children: u.mermaidFormatMmd
                    })
                ]
            }) : null
        ]
    });
};
var fo = ({ chart: e, config: t, onFullscreen: o, onExit: n, className: r, ...s })=>{
    let { Maximize2Icon: a, XIcon: l } = L(), i = y(), [d, c] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false), { isAnimating: p, controls: m } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(R), u = D(), f = (()=>{
        if (typeof m == "boolean") return m;
        let b = m.mermaid;
        return b === false ? false : b === true || b === void 0 ? true : b.panZoom !== false;
    })(), h = ()=>{
        c(!d);
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "fo.useEffect": ()=>{
            if (d) {
                le();
                let b = {
                    "fo.useEffect.b": (g)=>{
                        g.key === "Escape" && c(false);
                    }
                }["fo.useEffect.b"];
                return document.addEventListener("keydown", b), ({
                    "fo.useEffect": ()=>{
                        document.removeEventListener("keydown", b), ce();
                    }
                })["fo.useEffect"];
            }
        }
    }["fo.useEffect"], [
        d
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "fo.useEffect": ()=>{
            d ? o == null || o() : n && n();
        }
    }["fo.useEffect"], [
        d,
        o,
        n
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                className: i("cursor-pointer p-1 text-muted-foreground transition-all hover:text-foreground disabled:cursor-not-allowed disabled:opacity-50", r),
                disabled: p,
                onClick: h,
                title: u.viewFullscreen,
                type: "button",
                ...s,
                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(a, {
                    size: 14
                })
            }),
            d ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPortal"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                className: i("fixed inset-0 z-50 flex items-center justify-center bg-background/95 backdrop-blur-sm"),
                onClick: h,
                onKeyDown: (b)=>{
                    b.key === "Escape" && h();
                },
                role: "button",
                tabIndex: 0,
                children: [
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                        className: i("absolute top-4 right-4 z-10 rounded-md p-2 text-muted-foreground transition-all hover:bg-muted hover:text-foreground"),
                        onClick: h,
                        title: u.exitFullscreen,
                        type: "button",
                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(l, {
                            size: 20
                        })
                    }),
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                        className: i("flex size-full items-center justify-center p-4"),
                        onClick: (b)=>b.stopPropagation(),
                        onKeyDown: (b)=>b.stopPropagation(),
                        role: "presentation",
                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(po, {
                            chart: e,
                            className: i("size-full [&_svg]:h-auto [&_svg]:w-auto"),
                            config: t,
                            fullscreen: true,
                            showControls: f
                        })
                    })
                ]
            }), document.body) : null
        ]
    });
};
var ue = (e)=>{
    var s, a;
    let t = [], o = [], n = e.querySelectorAll("thead th");
    for (let l of n)t.push(((s = l.textContent) == null ? void 0 : s.trim()) || "");
    let r = e.querySelectorAll("tbody tr");
    for (let l of r){
        let i = [], d = l.querySelectorAll("td");
        for (let c of d)i.push(((a = c.textContent) == null ? void 0 : a.trim()) || "");
        o.push(i);
    }
    return {
        headers: t,
        rows: o
    };
}, ne = (e)=>{
    let { headers: t, rows: o } = e, n = (l)=>{
        let i = false, d = false;
        for (let c of l){
            if (c === '"') {
                i = true, d = true;
                break;
            }
            (c === "," || c === `
`) && (i = true);
        }
        return i ? d ? `"${l.replace(/"/g, '""')}"` : `"${l}"` : l;
    }, r = t.length > 0 ? o.length + 1 : o.length, s = new Array(r), a = 0;
    t.length > 0 && (s[a] = t.map(n).join(","), a += 1);
    for (let l of o)s[a] = l.map(n).join(","), a += 1;
    return s.join(`
`);
}, dt = (e)=>{
    let { headers: t, rows: o } = e, n = (l)=>{
        let i = false;
        for (let c of l)if (c === "	" || c === `
` || c === "\r") {
            i = true;
            break;
        }
        if (!i) return l;
        let d = [];
        for (let c of l)c === "	" ? d.push("\\t") : c === `
` ? d.push("\\n") : c === "\r" ? d.push("\\r") : d.push(c);
        return d.join("");
    }, r = t.length > 0 ? o.length + 1 : o.length, s = new Array(r), a = 0;
    t.length > 0 && (s[a] = t.map(n).join("	"), a += 1);
    for (let l of o)s[a] = l.map(n).join("	"), a += 1;
    return s.join(`
`);
}, je = (e)=>{
    let t = false;
    for (let n of e)if (n === "\\" || n === "|") {
        t = true;
        break;
    }
    if (!t) return e;
    let o = [];
    for (let n of e)n === "\\" ? o.push("\\\\") : n === "|" ? o.push("\\|") : o.push(n);
    return o.join("");
}, re = (e)=>{
    let { headers: t, rows: o } = e;
    if (t.length === 0) return "";
    let n = new Array(o.length + 2), r = 0, s = t.map((l)=>je(l));
    n[r] = `| ${s.join(" | ")} |`, r += 1;
    let a = new Array(t.length);
    for(let l = 0; l < t.length; l += 1)a[l] = "---";
    n[r] = `| ${a.join(" | ")} |`, r += 1;
    for (let l of o)if (l.length < t.length) {
        let i = new Array(t.length);
        for(let d = 0; d < t.length; d += 1)i[d] = d < l.length ? je(l[d]) : "";
        n[r] = `| ${i.join(" | ")} |`, r += 1;
    } else {
        let i = l.map((d)=>je(d));
        n[r] = `| ${i.join(" | ")} |`, r += 1;
    }
    return n.join(`
`);
};
var Te = ({ children: e, className: t, onCopy: o, onError: n, timeout: r = 2e3 })=>{
    let s = y(), [a, l] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false), [i, d] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false), c = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), p = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0), { isAnimating: m } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(R), u = D(), f = async (g)=>{
        var T, v;
        if (typeof window == "undefined" || !((T = navigator == null ? void 0 : navigator.clipboard) != null && T.write)) {
            n == null || n(new Error("Clipboard API not available"));
            return;
        }
        try {
            let w = (v = c.current) == null ? void 0 : v.closest('[data-streamdown="table-wrapper"]'), P = w == null ? void 0 : w.querySelector("table");
            if (!P) {
                n == null || n(new Error("Table not found"));
                return;
            }
            let M = ue(P), F = (({
                csv: ne,
                tsv: dt,
                md: re
            })[g] || re)(M), j = new ClipboardItem({
                "text/plain": new Blob([
                    F
                ], {
                    type: "text/plain"
                }),
                "text/html": new Blob([
                    P.outerHTML
                ], {
                    type: "text/html"
                })
            });
            await navigator.clipboard.write([
                j
            ]), d(!0), l(!1), o == null || o(g), p.current = window.setTimeout(()=>d(!1), r);
        } catch (w) {
            n == null || n(w);
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Te.useEffect": ()=>{
            let g = {
                "Te.useEffect.g": (T)=>{
                    let v = T.composedPath();
                    c.current && !v.includes(c.current) && l(false);
                }
            }["Te.useEffect.g"];
            return document.addEventListener("mousedown", g), ({
                "Te.useEffect": ()=>{
                    document.removeEventListener("mousedown", g), window.clearTimeout(p.current);
                }
            })["Te.useEffect"];
        }
    }["Te.useEffect"], []);
    let h = L(), b = i ? h.CheckIcon : h.CopyIcon;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
        className: s("relative"),
        ref: c,
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                className: s("cursor-pointer p-1 text-muted-foreground transition-all hover:text-foreground disabled:cursor-not-allowed disabled:opacity-50", t),
                disabled: m,
                onClick: ()=>l(!a),
                title: u.copyTable,
                type: "button",
                children: e != null ? e : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(b, {
                    height: 14,
                    width: 14
                })
            }),
            a ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                className: s("absolute top-full right-0 z-20 mt-1 min-w-[120px] overflow-hidden rounded-md border border-border bg-background shadow-lg"),
                children: [
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                        className: s("w-full px-3 py-2 text-left text-sm transition-colors hover:bg-muted/40"),
                        onClick: ()=>f("md"),
                        title: u.copyTableAsMarkdown,
                        type: "button",
                        children: u.tableFormatMarkdown
                    }),
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                        className: s("w-full px-3 py-2 text-left text-sm transition-colors hover:bg-muted/40"),
                        onClick: ()=>f("csv"),
                        title: u.copyTableAsCsv,
                        type: "button",
                        children: u.tableFormatCsv
                    }),
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                        className: s("w-full px-3 py-2 text-left text-sm transition-colors hover:bg-muted/40"),
                        onClick: ()=>f("tsv"),
                        title: u.copyTableAsTsv,
                        type: "button",
                        children: u.tableFormatTsv
                    })
                ]
            }) : null
        ]
    });
};
var Wr = ({ children: e, className: t, onDownload: o, onError: n, format: r = "csv", filename: s })=>{
    let a = y(), { isAnimating: l } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(R), i = D(), d = L(), c = (p)=>{
        try {
            let u = p.currentTarget.closest('[data-streamdown="table-wrapper"]'), f = u == null ? void 0 : u.querySelector("table");
            if (!f) {
                n == null || n(new Error("Table not found"));
                return;
            }
            let h = ue(f), b = "", g = "", T = "";
            switch(r){
                case "csv":
                    b = ne(h), g = "text/csv", T = "csv";
                    break;
                case "markdown":
                    b = re(h), g = "text/markdown", T = "md";
                    break;
                default:
                    b = ne(h), g = "text/csv", T = "csv";
            }
            W(`${s || "table"}.${T}`, b, g), o == null || o();
        } catch (m) {
            n == null || n(m);
        }
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
        className: a("cursor-pointer p-1 text-muted-foreground transition-all hover:text-foreground disabled:cursor-not-allowed disabled:opacity-50", t),
        disabled: l,
        onClick: c,
        title: r === "csv" ? i.downloadTableAsCsv : i.downloadTableAsMarkdown,
        type: "button",
        children: e != null ? e : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(d.DownloadIcon, {
            size: 14
        })
    });
}, Pe = ({ children: e, className: t, onDownload: o, onError: n })=>{
    let r = y(), [s, a] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false), l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), { isAnimating: i } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(R), d = D(), c = L(), p = (m)=>{
        var u;
        try {
            let f = (u = l.current) == null ? void 0 : u.closest('[data-streamdown="table-wrapper"]'), h = f == null ? void 0 : f.querySelector("table");
            if (!h) {
                n == null || n(new Error("Table not found"));
                return;
            }
            let b = ue(h), g = m === "csv" ? ne(b) : re(b);
            W(`table.${m === "csv" ? "csv" : "md"}`, g, m === "csv" ? "text/csv" : "text/markdown"), a(!1), o == null || o(m);
        } catch (f) {
            n == null || n(f);
        }
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Pe.useEffect": ()=>{
            let m = {
                "Pe.useEffect.m": (u)=>{
                    let f = u.composedPath();
                    l.current && !f.includes(l.current) && a(false);
                }
            }["Pe.useEffect.m"];
            return document.addEventListener("mousedown", m), ({
                "Pe.useEffect": ()=>{
                    document.removeEventListener("mousedown", m);
                }
            })["Pe.useEffect"];
        }
    }["Pe.useEffect"], []), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
        className: r("relative"),
        ref: l,
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                className: r("cursor-pointer p-1 text-muted-foreground transition-all hover:text-foreground disabled:cursor-not-allowed disabled:opacity-50", t),
                disabled: i,
                onClick: ()=>a(!s),
                title: d.downloadTable,
                type: "button",
                children: e != null ? e : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(c.DownloadIcon, {
                    size: 14
                })
            }),
            s ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                className: r("absolute top-full right-0 z-20 mt-1 min-w-[120px] overflow-hidden rounded-md border border-border bg-background shadow-lg"),
                children: [
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                        className: r("w-full px-3 py-2 text-left text-sm transition-colors hover:bg-muted/40"),
                        onClick: ()=>p("csv"),
                        title: d.downloadTableAsCsv,
                        type: "button",
                        children: d.tableFormatCsv
                    }),
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                        className: r("w-full px-3 py-2 text-left text-sm transition-colors hover:bg-muted/40"),
                        onClick: ()=>p("markdown"),
                        title: d.downloadTableAsMarkdown,
                        type: "button",
                        children: d.tableFormatMarkdown
                    })
                ]
            }) : null
        ]
    });
};
var Co = ({ children: e, className: t, showCopy: o = true, showDownload: n = true })=>{
    let { Maximize2Icon: r, XIcon: s } = L(), a = y(), [l, i] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false), { isAnimating: d } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(R), c = D(), p = ()=>{
        i(true);
    }, m = ()=>{
        i(false);
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Co.useEffect": ()=>{
            if (l) {
                le();
                let u = {
                    "Co.useEffect.u": (f)=>{
                        f.key === "Escape" && i(false);
                    }
                }["Co.useEffect.u"];
                return document.addEventListener("keydown", u), ({
                    "Co.useEffect": ()=>{
                        document.removeEventListener("keydown", u), ce();
                    }
                })["Co.useEffect"];
            }
        }
    }["Co.useEffect"], [
        l
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                className: a("cursor-pointer p-1 text-muted-foreground transition-all hover:text-foreground disabled:cursor-not-allowed disabled:opacity-50", t),
                disabled: d,
                onClick: p,
                title: c.viewFullscreen,
                type: "button",
                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(r, {
                    size: 14
                })
            }),
            l ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPortal"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                "aria-label": c.viewFullscreen,
                "aria-modal": "true",
                className: a("fixed inset-0 z-50 flex flex-col bg-background"),
                "data-streamdown": "table-fullscreen",
                onClick: m,
                onKeyDown: (u)=>{
                    u.key === "Escape" && m();
                },
                role: "dialog",
                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                    className: a("flex h-full flex-col"),
                    onClick: (u)=>u.stopPropagation(),
                    onKeyDown: (u)=>u.stopPropagation(),
                    role: "presentation",
                    children: [
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                            className: a("flex items-center justify-end gap-1 p-4"),
                            children: [
                                o ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Te, {}) : null,
                                n ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Pe, {}) : null,
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                                    className: a("rounded-md p-1 text-muted-foreground transition-all hover:bg-muted hover:text-foreground"),
                                    onClick: m,
                                    title: c.exitFullscreen,
                                    type: "button",
                                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(s, {
                                        size: 20
                                    })
                                })
                            ]
                        }),
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                            className: a("flex-1 overflow-auto p-4 pt-0 [&_thead]:sticky [&_thead]:top-0 [&_thead]:z-10"),
                            children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("table", {
                                className: a("w-full border-collapse border border-border"),
                                "data-streamdown": "table",
                                children: e
                            })
                        })
                    ]
                })
            }), document.body) : null
        ]
    });
};
var vo = ({ children: e, className: t, showControls: o, showCopy: n = true, showDownload: r = true, showFullscreen: s = true, ...a })=>{
    let l = y(), i = o && n, d = o && r, c = o && s, p = i || d || c;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
        className: l("my-4 flex flex-col gap-2 rounded-lg border border-border bg-sidebar p-2"),
        "data-streamdown": "table-wrapper",
        children: [
            p ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                className: l("flex items-center justify-end gap-1"),
                children: [
                    i ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Te, {}) : null,
                    d ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Pe, {}) : null,
                    c ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Co, {
                        showCopy: i,
                        showDownload: d,
                        children: e
                    }) : null
                ]
            }) : null,
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                className: l("border-collapse overflow-x-auto overflow-y-auto rounded-md border border-border bg-background"),
                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("table", {
                    className: l("w-full divide-y divide-border", t),
                    "data-streamdown": "table",
                    ...a,
                    children: e
                })
            })
        ]
    });
};
var es = /startLine=(\d+)/, ts = /\bnoLineNumbers\b/, os = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lazy"])(()=>__turbopack_context__.A("[project]/node_modules/.pnpm/streamdown@2.5.0_react-dom@19.2.4_react@19.2.4__react@19.2.4/node_modules/streamdown/dist/mermaid-GHXKKRXX.js [app-client] (ecmascript, async loader)").then((e)=>({
            default: e.Mermaid
        }))), ns = /language-([^\s]+)/;
function qe(e, t) {
    if (!(e != null && e.position || t != null && t.position)) return true;
    if (!(e != null && e.position && t != null && t.position)) return false;
    let o = e.position.start, n = t.position.start, r = e.position.end, s = t.position.end;
    return (o == null ? void 0 : o.line) === (n == null ? void 0 : n.line) && (o == null ? void 0 : o.column) === (n == null ? void 0 : n.column) && (r == null ? void 0 : r.line) === (s == null ? void 0 : s.line) && (r == null ? void 0 : r.column) === (s == null ? void 0 : s.column);
}
function E(e, t) {
    return e.className === t.className && qe(e.node, t.node);
}
var ft = (e, t)=>typeof e == "boolean" ? e : e[t] !== false, pt = (e, t)=>{
    if (typeof e == "boolean") return e;
    let o = e.table;
    return o === false ? false : o === true || o === void 0 ? true : o[t] !== false;
}, To = (e, t)=>{
    if (typeof e == "boolean") return e;
    let o = e.code;
    return o === false ? false : o === true || o === void 0 ? true : o[t] !== false;
}, Fe = (e, t)=>{
    if (typeof e == "boolean") return e;
    let o = e.mermaid;
    return o === false ? false : o === true || o === void 0 ? true : o[t] !== false;
}, bt = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(({ children: e, className: t, node: o, ...n })=>{
    let r = y();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("ol", {
        className: r("list-inside list-decimal whitespace-normal [li_&]:pl-6", t),
        "data-streamdown": "ordered-list",
        ...n,
        children: e
    });
}, (e, t)=>E(e, t));
bt.displayName = "MarkdownOl";
var Po = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(({ children: e, className: t, node: o, ...n })=>{
    let r = y();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("li", {
        className: r("py-1 [&>p]:inline", t),
        "data-streamdown": "list-item",
        ...n,
        children: e
    });
}, (e, t)=>e.className === t.className && qe(e.node, t.node));
Po.displayName = "MarkdownLi";
var Mo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(({ children: e, className: t, node: o, ...n })=>{
    let r = y();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("ul", {
        className: r("list-inside list-disc whitespace-normal [li_&]:pl-6", t),
        "data-streamdown": "unordered-list",
        ...n,
        children: e
    });
}, (e, t)=>E(e, t));
Mo.displayName = "MarkdownUl";
var Io = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(({ className: e, node: t, ...o })=>{
    let n = y();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("hr", {
        className: n("my-6 border-border", e),
        "data-streamdown": "horizontal-rule",
        ...o
    });
}, (e, t)=>E(e, t));
Io.displayName = "MarkdownHr";
var No = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(({ children: e, className: t, node: o, ...n })=>{
    let r = y();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
        className: r("font-semibold", t),
        "data-streamdown": "strong",
        ...n,
        children: e
    });
}, (e, t)=>E(e, t));
No.displayName = "MarkdownStrong";
var rs = ({ children: e, className: t, href: o, node: n, ...r })=>{
    let s = y(), { linkSafety: a } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(R), [l, i] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false), d = o === "streamdown:incomplete-link", c = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "rs.useCallback[c]": async (f)=>{
            if (!(!(a != null && a.enabled && o) || d)) {
                if (f.preventDefault(), a.onLinkCheck && await a.onLinkCheck(o)) {
                    window.open(o, "_blank", "noreferrer");
                    return;
                }
                i(true);
            }
        }
    }["rs.useCallback[c]"], [
        a,
        o,
        d
    ]), p = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "rs.useCallback[p]": ()=>{
            o && window.open(o, "_blank", "noreferrer");
        }
    }["rs.useCallback[p]"], [
        o
    ]), m = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "rs.useCallback[m]": ()=>{
            i(false);
        }
    }["rs.useCallback[m]"], []), u = {
        url: o != null ? o : "",
        isOpen: l,
        onClose: m,
        onConfirm: p
    };
    return a != null && a.enabled && o ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                className: s("wrap-anywhere appearance-none text-left font-medium text-primary underline", t),
                "data-incomplete": d,
                "data-streamdown": "link",
                onClick: c,
                type: "button",
                children: e
            }),
            a.renderModal ? a.renderModal(u) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(so, {
                ...u
            })
        ]
    }) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("a", {
        className: s("wrap-anywhere font-medium text-primary underline", t),
        "data-incomplete": d,
        "data-streamdown": "link",
        href: o,
        rel: "noreferrer",
        target: "_blank",
        ...r,
        children: e
    });
}, Lo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(rs, (e, t)=>E(e, t) && e.href === t.href);
Lo.displayName = "MarkdownA";
var Ro = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(({ children: e, className: t, node: o, ...n })=>{
    let r = y();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("h1", {
        className: r("mt-6 mb-2 font-semibold text-3xl", t),
        "data-streamdown": "heading-1",
        ...n,
        children: e
    });
}, (e, t)=>E(e, t));
Ro.displayName = "MarkdownH1";
var So = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(({ children: e, className: t, node: o, ...n })=>{
    let r = y();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("h2", {
        className: r("mt-6 mb-2 font-semibold text-2xl", t),
        "data-streamdown": "heading-2",
        ...n,
        children: e
    });
}, (e, t)=>E(e, t));
So.displayName = "MarkdownH2";
var Eo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(({ children: e, className: t, node: o, ...n })=>{
    let r = y();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("h3", {
        className: r("mt-6 mb-2 font-semibold text-xl", t),
        "data-streamdown": "heading-3",
        ...n,
        children: e
    });
}, (e, t)=>E(e, t));
Eo.displayName = "MarkdownH3";
var Ho = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(({ children: e, className: t, node: o, ...n })=>{
    let r = y();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("h4", {
        className: r("mt-6 mb-2 font-semibold text-lg", t),
        "data-streamdown": "heading-4",
        ...n,
        children: e
    });
}, (e, t)=>E(e, t));
Ho.displayName = "MarkdownH4";
var Do = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(({ children: e, className: t, node: o, ...n })=>{
    let r = y();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("h5", {
        className: r("mt-6 mb-2 font-semibold text-base", t),
        "data-streamdown": "heading-5",
        ...n,
        children: e
    });
}, (e, t)=>E(e, t));
Do.displayName = "MarkdownH5";
var Bo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(({ children: e, className: t, node: o, ...n })=>{
    let r = y();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("h6", {
        className: r("mt-6 mb-2 font-semibold text-sm", t),
        "data-streamdown": "heading-6",
        ...n,
        children: e
    });
}, (e, t)=>E(e, t));
Bo.displayName = "MarkdownH6";
var Ao = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(({ children: e, className: t, node: o, ...n })=>{
    let { controls: r } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(R), s = ft(r, "table"), a = pt(r, "copy"), l = pt(r, "download"), i = pt(r, "fullscreen");
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(vo, {
        className: t,
        showControls: s,
        showCopy: a,
        showDownload: l,
        showFullscreen: i,
        ...n,
        children: e
    });
}, (e, t)=>E(e, t));
Ao.displayName = "MarkdownTable";
var Oo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(({ children: e, className: t, node: o, ...n })=>{
    let r = y();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("thead", {
        className: r("bg-muted/80", t),
        "data-streamdown": "table-header",
        ...n,
        children: e
    });
}, (e, t)=>E(e, t));
Oo.displayName = "MarkdownThead";
var Vo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(({ children: e, className: t, node: o, ...n })=>{
    let r = y();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("tbody", {
        className: r("divide-y divide-border", t),
        "data-streamdown": "table-body",
        ...n,
        children: e
    });
}, (e, t)=>E(e, t));
Vo.displayName = "MarkdownTbody";
var jo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(({ children: e, className: t, node: o, ...n })=>{
    let r = y();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("tr", {
        className: r("border-border", t),
        "data-streamdown": "table-row",
        ...n,
        children: e
    });
}, (e, t)=>E(e, t));
jo.displayName = "MarkdownTr";
var Fo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(({ children: e, className: t, node: o, ...n })=>{
    let r = y();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("th", {
        className: r("whitespace-nowrap px-4 py-2 text-left font-semibold text-sm", t),
        "data-streamdown": "table-header-cell",
        ...n,
        children: e
    });
}, (e, t)=>E(e, t));
Fo.displayName = "MarkdownTh";
var zo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(({ children: e, className: t, node: o, ...n })=>{
    let r = y();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("td", {
        className: r("px-4 py-2 text-sm", t),
        "data-streamdown": "table-cell",
        ...n,
        children: e
    });
}, (e, t)=>E(e, t));
zo.displayName = "MarkdownTd";
var _o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(({ children: e, className: t, node: o, ...n })=>{
    let r = y();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("blockquote", {
        className: r("my-4 border-muted-foreground/30 border-l-4 pl-4 text-muted-foreground italic", t),
        "data-streamdown": "blockquote",
        ...n,
        children: e
    });
}, (e, t)=>E(e, t));
_o.displayName = "MarkdownBlockquote";
var qo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(({ children: e, className: t, node: o, ...n })=>{
    let r = y();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("sup", {
        className: r("text-sm", t),
        "data-streamdown": "superscript",
        ...n,
        children: e
    });
}, (e, t)=>E(e, t));
qo.displayName = "MarkdownSup";
var $o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(({ children: e, className: t, node: o, ...n })=>{
    let r = y();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("sub", {
        className: r("text-sm", t),
        "data-streamdown": "subscript",
        ...n,
        children: e
    });
}, (e, t)=>E(e, t));
$o.displayName = "MarkdownSub";
var Wo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(({ children: e, className: t, node: o, ...n })=>{
    if ("data-footnotes" in n) {
        let s = (i)=>{
            var m, u;
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElement"])(i)) return false;
            let d = Array.isArray(i.props.children) ? i.props.children : [
                i.props.children
            ], c = false, p = false;
            for (let f of d)if (f) {
                if (typeof f == "string") f.trim() !== "" && (c = true);
                else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElement"])(f)) if (((m = f.props) == null ? void 0 : m["data-footnote-backref"]) !== void 0) p = true;
                else {
                    let h = Array.isArray(f.props.children) ? f.props.children : [
                        f.props.children
                    ];
                    for (let b of h){
                        if (typeof b == "string" && b.trim() !== "") {
                            c = true;
                            break;
                        }
                        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElement"])(b) && ((u = b.props) == null ? void 0 : u["data-footnote-backref"]) === void 0) {
                            c = true;
                            break;
                        }
                    }
                }
            }
            return p && !c;
        }, a = Array.isArray(e) ? e.map((i)=>{
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElement"])(i)) return i;
            if (i.type === bt) {
                let c = (Array.isArray(i.props.children) ? i.props.children : [
                    i.props.children
                ]).filter((p)=>!s(p));
                return c.length === 0 ? null : {
                    ...i,
                    props: {
                        ...i.props,
                        children: c
                    }
                };
            }
            return i;
        }) : e;
        return (Array.isArray(a) ? a.some((i)=>i !== null) : a !== null) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("section", {
            className: t,
            ...n,
            children: a
        }) : null;
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("section", {
        className: t,
        ...n,
        children: e
    });
}, (e, t)=>E(e, t));
Wo.displayName = "MarkdownSection";
var ss = ({ node: e, className: t, children: o, ...n })=>{
    var S, F;
    let r = y(), s = !("data-block" in n), { mermaid: a, controls: l, lineNumbers: i } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(R), d = de(), c = tt(), p = t == null ? void 0 : t.match(ns), m = (S = p == null ? void 0 : p.at(1)) != null ? S : "", u = ao(m);
    if (s) return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("code", {
        className: r("rounded bg-muted px-1.5 py-0.5 font-mono text-sm", t),
        "data-streamdown": "inline-code",
        ...n,
        children: o
    });
    let f = (F = e == null ? void 0 : e.properties) == null ? void 0 : F.metastring, h = f == null ? void 0 : f.match(es), b = h ? Number.parseInt(h[1], 10) : void 0, g = b !== void 0 && b >= 1 ? b : void 0, v = !(f ? ts.test(f) : false) && i !== false, w = "";
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElement"])(o) && o.props && typeof o.props == "object" && "children" in o.props && typeof o.props.children == "string" ? w = o.props.children : typeof o == "string" && (w = o), u) {
        let j = u.component;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Suspense"], {
            fallback: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Oe, {}),
            children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(j, {
                code: w,
                isIncomplete: c,
                language: m,
                meta: f
            })
        });
    }
    if (m === "mermaid" && d) {
        let j = ft(l, "mermaid"), z = Fe(l, "download"), B = Fe(l, "copy"), _ = Fe(l, "fullscreen"), Q = Fe(l, "panZoom"), U = j && (z || B || _);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Suspense"], {
            fallback: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Oe, {}),
            children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                className: r("group relative my-4 flex w-full flex-col gap-2 rounded-xl border border-border bg-sidebar p-2", t),
                "data-streamdown": "mermaid-block",
                children: [
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                        className: r("flex h-8 items-center text-muted-foreground text-xs"),
                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
                            className: r("ml-1 font-mono lowercase"),
                            children: "mermaid"
                        })
                    }),
                    U ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                        className: r("pointer-events-none sticky top-2 z-10 -mt-10 flex h-8 items-center justify-end"),
                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                            className: r("pointer-events-auto flex shrink-0 items-center gap-2 rounded-md border border-sidebar bg-sidebar/80 px-1.5 py-1 supports-[backdrop-filter]:bg-sidebar/70 supports-[backdrop-filter]:backdrop-blur"),
                            "data-streamdown": "mermaid-block-actions",
                            children: [
                                z ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(co, {
                                    chart: w,
                                    config: a == null ? void 0 : a.config
                                }) : null,
                                B ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Ae, {
                                    code: w
                                }) : null,
                                _ ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(fo, {
                                    chart: w,
                                    config: a == null ? void 0 : a.config
                                }) : null
                            ]
                        })
                    }) : null,
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                        className: r("rounded-md border border-border bg-background"),
                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(os, {
                            chart: w,
                            config: a == null ? void 0 : a.config,
                            showControls: Q
                        })
                    })
                ]
            })
        });
    }
    let P = ft(l, "code"), M = To(l, "download"), H = To(l, "copy");
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(st, {
        className: t,
        code: w,
        isIncomplete: c,
        language: m,
        lineNumbers: v,
        startLine: g,
        children: P ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                M ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(it, {
                    code: w,
                    language: m
                }) : null,
                H ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Ae, {}) : null
            ]
        }) : null
    });
}, Zo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(ss, (e, t)=>e.className === t.className && qe(e.node, t.node));
Zo.displayName = "MarkdownCode";
var Xo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(oo, (e, t)=>e.className === t.className && qe(e.node, t.node));
Xo.displayName = "MarkdownImg";
var Jo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(({ children: e, node: t, ...o })=>{
    let r = (Array.isArray(e) ? e : [
        e
    ]).filter((s)=>s != null && s !== "");
    if (r.length === 1 && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElement"])(r[0])) {
        let s = r[0].props.node, a = s == null ? void 0 : s.tagName;
        if (a === "img") return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: e
        });
        if (a === "code" && "data-block" in r[0].props) return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: e
        });
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("p", {
        ...o,
        children: e
    });
}, (e, t)=>E(e, t));
Jo.displayName = "MarkdownParagraph";
var Ko = {
    ol: bt,
    li: Po,
    ul: Mo,
    hr: Io,
    strong: No,
    a: Lo,
    h1: Ro,
    h2: So,
    h3: Eo,
    h4: Ho,
    h5: Do,
    h6: Bo,
    table: Ao,
    thead: Oo,
    tbody: Vo,
    tr: jo,
    th: Fo,
    td: zo,
    blockquote: _o,
    code: Zo,
    img: Xo,
    pre: ({ children: e })=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElement"])(e) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cloneElement"])(e, {
            "data-block": "true"
        }) : e,
    sup: qo,
    sub: $o,
    p: Jo,
    section: Wo
};
var as = /[\u0590-\u08FF\uFB1D-\uFDFF\uFE70-\uFEFF]/, is = /\p{L}/u;
function $e(e) {
    let t = e.replace(/^#{1,6}\s+/gm, "").replace(/(\*{1,3}|_{1,3})/g, "").replace(/`[^`]*`/g, "").replace(/\[([^\]]*)\]\([^)]*\)/g, "$1").replace(/^[\s>*\-+\d.]+/gm, "");
    for (let o of t){
        if (as.test(o)) return "rtl";
        if (is.test(o)) return "ltr";
    }
    return "ltr";
}
var ls = /^[ \t]{0,3}(`{3,}|~{3,})/, cs = /^\|?[ \t]*:?-{1,}:?[ \t]*(\|[ \t]*:?-{1,}:?[ \t]*)*\|?$/, ht = (e)=>{
    let t = e.split(`
`), o = null, n = 0;
    for (let r of t){
        let s = ls.exec(r);
        if (o === null) {
            if (s) {
                let a = s[1];
                o = a[0], n = a.length;
            }
        } else if (s) {
            let a = s[1], l = a[0], i = a.length;
            l === o && i >= n && (o = null, n = 0);
        }
    }
    return o !== null;
}, Uo = (e)=>{
    let t = e.split(`
`);
    for (let o of t){
        let n = o.trim();
        if (n.length > 0 && n.includes("|") && cs.test(n)) return true;
    }
    return false;
};
var Go = ()=>(e)=>{
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$unist$2d$util$2d$visit$40$5$2e$1$2e$0$2f$node_modules$2f$unist$2d$util$2d$visit$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["visit"])(e, "html", (t, o, n)=>{
            !n || typeof o != "number" || (n.children[o] = {
                type: "text",
                value: t.value
            });
        });
    };
var Qo = [], en = {
    allowDangerousHtml: true
}, We = new WeakMap, wt = class {
    constructor(){
        this.cache = new Map;
        this.keyCache = new WeakMap;
        this.maxSize = 100;
    }
    generateCacheKey(t) {
        let o = this.keyCache.get(t);
        if (o) return o;
        let n = t.rehypePlugins, r = t.remarkPlugins, s = t.remarkRehypeOptions;
        if (!(n || r || s)) {
            let p = "default";
            return this.keyCache.set(t, p), p;
        }
        let a = (p)=>{
            if (!p || p.length === 0) return "";
            let m = "";
            for(let u = 0; u < p.length; u += 1){
                let f = p[u];
                if (u > 0 && (m += ","), Array.isArray(f)) {
                    let [h, b] = f;
                    if (typeof h == "function") {
                        let g = We.get(h);
                        g || (g = h.name, We.set(h, g)), m += g;
                    } else m += String(h);
                    m += ":", m += JSON.stringify(b);
                } else if (typeof f == "function") {
                    let h = We.get(f);
                    h || (h = f.name, We.set(f, h)), m += h;
                } else m += String(f);
            }
            return m;
        }, l = a(n), i = a(r), d = s ? JSON.stringify(s) : "", c = `${i}::${l}::${d}`;
        return this.keyCache.set(t, c), c;
    }
    get(t) {
        let o = this.generateCacheKey(t), n = this.cache.get(o);
        return n && (this.cache.delete(o), this.cache.set(o, n)), n;
    }
    set(t, o) {
        let n = this.generateCacheKey(t);
        if (this.cache.size >= this.maxSize) {
            let r = this.cache.keys().next().value;
            r && this.cache.delete(r);
        }
        this.cache.set(n, o);
    }
    clear() {
        this.cache.clear();
    }
}, tn = new wt, Ct = (e)=>{
    let t = ws(e), o = e.children || "", n = t.runSync(t.parse(o), o);
    return Ps(n, e);
}, ws = (e)=>{
    let t = tn.get(e);
    if (t) return t;
    let o = ks(e);
    return tn.set(e, o), o;
}, Cs = (e)=>e.some((t)=>Array.isArray(t) ? t[0] === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$rehype$2d$raw$40$7$2e$0$2e$0$2f$node_modules$2f$rehype$2d$raw$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] : t === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$rehype$2d$raw$40$7$2e$0$2e$0$2f$node_modules$2f$rehype$2d$raw$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]), ks = (e)=>{
    let t = e.rehypePlugins || Qo, o = e.remarkPlugins || Qo, n = Cs(t) ? o : [
        ...o,
        Go
    ], r = e.remarkRehypeOptions ? {
        ...en,
        ...e.remarkRehypeOptions
    } : en;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$unified$40$11$2e$0$2e$5$2f$node_modules$2f$unified$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["unified"])().use(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$remark$2d$parse$40$11$2e$0$2e$0$2f$node_modules$2f$remark$2d$parse$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]).use(n).use(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$remark$2d$rehype$40$11$2e$1$2e$2$2f$node_modules$2f$remark$2d$rehype$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], r).use(t);
}, on = (e)=>e, vs = (e, t, o, n)=>{
    o ? e.children.splice(t, 1) : e.children[t] = {
        type: "text",
        value: n
    };
}, xs = (e, t)=>{
    var o;
    for(let n in __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$html$2d$url$2d$attributes$40$3$2e$0$2e$1$2f$node_modules$2f$html$2d$url$2d$attributes$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["urlAttributes"])if (Object.hasOwn(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$html$2d$url$2d$attributes$40$3$2e$0$2e$1$2f$node_modules$2f$html$2d$url$2d$attributes$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["urlAttributes"], n) && Object.hasOwn(e.properties, n)) {
        let r = e.properties[n], s = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$html$2d$url$2d$attributes$40$3$2e$0$2e$1$2f$node_modules$2f$html$2d$url$2d$attributes$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["urlAttributes"][n];
        (s === null || s.includes(e.tagName)) && (e.properties[n] = (o = t(String(r || ""), n, e)) != null ? o : void 0);
    }
}, Ts = (e, t, o, n, r, s)=>{
    let a = false;
    return n ? a = !n.includes(e.tagName) : r && (a = r.includes(e.tagName)), !a && s && typeof t == "number" && (a = !s(e, t, o)), a;
}, Ps = (e, t)=>{
    let { allowElement: o, allowedElements: n, disallowedElements: r, skipHtml: s, unwrapDisallowed: a, urlTransform: l } = t;
    if (o || n || r || s || l) {
        let d = l || on;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$unist$2d$util$2d$visit$40$5$2e$1$2e$0$2f$node_modules$2f$unist$2d$util$2d$visit$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["visit"])(e, (c, p, m)=>{
            if (c.type === "raw" && m && typeof p == "number") return vs(m, p, s, c.value), p;
            if (c.type === "element" && (xs(c, d), Ts(c, p, m, n, r, o) && m && typeof p == "number")) return a && c.children ? m.children.splice(p, 1, ...c.children) : m.children.splice(p, 1), p;
        });
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$hast$2d$util$2d$to$2d$jsx$2d$runtime$40$2$2e$3$2e$6$2f$node_modules$2f$hast$2d$util$2d$to$2d$jsx$2d$runtime$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toJsxRuntime"])(e, {
        Fragment: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"],
        components: t.components,
        ignoreInvalidStyle: true,
        jsx: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"],
        jsxs: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"],
        passKeys: true,
        passNode: true
    });
};
var Is = /\[\^[\w-]{1,200}\](?!:)/, Ns = /\[\^[\w-]{1,200}\]:/;
var Ls = /<(\w+)[\s>]/, Rs = new Set([
    "area",
    "base",
    "br",
    "col",
    "embed",
    "hr",
    "img",
    "input",
    "link",
    "meta",
    "param",
    "source",
    "track",
    "wbr"
]), nn = new Map, rn = new Map, Ss = (e)=>{
    let t = e.toLowerCase(), o = nn.get(t);
    if (o) return o;
    let n = new RegExp(`<${t}(?=[\\s>/])[^>]*>`, "gi");
    return nn.set(t, n), n;
}, Es = (e)=>{
    let t = e.toLowerCase(), o = rn.get(t);
    if (o) return o;
    let n = new RegExp(`</${t}(?=[\\s>])[^>]*>`, "gi");
    return rn.set(t, n), n;
}, sn = (e, t)=>{
    if (Rs.has(t.toLowerCase())) return 0;
    let o = e.match(Ss(t));
    if (!o) return 0;
    let n = 0;
    for (let r of o)r.trimEnd().endsWith("/>") || (n += 1);
    return n;
}, an = (e, t)=>{
    let o = e.match(Es(t));
    return o ? o.length : 0;
}, Hs = (e)=>{
    let t = 0;
    for(let o = 0; o < e.length - 1; o += 1)e[o] === "$" && e[o + 1] === "$" && (t += 1, o += 1);
    return t;
}, kt = (e)=>{
    let t = Is.test(e), o = Ns.test(e);
    if (t || o) return [
        e
    ];
    let n = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$marked$40$17$2e$0$2e$6$2f$node_modules$2f$marked$2f$lib$2f$marked$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Lexer"].lex(e, {
        gfm: true
    }), r = [], s = [], a = false;
    for (let l of n){
        let i = l.raw, d = r.length;
        if (s.length > 0) {
            r[d - 1] += i;
            let c = s.at(-1), p = sn(i, c), m = an(i, c);
            for(let u = 0; u < p; u += 1)s.push(c);
            for(let u = 0; u < m; u += 1)s.length > 0 && s.at(-1) === c && s.pop();
            continue;
        }
        if (l.type === "html" && l.block) {
            let c = i.match(Ls);
            if (c) {
                let p = c[1], m = sn(i, p), u = an(i, p);
                m > u && s.push(p);
            }
        }
        if (d > 0 && !a) {
            let c = r[d - 1];
            if (Hs(c) % 2 === 1) {
                r[d - 1] = c + i;
                continue;
            }
        }
        r.push(i), l.type !== "space" && (a = l.type === "code");
    }
    return r;
};
var ln = (e, t)=>{
    if (!t.length) return e;
    let o = e;
    for (let n of t){
        let r = new RegExp(`(<${n}(?=[\\s>/])[^>]*>)([\\s\\S]*?)(</${n}\\s*>)`, "gi");
        o = o.replace(r, (s, a, l, i)=>{
            if (!l.includes(`

`)) return a + l + i;
            let d = l.replace(/\n\n/g, `
<!---->
`), c = (d.startsWith(`
`) ? "" : `
`) + d + (d.endsWith(`
`) ? "" : `
`);
            return `${a}${c}${i}

`;
        });
    }
    return o;
};
var Ds = /([\\`*_~[\]|])/g, Bs = (e)=>e.replace(Ds, "\\$1"), cn = (e, t)=>{
    if (!t.length) return e;
    let o = e;
    for (let n of t){
        let r = new RegExp(`(<${n}(?=[\\s>/])[^>]*>)([\\s\\S]*?)(</${n}\\s*>)`, "gi");
        o = o.replace(r, (s, a, l, i)=>{
            let d = Bs(l).replace(/\n\n/g, "&#10;&#10;");
            return a + d + i;
        });
    }
    return o;
};
var dn = (e)=>e.type === "text" ? e.value : "children" in e && Array.isArray(e.children) ? e.children.map(dn).join("") : "", mn = (e)=>(t)=>{
        if (!e || e.length === 0) return;
        let o = new Set(e.map((n)=>n.toLowerCase()));
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$unist$2d$util$2d$visit$40$5$2e$1$2e$0$2f$node_modules$2f$unist$2d$util$2d$visit$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["visit"])(t, "element", (n)=>{
            if (o.has(n.tagName.toLowerCase())) {
                let r = dn(n);
                n.children = r ? [
                    {
                        type: "text",
                        value: r
                    }
                ] : [];
            }
        });
    };
var un = ()=>(e)=>{
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$unist$2d$util$2d$visit$40$5$2e$1$2e$0$2f$node_modules$2f$unist$2d$util$2d$visit$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["visit"])(e, "code", (t)=>{
            var o, n;
            t.meta && (t.data = (o = t.data) != null ? o : {}, t.data.hProperties = {
                ...(n = t.data.hProperties) != null ? n : {},
                metastring: t.meta
            });
        });
    };
var Zs = /^[ \t]*<[\w!/?-]/, Xs = /(^|\n)[ \t]{4,}(?=<[\w!/?-])/g, Js = (e)=>typeof e != "string" || e.length === 0 || !Zs.test(e) ? e : e.replace(Xs, "$1"), bn, hn, yn, wn, Ze = {
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$hast$2d$util$2d$sanitize$40$5$2e$0$2e$2$2f$node_modules$2f$hast$2d$util$2d$sanitize$2f$lib$2f$schema$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultSchema"],
    protocols: {
        ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$hast$2d$util$2d$sanitize$40$5$2e$0$2e$2$2f$node_modules$2f$hast$2d$util$2d$sanitize$2f$lib$2f$schema$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultSchema"].protocols,
        href: [
            ...(hn = (bn = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$hast$2d$util$2d$sanitize$40$5$2e$0$2e$2$2f$node_modules$2f$hast$2d$util$2d$sanitize$2f$lib$2f$schema$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultSchema"].protocols) == null ? void 0 : bn.href) != null ? hn : [],
            "tel"
        ]
    },
    attributes: {
        ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$hast$2d$util$2d$sanitize$40$5$2e$0$2e$2$2f$node_modules$2f$hast$2d$util$2d$sanitize$2f$lib$2f$schema$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultSchema"].attributes,
        code: [
            ...(wn = (yn = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$hast$2d$util$2d$sanitize$40$5$2e$0$2e$2$2f$node_modules$2f$hast$2d$util$2d$sanitize$2f$lib$2f$schema$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultSchema"].attributes) == null ? void 0 : yn.code) != null ? wn : [],
            "metastring"
        ]
    }
}, xt = {
    raw: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$rehype$2d$raw$40$7$2e$0$2e$0$2f$node_modules$2f$rehype$2d$raw$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    sanitize: [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$rehype$2d$sanitize$40$6$2e$0$2e$0$2f$node_modules$2f$rehype$2d$sanitize$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        Ze
    ],
    harden: [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$rehype$2d$harden$40$1$2e$1$2e$8$2f$node_modules$2f$rehype$2d$harden$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["harden"],
        {
            allowedImagePrefixes: [
                "*"
            ],
            allowedLinkPrefixes: [
                "*"
            ],
            allowedProtocols: [
                "*"
            ],
            defaultOrigin: void 0,
            allowDataImages: true
        }
    ]
}, Ks = {
    gfm: [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$remark$2d$gfm$40$4$2e$0$2e$1$2f$node_modules$2f$remark$2d$gfm$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        {}
    ],
    codeMeta: un
}, gn = Object.values(xt), Us = Object.values(Ks), Gs = {
    block: " \u258B",
    circle: " \u25CF"
}, vn = [
    "github-light",
    "github-dark"
], xn = {
    enabled: true
}, Ys = {
    shikiTheme: vn,
    controls: true,
    isAnimating: false,
    lineNumbers: true,
    mode: "streaming",
    mermaid: void 0,
    linkSafety: xn
}, R = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(Ys), Tn = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(({ content: e, shouldParseIncompleteMarkdown: t, shouldNormalizeHtmlIndentation: o, index: n, isIncomplete: r, dir: s, animatePlugin: a, ...l })=>{
    if (a) {
        let c = a.getLastRenderCharCount();
        a.setPrevContentLength(c);
    }
    let i = typeof e == "string" && o ? Js(e) : e, d = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Ct, {
        ...l,
        children: i
    });
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(et.Provider, {
        value: r,
        children: s ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
            dir: s,
            style: {
                display: "contents"
            },
            children: d
        }) : d
    });
}, (e, t)=>{
    if (e.content !== t.content || e.shouldNormalizeHtmlIndentation !== t.shouldNormalizeHtmlIndentation || e.index !== t.index || e.isIncomplete !== t.isIncomplete || e.dir !== t.dir) return false;
    if (e.components !== t.components) {
        let o = Object.keys(e.components || {}), n = Object.keys(t.components || {});
        if (o.length !== n.length || o.some((r)=>{
            var s, a;
            return ((s = e.components) == null ? void 0 : s[r]) !== ((a = t.components) == null ? void 0 : a[r]);
        })) return false;
    }
    return !(e.rehypePlugins !== t.rehypePlugins || e.remarkPlugins !== t.remarkPlugins);
});
Tn.displayName = "Block";
var Qs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(({ children: e, mode: t = "streaming", dir: o, parseIncompleteMarkdown: n = true, normalizeHtmlIndentation: r = false, components: s, rehypePlugins: a = gn, remarkPlugins: l = Us, className: i, shikiTheme: d = vn, mermaid: c, controls: p = true, isAnimating: m = false, animated: u, BlockComponent: f = Tn, parseMarkdownIntoBlocksFn: h = kt, caret: b, plugins: g, remend: T, linkSafety: v = xn, lineNumbers: w = true, allowedTags: P, literalTagContent: M, translations: H, icons: S, prefix: F, onAnimationStart: j, onAnimationEnd: z, ...B })=>{
    let _ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])(), [Q, U] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTransition"])(), x = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Qs.useMemo[x]": ()=>Dt(F)
    }["Qs.useMemo[x]"], [
        F
    ]), q = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), X = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(j), Re = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(z);
    X.current = j, Re.current = z, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Qs.useEffect": ()=>{
            var A, K, ee;
            if (t === "static") return;
            let k = q.current;
            if (q.current = m, k === null) {
                m && ((A = X.current) == null || A.call(X));
                return;
            }
            m && !k ? (K = X.current) == null || K.call(X) : !m && k && ((ee = Re.current) == null || ee.call(Re));
        }
    }["Qs.useEffect"], [
        m,
        t
    ]);
    let Je = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Qs.useMemo[Je]": ()=>P ? Object.keys(P) : []
    }["Qs.useMemo[Je]"], [
        P
    ]), Se = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Qs.useMemo[Se]": ()=>{
            if (typeof e != "string") return "";
            let k = t === "streaming" && n ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$remend$40$1$2e$3$2e$0$2f$node_modules$2f$remend$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(e, T) : e;
            return M && M.length > 0 && (k = cn(k, M)), Je.length > 0 && (k = ln(k, Je)), k;
        }
    }["Qs.useMemo[Se]"], [
        e,
        t,
        n,
        T,
        Je,
        M
    ]), fe = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Qs.useMemo[fe]": ()=>h(Se)
    }["Qs.useMemo[fe]"], [
        Se,
        h
    ]), [Ln, Tt] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(fe);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Qs.useEffect": ()=>{
            t === "streaming" && !ge ? U({
                "Qs.useEffect": ()=>{
                    Tt(fe);
                }
            }["Qs.useEffect"]) : Tt(fe);
        }
    }["Qs.useEffect"], [
        fe,
        t
    ]);
    let J = t === "streaming" ? Ln : fe, Ke = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Qs.useMemo[Ke]": ()=>o === "auto" ? J.map($e) : void 0
    }["Qs.useMemo[Ke]"], [
        J,
        o
    ]), Rn = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Qs.useMemo[Rn]": ()=>J.map({
                "Qs.useMemo[Rn]": (k, A)=>`${_}-${A}`
            }["Qs.useMemo[Rn]"])
    }["Qs.useMemo[Rn]"], [
        J.length,
        _
    ]), Ue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Qs.useMemo[Ue]": ()=>u === true ? "true" : u ? JSON.stringify(u) : ""
    }["Qs.useMemo[Ue]"], [
        u
    ]), ge = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Qs.useMemo[ge]": ()=>Ue ? Ue === "true" ? be() : be(u) : null
    }["Qs.useMemo[ge]"], [
        Ue
    ]), Pt = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Qs.useMemo[Pt]": ()=>{
            var k, A;
            return {
                shikiTheme: (A = (k = g == null ? void 0 : g.code) == null ? void 0 : k.getThemes()) != null ? A : d,
                controls: p,
                isAnimating: m,
                lineNumbers: w,
                mode: t,
                mermaid: c,
                linkSafety: v
            };
        }
    }["Qs.useMemo[Pt]"], [
        d,
        p,
        m,
        w,
        t,
        c,
        v,
        g == null ? void 0 : g.code
    ]), Sn = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Qs.useMemo[Sn]": ()=>H ? JSON.stringify(H) : ""
    }["Qs.useMemo[Sn]"], [
        H
    ]), Mt = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Qs.useMemo[Mt]": ()=>({
                ...De,
                ...H
            })
    }["Qs.useMemo[Mt]"], [
        Sn
    ]), It = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Qs.useMemo[It]": ()=>{
            let { inlineCode: k, ...A } = s != null ? s : {}, K = {
                ...Ko,
                ...A
            };
            if (k) {
                let ee = K.code;
                K.code = ({
                    "Qs.useMemo[It]": (ie)=>"data-block" in ie ? ee ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(ee, ie) : null : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(k, ie)
                })["Qs.useMemo[It]"];
            }
            return K;
        }
    }["Qs.useMemo[It]"], [
        s
    ]), Nt = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Qs.useMemo[Nt]": ()=>{
            let k = [];
            return g != null && g.cjk && (k = [
                ...k,
                ...g.cjk.remarkPluginsBefore
            ]), k = [
                ...k,
                ...l
            ], g != null && g.cjk && (k = [
                ...k,
                ...g.cjk.remarkPluginsAfter
            ]), g != null && g.math && (k = [
                ...k,
                g.math.remarkPlugin
            ]), k;
        }
    }["Qs.useMemo[Nt]"], [
        l,
        g == null ? void 0 : g.math,
        g == null ? void 0 : g.cjk
    ]), Lt = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Qs.useMemo[Lt]": ()=>{
            var A;
            let k = a;
            if (P && Object.keys(P).length > 0 && a === gn) {
                let K = {
                    ...Ze,
                    tagNames: [
                        ...(A = Ze.tagNames) != null ? A : [],
                        ...Object.keys(P)
                    ],
                    attributes: {
                        ...Ze.attributes,
                        ...P
                    }
                };
                k = [
                    xt.raw,
                    [
                        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$rehype$2d$sanitize$40$6$2e$0$2e$0$2f$node_modules$2f$rehype$2d$sanitize$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
                        K
                    ],
                    xt.harden
                ];
            }
            return M && M.length > 0 && (k = [
                ...k,
                [
                    mn,
                    M
                ]
            ]), g != null && g.math && (k = [
                ...k,
                g.math.rehypePlugin
            ]), ge && m && (k = [
                ...k,
                ge.rehypePlugin
            ]), k;
        }
    }["Qs.useMemo[Lt]"], [
        a,
        g == null ? void 0 : g.math,
        ge,
        m,
        P,
        M
    ]), Ge = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Qs.useMemo[Ge]": ()=>{
            if (!m || J.length === 0) return false;
            let k = J.at(-1);
            return ht(k) || Uo(k);
        }
    }["Qs.useMemo[Ge]"], [
        m,
        J
    ]), En = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Qs.useMemo[En]": ()=>b && m && !Ge ? {
                "--streamdown-caret": `"${Gs[b]}"`
            } : void 0
    }["Qs.useMemo[En]"], [
        b,
        m,
        Ge
    ]);
    return t === "static" ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Be.Provider, {
        value: Mt,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Ve.Provider, {
            value: g != null ? g : null,
            children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(R.Provider, {
                value: Pt,
                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(at, {
                    icons: S,
                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Ee.Provider, {
                        value: x,
                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                            className: x("space-y-4 whitespace-normal [&>*:first-child]:mt-0 [&>*:last-child]:mb-0", i),
                            dir: o === "auto" ? $e(Se) : o,
                            children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Ct, {
                                components: It,
                                rehypePlugins: Lt,
                                remarkPlugins: Nt,
                                ...B,
                                children: Se
                            })
                        })
                    })
                })
            })
        })
    }) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Be.Provider, {
        value: Mt,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Ve.Provider, {
            value: g != null ? g : null,
            children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(R.Provider, {
                value: Pt,
                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(at, {
                    icons: S,
                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Ee.Provider, {
                        value: x,
                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                            className: x("space-y-4 whitespace-normal [&>*:first-child]:mt-0 [&>*:last-child]:mb-0", b && !Ge ? "[&>*:last-child]:after:inline [&>*:last-child]:after:align-baseline [&>*:last-child]:after:content-[var(--streamdown-caret)]" : null, i),
                            style: En,
                            children: [
                                J.length === 0 && b && m && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {}),
                                J.map((k, A)=>{
                                    var ie;
                                    let K = A === J.length - 1, ee = m && K && ht(k);
                                    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(f, {
                                        animatePlugin: ge,
                                        components: It,
                                        content: k,
                                        dir: (ie = Ke == null ? void 0 : Ke[A]) != null ? ie : o !== "auto" ? o : void 0,
                                        index: A,
                                        isIncomplete: ee,
                                        rehypePlugins: Lt,
                                        remarkPlugins: Nt,
                                        shouldNormalizeHtmlIndentation: r,
                                        shouldParseIncompleteMarkdown: n,
                                        ...B
                                    }, Rn[A]);
                                })
                            ]
                        })
                    })
                })
            })
        })
    });
}, (e, t)=>e.children === t.children && e.shikiTheme === t.shikiTheme && e.isAnimating === t.isAnimating && e.animated === t.animated && e.mode === t.mode && e.plugins === t.plugins && e.className === t.className && e.linkSafety === t.linkSafety && e.lineNumbers === t.lineNumbers && e.normalizeHtmlIndentation === t.normalizeHtmlIndentation && e.literalTagContent === t.literalTagContent && JSON.stringify(e.translations) === JSON.stringify(t.translations) && e.prefix === t.prefix && e.dir === t.dir);
Qs.displayName = "Streamdown";
var Nn = ({ children: e, className: t, minZoom: o = .5, maxZoom: n = 3, zoomStep: r = .1, showControls: s = true, initialZoom: a = 1, fullscreen: l = false })=>{
    let { RotateCcwIcon: i, ZoomInIcon: d, ZoomOutIcon: c } = L(), p = y(), m = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), u = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), [f, h] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(a), [b, g] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        x: 0,
        y: 0
    }), [T, v] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false), [w, P] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        x: 0,
        y: 0
    }), [M, H] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        x: 0,
        y: 0
    }), S = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Nn.useCallback[S]": (x)=>{
            h({
                "Nn.useCallback[S]": (q)=>Math.max(o, Math.min(n, q + x))
            }["Nn.useCallback[S]"]);
        }
    }["Nn.useCallback[S]"], [
        o,
        n
    ]), F = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Nn.useCallback[F]": ()=>{
            S(r);
        }
    }["Nn.useCallback[F]"], [
        S,
        r
    ]), j = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Nn.useCallback[j]": ()=>{
            S(-r);
        }
    }["Nn.useCallback[j]"], [
        S,
        r
    ]), z = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Nn.useCallback[z]": ()=>{
            h(a), g({
                x: 0,
                y: 0
            });
        }
    }["Nn.useCallback[z]"], [
        a
    ]), B = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Nn.useCallback[B]": (x)=>{
            x.preventDefault();
            let q = x.deltaY > 0 ? -r : r;
            S(q);
        }
    }["Nn.useCallback[B]"], [
        S,
        r
    ]), _ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Nn.useCallback[_]": (x)=>{
            if (x.button !== 0 || x.isPrimary === false) return;
            v(true), P({
                x: x.clientX,
                y: x.clientY
            }), H(b);
            let q = x.currentTarget;
            q instanceof HTMLElement && q.setPointerCapture(x.pointerId);
        }
    }["Nn.useCallback[_]"], [
        b
    ]), Q = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Nn.useCallback[Q]": (x)=>{
            if (!T) return;
            x.preventDefault();
            let q = x.clientX - w.x, X = x.clientY - w.y;
            g({
                x: M.x + q,
                y: M.y + X
            });
        }
    }["Nn.useCallback[Q]"], [
        T,
        w,
        M
    ]), U = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Nn.useCallback[U]": (x)=>{
            v(false);
            let q = x.currentTarget;
            q instanceof HTMLElement && q.releasePointerCapture(x.pointerId);
        }
    }["Nn.useCallback[U]"], []);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Nn.useEffect": ()=>{
            let x = m.current;
            if (x) return x.addEventListener("wheel", B, {
                passive: false
            }), ({
                "Nn.useEffect": ()=>{
                    x.removeEventListener("wheel", B);
                }
            })["Nn.useEffect"];
        }
    }["Nn.useEffect"], [
        B
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Nn.useEffect": ()=>{
            let x = u.current;
            if (x && T) return document.body.style.userSelect = "none", x.addEventListener("pointermove", Q, {
                passive: false
            }), x.addEventListener("pointerup", U), x.addEventListener("pointercancel", U), ({
                "Nn.useEffect": ()=>{
                    document.body.style.userSelect = "", x.removeEventListener("pointermove", Q), x.removeEventListener("pointerup", U), x.removeEventListener("pointercancel", U);
                }
            })["Nn.useEffect"];
        }
    }["Nn.useEffect"], [
        T,
        Q,
        U
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
        className: p("relative flex flex-col", l ? "h-full w-full" : "min-h-28 w-full", t),
        ref: m,
        style: {
            cursor: T ? "grabbing" : "grab"
        },
        children: [
            s ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                className: p("absolute z-10 flex flex-col gap-1 rounded-md border border-border bg-background/80 p-1 supports-[backdrop-filter]:bg-background/70 supports-[backdrop-filter]:backdrop-blur-sm", l ? "bottom-4 left-4" : "bottom-2 left-2"),
                children: [
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                        className: p("flex items-center justify-center rounded p-1.5 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground disabled:cursor-not-allowed disabled:opacity-50"),
                        disabled: f >= n,
                        onClick: F,
                        title: "Zoom in",
                        type: "button",
                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(d, {
                            size: 16
                        })
                    }),
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                        className: p("flex items-center justify-center rounded p-1.5 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground disabled:cursor-not-allowed disabled:opacity-50"),
                        disabled: f <= o,
                        onClick: j,
                        title: "Zoom out",
                        type: "button",
                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(c, {
                            size: 16
                        })
                    }),
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                        className: p("flex items-center justify-center rounded p-1.5 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"),
                        onClick: z,
                        title: "Reset zoom and pan",
                        type: "button",
                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(i, {
                            size: 16
                        })
                    })
                ]
            }) : null,
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                className: p("flex-1 origin-center transition-transform duration-150 ease-out", l ? "flex h-full w-full items-center justify-center" : "flex w-full items-center justify-center"),
                onPointerDown: _,
                ref: u,
                role: "application",
                style: {
                    transform: `translate(${b.x}px, ${b.y}px) scale(${f})`,
                    transformOrigin: "center center",
                    touchAction: "none",
                    willChange: "transform"
                },
                children: e
            })
        ]
    });
};
var po = ({ chart: e, className: t, config: o, fullscreen: n = false, showControls: r = true })=>{
    let s = y(), [a, l] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null), [i, d] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false), [c, p] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(""), [m, u] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(""), [f, h] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0), { mermaid: b } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(R), g = de(), T = b == null ? void 0 : b.errorComponent, { shouldRender: v, containerRef: w } = Rt({
        immediate: n
    });
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "po.useEffect": ()=>{
            if (!v) return;
            if (!g) {
                l("Mermaid plugin not available. Please add the mermaid plugin to enable diagram rendering.");
                return;
            }
            ({
                "po.useEffect": async ()=>{
                    try {
                        l(null), d(!0);
                        let H = g.getMermaid(o), S = e.split("").reduce({
                            "po.useEffect.S": (z, B)=>(z << 5) - z + B.charCodeAt(0) | 0
                        }["po.useEffect.S"], 0), F = `mermaid-${Math.abs(S)}-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`, { svg: j } = await H.render(F, e);
                        p(j), u(j);
                    } catch (H) {
                        if (!(m || c)) {
                            let S = H instanceof Error ? H.message : "Failed to render Mermaid chart";
                            l(S);
                        }
                    } finally{
                        d(false);
                    }
                }
            })["po.useEffect"]();
        }
    }["po.useEffect"], [
        e,
        o,
        f,
        v,
        g
    ]), !(v || c || m)) return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
        className: s("my-4 min-h-[200px]", t),
        ref: w
    });
    if (i && !c && !m) return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
        className: s("my-4 flex justify-center p-4", t),
        ref: w,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
            className: s("flex items-center space-x-2 text-muted-foreground"),
            children: [
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                    className: s("h-4 w-4 animate-spin rounded-full border-current border-b-2")
                }),
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
                    className: s("text-sm"),
                    children: "Loading diagram..."
                })
            ]
        })
    });
    if (a && !c && !m) {
        let M = ()=>h((H)=>H + 1);
        return T ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
            ref: w,
            children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(T, {
                chart: e,
                error: a,
                retry: M
            })
        }) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
            className: s("rounded-md bg-red-50 p-4", t),
            ref: w,
            children: [
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("p", {
                    className: s("font-mono text-red-700 text-sm"),
                    children: [
                        "Mermaid Error: ",
                        a
                    ]
                }),
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("details", {
                    className: s("mt-2"),
                    children: [
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("summary", {
                            className: s("cursor-pointer text-red-600 text-xs"),
                            children: "Show Code"
                        }),
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("pre", {
                            className: s("mt-2 overflow-x-auto rounded bg-red-100 p-2 text-red-800 text-xs"),
                            children: e
                        })
                    ]
                })
            ]
        });
    }
    let P = c || m;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
        className: s("size-full", t),
        "data-streamdown": "mermaid",
        ref: w,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Nn, {
            className: s(n ? "size-full overflow-hidden" : "overflow-hidden", t),
            fullscreen: n,
            maxZoom: 3,
            minZoom: .5,
            showControls: r,
            zoomStep: .1,
            children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$2_$40$babel$2b$core$40$7$2e$29$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$d_00302af571a966878a6c3f1b2db86a61$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                "aria-label": "Mermaid chart",
                className: s("flex justify-center", n ? "size-full items-center" : null),
                dangerouslySetInnerHTML: {
                    __html: P
                },
                role: "img"
            })
        })
    });
};
;
}),
"[project]/node_modules/.pnpm/streamdown@2.5.0_react-dom@19.2.4_react@19.2.4__react@19.2.4/node_modules/streamdown/dist/index.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$streamdown$40$2$2e$5$2e$0_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$streamdown$2f$dist$2f$chunk$2d$BO2N2NFS$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/streamdown@2.5.0_react-dom@19.2.4_react@19.2.4__react@19.2.4/node_modules/streamdown/dist/chunk-BO2N2NFS.js [app-client] (ecmascript)");
"use client";
;
}),
"[project]/node_modules/.pnpm/streamdown@2.5.0_react-dom@19.2.4_react@19.2.4__react@19.2.4/node_modules/streamdown/dist/chunk-BO2N2NFS.js [app-client] (ecmascript) <export C as Streamdown>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Streamdown",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$streamdown$40$2$2e$5$2e$0_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$streamdown$2f$dist$2f$chunk$2d$BO2N2NFS$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["C"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$streamdown$40$2$2e$5$2e$0_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$streamdown$2f$dist$2f$chunk$2d$BO2N2NFS$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/streamdown@2.5.0_react-dom@19.2.4_react@19.2.4__react@19.2.4/node_modules/streamdown/dist/chunk-BO2N2NFS.js [app-client] (ecmascript)");
}),
]);

//# sourceMappingURL=04y0_streamdown_dist_0.9wuro._.js.map