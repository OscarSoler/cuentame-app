(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/next/dist/compiled/react/cjs/react-jsx-dev-runtime.development.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
/**
 * @license React
 * react-jsx-dev-runtime.development.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ "use strict";
"production" !== ("TURBOPACK compile-time value", "development") && function() {
    function getComponentNameFromType(type) {
        if (null == type) return null;
        if ("function" === typeof type) return type.$$typeof === REACT_CLIENT_REFERENCE ? null : type.displayName || type.name || null;
        if ("string" === typeof type) return type;
        switch(type){
            case REACT_FRAGMENT_TYPE:
                return "Fragment";
            case REACT_PROFILER_TYPE:
                return "Profiler";
            case REACT_STRICT_MODE_TYPE:
                return "StrictMode";
            case REACT_SUSPENSE_TYPE:
                return "Suspense";
            case REACT_SUSPENSE_LIST_TYPE:
                return "SuspenseList";
            case REACT_ACTIVITY_TYPE:
                return "Activity";
            case REACT_VIEW_TRANSITION_TYPE:
                return "ViewTransition";
        }
        if ("object" === typeof type) switch("number" === typeof type.tag && console.error("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."), type.$$typeof){
            case REACT_PORTAL_TYPE:
                return "Portal";
            case REACT_CONTEXT_TYPE:
                return type.displayName || "Context";
            case REACT_CONSUMER_TYPE:
                return (type._context.displayName || "Context") + ".Consumer";
            case REACT_FORWARD_REF_TYPE:
                var innerType = type.render;
                type = type.displayName;
                type || (type = innerType.displayName || innerType.name || "", type = "" !== type ? "ForwardRef(" + type + ")" : "ForwardRef");
                return type;
            case REACT_MEMO_TYPE:
                return innerType = type.displayName || null, null !== innerType ? innerType : getComponentNameFromType(type.type) || "Memo";
            case REACT_LAZY_TYPE:
                innerType = type._payload;
                type = type._init;
                try {
                    return getComponentNameFromType(type(innerType));
                } catch (x) {}
        }
        return null;
    }
    function testStringCoercion(value) {
        return "" + value;
    }
    function checkKeyStringCoercion(value) {
        try {
            testStringCoercion(value);
            var JSCompiler_inline_result = !1;
        } catch (e) {
            JSCompiler_inline_result = !0;
        }
        if (JSCompiler_inline_result) {
            JSCompiler_inline_result = console;
            var JSCompiler_temp_const = JSCompiler_inline_result.error;
            var JSCompiler_inline_result$jscomp$0 = "function" === typeof Symbol && Symbol.toStringTag && value[Symbol.toStringTag] || value.constructor.name || "Object";
            JSCompiler_temp_const.call(JSCompiler_inline_result, "The provided key is an unsupported type %s. This value must be coerced to a string before using it here.", JSCompiler_inline_result$jscomp$0);
            return testStringCoercion(value);
        }
    }
    function getTaskName(type) {
        if (type === REACT_FRAGMENT_TYPE) return "<>";
        if ("object" === typeof type && null !== type && type.$$typeof === REACT_LAZY_TYPE) return "<...>";
        try {
            var name = getComponentNameFromType(type);
            return name ? "<" + name + ">" : "<...>";
        } catch (x) {
            return "<...>";
        }
    }
    function getOwner() {
        var dispatcher = ReactSharedInternals.A;
        return null === dispatcher ? null : dispatcher.getOwner();
    }
    function UnknownOwner() {
        return Error("react-stack-top-frame");
    }
    function hasValidKey(config) {
        if (hasOwnProperty.call(config, "key")) {
            var getter = Object.getOwnPropertyDescriptor(config, "key").get;
            if (getter && getter.isReactWarning) return !1;
        }
        return void 0 !== config.key;
    }
    function defineKeyPropWarningGetter(props, displayName) {
        function warnAboutAccessingKey() {
            specialPropKeyWarningShown || (specialPropKeyWarningShown = !0, console.error("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://react.dev/link/special-props)", displayName));
        }
        warnAboutAccessingKey.isReactWarning = !0;
        Object.defineProperty(props, "key", {
            get: warnAboutAccessingKey,
            configurable: !0
        });
    }
    function elementRefGetterWithDeprecationWarning() {
        var componentName = getComponentNameFromType(this.type);
        didWarnAboutElementRef[componentName] || (didWarnAboutElementRef[componentName] = !0, console.error("Accessing element.ref was removed in React 19. ref is now a regular prop. It will be removed from the JSX Element type in a future release."));
        componentName = this.props.ref;
        return void 0 !== componentName ? componentName : null;
    }
    function ReactElement(type, key, props, owner, debugStack, debugTask) {
        var refProp = props.ref;
        type = {
            $$typeof: REACT_ELEMENT_TYPE,
            type: type,
            key: key,
            props: props,
            _owner: owner
        };
        null !== (void 0 !== refProp ? refProp : null) ? Object.defineProperty(type, "ref", {
            enumerable: !1,
            get: elementRefGetterWithDeprecationWarning
        }) : Object.defineProperty(type, "ref", {
            enumerable: !1,
            value: null
        });
        type._store = {};
        Object.defineProperty(type._store, "validated", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: 0
        });
        Object.defineProperty(type, "_debugInfo", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: null
        });
        Object.defineProperty(type, "_debugStack", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: debugStack
        });
        Object.defineProperty(type, "_debugTask", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: debugTask
        });
        Object.freeze && (Object.freeze(type.props), Object.freeze(type));
        return type;
    }
    function jsxDEVImpl(type, config, maybeKey, isStaticChildren, debugStack, debugTask) {
        var children = config.children;
        if (void 0 !== children) if (isStaticChildren) if (isArrayImpl(children)) {
            for(isStaticChildren = 0; isStaticChildren < children.length; isStaticChildren++)validateChildKeys(children[isStaticChildren]);
            Object.freeze && Object.freeze(children);
        } else console.error("React.jsx: Static children should always be an array. You are likely explicitly calling React.jsxs or React.jsxDEV. Use the Babel transform instead.");
        else validateChildKeys(children);
        if (hasOwnProperty.call(config, "key")) {
            children = getComponentNameFromType(type);
            var keys = Object.keys(config).filter(function(k) {
                return "key" !== k;
            });
            isStaticChildren = 0 < keys.length ? "{key: someKey, " + keys.join(": ..., ") + ": ...}" : "{key: someKey}";
            didWarnAboutKeySpread[children + isStaticChildren] || (keys = 0 < keys.length ? "{" + keys.join(": ..., ") + ": ...}" : "{}", console.error('A props object containing a "key" prop is being spread into JSX:\n  let props = %s;\n  <%s {...props} />\nReact keys must be passed directly to JSX without using spread:\n  let props = %s;\n  <%s key={someKey} {...props} />', isStaticChildren, children, keys, children), didWarnAboutKeySpread[children + isStaticChildren] = !0);
        }
        children = null;
        void 0 !== maybeKey && (checkKeyStringCoercion(maybeKey), children = "" + maybeKey);
        hasValidKey(config) && (checkKeyStringCoercion(config.key), children = "" + config.key);
        if ("key" in config) {
            maybeKey = {};
            for(var propName in config)"key" !== propName && (maybeKey[propName] = config[propName]);
        } else maybeKey = config;
        children && defineKeyPropWarningGetter(maybeKey, "function" === typeof type ? type.displayName || type.name || "Unknown" : type);
        return ReactElement(type, children, maybeKey, getOwner(), debugStack, debugTask);
    }
    function validateChildKeys(node) {
        isValidElement(node) ? node._store && (node._store.validated = 1) : "object" === typeof node && null !== node && node.$$typeof === REACT_LAZY_TYPE && ("fulfilled" === node._payload.status ? isValidElement(node._payload.value) && node._payload.value._store && (node._payload.value._store.validated = 1) : node._store && (node._store.validated = 1));
    }
    function isValidElement(object) {
        return "object" === typeof object && null !== object && object.$$typeof === REACT_ELEMENT_TYPE;
    }
    var React = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"), REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element"), REACT_PORTAL_TYPE = Symbol.for("react.portal"), REACT_FRAGMENT_TYPE = Symbol.for("react.fragment"), REACT_STRICT_MODE_TYPE = Symbol.for("react.strict_mode"), REACT_PROFILER_TYPE = Symbol.for("react.profiler"), REACT_CONSUMER_TYPE = Symbol.for("react.consumer"), REACT_CONTEXT_TYPE = Symbol.for("react.context"), REACT_FORWARD_REF_TYPE = Symbol.for("react.forward_ref"), REACT_SUSPENSE_TYPE = Symbol.for("react.suspense"), REACT_SUSPENSE_LIST_TYPE = Symbol.for("react.suspense_list"), REACT_MEMO_TYPE = Symbol.for("react.memo"), REACT_LAZY_TYPE = Symbol.for("react.lazy"), REACT_ACTIVITY_TYPE = Symbol.for("react.activity"), REACT_VIEW_TRANSITION_TYPE = Symbol.for("react.view_transition"), REACT_CLIENT_REFERENCE = Symbol.for("react.client.reference"), ReactSharedInternals = React.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, hasOwnProperty = Object.prototype.hasOwnProperty, isArrayImpl = Array.isArray, createTask = console.createTask ? console.createTask : function() {
        return null;
    };
    React = {
        react_stack_bottom_frame: function(callStackForError) {
            return callStackForError();
        }
    };
    var specialPropKeyWarningShown;
    var didWarnAboutElementRef = {};
    var unknownOwnerDebugStack = React.react_stack_bottom_frame.bind(React, UnknownOwner)();
    var unknownOwnerDebugTask = createTask(getTaskName(UnknownOwner));
    var didWarnAboutKeySpread = {};
    exports.Fragment = REACT_FRAGMENT_TYPE;
    exports.jsxDEV = function(type, config, maybeKey, isStaticChildren) {
        var trackActualOwner = 1e4 > ReactSharedInternals.recentlyCreatedOwnerStacks++;
        if (trackActualOwner) {
            var previousStackTraceLimit = Error.stackTraceLimit;
            Error.stackTraceLimit = 10;
            var debugStackDEV = Error("react-stack-top-frame");
            Error.stackTraceLimit = previousStackTraceLimit;
        } else debugStackDEV = unknownOwnerDebugStack;
        return jsxDEVImpl(type, config, maybeKey, isStaticChildren, debugStackDEV, trackActualOwner ? createTask(getTaskName(type)) : unknownOwnerDebugTask);
    };
}();
}),
"[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use strict';
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
else {
    module.exports = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/cjs/react-jsx-dev-runtime.development.js [app-client] (ecmascript)");
}
}),
"[project]/node_modules/next/navigation.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = __turbopack_context__.r("[project]/node_modules/next/dist/client/components/navigation.js [app-client] (ecmascript)");
}),
"[project]/node_modules/@floating-ui/utils/dist/floating-ui.utils.dom.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getComputedStyle",
    ()=>getComputedStyle,
    "getContainingBlock",
    ()=>getContainingBlock,
    "getDocumentElement",
    ()=>getDocumentElement,
    "getFrameElement",
    ()=>getFrameElement,
    "getNearestOverflowAncestor",
    ()=>getNearestOverflowAncestor,
    "getNodeName",
    ()=>getNodeName,
    "getNodeScroll",
    ()=>getNodeScroll,
    "getOverflowAncestors",
    ()=>getOverflowAncestors,
    "getParentNode",
    ()=>getParentNode,
    "getWindow",
    ()=>getWindow,
    "isContainingBlock",
    ()=>isContainingBlock,
    "isElement",
    ()=>isElement,
    "isHTMLElement",
    ()=>isHTMLElement,
    "isLastTraversableNode",
    ()=>isLastTraversableNode,
    "isNode",
    ()=>isNode,
    "isOverflowElement",
    ()=>isOverflowElement,
    "isShadowRoot",
    ()=>isShadowRoot,
    "isTableElement",
    ()=>isTableElement,
    "isTopLayer",
    ()=>isTopLayer,
    "isWebKit",
    ()=>isWebKit
]);
function hasWindow() {
    return typeof window !== 'undefined';
}
function getNodeName(node) {
    if (isNode(node)) {
        return (node.nodeName || '').toLowerCase();
    }
    // Mocked nodes in testing environments may not be instances of Node. By
    // returning `#document` an infinite loop won't occur.
    // https://github.com/floating-ui/floating-ui/issues/2317
    return '#document';
}
function getWindow(node) {
    var _node$ownerDocument;
    return (node == null || (_node$ownerDocument = node.ownerDocument) == null ? void 0 : _node$ownerDocument.defaultView) || window;
}
function getDocumentElement(node) {
    var _ref;
    return (_ref = (isNode(node) ? node.ownerDocument : node.document) || window.document) == null ? void 0 : _ref.documentElement;
}
function isNode(value) {
    if (!hasWindow()) {
        return false;
    }
    return value instanceof Node || value instanceof getWindow(value).Node;
}
function isElement(value) {
    if (!hasWindow()) {
        return false;
    }
    return value instanceof Element || value instanceof getWindow(value).Element;
}
function isHTMLElement(value) {
    if (!hasWindow()) {
        return false;
    }
    return value instanceof HTMLElement || value instanceof getWindow(value).HTMLElement;
}
function isShadowRoot(value) {
    if (!hasWindow() || typeof ShadowRoot === 'undefined') {
        return false;
    }
    return value instanceof ShadowRoot || value instanceof getWindow(value).ShadowRoot;
}
function isOverflowElement(element) {
    const { overflow, overflowX, overflowY, display } = getComputedStyle(element);
    return /auto|scroll|overlay|hidden|clip/.test(overflow + overflowY + overflowX) && display !== 'inline' && display !== 'contents';
}
function isTableElement(element) {
    return /^(table|td|th)$/.test(getNodeName(element));
}
function isTopLayer(element) {
    try {
        if (element.matches(':popover-open')) {
            return true;
        }
    } catch (_e) {
    // no-op
    }
    try {
        return element.matches(':modal');
    } catch (_e) {
        return false;
    }
}
const willChangeRe = /transform|translate|scale|rotate|perspective|filter/;
const containRe = /paint|layout|strict|content/;
const isNotNone = (value)=>!!value && value !== 'none';
let isWebKitValue;
function isContainingBlock(elementOrCss) {
    const css = isElement(elementOrCss) ? getComputedStyle(elementOrCss) : elementOrCss;
    // https://developer.mozilla.org/en-US/docs/Web/CSS/Containing_block#identifying_the_containing_block
    // https://drafts.csswg.org/css-transforms-2/#individual-transforms
    return isNotNone(css.transform) || isNotNone(css.translate) || isNotNone(css.scale) || isNotNone(css.rotate) || isNotNone(css.perspective) || !isWebKit() && (isNotNone(css.backdropFilter) || isNotNone(css.filter)) || willChangeRe.test(css.willChange || '') || containRe.test(css.contain || '');
}
function getContainingBlock(element) {
    let currentNode = getParentNode(element);
    while(isHTMLElement(currentNode) && !isLastTraversableNode(currentNode)){
        if (isContainingBlock(currentNode)) {
            return currentNode;
        } else if (isTopLayer(currentNode)) {
            return null;
        }
        currentNode = getParentNode(currentNode);
    }
    return null;
}
function isWebKit() {
    if (isWebKitValue == null) {
        isWebKitValue = typeof CSS !== 'undefined' && CSS.supports && CSS.supports('-webkit-backdrop-filter', 'none');
    }
    return isWebKitValue;
}
function isLastTraversableNode(node) {
    return /^(html|body|#document)$/.test(getNodeName(node));
}
function getComputedStyle(element) {
    return getWindow(element).getComputedStyle(element);
}
function getNodeScroll(element) {
    if (isElement(element)) {
        return {
            scrollLeft: element.scrollLeft,
            scrollTop: element.scrollTop
        };
    }
    return {
        scrollLeft: element.scrollX,
        scrollTop: element.scrollY
    };
}
function getParentNode(node) {
    if (getNodeName(node) === 'html') {
        return node;
    }
    const result = // Step into the shadow DOM of the parent of a slotted node.
    node.assignedSlot || // DOM Element detected.
    node.parentNode || // ShadowRoot detected.
    isShadowRoot(node) && node.host || // Fallback.
    getDocumentElement(node);
    return isShadowRoot(result) ? result.host : result;
}
function getNearestOverflowAncestor(node) {
    const parentNode = getParentNode(node);
    if (isLastTraversableNode(parentNode)) {
        return node.ownerDocument ? node.ownerDocument.body : node.body;
    }
    if (isHTMLElement(parentNode) && isOverflowElement(parentNode)) {
        return parentNode;
    }
    return getNearestOverflowAncestor(parentNode);
}
function getOverflowAncestors(node, list, traverseIframes) {
    var _node$ownerDocument2;
    if (list === void 0) {
        list = [];
    }
    if (traverseIframes === void 0) {
        traverseIframes = true;
    }
    const scrollableAncestor = getNearestOverflowAncestor(node);
    const isBody = scrollableAncestor === ((_node$ownerDocument2 = node.ownerDocument) == null ? void 0 : _node$ownerDocument2.body);
    const win = getWindow(scrollableAncestor);
    if (isBody) {
        const frameElement = getFrameElement(win);
        return list.concat(win, win.visualViewport || [], isOverflowElement(scrollableAncestor) ? scrollableAncestor : [], frameElement && traverseIframes ? getOverflowAncestors(frameElement) : []);
    } else {
        return list.concat(scrollableAncestor, getOverflowAncestors(scrollableAncestor, [], traverseIframes));
    }
}
function getFrameElement(win) {
    return win.parent && Object.getPrototypeOf(win.parent) ? win.frameElement : null;
}
;
}),
"[project]/node_modules/@base-ui/utils/esm/useRefWithInit.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useRefWithInit",
    ()=>useRefWithInit
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
'use client';
;
const UNINITIALIZED = {};
function useRefWithInit(init, initArg) {
    const ref = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](UNINITIALIZED);
    if (ref.current === UNINITIALIZED) {
        ref.current = init(initArg);
    }
    return ref;
}
}),
"[project]/node_modules/@base-ui/utils/esm/useStableCallback.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useStableCallback",
    ()=>useStableCallback
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useRefWithInit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/useRefWithInit.js [app-client] (ecmascript)");
'use client';
;
;
// https://github.com/mui/material-ui/issues/41190#issuecomment-2040873379
const useInsertionEffect = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__[`useInsertionEffect${Math.random().toFixed(1)}`.slice(0, -3)];
const useSafeInsertionEffect = // React 17 doesn't have useInsertionEffect.
useInsertionEffect && // Preact replaces useInsertionEffect with useLayoutEffect and fires too late.
useInsertionEffect !== __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.useLayoutEffect ? useInsertionEffect : (fn)=>fn();
function useStableCallback(callback) {
    const stable = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useRefWithInit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRefWithInit"])(createStableCallback).current;
    stable.next = callback;
    useSafeInsertionEffect(stable.effect);
    return stable.trampoline;
}
function createStableCallback() {
    const stable = {
        next: undefined,
        callback: assertNotCalled,
        trampoline: (...args)=>stable.callback?.(...args),
        effect: ()=>{
            stable.callback = stable.next;
        }
    };
    return stable;
}
function assertNotCalled() {
    if ("TURBOPACK compile-time truthy", 1) {
        throw /* minify-error-disabled */ new Error('Base UI: Cannot call an event handler while rendering.');
    }
}
}),
"[project]/node_modules/@base-ui/utils/esm/error.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "error",
    ()=>error,
    "reset",
    ()=>reset
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
let set;
if ("TURBOPACK compile-time truthy", 1) {
    set = new Set();
}
function error(...messages) {
    if ("TURBOPACK compile-time truthy", 1) {
        const messageKey = messages.join(' ');
        if (!set.has(messageKey)) {
            set.add(messageKey);
            console.error(`Base UI: ${messageKey}`);
        }
    }
}
function reset() {
    set?.clear();
}
}),
"[project]/node_modules/@base-ui/utils/esm/safeReact.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SafeReact",
    ()=>SafeReact
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
const SafeReact = {
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__
};
}),
"[project]/node_modules/@base-ui/utils/esm/useIsoLayoutEffect.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useIsoLayoutEffect",
    ()=>useIsoLayoutEffect
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
'use client';
;
const noop = ()=>{};
const useIsoLayoutEffect = typeof document !== 'undefined' ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"] : noop;
}),
"[project]/node_modules/@base-ui/utils/esm/mergeObjects.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "mergeObjects",
    ()=>mergeObjects
]);
function mergeObjects(a, b) {
    if (a && !b) {
        return a;
    }
    if (!a && b) {
        return b;
    }
    if (a || b) {
        return {
            ...a,
            ...b
        };
    }
    return undefined;
}
}),
"[project]/node_modules/@base-ui/react/esm/merge-props/mergeProps.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "makeEventPreventable",
    ()=>makeEventPreventable,
    "mergeClassNames",
    ()=>mergeClassNames,
    "mergeProps",
    ()=>mergeProps,
    "mergePropsN",
    ()=>mergePropsN
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$mergeObjects$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/mergeObjects.js [app-client] (ecmascript)");
;
const EMPTY_PROPS = {};
function mergeProps(a, b, c, d, e) {
    // We need to mutably own `merged`
    let merged = {
        ...resolvePropsGetter(a, EMPTY_PROPS)
    };
    if (b) {
        merged = mergeOne(merged, b);
    }
    if (c) {
        merged = mergeOne(merged, c);
    }
    if (d) {
        merged = mergeOne(merged, d);
    }
    if (e) {
        merged = mergeOne(merged, e);
    }
    return merged;
}
function mergePropsN(props) {
    if (props.length === 0) {
        return EMPTY_PROPS;
    }
    if (props.length === 1) {
        return resolvePropsGetter(props[0], EMPTY_PROPS);
    }
    // We need to mutably own `merged`
    let merged = {
        ...resolvePropsGetter(props[0], EMPTY_PROPS)
    };
    for(let i = 1; i < props.length; i += 1){
        merged = mergeOne(merged, props[i]);
    }
    return merged;
}
function mergeOne(merged, inputProps) {
    if (isPropsGetter(inputProps)) {
        return inputProps(merged);
    }
    return mutablyMergeInto(merged, inputProps);
}
/**
 * Merges two sets of props. In case of conflicts, the external props take precedence.
 */ function mutablyMergeInto(mergedProps, externalProps) {
    if (!externalProps) {
        return mergedProps;
    }
    // eslint-disable-next-line guard-for-in
    for(const propName in externalProps){
        const externalPropValue = externalProps[propName];
        switch(propName){
            case 'style':
                {
                    mergedProps[propName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$mergeObjects$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeObjects"])(mergedProps.style, externalPropValue);
                    break;
                }
            case 'className':
                {
                    mergedProps[propName] = mergeClassNames(mergedProps.className, externalPropValue);
                    break;
                }
            default:
                {
                    if (isEventHandler(propName, externalPropValue)) {
                        mergedProps[propName] = mergeEventHandlers(mergedProps[propName], externalPropValue);
                    } else {
                        mergedProps[propName] = externalPropValue;
                    }
                }
        }
    }
    return mergedProps;
}
function isEventHandler(key, value) {
    // This approach is more efficient than using a regex.
    const code0 = key.charCodeAt(0);
    const code1 = key.charCodeAt(1);
    const code2 = key.charCodeAt(2);
    return code0 === 111 /* o */  && code1 === 110 /* n */  && code2 >= 65 /* A */  && code2 <= 90 /* Z */  && (typeof value === 'function' || typeof value === 'undefined');
}
function isPropsGetter(inputProps) {
    return typeof inputProps === 'function';
}
function resolvePropsGetter(inputProps, previousProps) {
    if (isPropsGetter(inputProps)) {
        return inputProps(previousProps);
    }
    return inputProps ?? EMPTY_PROPS;
}
function mergeEventHandlers(ourHandler, theirHandler) {
    if (!theirHandler) {
        return ourHandler;
    }
    if (!ourHandler) {
        return theirHandler;
    }
    return (event)=>{
        if (isSyntheticEvent(event)) {
            const baseUIEvent = event;
            makeEventPreventable(baseUIEvent);
            const result = theirHandler(baseUIEvent);
            if (!baseUIEvent.baseUIHandlerPrevented) {
                ourHandler?.(baseUIEvent);
            }
            return result;
        }
        const result = theirHandler(event);
        ourHandler?.(event);
        return result;
    };
}
function makeEventPreventable(event) {
    event.preventBaseUIHandler = ()=>{
        event.baseUIHandlerPrevented = true;
    };
    return event;
}
function mergeClassNames(ourClassName, theirClassName) {
    if (theirClassName) {
        if (ourClassName) {
            // eslint-disable-next-line prefer-template
            return theirClassName + ' ' + ourClassName;
        }
        return theirClassName;
    }
    return ourClassName;
}
function isSyntheticEvent(event) {
    return event != null && typeof event === 'object' && 'nativeEvent' in event;
}
}),
"[project]/node_modules/@base-ui/react/esm/composite/root/CompositeRootContext.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CompositeRootContext",
    ()=>CompositeRootContext,
    "useCompositeRootContext",
    ()=>useCompositeRootContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
'use client';
;
;
const CompositeRootContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](undefined);
if ("TURBOPACK compile-time truthy", 1) CompositeRootContext.displayName = "CompositeRootContext";
function useCompositeRootContext(optional = false) {
    const context = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](CompositeRootContext);
    if (context === undefined && !optional) {
        throw new Error(("TURBOPACK compile-time truthy", 1) ? 'Base UI: CompositeRootContext is missing. Composite parts must be placed within <Composite.Root>.' : "TURBOPACK unreachable");
    }
    return context;
}
}),
"[project]/node_modules/@base-ui/react/esm/utils/useFocusableWhenDisabled.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useFocusableWhenDisabled",
    ()=>useFocusableWhenDisabled
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
'use client';
;
function useFocusableWhenDisabled(parameters) {
    const { focusableWhenDisabled, disabled, composite = false, tabIndex: tabIndexProp = 0, isNativeButton } = parameters;
    const isFocusableComposite = composite && focusableWhenDisabled !== false;
    const isNonFocusableComposite = composite && focusableWhenDisabled === false;
    // we can't explicitly assign `undefined` to any of these props because it
    // would otherwise prevent subsequently merged props from setting them
    const props = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "useFocusableWhenDisabled.useMemo[props]": ()=>{
            const additionalProps = {
                // allow Tabbing away from focusableWhenDisabled elements
                onKeyDown (event) {
                    if (disabled && focusableWhenDisabled && event.key !== 'Tab') {
                        event.preventDefault();
                    }
                }
            };
            if (!composite) {
                additionalProps.tabIndex = tabIndexProp;
                if (!isNativeButton && disabled) {
                    additionalProps.tabIndex = focusableWhenDisabled ? tabIndexProp : -1;
                }
            }
            if (isNativeButton && (focusableWhenDisabled || isFocusableComposite) || !isNativeButton && disabled) {
                additionalProps['aria-disabled'] = disabled;
            }
            if (isNativeButton && (!focusableWhenDisabled || isNonFocusableComposite)) {
                additionalProps.disabled = disabled;
            }
            return additionalProps;
        }
    }["useFocusableWhenDisabled.useMemo[props]"], [
        composite,
        disabled,
        focusableWhenDisabled,
        isFocusableComposite,
        isNonFocusableComposite,
        isNativeButton,
        tabIndexProp
    ]);
    return {
        props
    };
}
}),
"[project]/node_modules/@base-ui/react/esm/use-button/useButton.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useButton",
    ()=>useButton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@floating-ui/utils/dist/floating-ui.utils.dom.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useStableCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/useStableCallback.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$error$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/error.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$safeReact$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/safeReact.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useIsoLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/useIsoLayoutEffect.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$merge$2d$props$2f$mergeProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/merge-props/mergeProps.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$composite$2f$root$2f$CompositeRootContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/composite/root/CompositeRootContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$useFocusableWhenDisabled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/utils/useFocusableWhenDisabled.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
function useButton(parameters = {}) {
    const { disabled = false, focusableWhenDisabled, tabIndex = 0, native: isNativeButton = true, composite: compositeProp } = parameters;
    const elementRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const compositeRootContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$composite$2f$root$2f$CompositeRootContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCompositeRootContext"])(true);
    const isCompositeItem = compositeProp ?? compositeRootContext !== undefined;
    const { props: focusableWhenDisabledProps } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$useFocusableWhenDisabled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFocusableWhenDisabled"])({
        focusableWhenDisabled,
        disabled,
        composite: isCompositeItem,
        tabIndex,
        isNativeButton
    });
    if ("TURBOPACK compile-time truthy", 1) {
        // eslint-disable-next-line react-hooks/rules-of-hooks
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
            "useButton.useEffect": ()=>{
                if (!elementRef.current) {
                    return;
                }
                const isButtonTag = isButtonElement(elementRef.current);
                if (isNativeButton) {
                    if (!isButtonTag) {
                        const ownerStackMessage = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$safeReact$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SafeReact"].captureOwnerStack?.() || '';
                        const message = 'A component that acts as a button expected a native <button> because the ' + '`nativeButton` prop is true. Rendering a non-<button> removes native button ' + 'semantics, which can impact forms and accessibility. Use a real <button> in the ' + '`render` prop, or set `nativeButton` to `false`.';
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$error$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["error"])(`${message}${ownerStackMessage}`);
                    }
                } else if (isButtonTag) {
                    const ownerStackMessage = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$safeReact$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SafeReact"].captureOwnerStack?.() || '';
                    const message = 'A component that acts as a button expected a non-<button> because the `nativeButton` ' + 'prop is false. Rendering a <button> keeps native behavior while Base UI applies ' + 'non-native attributes and handlers, which can add unintended extra attributes (such ' + 'as `role` or `aria-disabled`). Use a non-<button> in the `render` prop, or set ' + '`nativeButton` to `true`.';
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$error$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["error"])(`${message}${ownerStackMessage}`);
                }
            }
        }["useButton.useEffect"], [
            isNativeButton
        ]);
    }
    // handles a disabled composite button rendering another button, e.g.
    // <Toolbar.Button disabled render={<Menu.Trigger />} />
    // the `disabled` prop needs to pass through 2 `useButton`s then finally
    // delete the `disabled` attribute from DOM
    const updateDisabled = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "useButton.useCallback[updateDisabled]": ()=>{
            const element = elementRef.current;
            if (!isButtonElement(element)) {
                return;
            }
            if (isCompositeItem && disabled && focusableWhenDisabledProps.disabled === undefined && element.disabled) {
                element.disabled = false;
            }
        }
    }["useButton.useCallback[updateDisabled]"], [
        disabled,
        focusableWhenDisabledProps.disabled,
        isCompositeItem
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useIsoLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])(updateDisabled, [
        updateDisabled
    ]);
    const getButtonProps = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "useButton.useCallback[getButtonProps]": (externalProps = {})=>{
            const { onClick: externalOnClick, onMouseDown: externalOnMouseDown, onKeyUp: externalOnKeyUp, onKeyDown: externalOnKeyDown, onPointerDown: externalOnPointerDown, ...otherExternalProps } = externalProps;
            const type = isNativeButton ? 'button' : undefined;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$merge$2d$props$2f$mergeProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeProps"])({
                type,
                onClick (event) {
                    if (disabled) {
                        event.preventDefault();
                        return;
                    }
                    externalOnClick?.(event);
                },
                onMouseDown (event) {
                    if (!disabled) {
                        externalOnMouseDown?.(event);
                    }
                },
                onKeyDown (event) {
                    if (disabled) {
                        return;
                    }
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$merge$2d$props$2f$mergeProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["makeEventPreventable"])(event);
                    externalOnKeyDown?.(event);
                    if (event.baseUIHandlerPrevented) {
                        return;
                    }
                    const isCurrentTarget = event.target === event.currentTarget;
                    const currentTarget = event.currentTarget;
                    const isButton = isButtonElement(currentTarget);
                    const isLink = !isNativeButton && isValidLinkElement(currentTarget);
                    const shouldClick = isCurrentTarget && (isNativeButton ? isButton : !isLink);
                    const isEnterKey = event.key === 'Enter';
                    const isSpaceKey = event.key === ' ';
                    const role = currentTarget.getAttribute('role');
                    const isTextNavigationRole = role?.startsWith('menuitem') || role === 'option' || role === 'gridcell';
                    if (isCurrentTarget && isCompositeItem && isSpaceKey) {
                        if (event.defaultPrevented && isTextNavigationRole) {
                            return;
                        }
                        event.preventDefault();
                        if (isLink || isNativeButton && isButton) {
                            currentTarget.click();
                            event.preventBaseUIHandler();
                        } else if (shouldClick) {
                            externalOnClick?.(event);
                            event.preventBaseUIHandler();
                        }
                        return;
                    }
                    // Keyboard accessibility for native and non-native elements.
                    if (shouldClick) {
                        if (!isNativeButton && (isSpaceKey || isEnterKey)) {
                            event.preventDefault();
                        }
                        if (!isNativeButton && isEnterKey) {
                            externalOnClick?.(event);
                        }
                    }
                },
                onKeyUp (event) {
                    if (disabled) {
                        return;
                    }
                    // calling preventDefault in keyUp on a <button> will not dispatch a click event if Space is pressed
                    // https://codesandbox.io/p/sandbox/button-keyup-preventdefault-dn7f0
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$merge$2d$props$2f$mergeProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["makeEventPreventable"])(event);
                    externalOnKeyUp?.(event);
                    if (event.target === event.currentTarget && isNativeButton && isCompositeItem && isButtonElement(event.currentTarget) && event.key === ' ') {
                        event.preventDefault();
                        return;
                    }
                    if (event.baseUIHandlerPrevented) {
                        return;
                    }
                    // Keyboard accessibility for non interactive elements
                    if (event.target === event.currentTarget && !isNativeButton && !isCompositeItem && event.key === ' ') {
                        externalOnClick?.(event);
                    }
                },
                onPointerDown (event) {
                    if (disabled) {
                        event.preventDefault();
                        return;
                    }
                    externalOnPointerDown?.(event);
                }
            }, !isNativeButton ? {
                role: 'button'
            } : undefined, focusableWhenDisabledProps, otherExternalProps);
        }
    }["useButton.useCallback[getButtonProps]"], [
        disabled,
        focusableWhenDisabledProps,
        isCompositeItem,
        isNativeButton
    ]);
    const buttonRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useStableCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "useButton.useStableCallback[buttonRef]": (element)=>{
            elementRef.current = element;
            updateDisabled();
        }
    }["useButton.useStableCallback[buttonRef]"]);
    return {
        getButtonProps,
        buttonRef
    };
}
function isButtonElement(elem) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLElement"])(elem) && elem.tagName === 'BUTTON';
}
function isValidLinkElement(elem) {
    return Boolean(elem?.tagName === 'A' && elem?.href);
}
}),
"[project]/node_modules/@base-ui/utils/esm/useMergedRefs.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useMergedRefs",
    ()=>useMergedRefs,
    "useMergedRefsN",
    ()=>useMergedRefsN
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useRefWithInit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/useRefWithInit.js [app-client] (ecmascript)");
;
function useMergedRefs(a, b, c, d) {
    const forkRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useRefWithInit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRefWithInit"])(createForkRef).current;
    if (didChange(forkRef, a, b, c, d)) {
        update(forkRef, [
            a,
            b,
            c,
            d
        ]);
    }
    return forkRef.callback;
}
function useMergedRefsN(refs) {
    const forkRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useRefWithInit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRefWithInit"])(createForkRef).current;
    if (didChangeN(forkRef, refs)) {
        update(forkRef, refs);
    }
    return forkRef.callback;
}
function createForkRef() {
    return {
        callback: null,
        cleanup: null,
        refs: []
    };
}
function didChange(forkRef, a, b, c, d) {
    // prettier-ignore
    return forkRef.refs[0] !== a || forkRef.refs[1] !== b || forkRef.refs[2] !== c || forkRef.refs[3] !== d;
}
function didChangeN(forkRef, newRefs) {
    return forkRef.refs.length !== newRefs.length || forkRef.refs.some((ref, index)=>ref !== newRefs[index]);
}
function update(forkRef, refs) {
    forkRef.refs = refs;
    if (refs.every((ref)=>ref == null)) {
        forkRef.callback = null;
        return;
    }
    forkRef.callback = (instance)=>{
        if (forkRef.cleanup) {
            forkRef.cleanup();
            forkRef.cleanup = null;
        }
        if (instance != null) {
            const cleanupCallbacks = Array(refs.length).fill(null);
            for(let i = 0; i < refs.length; i += 1){
                const ref = refs[i];
                if (ref == null) {
                    continue;
                }
                switch(typeof ref){
                    case 'function':
                        {
                            const refCleanup = ref(instance);
                            if (typeof refCleanup === 'function') {
                                cleanupCallbacks[i] = refCleanup;
                            }
                            break;
                        }
                    case 'object':
                        {
                            ref.current = instance;
                            break;
                        }
                    default:
                }
            }
            forkRef.cleanup = ()=>{
                for(let i = 0; i < refs.length; i += 1){
                    const ref = refs[i];
                    if (ref == null) {
                        continue;
                    }
                    switch(typeof ref){
                        case 'function':
                            {
                                const cleanupCallback = cleanupCallbacks[i];
                                if (typeof cleanupCallback === 'function') {
                                    cleanupCallback();
                                } else {
                                    ref(null);
                                }
                                break;
                            }
                        case 'object':
                            {
                                ref.current = null;
                                break;
                            }
                        default:
                    }
                }
            };
        }
    };
}
}),
"[project]/node_modules/@base-ui/utils/esm/reactVersion.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isReactVersionAtLeast",
    ()=>isReactVersionAtLeast
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
const majorVersion = parseInt(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["version"], 10);
function isReactVersionAtLeast(reactVersionToCheck) {
    return majorVersion >= reactVersionToCheck;
}
}),
"[project]/node_modules/@base-ui/utils/esm/getReactElementRef.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getReactElementRef",
    ()=>getReactElementRef
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$reactVersion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/reactVersion.js [app-client] (ecmascript)");
;
;
function getReactElementRef(element) {
    if (!/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElement"](element)) {
        return null;
    }
    const reactElement = element;
    const propsWithRef = reactElement.props;
    return ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$reactVersion$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isReactVersionAtLeast"])(19) ? propsWithRef?.ref : reactElement.ref) ?? null;
}
}),
"[project]/node_modules/@base-ui/utils/esm/warn.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "warn",
    ()=>warn
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
let set;
if ("TURBOPACK compile-time truthy", 1) {
    set = new Set();
}
function warn(...messages) {
    if ("TURBOPACK compile-time truthy", 1) {
        const messageKey = messages.join(' ');
        if (!set.has(messageKey)) {
            set.add(messageKey);
            console.warn(`Base UI: ${messageKey}`);
        }
    }
}
}),
"[project]/node_modules/@base-ui/react/esm/utils/getStateAttributesProps.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getStateAttributesProps",
    ()=>getStateAttributesProps
]);
function getStateAttributesProps(state, customMapping) {
    const props = {};
    /* eslint-disable-next-line guard-for-in */ for(const key in state){
        const value = state[key];
        if (customMapping?.hasOwnProperty(key)) {
            const customProps = customMapping[key](value);
            if (customProps != null) {
                Object.assign(props, customProps);
            }
            continue;
        }
        if (value === true) {
            props[`data-${key.toLowerCase()}`] = '';
        } else if (value) {
            props[`data-${key.toLowerCase()}`] = value.toString();
        }
    }
    return props;
}
}),
"[project]/node_modules/@base-ui/react/esm/utils/resolveClassName.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * If the provided className is a string, it will be returned as is.
 * Otherwise, the function will call the className function with the state as the first argument.
 *
 * @param className
 * @param state
 */ __turbopack_context__.s([
    "resolveClassName",
    ()=>resolveClassName
]);
function resolveClassName(className, state) {
    return typeof className === 'function' ? className(state) : className;
}
}),
"[project]/node_modules/@base-ui/react/esm/utils/resolveStyle.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * If the provided style is an object, it will be returned as is.
 * Otherwise, the function will call the style function with the state as the first argument.
 *
 * @param style
 * @param state
 */ __turbopack_context__.s([
    "resolveStyle",
    ()=>resolveStyle
]);
function resolveStyle(style, state) {
    return typeof style === 'function' ? style(state) : style;
}
}),
"[project]/node_modules/@base-ui/utils/esm/empty.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EMPTY_ARRAY",
    ()=>EMPTY_ARRAY,
    "EMPTY_OBJECT",
    ()=>EMPTY_OBJECT,
    "NOOP",
    ()=>NOOP
]);
function NOOP() {}
const EMPTY_ARRAY = Object.freeze([]);
const EMPTY_OBJECT = Object.freeze({});
}),
"[project]/node_modules/@base-ui/react/esm/utils/useRenderElement.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useRenderElement",
    ()=>useRenderElement
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useMergedRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/useMergedRefs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$getReactElementRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/getReactElementRef.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$mergeObjects$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/mergeObjects.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$warn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/warn.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$getStateAttributesProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/utils/getStateAttributesProps.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$resolveClassName$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/utils/resolveClassName.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$resolveStyle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/utils/resolveStyle.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$merge$2d$props$2f$mergeProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/merge-props/mergeProps.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$empty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/empty.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
function useRenderElement(element, componentProps, params = {}) {
    const renderProp = componentProps.render;
    const outProps = useRenderElementProps(componentProps, params);
    if (params.enabled === false) {
        return null;
    }
    const state = params.state ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$empty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_OBJECT"];
    return evaluateRenderProp(element, renderProp, outProps, state);
}
/**
 * Computes render element final props.
 */ function useRenderElementProps(componentProps, params = {}) {
    const { className: classNameProp, style: styleProp, render: renderProp } = componentProps;
    const { state = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$empty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_OBJECT"], ref, props, stateAttributesMapping, enabled = true } = params;
    const className = enabled ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$resolveClassName$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resolveClassName"])(classNameProp, state) : undefined;
    const style = enabled ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$resolveStyle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resolveStyle"])(styleProp, state) : undefined;
    const stateProps = enabled ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$getStateAttributesProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStateAttributesProps"])(state, stateAttributesMapping) : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$empty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_OBJECT"];
    const outProps = enabled ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$mergeObjects$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeObjects"])(stateProps, Array.isArray(props) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$merge$2d$props$2f$mergeProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergePropsN"])(props) : props) ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$empty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_OBJECT"] : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$empty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_OBJECT"];
    // SAFETY: The `useMergedRefs` functions use a single hook to store the same value,
    // switching between them at runtime is safe. If this assertion fails, React will
    // throw at runtime anyway.
    // This also skips the `useMergedRefs` call on the server, which is fine because
    // refs are not used on the server side.
    /* eslint-disable react-hooks/rules-of-hooks */ if (typeof document !== 'undefined') {
        if (!enabled) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useMergedRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergedRefs"])(null, null);
        } else if (Array.isArray(ref)) {
            outProps.ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useMergedRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergedRefsN"])([
                outProps.ref,
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$getReactElementRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getReactElementRef"])(renderProp),
                ...ref
            ]);
        } else {
            outProps.ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useMergedRefs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergedRefs"])(outProps.ref, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$getReactElementRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getReactElementRef"])(renderProp), ref);
        }
    }
    if (!enabled) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$empty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_OBJECT"];
    }
    if (className !== undefined) {
        outProps.className = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$merge$2d$props$2f$mergeProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeClassNames"])(outProps.className, className);
    }
    if (style !== undefined) {
        outProps.style = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$mergeObjects$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeObjects"])(outProps.style, style);
    }
    return outProps;
}
// The symbol React uses internally for lazy components
// https://github.com/facebook/react/blob/a0566250b210499b4c5677f5ac2eedbd71d51a1b/packages/shared/ReactSymbols.js#L31
//
// TODO delete once https://github.com/facebook/react/issues/32392 is fixed
const REACT_LAZY_TYPE = Symbol.for('react.lazy');
function evaluateRenderProp(element, render, props, state) {
    if (render) {
        if (typeof render === 'function') {
            if ("TURBOPACK compile-time truthy", 1) {
                warnIfRenderPropLooksLikeComponent(render);
            }
            return render(props, state);
        }
        const mergedProps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$merge$2d$props$2f$mergeProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeProps"])(props, render.props);
        mergedProps.ref = props.ref;
        let newElement = render;
        // Workaround for https://github.com/facebook/react/issues/32392
        // This works because the toArray() logic unwrap lazy element type in
        // https://github.com/facebook/react/blob/a0566250b210499b4c5677f5ac2eedbd71d51a1b/packages/react/src/ReactChildren.js#L186
        if (newElement?.$$typeof === REACT_LAZY_TYPE) {
            const children = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Children"].toArray(render);
            newElement = children[0];
        }
        // There is a high number of indirections, the error message thrown by React.cloneElement() is
        // hard to use for developers, this logic provides a better context.
        //
        // Our general guideline is to never change the control flow depending on the environment.
        // However, React.cloneElement() throws if React.isValidElement() is false,
        // so we can throw before with custom message.
        if ("TURBOPACK compile-time truthy", 1) {
            if (!/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElement"](newElement)) {
                throw new Error([
                    'Base UI: The `render` prop was provided an invalid React element as `React.isValidElement(render)` is `false`.',
                    'A valid React element must be provided to the `render` prop because it is cloned with props to replace the default element.',
                    'https://base-ui.com/r/invalid-render-prop'
                ].join('\n'));
            }
        }
        return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cloneElement"](newElement, mergedProps);
    }
    if (element) {
        if (typeof element === 'string') {
            return renderTag(element, props);
        }
    }
    // Unreachable, but the typings on `useRenderElement` need to be reworked
    // to annotate it correctly.
    throw new Error(("TURBOPACK compile-time truthy", 1) ? 'Base UI: Render element or function are not defined.' : "TURBOPACK unreachable");
}
function warnIfRenderPropLooksLikeComponent(renderFn) {
    const functionName = renderFn.name;
    if (functionName.length === 0) {
        return;
    }
    const firstCharacterCode = functionName.charCodeAt(0);
    if (firstCharacterCode < 65 || firstCharacterCode > 90) {
        return;
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$warn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["warn"])(`The \`render\` prop received a function named \`${functionName}\` that starts with an uppercase letter.`, 'This usually means a React component was passed directly as `render={Component}`.', 'Base UI calls `render` as a plain function, which can break the Rules of Hooks during reconciliation.', 'If this is an intentional render callback, rename it to start with a lowercase letter.', 'Use `render={<Component />}` or `render={(props) => <Component {...props} />}` instead.', 'https://base-ui.com/r/invalid-render-prop');
}
function renderTag(Tag, props) {
    if (Tag === 'button') {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("button", {
            type: "button",
            ...props,
            key: props.key
        });
    }
    if (Tag === 'img') {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("img", {
            alt: "",
            ...props,
            key: props.key
        });
    }
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"](Tag, props);
}
}),
"[project]/node_modules/@base-ui/react/esm/button/Button.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Button",
    ()=>Button
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$use$2d$button$2f$useButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/use-button/useButton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$useRenderElement$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/utils/useRenderElement.js [app-client] (ecmascript)");
'use client';
;
;
;
const Button = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function Button(componentProps, forwardedRef) {
    const { render, className, disabled = false, focusableWhenDisabled = false, nativeButton = true, ...elementProps } = componentProps;
    const { getButtonProps, buttonRef } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$use$2d$button$2f$useButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useButton"])({
        disabled,
        focusableWhenDisabled,
        native: nativeButton
    });
    const state = {
        disabled
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$useRenderElement$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('button', componentProps, {
        state,
        ref: [
            forwardedRef,
            buttonRef
        ],
        props: [
            elementProps,
            getButtonProps
        ]
    });
});
if ("TURBOPACK compile-time truthy", 1) Button.displayName = "Button";
}),
"[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "clsx",
    ()=>clsx,
    "default",
    ()=>__TURBOPACK__default__export__
]);
function r(e) {
    var t, f, n = "";
    if ("string" == typeof e || "number" == typeof e) n += e;
    else if ("object" == typeof e) if (Array.isArray(e)) {
        var o = e.length;
        for(t = 0; t < o; t++)e[t] && (f = r(e[t])) && (n && (n += " "), n += f);
    } else for(f in e)e[f] && (n && (n += " "), n += f);
    return n;
}
function clsx() {
    for(var e, t, f = 0, n = "", o = arguments.length; f < o; f++)(e = arguments[f]) && (t = r(e)) && (n && (n += " "), n += t);
    return n;
}
const __TURBOPACK__default__export__ = clsx;
}),
"[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cva",
    ()=>cva,
    "cx",
    ()=>cx
]);
/**
 * Copyright 2022 Joe Bell. All rights reserved.
 *
 * This file is licensed to you under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with the
 * License. You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR REPRESENTATIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
;
const falsyToString = (value)=>typeof value === "boolean" ? `${value}` : value === 0 ? "0" : value;
const cx = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsx"];
const cva = (base, config)=>(props)=>{
        var _config_compoundVariants;
        if ((config === null || config === void 0 ? void 0 : config.variants) == null) return cx(base, props === null || props === void 0 ? void 0 : props.class, props === null || props === void 0 ? void 0 : props.className);
        const { variants, defaultVariants } = config;
        const getVariantClassNames = Object.keys(variants).map((variant)=>{
            const variantProp = props === null || props === void 0 ? void 0 : props[variant];
            const defaultVariantProp = defaultVariants === null || defaultVariants === void 0 ? void 0 : defaultVariants[variant];
            if (variantProp === null) return null;
            const variantKey = falsyToString(variantProp) || falsyToString(defaultVariantProp);
            return variants[variant][variantKey];
        });
        const propsWithoutUndefined = props && Object.entries(props).reduce((acc, param)=>{
            let [key, value] = param;
            if (value === undefined) {
                return acc;
            }
            acc[key] = value;
            return acc;
        }, {});
        const getCompoundVariantClassNames = config === null || config === void 0 ? void 0 : (_config_compoundVariants = config.compoundVariants) === null || _config_compoundVariants === void 0 ? void 0 : _config_compoundVariants.reduce((acc, param)=>{
            let { class: cvClass, className: cvClassName, ...compoundVariantOptions } = param;
            return Object.entries(compoundVariantOptions).every((param)=>{
                let [key, value] = param;
                return Array.isArray(value) ? value.includes({
                    ...defaultVariants,
                    ...propsWithoutUndefined
                }[key]) : ({
                    ...defaultVariants,
                    ...propsWithoutUndefined
                })[key] === value;
            }) ? [
                ...acc,
                cvClass,
                cvClassName
            ] : acc;
        }, []);
        return cx(base, getVariantClassNames, getCompoundVariantClassNames, props === null || props === void 0 ? void 0 : props.class, props === null || props === void 0 ? void 0 : props.className);
    };
}),
"[project]/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createTailwindMerge",
    ()=>createTailwindMerge,
    "extendTailwindMerge",
    ()=>extendTailwindMerge,
    "fromTheme",
    ()=>fromTheme,
    "getDefaultConfig",
    ()=>getDefaultConfig,
    "mergeConfigs",
    ()=>mergeConfigs,
    "twJoin",
    ()=>twJoin,
    "twMerge",
    ()=>twMerge,
    "validators",
    ()=>validators
]);
/**
 * Concatenates two arrays faster than the array spread operator.
 */ const concatArrays = (array1, array2)=>{
    // Pre-allocate for better V8 optimization
    const combinedArray = new Array(array1.length + array2.length);
    for(let i = 0; i < array1.length; i++){
        combinedArray[i] = array1[i];
    }
    for(let i = 0; i < array2.length; i++){
        combinedArray[array1.length + i] = array2[i];
    }
    return combinedArray;
};
// Factory function ensures consistent object shapes
const createClassValidatorObject = (classGroupId, validator)=>({
        classGroupId,
        validator
    });
// Factory ensures consistent ClassPartObject shape
const createClassPartObject = (nextPart = new Map(), validators = null, classGroupId)=>({
        nextPart,
        validators,
        classGroupId
    });
const CLASS_PART_SEPARATOR = '-';
const EMPTY_CONFLICTS = [];
// I use two dots here because one dot is used as prefix for class groups in plugins
const ARBITRARY_PROPERTY_PREFIX = 'arbitrary..';
const createClassGroupUtils = (config)=>{
    const classMap = createClassMap(config);
    const { conflictingClassGroups, conflictingClassGroupModifiers } = config;
    const getClassGroupId = (className)=>{
        if (className.startsWith('[') && className.endsWith(']')) {
            return getGroupIdForArbitraryProperty(className);
        }
        const classParts = className.split(CLASS_PART_SEPARATOR);
        // Classes like `-inset-1` produce an empty string as first classPart. We assume that classes for negative values are used correctly and skip it.
        const startIndex = classParts[0] === '' && classParts.length > 1 ? 1 : 0;
        return getGroupRecursive(classParts, startIndex, classMap);
    };
    const getConflictingClassGroupIds = (classGroupId, hasPostfixModifier)=>{
        if (hasPostfixModifier) {
            const modifierConflicts = conflictingClassGroupModifiers[classGroupId];
            const baseConflicts = conflictingClassGroups[classGroupId];
            if (modifierConflicts) {
                if (baseConflicts) {
                    // Merge base conflicts with modifier conflicts
                    return concatArrays(baseConflicts, modifierConflicts);
                }
                // Only modifier conflicts
                return modifierConflicts;
            }
            // Fall back to without postfix if no modifier conflicts
            return baseConflicts || EMPTY_CONFLICTS;
        }
        return conflictingClassGroups[classGroupId] || EMPTY_CONFLICTS;
    };
    return {
        getClassGroupId,
        getConflictingClassGroupIds
    };
};
const getGroupRecursive = (classParts, startIndex, classPartObject)=>{
    const classPathsLength = classParts.length - startIndex;
    if (classPathsLength === 0) {
        return classPartObject.classGroupId;
    }
    const currentClassPart = classParts[startIndex];
    const nextClassPartObject = classPartObject.nextPart.get(currentClassPart);
    if (nextClassPartObject) {
        const result = getGroupRecursive(classParts, startIndex + 1, nextClassPartObject);
        if (result) return result;
    }
    const validators = classPartObject.validators;
    if (validators === null) {
        return undefined;
    }
    // Build classRest string efficiently by joining from startIndex onwards
    const classRest = startIndex === 0 ? classParts.join(CLASS_PART_SEPARATOR) : classParts.slice(startIndex).join(CLASS_PART_SEPARATOR);
    const validatorsLength = validators.length;
    for(let i = 0; i < validatorsLength; i++){
        const validatorObj = validators[i];
        if (validatorObj.validator(classRest)) {
            return validatorObj.classGroupId;
        }
    }
    return undefined;
};
/**
 * Get the class group ID for an arbitrary property.
 *
 * @param className - The class name to get the group ID for. Is expected to be string starting with `[` and ending with `]`.
 */ const getGroupIdForArbitraryProperty = (className)=>className.slice(1, -1).indexOf(':') === -1 ? undefined : (()=>{
        const content = className.slice(1, -1);
        const colonIndex = content.indexOf(':');
        const property = content.slice(0, colonIndex);
        return property ? ARBITRARY_PROPERTY_PREFIX + property : undefined;
    })();
/**
 * Exported for testing only
 */ const createClassMap = (config)=>{
    const { theme, classGroups } = config;
    return processClassGroups(classGroups, theme);
};
// Split into separate functions to maintain monomorphic call sites
const processClassGroups = (classGroups, theme)=>{
    const classMap = createClassPartObject();
    for(const classGroupId in classGroups){
        const group = classGroups[classGroupId];
        processClassesRecursively(group, classMap, classGroupId, theme);
    }
    return classMap;
};
const processClassesRecursively = (classGroup, classPartObject, classGroupId, theme)=>{
    const len = classGroup.length;
    for(let i = 0; i < len; i++){
        const classDefinition = classGroup[i];
        processClassDefinition(classDefinition, classPartObject, classGroupId, theme);
    }
};
// Split into separate functions for each type to maintain monomorphic call sites
const processClassDefinition = (classDefinition, classPartObject, classGroupId, theme)=>{
    if (typeof classDefinition === 'string') {
        processStringDefinition(classDefinition, classPartObject, classGroupId);
        return;
    }
    if (typeof classDefinition === 'function') {
        processFunctionDefinition(classDefinition, classPartObject, classGroupId, theme);
        return;
    }
    processObjectDefinition(classDefinition, classPartObject, classGroupId, theme);
};
const processStringDefinition = (classDefinition, classPartObject, classGroupId)=>{
    const classPartObjectToEdit = classDefinition === '' ? classPartObject : getPart(classPartObject, classDefinition);
    classPartObjectToEdit.classGroupId = classGroupId;
};
const processFunctionDefinition = (classDefinition, classPartObject, classGroupId, theme)=>{
    if (isThemeGetter(classDefinition)) {
        processClassesRecursively(classDefinition(theme), classPartObject, classGroupId, theme);
        return;
    }
    if (classPartObject.validators === null) {
        classPartObject.validators = [];
    }
    classPartObject.validators.push(createClassValidatorObject(classGroupId, classDefinition));
};
const processObjectDefinition = (classDefinition, classPartObject, classGroupId, theme)=>{
    const entries = Object.entries(classDefinition);
    const len = entries.length;
    for(let i = 0; i < len; i++){
        const [key, value] = entries[i];
        processClassesRecursively(value, getPart(classPartObject, key), classGroupId, theme);
    }
};
const getPart = (classPartObject, path)=>{
    let current = classPartObject;
    const parts = path.split(CLASS_PART_SEPARATOR);
    const len = parts.length;
    for(let i = 0; i < len; i++){
        const part = parts[i];
        let next = current.nextPart.get(part);
        if (!next) {
            next = createClassPartObject();
            current.nextPart.set(part, next);
        }
        current = next;
    }
    return current;
};
// Type guard maintains monomorphic check
const isThemeGetter = (func)=>'isThemeGetter' in func && func.isThemeGetter === true;
// LRU cache implementation using plain objects for simplicity
const createLruCache = (maxCacheSize)=>{
    if (maxCacheSize < 1) {
        return {
            get: ()=>undefined,
            set: ()=>{}
        };
    }
    let cacheSize = 0;
    let cache = Object.create(null);
    let previousCache = Object.create(null);
    const update = (key, value)=>{
        cache[key] = value;
        cacheSize++;
        if (cacheSize > maxCacheSize) {
            cacheSize = 0;
            previousCache = cache;
            cache = Object.create(null);
        }
    };
    return {
        get (key) {
            let value = cache[key];
            if (value !== undefined) {
                return value;
            }
            if ((value = previousCache[key]) !== undefined) {
                update(key, value);
                return value;
            }
        },
        set (key, value) {
            if (key in cache) {
                cache[key] = value;
            } else {
                update(key, value);
            }
        }
    };
};
const IMPORTANT_MODIFIER = '!';
const MODIFIER_SEPARATOR = ':';
const EMPTY_MODIFIERS = [];
// Pre-allocated result object shape for consistency
const createResultObject = (modifiers, hasImportantModifier, baseClassName, maybePostfixModifierPosition, isExternal)=>({
        modifiers,
        hasImportantModifier,
        baseClassName,
        maybePostfixModifierPosition,
        isExternal
    });
const createParseClassName = (config)=>{
    const { prefix, experimentalParseClassName } = config;
    /**
   * Parse class name into parts.
   *
   * Inspired by `splitAtTopLevelOnly` used in Tailwind CSS
   * @see https://github.com/tailwindlabs/tailwindcss/blob/v3.2.2/src/util/splitAtTopLevelOnly.js
   */ let parseClassName = (className)=>{
        // Use simple array with push for better performance
        const modifiers = [];
        let bracketDepth = 0;
        let parenDepth = 0;
        let modifierStart = 0;
        let postfixModifierPosition;
        const len = className.length;
        for(let index = 0; index < len; index++){
            const currentCharacter = className[index];
            if (bracketDepth === 0 && parenDepth === 0) {
                if (currentCharacter === MODIFIER_SEPARATOR) {
                    modifiers.push(className.slice(modifierStart, index));
                    modifierStart = index + 1;
                    continue;
                }
                if (currentCharacter === '/') {
                    postfixModifierPosition = index;
                    continue;
                }
            }
            if (currentCharacter === '[') bracketDepth++;
            else if (currentCharacter === ']') bracketDepth--;
            else if (currentCharacter === '(') parenDepth++;
            else if (currentCharacter === ')') parenDepth--;
        }
        const baseClassNameWithImportantModifier = modifiers.length === 0 ? className : className.slice(modifierStart);
        // Inline important modifier check
        let baseClassName = baseClassNameWithImportantModifier;
        let hasImportantModifier = false;
        if (baseClassNameWithImportantModifier.endsWith(IMPORTANT_MODIFIER)) {
            baseClassName = baseClassNameWithImportantModifier.slice(0, -1);
            hasImportantModifier = true;
        } else if (/**
     * In Tailwind CSS v3 the important modifier was at the start of the base class name. This is still supported for legacy reasons.
     * @see https://github.com/dcastil/tailwind-merge/issues/513#issuecomment-2614029864
     */ baseClassNameWithImportantModifier.startsWith(IMPORTANT_MODIFIER)) {
            baseClassName = baseClassNameWithImportantModifier.slice(1);
            hasImportantModifier = true;
        }
        const maybePostfixModifierPosition = postfixModifierPosition && postfixModifierPosition > modifierStart ? postfixModifierPosition - modifierStart : undefined;
        return createResultObject(modifiers, hasImportantModifier, baseClassName, maybePostfixModifierPosition);
    };
    if (prefix) {
        const fullPrefix = prefix + MODIFIER_SEPARATOR;
        const parseClassNameOriginal = parseClassName;
        parseClassName = (className)=>className.startsWith(fullPrefix) ? parseClassNameOriginal(className.slice(fullPrefix.length)) : createResultObject(EMPTY_MODIFIERS, false, className, undefined, true);
    }
    if (experimentalParseClassName) {
        const parseClassNameOriginal = parseClassName;
        parseClassName = (className)=>experimentalParseClassName({
                className,
                parseClassName: parseClassNameOriginal
            });
    }
    return parseClassName;
};
/**
 * Sorts modifiers according to following schema:
 * - Predefined modifiers are sorted alphabetically
 * - When an arbitrary variant appears, it must be preserved which modifiers are before and after it
 */ const createSortModifiers = (config)=>{
    // Pre-compute weights for all known modifiers for O(1) comparison
    const modifierWeights = new Map();
    // Assign weights to sensitive modifiers (highest priority, but preserve order)
    config.orderSensitiveModifiers.forEach((mod, index)=>{
        modifierWeights.set(mod, 1000000 + index); // High weights for sensitive mods
    });
    return (modifiers)=>{
        const result = [];
        let currentSegment = [];
        // Process modifiers in one pass
        for(let i = 0; i < modifiers.length; i++){
            const modifier = modifiers[i];
            // Check if modifier is sensitive (starts with '[' or in orderSensitiveModifiers)
            const isArbitrary = modifier[0] === '[';
            const isOrderSensitive = modifierWeights.has(modifier);
            if (isArbitrary || isOrderSensitive) {
                // Sort and flush current segment alphabetically
                if (currentSegment.length > 0) {
                    currentSegment.sort();
                    result.push(...currentSegment);
                    currentSegment = [];
                }
                result.push(modifier);
            } else {
                // Regular modifier - add to current segment for batch sorting
                currentSegment.push(modifier);
            }
        }
        // Sort and add any remaining segment items
        if (currentSegment.length > 0) {
            currentSegment.sort();
            result.push(...currentSegment);
        }
        return result;
    };
};
const createConfigUtils = (config)=>({
        cache: createLruCache(config.cacheSize),
        parseClassName: createParseClassName(config),
        sortModifiers: createSortModifiers(config),
        ...createClassGroupUtils(config)
    });
const SPLIT_CLASSES_REGEX = /\s+/;
const mergeClassList = (classList, configUtils)=>{
    const { parseClassName, getClassGroupId, getConflictingClassGroupIds, sortModifiers } = configUtils;
    /**
   * Set of classGroupIds in following format:
   * `{importantModifier}{variantModifiers}{classGroupId}`
   * @example 'float'
   * @example 'hover:focus:bg-color'
   * @example 'md:!pr'
   */ const classGroupsInConflict = [];
    const classNames = classList.trim().split(SPLIT_CLASSES_REGEX);
    let result = '';
    for(let index = classNames.length - 1; index >= 0; index -= 1){
        const originalClassName = classNames[index];
        const { isExternal, modifiers, hasImportantModifier, baseClassName, maybePostfixModifierPosition } = parseClassName(originalClassName);
        if (isExternal) {
            result = originalClassName + (result.length > 0 ? ' ' + result : result);
            continue;
        }
        let hasPostfixModifier = !!maybePostfixModifierPosition;
        let classGroupId = getClassGroupId(hasPostfixModifier ? baseClassName.substring(0, maybePostfixModifierPosition) : baseClassName);
        if (!classGroupId) {
            if (!hasPostfixModifier) {
                // Not a Tailwind class
                result = originalClassName + (result.length > 0 ? ' ' + result : result);
                continue;
            }
            classGroupId = getClassGroupId(baseClassName);
            if (!classGroupId) {
                // Not a Tailwind class
                result = originalClassName + (result.length > 0 ? ' ' + result : result);
                continue;
            }
            hasPostfixModifier = false;
        }
        // Fast path: skip sorting for empty or single modifier
        const variantModifier = modifiers.length === 0 ? '' : modifiers.length === 1 ? modifiers[0] : sortModifiers(modifiers).join(':');
        const modifierId = hasImportantModifier ? variantModifier + IMPORTANT_MODIFIER : variantModifier;
        const classId = modifierId + classGroupId;
        if (classGroupsInConflict.indexOf(classId) > -1) {
            continue;
        }
        classGroupsInConflict.push(classId);
        const conflictGroups = getConflictingClassGroupIds(classGroupId, hasPostfixModifier);
        for(let i = 0; i < conflictGroups.length; ++i){
            const group = conflictGroups[i];
            classGroupsInConflict.push(modifierId + group);
        }
        // Tailwind class not in conflict
        result = originalClassName + (result.length > 0 ? ' ' + result : result);
    }
    return result;
};
/**
 * The code in this file is copied from https://github.com/lukeed/clsx and modified to suit the needs of tailwind-merge better.
 *
 * Specifically:
 * - Runtime code from https://github.com/lukeed/clsx/blob/v1.2.1/src/index.js
 * - TypeScript types from https://github.com/lukeed/clsx/blob/v1.2.1/clsx.d.ts
 *
 * Original code has MIT license: Copyright (c) Luke Edwards <luke.edwards05@gmail.com> (lukeed.com)
 */ const twJoin = (...classLists)=>{
    let index = 0;
    let argument;
    let resolvedValue;
    let string = '';
    while(index < classLists.length){
        if (argument = classLists[index++]) {
            if (resolvedValue = toValue(argument)) {
                string && (string += ' ');
                string += resolvedValue;
            }
        }
    }
    return string;
};
const toValue = (mix)=>{
    // Fast path for strings
    if (typeof mix === 'string') {
        return mix;
    }
    let resolvedValue;
    let string = '';
    for(let k = 0; k < mix.length; k++){
        if (mix[k]) {
            if (resolvedValue = toValue(mix[k])) {
                string && (string += ' ');
                string += resolvedValue;
            }
        }
    }
    return string;
};
const createTailwindMerge = (createConfigFirst, ...createConfigRest)=>{
    let configUtils;
    let cacheGet;
    let cacheSet;
    let functionToCall;
    const initTailwindMerge = (classList)=>{
        const config = createConfigRest.reduce((previousConfig, createConfigCurrent)=>createConfigCurrent(previousConfig), createConfigFirst());
        configUtils = createConfigUtils(config);
        cacheGet = configUtils.cache.get;
        cacheSet = configUtils.cache.set;
        functionToCall = tailwindMerge;
        return tailwindMerge(classList);
    };
    const tailwindMerge = (classList)=>{
        const cachedResult = cacheGet(classList);
        if (cachedResult) {
            return cachedResult;
        }
        const result = mergeClassList(classList, configUtils);
        cacheSet(classList, result);
        return result;
    };
    functionToCall = initTailwindMerge;
    return (...args)=>functionToCall(twJoin(...args));
};
const fallbackThemeArr = [];
const fromTheme = (key)=>{
    const themeGetter = (theme)=>theme[key] || fallbackThemeArr;
    themeGetter.isThemeGetter = true;
    return themeGetter;
};
const arbitraryValueRegex = /^\[(?:(\w[\w-]*):)?(.+)\]$/i;
const arbitraryVariableRegex = /^\((?:(\w[\w-]*):)?(.+)\)$/i;
const fractionRegex = /^\d+(?:\.\d+)?\/\d+(?:\.\d+)?$/;
const tshirtUnitRegex = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/;
const lengthUnitRegex = /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/;
const colorFunctionRegex = /^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix)\(.+\)$/;
// Shadow always begins with x and y offset separated by underscore optionally prepended by inset
const shadowRegex = /^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/;
const imageRegex = /^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/;
const isFraction = (value)=>fractionRegex.test(value);
const isNumber = (value)=>!!value && !Number.isNaN(Number(value));
const isInteger = (value)=>!!value && Number.isInteger(Number(value));
const isPercent = (value)=>value.endsWith('%') && isNumber(value.slice(0, -1));
const isTshirtSize = (value)=>tshirtUnitRegex.test(value);
const isAny = ()=>true;
const isLengthOnly = (value)=>// `colorFunctionRegex` check is necessary because color functions can have percentages in them which which would be incorrectly classified as lengths.
    // For example, `hsl(0 0% 0%)` would be classified as a length without this check.
    // I could also use lookbehind assertion in `lengthUnitRegex` but that isn't supported widely enough.
    lengthUnitRegex.test(value) && !colorFunctionRegex.test(value);
const isNever = ()=>false;
const isShadow = (value)=>shadowRegex.test(value);
const isImage = (value)=>imageRegex.test(value);
const isAnyNonArbitrary = (value)=>!isArbitraryValue(value) && !isArbitraryVariable(value);
const isArbitrarySize = (value)=>getIsArbitraryValue(value, isLabelSize, isNever);
const isArbitraryValue = (value)=>arbitraryValueRegex.test(value);
const isArbitraryLength = (value)=>getIsArbitraryValue(value, isLabelLength, isLengthOnly);
const isArbitraryNumber = (value)=>getIsArbitraryValue(value, isLabelNumber, isNumber);
const isArbitraryWeight = (value)=>getIsArbitraryValue(value, isLabelWeight, isAny);
const isArbitraryFamilyName = (value)=>getIsArbitraryValue(value, isLabelFamilyName, isNever);
const isArbitraryPosition = (value)=>getIsArbitraryValue(value, isLabelPosition, isNever);
const isArbitraryImage = (value)=>getIsArbitraryValue(value, isLabelImage, isImage);
const isArbitraryShadow = (value)=>getIsArbitraryValue(value, isLabelShadow, isShadow);
const isArbitraryVariable = (value)=>arbitraryVariableRegex.test(value);
const isArbitraryVariableLength = (value)=>getIsArbitraryVariable(value, isLabelLength);
const isArbitraryVariableFamilyName = (value)=>getIsArbitraryVariable(value, isLabelFamilyName);
const isArbitraryVariablePosition = (value)=>getIsArbitraryVariable(value, isLabelPosition);
const isArbitraryVariableSize = (value)=>getIsArbitraryVariable(value, isLabelSize);
const isArbitraryVariableImage = (value)=>getIsArbitraryVariable(value, isLabelImage);
const isArbitraryVariableShadow = (value)=>getIsArbitraryVariable(value, isLabelShadow, true);
const isArbitraryVariableWeight = (value)=>getIsArbitraryVariable(value, isLabelWeight, true);
// Helpers
const getIsArbitraryValue = (value, testLabel, testValue)=>{
    const result = arbitraryValueRegex.exec(value);
    if (result) {
        if (result[1]) {
            return testLabel(result[1]);
        }
        return testValue(result[2]);
    }
    return false;
};
const getIsArbitraryVariable = (value, testLabel, shouldMatchNoLabel = false)=>{
    const result = arbitraryVariableRegex.exec(value);
    if (result) {
        if (result[1]) {
            return testLabel(result[1]);
        }
        return shouldMatchNoLabel;
    }
    return false;
};
// Labels
const isLabelPosition = (label)=>label === 'position' || label === 'percentage';
const isLabelImage = (label)=>label === 'image' || label === 'url';
const isLabelSize = (label)=>label === 'length' || label === 'size' || label === 'bg-size';
const isLabelLength = (label)=>label === 'length';
const isLabelNumber = (label)=>label === 'number';
const isLabelFamilyName = (label)=>label === 'family-name';
const isLabelWeight = (label)=>label === 'number' || label === 'weight';
const isLabelShadow = (label)=>label === 'shadow';
const validators = /*#__PURE__*/ Object.defineProperty({
    __proto__: null,
    isAny,
    isAnyNonArbitrary,
    isArbitraryFamilyName,
    isArbitraryImage,
    isArbitraryLength,
    isArbitraryNumber,
    isArbitraryPosition,
    isArbitraryShadow,
    isArbitrarySize,
    isArbitraryValue,
    isArbitraryVariable,
    isArbitraryVariableFamilyName,
    isArbitraryVariableImage,
    isArbitraryVariableLength,
    isArbitraryVariablePosition,
    isArbitraryVariableShadow,
    isArbitraryVariableSize,
    isArbitraryVariableWeight,
    isArbitraryWeight,
    isFraction,
    isInteger,
    isNumber,
    isPercent,
    isTshirtSize
}, Symbol.toStringTag, {
    value: 'Module'
});
const getDefaultConfig = ()=>{
    /**
   * Theme getters for theme variable namespaces
   * @see https://tailwindcss.com/docs/theme#theme-variable-namespaces
   */ /***/ const themeColor = fromTheme('color');
    const themeFont = fromTheme('font');
    const themeText = fromTheme('text');
    const themeFontWeight = fromTheme('font-weight');
    const themeTracking = fromTheme('tracking');
    const themeLeading = fromTheme('leading');
    const themeBreakpoint = fromTheme('breakpoint');
    const themeContainer = fromTheme('container');
    const themeSpacing = fromTheme('spacing');
    const themeRadius = fromTheme('radius');
    const themeShadow = fromTheme('shadow');
    const themeInsetShadow = fromTheme('inset-shadow');
    const themeTextShadow = fromTheme('text-shadow');
    const themeDropShadow = fromTheme('drop-shadow');
    const themeBlur = fromTheme('blur');
    const themePerspective = fromTheme('perspective');
    const themeAspect = fromTheme('aspect');
    const themeEase = fromTheme('ease');
    const themeAnimate = fromTheme('animate');
    /**
   * Helpers to avoid repeating the same scales
   *
   * We use functions that create a new array every time they're called instead of static arrays.
   * This ensures that users who modify any scale by mutating the array (e.g. with `array.push(element)`) don't accidentally mutate arrays in other parts of the config.
   */ /***/ const scaleBreak = ()=>[
            'auto',
            'avoid',
            'all',
            'avoid-page',
            'page',
            'left',
            'right',
            'column'
        ];
    const scalePosition = ()=>[
            'center',
            'top',
            'bottom',
            'left',
            'right',
            'top-left',
            // Deprecated since Tailwind CSS v4.1.0, see https://github.com/tailwindlabs/tailwindcss/pull/17378
            'left-top',
            'top-right',
            // Deprecated since Tailwind CSS v4.1.0, see https://github.com/tailwindlabs/tailwindcss/pull/17378
            'right-top',
            'bottom-right',
            // Deprecated since Tailwind CSS v4.1.0, see https://github.com/tailwindlabs/tailwindcss/pull/17378
            'right-bottom',
            'bottom-left',
            // Deprecated since Tailwind CSS v4.1.0, see https://github.com/tailwindlabs/tailwindcss/pull/17378
            'left-bottom'
        ];
    const scalePositionWithArbitrary = ()=>[
            ...scalePosition(),
            isArbitraryVariable,
            isArbitraryValue
        ];
    const scaleOverflow = ()=>[
            'auto',
            'hidden',
            'clip',
            'visible',
            'scroll'
        ];
    const scaleOverscroll = ()=>[
            'auto',
            'contain',
            'none'
        ];
    const scaleUnambiguousSpacing = ()=>[
            isArbitraryVariable,
            isArbitraryValue,
            themeSpacing
        ];
    const scaleInset = ()=>[
            isFraction,
            'full',
            'auto',
            ...scaleUnambiguousSpacing()
        ];
    const scaleGridTemplateColsRows = ()=>[
            isInteger,
            'none',
            'subgrid',
            isArbitraryVariable,
            isArbitraryValue
        ];
    const scaleGridColRowStartAndEnd = ()=>[
            'auto',
            {
                span: [
                    'full',
                    isInteger,
                    isArbitraryVariable,
                    isArbitraryValue
                ]
            },
            isInteger,
            isArbitraryVariable,
            isArbitraryValue
        ];
    const scaleGridColRowStartOrEnd = ()=>[
            isInteger,
            'auto',
            isArbitraryVariable,
            isArbitraryValue
        ];
    const scaleGridAutoColsRows = ()=>[
            'auto',
            'min',
            'max',
            'fr',
            isArbitraryVariable,
            isArbitraryValue
        ];
    const scaleAlignPrimaryAxis = ()=>[
            'start',
            'end',
            'center',
            'between',
            'around',
            'evenly',
            'stretch',
            'baseline',
            'center-safe',
            'end-safe'
        ];
    const scaleAlignSecondaryAxis = ()=>[
            'start',
            'end',
            'center',
            'stretch',
            'center-safe',
            'end-safe'
        ];
    const scaleMargin = ()=>[
            'auto',
            ...scaleUnambiguousSpacing()
        ];
    const scaleSizing = ()=>[
            isFraction,
            'auto',
            'full',
            'dvw',
            'dvh',
            'lvw',
            'lvh',
            'svw',
            'svh',
            'min',
            'max',
            'fit',
            ...scaleUnambiguousSpacing()
        ];
    const scaleSizingInline = ()=>[
            isFraction,
            'screen',
            'full',
            'dvw',
            'lvw',
            'svw',
            'min',
            'max',
            'fit',
            ...scaleUnambiguousSpacing()
        ];
    const scaleSizingBlock = ()=>[
            isFraction,
            'screen',
            'full',
            'lh',
            'dvh',
            'lvh',
            'svh',
            'min',
            'max',
            'fit',
            ...scaleUnambiguousSpacing()
        ];
    const scaleColor = ()=>[
            themeColor,
            isArbitraryVariable,
            isArbitraryValue
        ];
    const scaleBgPosition = ()=>[
            ...scalePosition(),
            isArbitraryVariablePosition,
            isArbitraryPosition,
            {
                position: [
                    isArbitraryVariable,
                    isArbitraryValue
                ]
            }
        ];
    const scaleBgRepeat = ()=>[
            'no-repeat',
            {
                repeat: [
                    '',
                    'x',
                    'y',
                    'space',
                    'round'
                ]
            }
        ];
    const scaleBgSize = ()=>[
            'auto',
            'cover',
            'contain',
            isArbitraryVariableSize,
            isArbitrarySize,
            {
                size: [
                    isArbitraryVariable,
                    isArbitraryValue
                ]
            }
        ];
    const scaleGradientStopPosition = ()=>[
            isPercent,
            isArbitraryVariableLength,
            isArbitraryLength
        ];
    const scaleRadius = ()=>[
            // Deprecated since Tailwind CSS v4.0.0
            '',
            'none',
            'full',
            themeRadius,
            isArbitraryVariable,
            isArbitraryValue
        ];
    const scaleBorderWidth = ()=>[
            '',
            isNumber,
            isArbitraryVariableLength,
            isArbitraryLength
        ];
    const scaleLineStyle = ()=>[
            'solid',
            'dashed',
            'dotted',
            'double'
        ];
    const scaleBlendMode = ()=>[
            'normal',
            'multiply',
            'screen',
            'overlay',
            'darken',
            'lighten',
            'color-dodge',
            'color-burn',
            'hard-light',
            'soft-light',
            'difference',
            'exclusion',
            'hue',
            'saturation',
            'color',
            'luminosity'
        ];
    const scaleMaskImagePosition = ()=>[
            isNumber,
            isPercent,
            isArbitraryVariablePosition,
            isArbitraryPosition
        ];
    const scaleBlur = ()=>[
            // Deprecated since Tailwind CSS v4.0.0
            '',
            'none',
            themeBlur,
            isArbitraryVariable,
            isArbitraryValue
        ];
    const scaleRotate = ()=>[
            'none',
            isNumber,
            isArbitraryVariable,
            isArbitraryValue
        ];
    const scaleScale = ()=>[
            'none',
            isNumber,
            isArbitraryVariable,
            isArbitraryValue
        ];
    const scaleSkew = ()=>[
            isNumber,
            isArbitraryVariable,
            isArbitraryValue
        ];
    const scaleTranslate = ()=>[
            isFraction,
            'full',
            ...scaleUnambiguousSpacing()
        ];
    return {
        cacheSize: 500,
        theme: {
            animate: [
                'spin',
                'ping',
                'pulse',
                'bounce'
            ],
            aspect: [
                'video'
            ],
            blur: [
                isTshirtSize
            ],
            breakpoint: [
                isTshirtSize
            ],
            color: [
                isAny
            ],
            container: [
                isTshirtSize
            ],
            'drop-shadow': [
                isTshirtSize
            ],
            ease: [
                'in',
                'out',
                'in-out'
            ],
            font: [
                isAnyNonArbitrary
            ],
            'font-weight': [
                'thin',
                'extralight',
                'light',
                'normal',
                'medium',
                'semibold',
                'bold',
                'extrabold',
                'black'
            ],
            'inset-shadow': [
                isTshirtSize
            ],
            leading: [
                'none',
                'tight',
                'snug',
                'normal',
                'relaxed',
                'loose'
            ],
            perspective: [
                'dramatic',
                'near',
                'normal',
                'midrange',
                'distant',
                'none'
            ],
            radius: [
                isTshirtSize
            ],
            shadow: [
                isTshirtSize
            ],
            spacing: [
                'px',
                isNumber
            ],
            text: [
                isTshirtSize
            ],
            'text-shadow': [
                isTshirtSize
            ],
            tracking: [
                'tighter',
                'tight',
                'normal',
                'wide',
                'wider',
                'widest'
            ]
        },
        classGroups: {
            // --------------
            // --- Layout ---
            // --------------
            /**
       * Aspect Ratio
       * @see https://tailwindcss.com/docs/aspect-ratio
       */ aspect: [
                {
                    aspect: [
                        'auto',
                        'square',
                        isFraction,
                        isArbitraryValue,
                        isArbitraryVariable,
                        themeAspect
                    ]
                }
            ],
            /**
       * Container
       * @see https://tailwindcss.com/docs/container
       * @deprecated since Tailwind CSS v4.0.0
       */ container: [
                'container'
            ],
            /**
       * Columns
       * @see https://tailwindcss.com/docs/columns
       */ columns: [
                {
                    columns: [
                        isNumber,
                        isArbitraryValue,
                        isArbitraryVariable,
                        themeContainer
                    ]
                }
            ],
            /**
       * Break After
       * @see https://tailwindcss.com/docs/break-after
       */ 'break-after': [
                {
                    'break-after': scaleBreak()
                }
            ],
            /**
       * Break Before
       * @see https://tailwindcss.com/docs/break-before
       */ 'break-before': [
                {
                    'break-before': scaleBreak()
                }
            ],
            /**
       * Break Inside
       * @see https://tailwindcss.com/docs/break-inside
       */ 'break-inside': [
                {
                    'break-inside': [
                        'auto',
                        'avoid',
                        'avoid-page',
                        'avoid-column'
                    ]
                }
            ],
            /**
       * Box Decoration Break
       * @see https://tailwindcss.com/docs/box-decoration-break
       */ 'box-decoration': [
                {
                    'box-decoration': [
                        'slice',
                        'clone'
                    ]
                }
            ],
            /**
       * Box Sizing
       * @see https://tailwindcss.com/docs/box-sizing
       */ box: [
                {
                    box: [
                        'border',
                        'content'
                    ]
                }
            ],
            /**
       * Display
       * @see https://tailwindcss.com/docs/display
       */ display: [
                'block',
                'inline-block',
                'inline',
                'flex',
                'inline-flex',
                'table',
                'inline-table',
                'table-caption',
                'table-cell',
                'table-column',
                'table-column-group',
                'table-footer-group',
                'table-header-group',
                'table-row-group',
                'table-row',
                'flow-root',
                'grid',
                'inline-grid',
                'contents',
                'list-item',
                'hidden'
            ],
            /**
       * Screen Reader Only
       * @see https://tailwindcss.com/docs/display#screen-reader-only
       */ sr: [
                'sr-only',
                'not-sr-only'
            ],
            /**
       * Floats
       * @see https://tailwindcss.com/docs/float
       */ float: [
                {
                    float: [
                        'right',
                        'left',
                        'none',
                        'start',
                        'end'
                    ]
                }
            ],
            /**
       * Clear
       * @see https://tailwindcss.com/docs/clear
       */ clear: [
                {
                    clear: [
                        'left',
                        'right',
                        'both',
                        'none',
                        'start',
                        'end'
                    ]
                }
            ],
            /**
       * Isolation
       * @see https://tailwindcss.com/docs/isolation
       */ isolation: [
                'isolate',
                'isolation-auto'
            ],
            /**
       * Object Fit
       * @see https://tailwindcss.com/docs/object-fit
       */ 'object-fit': [
                {
                    object: [
                        'contain',
                        'cover',
                        'fill',
                        'none',
                        'scale-down'
                    ]
                }
            ],
            /**
       * Object Position
       * @see https://tailwindcss.com/docs/object-position
       */ 'object-position': [
                {
                    object: scalePositionWithArbitrary()
                }
            ],
            /**
       * Overflow
       * @see https://tailwindcss.com/docs/overflow
       */ overflow: [
                {
                    overflow: scaleOverflow()
                }
            ],
            /**
       * Overflow X
       * @see https://tailwindcss.com/docs/overflow
       */ 'overflow-x': [
                {
                    'overflow-x': scaleOverflow()
                }
            ],
            /**
       * Overflow Y
       * @see https://tailwindcss.com/docs/overflow
       */ 'overflow-y': [
                {
                    'overflow-y': scaleOverflow()
                }
            ],
            /**
       * Overscroll Behavior
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */ overscroll: [
                {
                    overscroll: scaleOverscroll()
                }
            ],
            /**
       * Overscroll Behavior X
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */ 'overscroll-x': [
                {
                    'overscroll-x': scaleOverscroll()
                }
            ],
            /**
       * Overscroll Behavior Y
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */ 'overscroll-y': [
                {
                    'overscroll-y': scaleOverscroll()
                }
            ],
            /**
       * Position
       * @see https://tailwindcss.com/docs/position
       */ position: [
                'static',
                'fixed',
                'absolute',
                'relative',
                'sticky'
            ],
            /**
       * Inset
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */ inset: [
                {
                    inset: scaleInset()
                }
            ],
            /**
       * Inset Inline
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */ 'inset-x': [
                {
                    'inset-x': scaleInset()
                }
            ],
            /**
       * Inset Block
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */ 'inset-y': [
                {
                    'inset-y': scaleInset()
                }
            ],
            /**
       * Inset Inline Start
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       * @todo class group will be renamed to `inset-s` in next major release
       */ start: [
                {
                    'inset-s': scaleInset(),
                    /**
         * @deprecated since Tailwind CSS v4.2.0 in favor of `inset-s-*` utilities.
         * @see https://github.com/tailwindlabs/tailwindcss/pull/19613
         */ start: scaleInset()
                }
            ],
            /**
       * Inset Inline End
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       * @todo class group will be renamed to `inset-e` in next major release
       */ end: [
                {
                    'inset-e': scaleInset(),
                    /**
         * @deprecated since Tailwind CSS v4.2.0 in favor of `inset-e-*` utilities.
         * @see https://github.com/tailwindlabs/tailwindcss/pull/19613
         */ end: scaleInset()
                }
            ],
            /**
       * Inset Block Start
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */ 'inset-bs': [
                {
                    'inset-bs': scaleInset()
                }
            ],
            /**
       * Inset Block End
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */ 'inset-be': [
                {
                    'inset-be': scaleInset()
                }
            ],
            /**
       * Top
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */ top: [
                {
                    top: scaleInset()
                }
            ],
            /**
       * Right
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */ right: [
                {
                    right: scaleInset()
                }
            ],
            /**
       * Bottom
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */ bottom: [
                {
                    bottom: scaleInset()
                }
            ],
            /**
       * Left
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */ left: [
                {
                    left: scaleInset()
                }
            ],
            /**
       * Visibility
       * @see https://tailwindcss.com/docs/visibility
       */ visibility: [
                'visible',
                'invisible',
                'collapse'
            ],
            /**
       * Z-Index
       * @see https://tailwindcss.com/docs/z-index
       */ z: [
                {
                    z: [
                        isInteger,
                        'auto',
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            // ------------------------
            // --- Flexbox and Grid ---
            // ------------------------
            /**
       * Flex Basis
       * @see https://tailwindcss.com/docs/flex-basis
       */ basis: [
                {
                    basis: [
                        isFraction,
                        'full',
                        'auto',
                        themeContainer,
                        ...scaleUnambiguousSpacing()
                    ]
                }
            ],
            /**
       * Flex Direction
       * @see https://tailwindcss.com/docs/flex-direction
       */ 'flex-direction': [
                {
                    flex: [
                        'row',
                        'row-reverse',
                        'col',
                        'col-reverse'
                    ]
                }
            ],
            /**
       * Flex Wrap
       * @see https://tailwindcss.com/docs/flex-wrap
       */ 'flex-wrap': [
                {
                    flex: [
                        'nowrap',
                        'wrap',
                        'wrap-reverse'
                    ]
                }
            ],
            /**
       * Flex
       * @see https://tailwindcss.com/docs/flex
       */ flex: [
                {
                    flex: [
                        isNumber,
                        isFraction,
                        'auto',
                        'initial',
                        'none',
                        isArbitraryValue
                    ]
                }
            ],
            /**
       * Flex Grow
       * @see https://tailwindcss.com/docs/flex-grow
       */ grow: [
                {
                    grow: [
                        '',
                        isNumber,
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            /**
       * Flex Shrink
       * @see https://tailwindcss.com/docs/flex-shrink
       */ shrink: [
                {
                    shrink: [
                        '',
                        isNumber,
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            /**
       * Order
       * @see https://tailwindcss.com/docs/order
       */ order: [
                {
                    order: [
                        isInteger,
                        'first',
                        'last',
                        'none',
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            /**
       * Grid Template Columns
       * @see https://tailwindcss.com/docs/grid-template-columns
       */ 'grid-cols': [
                {
                    'grid-cols': scaleGridTemplateColsRows()
                }
            ],
            /**
       * Grid Column Start / End
       * @see https://tailwindcss.com/docs/grid-column
       */ 'col-start-end': [
                {
                    col: scaleGridColRowStartAndEnd()
                }
            ],
            /**
       * Grid Column Start
       * @see https://tailwindcss.com/docs/grid-column
       */ 'col-start': [
                {
                    'col-start': scaleGridColRowStartOrEnd()
                }
            ],
            /**
       * Grid Column End
       * @see https://tailwindcss.com/docs/grid-column
       */ 'col-end': [
                {
                    'col-end': scaleGridColRowStartOrEnd()
                }
            ],
            /**
       * Grid Template Rows
       * @see https://tailwindcss.com/docs/grid-template-rows
       */ 'grid-rows': [
                {
                    'grid-rows': scaleGridTemplateColsRows()
                }
            ],
            /**
       * Grid Row Start / End
       * @see https://tailwindcss.com/docs/grid-row
       */ 'row-start-end': [
                {
                    row: scaleGridColRowStartAndEnd()
                }
            ],
            /**
       * Grid Row Start
       * @see https://tailwindcss.com/docs/grid-row
       */ 'row-start': [
                {
                    'row-start': scaleGridColRowStartOrEnd()
                }
            ],
            /**
       * Grid Row End
       * @see https://tailwindcss.com/docs/grid-row
       */ 'row-end': [
                {
                    'row-end': scaleGridColRowStartOrEnd()
                }
            ],
            /**
       * Grid Auto Flow
       * @see https://tailwindcss.com/docs/grid-auto-flow
       */ 'grid-flow': [
                {
                    'grid-flow': [
                        'row',
                        'col',
                        'dense',
                        'row-dense',
                        'col-dense'
                    ]
                }
            ],
            /**
       * Grid Auto Columns
       * @see https://tailwindcss.com/docs/grid-auto-columns
       */ 'auto-cols': [
                {
                    'auto-cols': scaleGridAutoColsRows()
                }
            ],
            /**
       * Grid Auto Rows
       * @see https://tailwindcss.com/docs/grid-auto-rows
       */ 'auto-rows': [
                {
                    'auto-rows': scaleGridAutoColsRows()
                }
            ],
            /**
       * Gap
       * @see https://tailwindcss.com/docs/gap
       */ gap: [
                {
                    gap: scaleUnambiguousSpacing()
                }
            ],
            /**
       * Gap X
       * @see https://tailwindcss.com/docs/gap
       */ 'gap-x': [
                {
                    'gap-x': scaleUnambiguousSpacing()
                }
            ],
            /**
       * Gap Y
       * @see https://tailwindcss.com/docs/gap
       */ 'gap-y': [
                {
                    'gap-y': scaleUnambiguousSpacing()
                }
            ],
            /**
       * Justify Content
       * @see https://tailwindcss.com/docs/justify-content
       */ 'justify-content': [
                {
                    justify: [
                        ...scaleAlignPrimaryAxis(),
                        'normal'
                    ]
                }
            ],
            /**
       * Justify Items
       * @see https://tailwindcss.com/docs/justify-items
       */ 'justify-items': [
                {
                    'justify-items': [
                        ...scaleAlignSecondaryAxis(),
                        'normal'
                    ]
                }
            ],
            /**
       * Justify Self
       * @see https://tailwindcss.com/docs/justify-self
       */ 'justify-self': [
                {
                    'justify-self': [
                        'auto',
                        ...scaleAlignSecondaryAxis()
                    ]
                }
            ],
            /**
       * Align Content
       * @see https://tailwindcss.com/docs/align-content
       */ 'align-content': [
                {
                    content: [
                        'normal',
                        ...scaleAlignPrimaryAxis()
                    ]
                }
            ],
            /**
       * Align Items
       * @see https://tailwindcss.com/docs/align-items
       */ 'align-items': [
                {
                    items: [
                        ...scaleAlignSecondaryAxis(),
                        {
                            baseline: [
                                '',
                                'last'
                            ]
                        }
                    ]
                }
            ],
            /**
       * Align Self
       * @see https://tailwindcss.com/docs/align-self
       */ 'align-self': [
                {
                    self: [
                        'auto',
                        ...scaleAlignSecondaryAxis(),
                        {
                            baseline: [
                                '',
                                'last'
                            ]
                        }
                    ]
                }
            ],
            /**
       * Place Content
       * @see https://tailwindcss.com/docs/place-content
       */ 'place-content': [
                {
                    'place-content': scaleAlignPrimaryAxis()
                }
            ],
            /**
       * Place Items
       * @see https://tailwindcss.com/docs/place-items
       */ 'place-items': [
                {
                    'place-items': [
                        ...scaleAlignSecondaryAxis(),
                        'baseline'
                    ]
                }
            ],
            /**
       * Place Self
       * @see https://tailwindcss.com/docs/place-self
       */ 'place-self': [
                {
                    'place-self': [
                        'auto',
                        ...scaleAlignSecondaryAxis()
                    ]
                }
            ],
            // Spacing
            /**
       * Padding
       * @see https://tailwindcss.com/docs/padding
       */ p: [
                {
                    p: scaleUnambiguousSpacing()
                }
            ],
            /**
       * Padding Inline
       * @see https://tailwindcss.com/docs/padding
       */ px: [
                {
                    px: scaleUnambiguousSpacing()
                }
            ],
            /**
       * Padding Block
       * @see https://tailwindcss.com/docs/padding
       */ py: [
                {
                    py: scaleUnambiguousSpacing()
                }
            ],
            /**
       * Padding Inline Start
       * @see https://tailwindcss.com/docs/padding
       */ ps: [
                {
                    ps: scaleUnambiguousSpacing()
                }
            ],
            /**
       * Padding Inline End
       * @see https://tailwindcss.com/docs/padding
       */ pe: [
                {
                    pe: scaleUnambiguousSpacing()
                }
            ],
            /**
       * Padding Block Start
       * @see https://tailwindcss.com/docs/padding
       */ pbs: [
                {
                    pbs: scaleUnambiguousSpacing()
                }
            ],
            /**
       * Padding Block End
       * @see https://tailwindcss.com/docs/padding
       */ pbe: [
                {
                    pbe: scaleUnambiguousSpacing()
                }
            ],
            /**
       * Padding Top
       * @see https://tailwindcss.com/docs/padding
       */ pt: [
                {
                    pt: scaleUnambiguousSpacing()
                }
            ],
            /**
       * Padding Right
       * @see https://tailwindcss.com/docs/padding
       */ pr: [
                {
                    pr: scaleUnambiguousSpacing()
                }
            ],
            /**
       * Padding Bottom
       * @see https://tailwindcss.com/docs/padding
       */ pb: [
                {
                    pb: scaleUnambiguousSpacing()
                }
            ],
            /**
       * Padding Left
       * @see https://tailwindcss.com/docs/padding
       */ pl: [
                {
                    pl: scaleUnambiguousSpacing()
                }
            ],
            /**
       * Margin
       * @see https://tailwindcss.com/docs/margin
       */ m: [
                {
                    m: scaleMargin()
                }
            ],
            /**
       * Margin Inline
       * @see https://tailwindcss.com/docs/margin
       */ mx: [
                {
                    mx: scaleMargin()
                }
            ],
            /**
       * Margin Block
       * @see https://tailwindcss.com/docs/margin
       */ my: [
                {
                    my: scaleMargin()
                }
            ],
            /**
       * Margin Inline Start
       * @see https://tailwindcss.com/docs/margin
       */ ms: [
                {
                    ms: scaleMargin()
                }
            ],
            /**
       * Margin Inline End
       * @see https://tailwindcss.com/docs/margin
       */ me: [
                {
                    me: scaleMargin()
                }
            ],
            /**
       * Margin Block Start
       * @see https://tailwindcss.com/docs/margin
       */ mbs: [
                {
                    mbs: scaleMargin()
                }
            ],
            /**
       * Margin Block End
       * @see https://tailwindcss.com/docs/margin
       */ mbe: [
                {
                    mbe: scaleMargin()
                }
            ],
            /**
       * Margin Top
       * @see https://tailwindcss.com/docs/margin
       */ mt: [
                {
                    mt: scaleMargin()
                }
            ],
            /**
       * Margin Right
       * @see https://tailwindcss.com/docs/margin
       */ mr: [
                {
                    mr: scaleMargin()
                }
            ],
            /**
       * Margin Bottom
       * @see https://tailwindcss.com/docs/margin
       */ mb: [
                {
                    mb: scaleMargin()
                }
            ],
            /**
       * Margin Left
       * @see https://tailwindcss.com/docs/margin
       */ ml: [
                {
                    ml: scaleMargin()
                }
            ],
            /**
       * Space Between X
       * @see https://tailwindcss.com/docs/margin#adding-space-between-children
       */ 'space-x': [
                {
                    'space-x': scaleUnambiguousSpacing()
                }
            ],
            /**
       * Space Between X Reverse
       * @see https://tailwindcss.com/docs/margin#adding-space-between-children
       */ 'space-x-reverse': [
                'space-x-reverse'
            ],
            /**
       * Space Between Y
       * @see https://tailwindcss.com/docs/margin#adding-space-between-children
       */ 'space-y': [
                {
                    'space-y': scaleUnambiguousSpacing()
                }
            ],
            /**
       * Space Between Y Reverse
       * @see https://tailwindcss.com/docs/margin#adding-space-between-children
       */ 'space-y-reverse': [
                'space-y-reverse'
            ],
            // --------------
            // --- Sizing ---
            // --------------
            /**
       * Size
       * @see https://tailwindcss.com/docs/width#setting-both-width-and-height
       */ size: [
                {
                    size: scaleSizing()
                }
            ],
            /**
       * Inline Size
       * @see https://tailwindcss.com/docs/width
       */ 'inline-size': [
                {
                    inline: [
                        'auto',
                        ...scaleSizingInline()
                    ]
                }
            ],
            /**
       * Min-Inline Size
       * @see https://tailwindcss.com/docs/min-width
       */ 'min-inline-size': [
                {
                    'min-inline': [
                        'auto',
                        ...scaleSizingInline()
                    ]
                }
            ],
            /**
       * Max-Inline Size
       * @see https://tailwindcss.com/docs/max-width
       */ 'max-inline-size': [
                {
                    'max-inline': [
                        'none',
                        ...scaleSizingInline()
                    ]
                }
            ],
            /**
       * Block Size
       * @see https://tailwindcss.com/docs/height
       */ 'block-size': [
                {
                    block: [
                        'auto',
                        ...scaleSizingBlock()
                    ]
                }
            ],
            /**
       * Min-Block Size
       * @see https://tailwindcss.com/docs/min-height
       */ 'min-block-size': [
                {
                    'min-block': [
                        'auto',
                        ...scaleSizingBlock()
                    ]
                }
            ],
            /**
       * Max-Block Size
       * @see https://tailwindcss.com/docs/max-height
       */ 'max-block-size': [
                {
                    'max-block': [
                        'none',
                        ...scaleSizingBlock()
                    ]
                }
            ],
            /**
       * Width
       * @see https://tailwindcss.com/docs/width
       */ w: [
                {
                    w: [
                        themeContainer,
                        'screen',
                        ...scaleSizing()
                    ]
                }
            ],
            /**
       * Min-Width
       * @see https://tailwindcss.com/docs/min-width
       */ 'min-w': [
                {
                    'min-w': [
                        themeContainer,
                        'screen',
                        /** Deprecated. @see https://github.com/tailwindlabs/tailwindcss.com/issues/2027#issuecomment-2620152757 */ 'none',
                        ...scaleSizing()
                    ]
                }
            ],
            /**
       * Max-Width
       * @see https://tailwindcss.com/docs/max-width
       */ 'max-w': [
                {
                    'max-w': [
                        themeContainer,
                        'screen',
                        'none',
                        /** Deprecated since Tailwind CSS v4.0.0. @see https://github.com/tailwindlabs/tailwindcss.com/issues/2027#issuecomment-2620152757 */ 'prose',
                        /** Deprecated since Tailwind CSS v4.0.0. @see https://github.com/tailwindlabs/tailwindcss.com/issues/2027#issuecomment-2620152757 */ {
                            screen: [
                                themeBreakpoint
                            ]
                        },
                        ...scaleSizing()
                    ]
                }
            ],
            /**
       * Height
       * @see https://tailwindcss.com/docs/height
       */ h: [
                {
                    h: [
                        'screen',
                        'lh',
                        ...scaleSizing()
                    ]
                }
            ],
            /**
       * Min-Height
       * @see https://tailwindcss.com/docs/min-height
       */ 'min-h': [
                {
                    'min-h': [
                        'screen',
                        'lh',
                        'none',
                        ...scaleSizing()
                    ]
                }
            ],
            /**
       * Max-Height
       * @see https://tailwindcss.com/docs/max-height
       */ 'max-h': [
                {
                    'max-h': [
                        'screen',
                        'lh',
                        ...scaleSizing()
                    ]
                }
            ],
            // ------------------
            // --- Typography ---
            // ------------------
            /**
       * Font Size
       * @see https://tailwindcss.com/docs/font-size
       */ 'font-size': [
                {
                    text: [
                        'base',
                        themeText,
                        isArbitraryVariableLength,
                        isArbitraryLength
                    ]
                }
            ],
            /**
       * Font Smoothing
       * @see https://tailwindcss.com/docs/font-smoothing
       */ 'font-smoothing': [
                'antialiased',
                'subpixel-antialiased'
            ],
            /**
       * Font Style
       * @see https://tailwindcss.com/docs/font-style
       */ 'font-style': [
                'italic',
                'not-italic'
            ],
            /**
       * Font Weight
       * @see https://tailwindcss.com/docs/font-weight
       */ 'font-weight': [
                {
                    font: [
                        themeFontWeight,
                        isArbitraryVariableWeight,
                        isArbitraryWeight
                    ]
                }
            ],
            /**
       * Font Stretch
       * @see https://tailwindcss.com/docs/font-stretch
       */ 'font-stretch': [
                {
                    'font-stretch': [
                        'ultra-condensed',
                        'extra-condensed',
                        'condensed',
                        'semi-condensed',
                        'normal',
                        'semi-expanded',
                        'expanded',
                        'extra-expanded',
                        'ultra-expanded',
                        isPercent,
                        isArbitraryValue
                    ]
                }
            ],
            /**
       * Font Family
       * @see https://tailwindcss.com/docs/font-family
       */ 'font-family': [
                {
                    font: [
                        isArbitraryVariableFamilyName,
                        isArbitraryFamilyName,
                        themeFont
                    ]
                }
            ],
            /**
       * Font Feature Settings
       * @see https://tailwindcss.com/docs/font-feature-settings
       */ 'font-features': [
                {
                    'font-features': [
                        isArbitraryValue
                    ]
                }
            ],
            /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */ 'fvn-normal': [
                'normal-nums'
            ],
            /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */ 'fvn-ordinal': [
                'ordinal'
            ],
            /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */ 'fvn-slashed-zero': [
                'slashed-zero'
            ],
            /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */ 'fvn-figure': [
                'lining-nums',
                'oldstyle-nums'
            ],
            /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */ 'fvn-spacing': [
                'proportional-nums',
                'tabular-nums'
            ],
            /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */ 'fvn-fraction': [
                'diagonal-fractions',
                'stacked-fractions'
            ],
            /**
       * Letter Spacing
       * @see https://tailwindcss.com/docs/letter-spacing
       */ tracking: [
                {
                    tracking: [
                        themeTracking,
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            /**
       * Line Clamp
       * @see https://tailwindcss.com/docs/line-clamp
       */ 'line-clamp': [
                {
                    'line-clamp': [
                        isNumber,
                        'none',
                        isArbitraryVariable,
                        isArbitraryNumber
                    ]
                }
            ],
            /**
       * Line Height
       * @see https://tailwindcss.com/docs/line-height
       */ leading: [
                {
                    leading: [
                        /** Deprecated since Tailwind CSS v4.0.0. @see https://github.com/tailwindlabs/tailwindcss.com/issues/2027#issuecomment-2620152757 */ themeLeading,
                        ...scaleUnambiguousSpacing()
                    ]
                }
            ],
            /**
       * List Style Image
       * @see https://tailwindcss.com/docs/list-style-image
       */ 'list-image': [
                {
                    'list-image': [
                        'none',
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            /**
       * List Style Position
       * @see https://tailwindcss.com/docs/list-style-position
       */ 'list-style-position': [
                {
                    list: [
                        'inside',
                        'outside'
                    ]
                }
            ],
            /**
       * List Style Type
       * @see https://tailwindcss.com/docs/list-style-type
       */ 'list-style-type': [
                {
                    list: [
                        'disc',
                        'decimal',
                        'none',
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            /**
       * Text Alignment
       * @see https://tailwindcss.com/docs/text-align
       */ 'text-alignment': [
                {
                    text: [
                        'left',
                        'center',
                        'right',
                        'justify',
                        'start',
                        'end'
                    ]
                }
            ],
            /**
       * Placeholder Color
       * @deprecated since Tailwind CSS v3.0.0
       * @see https://v3.tailwindcss.com/docs/placeholder-color
       */ 'placeholder-color': [
                {
                    placeholder: scaleColor()
                }
            ],
            /**
       * Text Color
       * @see https://tailwindcss.com/docs/text-color
       */ 'text-color': [
                {
                    text: scaleColor()
                }
            ],
            /**
       * Text Decoration
       * @see https://tailwindcss.com/docs/text-decoration
       */ 'text-decoration': [
                'underline',
                'overline',
                'line-through',
                'no-underline'
            ],
            /**
       * Text Decoration Style
       * @see https://tailwindcss.com/docs/text-decoration-style
       */ 'text-decoration-style': [
                {
                    decoration: [
                        ...scaleLineStyle(),
                        'wavy'
                    ]
                }
            ],
            /**
       * Text Decoration Thickness
       * @see https://tailwindcss.com/docs/text-decoration-thickness
       */ 'text-decoration-thickness': [
                {
                    decoration: [
                        isNumber,
                        'from-font',
                        'auto',
                        isArbitraryVariable,
                        isArbitraryLength
                    ]
                }
            ],
            /**
       * Text Decoration Color
       * @see https://tailwindcss.com/docs/text-decoration-color
       */ 'text-decoration-color': [
                {
                    decoration: scaleColor()
                }
            ],
            /**
       * Text Underline Offset
       * @see https://tailwindcss.com/docs/text-underline-offset
       */ 'underline-offset': [
                {
                    'underline-offset': [
                        isNumber,
                        'auto',
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            /**
       * Text Transform
       * @see https://tailwindcss.com/docs/text-transform
       */ 'text-transform': [
                'uppercase',
                'lowercase',
                'capitalize',
                'normal-case'
            ],
            /**
       * Text Overflow
       * @see https://tailwindcss.com/docs/text-overflow
       */ 'text-overflow': [
                'truncate',
                'text-ellipsis',
                'text-clip'
            ],
            /**
       * Text Wrap
       * @see https://tailwindcss.com/docs/text-wrap
       */ 'text-wrap': [
                {
                    text: [
                        'wrap',
                        'nowrap',
                        'balance',
                        'pretty'
                    ]
                }
            ],
            /**
       * Text Indent
       * @see https://tailwindcss.com/docs/text-indent
       */ indent: [
                {
                    indent: scaleUnambiguousSpacing()
                }
            ],
            /**
       * Vertical Alignment
       * @see https://tailwindcss.com/docs/vertical-align
       */ 'vertical-align': [
                {
                    align: [
                        'baseline',
                        'top',
                        'middle',
                        'bottom',
                        'text-top',
                        'text-bottom',
                        'sub',
                        'super',
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            /**
       * Whitespace
       * @see https://tailwindcss.com/docs/whitespace
       */ whitespace: [
                {
                    whitespace: [
                        'normal',
                        'nowrap',
                        'pre',
                        'pre-line',
                        'pre-wrap',
                        'break-spaces'
                    ]
                }
            ],
            /**
       * Word Break
       * @see https://tailwindcss.com/docs/word-break
       */ break: [
                {
                    break: [
                        'normal',
                        'words',
                        'all',
                        'keep'
                    ]
                }
            ],
            /**
       * Overflow Wrap
       * @see https://tailwindcss.com/docs/overflow-wrap
       */ wrap: [
                {
                    wrap: [
                        'break-word',
                        'anywhere',
                        'normal'
                    ]
                }
            ],
            /**
       * Hyphens
       * @see https://tailwindcss.com/docs/hyphens
       */ hyphens: [
                {
                    hyphens: [
                        'none',
                        'manual',
                        'auto'
                    ]
                }
            ],
            /**
       * Content
       * @see https://tailwindcss.com/docs/content
       */ content: [
                {
                    content: [
                        'none',
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            // -------------------
            // --- Backgrounds ---
            // -------------------
            /**
       * Background Attachment
       * @see https://tailwindcss.com/docs/background-attachment
       */ 'bg-attachment': [
                {
                    bg: [
                        'fixed',
                        'local',
                        'scroll'
                    ]
                }
            ],
            /**
       * Background Clip
       * @see https://tailwindcss.com/docs/background-clip
       */ 'bg-clip': [
                {
                    'bg-clip': [
                        'border',
                        'padding',
                        'content',
                        'text'
                    ]
                }
            ],
            /**
       * Background Origin
       * @see https://tailwindcss.com/docs/background-origin
       */ 'bg-origin': [
                {
                    'bg-origin': [
                        'border',
                        'padding',
                        'content'
                    ]
                }
            ],
            /**
       * Background Position
       * @see https://tailwindcss.com/docs/background-position
       */ 'bg-position': [
                {
                    bg: scaleBgPosition()
                }
            ],
            /**
       * Background Repeat
       * @see https://tailwindcss.com/docs/background-repeat
       */ 'bg-repeat': [
                {
                    bg: scaleBgRepeat()
                }
            ],
            /**
       * Background Size
       * @see https://tailwindcss.com/docs/background-size
       */ 'bg-size': [
                {
                    bg: scaleBgSize()
                }
            ],
            /**
       * Background Image
       * @see https://tailwindcss.com/docs/background-image
       */ 'bg-image': [
                {
                    bg: [
                        'none',
                        {
                            linear: [
                                {
                                    to: [
                                        't',
                                        'tr',
                                        'r',
                                        'br',
                                        'b',
                                        'bl',
                                        'l',
                                        'tl'
                                    ]
                                },
                                isInteger,
                                isArbitraryVariable,
                                isArbitraryValue
                            ],
                            radial: [
                                '',
                                isArbitraryVariable,
                                isArbitraryValue
                            ],
                            conic: [
                                isInteger,
                                isArbitraryVariable,
                                isArbitraryValue
                            ]
                        },
                        isArbitraryVariableImage,
                        isArbitraryImage
                    ]
                }
            ],
            /**
       * Background Color
       * @see https://tailwindcss.com/docs/background-color
       */ 'bg-color': [
                {
                    bg: scaleColor()
                }
            ],
            /**
       * Gradient Color Stops From Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */ 'gradient-from-pos': [
                {
                    from: scaleGradientStopPosition()
                }
            ],
            /**
       * Gradient Color Stops Via Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */ 'gradient-via-pos': [
                {
                    via: scaleGradientStopPosition()
                }
            ],
            /**
       * Gradient Color Stops To Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */ 'gradient-to-pos': [
                {
                    to: scaleGradientStopPosition()
                }
            ],
            /**
       * Gradient Color Stops From
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */ 'gradient-from': [
                {
                    from: scaleColor()
                }
            ],
            /**
       * Gradient Color Stops Via
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */ 'gradient-via': [
                {
                    via: scaleColor()
                }
            ],
            /**
       * Gradient Color Stops To
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */ 'gradient-to': [
                {
                    to: scaleColor()
                }
            ],
            // ---------------
            // --- Borders ---
            // ---------------
            /**
       * Border Radius
       * @see https://tailwindcss.com/docs/border-radius
       */ rounded: [
                {
                    rounded: scaleRadius()
                }
            ],
            /**
       * Border Radius Start
       * @see https://tailwindcss.com/docs/border-radius
       */ 'rounded-s': [
                {
                    'rounded-s': scaleRadius()
                }
            ],
            /**
       * Border Radius End
       * @see https://tailwindcss.com/docs/border-radius
       */ 'rounded-e': [
                {
                    'rounded-e': scaleRadius()
                }
            ],
            /**
       * Border Radius Top
       * @see https://tailwindcss.com/docs/border-radius
       */ 'rounded-t': [
                {
                    'rounded-t': scaleRadius()
                }
            ],
            /**
       * Border Radius Right
       * @see https://tailwindcss.com/docs/border-radius
       */ 'rounded-r': [
                {
                    'rounded-r': scaleRadius()
                }
            ],
            /**
       * Border Radius Bottom
       * @see https://tailwindcss.com/docs/border-radius
       */ 'rounded-b': [
                {
                    'rounded-b': scaleRadius()
                }
            ],
            /**
       * Border Radius Left
       * @see https://tailwindcss.com/docs/border-radius
       */ 'rounded-l': [
                {
                    'rounded-l': scaleRadius()
                }
            ],
            /**
       * Border Radius Start Start
       * @see https://tailwindcss.com/docs/border-radius
       */ 'rounded-ss': [
                {
                    'rounded-ss': scaleRadius()
                }
            ],
            /**
       * Border Radius Start End
       * @see https://tailwindcss.com/docs/border-radius
       */ 'rounded-se': [
                {
                    'rounded-se': scaleRadius()
                }
            ],
            /**
       * Border Radius End End
       * @see https://tailwindcss.com/docs/border-radius
       */ 'rounded-ee': [
                {
                    'rounded-ee': scaleRadius()
                }
            ],
            /**
       * Border Radius End Start
       * @see https://tailwindcss.com/docs/border-radius
       */ 'rounded-es': [
                {
                    'rounded-es': scaleRadius()
                }
            ],
            /**
       * Border Radius Top Left
       * @see https://tailwindcss.com/docs/border-radius
       */ 'rounded-tl': [
                {
                    'rounded-tl': scaleRadius()
                }
            ],
            /**
       * Border Radius Top Right
       * @see https://tailwindcss.com/docs/border-radius
       */ 'rounded-tr': [
                {
                    'rounded-tr': scaleRadius()
                }
            ],
            /**
       * Border Radius Bottom Right
       * @see https://tailwindcss.com/docs/border-radius
       */ 'rounded-br': [
                {
                    'rounded-br': scaleRadius()
                }
            ],
            /**
       * Border Radius Bottom Left
       * @see https://tailwindcss.com/docs/border-radius
       */ 'rounded-bl': [
                {
                    'rounded-bl': scaleRadius()
                }
            ],
            /**
       * Border Width
       * @see https://tailwindcss.com/docs/border-width
       */ 'border-w': [
                {
                    border: scaleBorderWidth()
                }
            ],
            /**
       * Border Width Inline
       * @see https://tailwindcss.com/docs/border-width
       */ 'border-w-x': [
                {
                    'border-x': scaleBorderWidth()
                }
            ],
            /**
       * Border Width Block
       * @see https://tailwindcss.com/docs/border-width
       */ 'border-w-y': [
                {
                    'border-y': scaleBorderWidth()
                }
            ],
            /**
       * Border Width Inline Start
       * @see https://tailwindcss.com/docs/border-width
       */ 'border-w-s': [
                {
                    'border-s': scaleBorderWidth()
                }
            ],
            /**
       * Border Width Inline End
       * @see https://tailwindcss.com/docs/border-width
       */ 'border-w-e': [
                {
                    'border-e': scaleBorderWidth()
                }
            ],
            /**
       * Border Width Block Start
       * @see https://tailwindcss.com/docs/border-width
       */ 'border-w-bs': [
                {
                    'border-bs': scaleBorderWidth()
                }
            ],
            /**
       * Border Width Block End
       * @see https://tailwindcss.com/docs/border-width
       */ 'border-w-be': [
                {
                    'border-be': scaleBorderWidth()
                }
            ],
            /**
       * Border Width Top
       * @see https://tailwindcss.com/docs/border-width
       */ 'border-w-t': [
                {
                    'border-t': scaleBorderWidth()
                }
            ],
            /**
       * Border Width Right
       * @see https://tailwindcss.com/docs/border-width
       */ 'border-w-r': [
                {
                    'border-r': scaleBorderWidth()
                }
            ],
            /**
       * Border Width Bottom
       * @see https://tailwindcss.com/docs/border-width
       */ 'border-w-b': [
                {
                    'border-b': scaleBorderWidth()
                }
            ],
            /**
       * Border Width Left
       * @see https://tailwindcss.com/docs/border-width
       */ 'border-w-l': [
                {
                    'border-l': scaleBorderWidth()
                }
            ],
            /**
       * Divide Width X
       * @see https://tailwindcss.com/docs/border-width#between-children
       */ 'divide-x': [
                {
                    'divide-x': scaleBorderWidth()
                }
            ],
            /**
       * Divide Width X Reverse
       * @see https://tailwindcss.com/docs/border-width#between-children
       */ 'divide-x-reverse': [
                'divide-x-reverse'
            ],
            /**
       * Divide Width Y
       * @see https://tailwindcss.com/docs/border-width#between-children
       */ 'divide-y': [
                {
                    'divide-y': scaleBorderWidth()
                }
            ],
            /**
       * Divide Width Y Reverse
       * @see https://tailwindcss.com/docs/border-width#between-children
       */ 'divide-y-reverse': [
                'divide-y-reverse'
            ],
            /**
       * Border Style
       * @see https://tailwindcss.com/docs/border-style
       */ 'border-style': [
                {
                    border: [
                        ...scaleLineStyle(),
                        'hidden',
                        'none'
                    ]
                }
            ],
            /**
       * Divide Style
       * @see https://tailwindcss.com/docs/border-style#setting-the-divider-style
       */ 'divide-style': [
                {
                    divide: [
                        ...scaleLineStyle(),
                        'hidden',
                        'none'
                    ]
                }
            ],
            /**
       * Border Color
       * @see https://tailwindcss.com/docs/border-color
       */ 'border-color': [
                {
                    border: scaleColor()
                }
            ],
            /**
       * Border Color Inline
       * @see https://tailwindcss.com/docs/border-color
       */ 'border-color-x': [
                {
                    'border-x': scaleColor()
                }
            ],
            /**
       * Border Color Block
       * @see https://tailwindcss.com/docs/border-color
       */ 'border-color-y': [
                {
                    'border-y': scaleColor()
                }
            ],
            /**
       * Border Color Inline Start
       * @see https://tailwindcss.com/docs/border-color
       */ 'border-color-s': [
                {
                    'border-s': scaleColor()
                }
            ],
            /**
       * Border Color Inline End
       * @see https://tailwindcss.com/docs/border-color
       */ 'border-color-e': [
                {
                    'border-e': scaleColor()
                }
            ],
            /**
       * Border Color Block Start
       * @see https://tailwindcss.com/docs/border-color
       */ 'border-color-bs': [
                {
                    'border-bs': scaleColor()
                }
            ],
            /**
       * Border Color Block End
       * @see https://tailwindcss.com/docs/border-color
       */ 'border-color-be': [
                {
                    'border-be': scaleColor()
                }
            ],
            /**
       * Border Color Top
       * @see https://tailwindcss.com/docs/border-color
       */ 'border-color-t': [
                {
                    'border-t': scaleColor()
                }
            ],
            /**
       * Border Color Right
       * @see https://tailwindcss.com/docs/border-color
       */ 'border-color-r': [
                {
                    'border-r': scaleColor()
                }
            ],
            /**
       * Border Color Bottom
       * @see https://tailwindcss.com/docs/border-color
       */ 'border-color-b': [
                {
                    'border-b': scaleColor()
                }
            ],
            /**
       * Border Color Left
       * @see https://tailwindcss.com/docs/border-color
       */ 'border-color-l': [
                {
                    'border-l': scaleColor()
                }
            ],
            /**
       * Divide Color
       * @see https://tailwindcss.com/docs/divide-color
       */ 'divide-color': [
                {
                    divide: scaleColor()
                }
            ],
            /**
       * Outline Style
       * @see https://tailwindcss.com/docs/outline-style
       */ 'outline-style': [
                {
                    outline: [
                        ...scaleLineStyle(),
                        'none',
                        'hidden'
                    ]
                }
            ],
            /**
       * Outline Offset
       * @see https://tailwindcss.com/docs/outline-offset
       */ 'outline-offset': [
                {
                    'outline-offset': [
                        isNumber,
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            /**
       * Outline Width
       * @see https://tailwindcss.com/docs/outline-width
       */ 'outline-w': [
                {
                    outline: [
                        '',
                        isNumber,
                        isArbitraryVariableLength,
                        isArbitraryLength
                    ]
                }
            ],
            /**
       * Outline Color
       * @see https://tailwindcss.com/docs/outline-color
       */ 'outline-color': [
                {
                    outline: scaleColor()
                }
            ],
            // ---------------
            // --- Effects ---
            // ---------------
            /**
       * Box Shadow
       * @see https://tailwindcss.com/docs/box-shadow
       */ shadow: [
                {
                    shadow: [
                        // Deprecated since Tailwind CSS v4.0.0
                        '',
                        'none',
                        themeShadow,
                        isArbitraryVariableShadow,
                        isArbitraryShadow
                    ]
                }
            ],
            /**
       * Box Shadow Color
       * @see https://tailwindcss.com/docs/box-shadow#setting-the-shadow-color
       */ 'shadow-color': [
                {
                    shadow: scaleColor()
                }
            ],
            /**
       * Inset Box Shadow
       * @see https://tailwindcss.com/docs/box-shadow#adding-an-inset-shadow
       */ 'inset-shadow': [
                {
                    'inset-shadow': [
                        'none',
                        themeInsetShadow,
                        isArbitraryVariableShadow,
                        isArbitraryShadow
                    ]
                }
            ],
            /**
       * Inset Box Shadow Color
       * @see https://tailwindcss.com/docs/box-shadow#setting-the-inset-shadow-color
       */ 'inset-shadow-color': [
                {
                    'inset-shadow': scaleColor()
                }
            ],
            /**
       * Ring Width
       * @see https://tailwindcss.com/docs/box-shadow#adding-a-ring
       */ 'ring-w': [
                {
                    ring: scaleBorderWidth()
                }
            ],
            /**
       * Ring Width Inset
       * @see https://v3.tailwindcss.com/docs/ring-width#inset-rings
       * @deprecated since Tailwind CSS v4.0.0
       * @see https://github.com/tailwindlabs/tailwindcss/blob/v4.0.0/packages/tailwindcss/src/utilities.ts#L4158
       */ 'ring-w-inset': [
                'ring-inset'
            ],
            /**
       * Ring Color
       * @see https://tailwindcss.com/docs/box-shadow#setting-the-ring-color
       */ 'ring-color': [
                {
                    ring: scaleColor()
                }
            ],
            /**
       * Ring Offset Width
       * @see https://v3.tailwindcss.com/docs/ring-offset-width
       * @deprecated since Tailwind CSS v4.0.0
       * @see https://github.com/tailwindlabs/tailwindcss/blob/v4.0.0/packages/tailwindcss/src/utilities.ts#L4158
       */ 'ring-offset-w': [
                {
                    'ring-offset': [
                        isNumber,
                        isArbitraryLength
                    ]
                }
            ],
            /**
       * Ring Offset Color
       * @see https://v3.tailwindcss.com/docs/ring-offset-color
       * @deprecated since Tailwind CSS v4.0.0
       * @see https://github.com/tailwindlabs/tailwindcss/blob/v4.0.0/packages/tailwindcss/src/utilities.ts#L4158
       */ 'ring-offset-color': [
                {
                    'ring-offset': scaleColor()
                }
            ],
            /**
       * Inset Ring Width
       * @see https://tailwindcss.com/docs/box-shadow#adding-an-inset-ring
       */ 'inset-ring-w': [
                {
                    'inset-ring': scaleBorderWidth()
                }
            ],
            /**
       * Inset Ring Color
       * @see https://tailwindcss.com/docs/box-shadow#setting-the-inset-ring-color
       */ 'inset-ring-color': [
                {
                    'inset-ring': scaleColor()
                }
            ],
            /**
       * Text Shadow
       * @see https://tailwindcss.com/docs/text-shadow
       */ 'text-shadow': [
                {
                    'text-shadow': [
                        'none',
                        themeTextShadow,
                        isArbitraryVariableShadow,
                        isArbitraryShadow
                    ]
                }
            ],
            /**
       * Text Shadow Color
       * @see https://tailwindcss.com/docs/text-shadow#setting-the-shadow-color
       */ 'text-shadow-color': [
                {
                    'text-shadow': scaleColor()
                }
            ],
            /**
       * Opacity
       * @see https://tailwindcss.com/docs/opacity
       */ opacity: [
                {
                    opacity: [
                        isNumber,
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            /**
       * Mix Blend Mode
       * @see https://tailwindcss.com/docs/mix-blend-mode
       */ 'mix-blend': [
                {
                    'mix-blend': [
                        ...scaleBlendMode(),
                        'plus-darker',
                        'plus-lighter'
                    ]
                }
            ],
            /**
       * Background Blend Mode
       * @see https://tailwindcss.com/docs/background-blend-mode
       */ 'bg-blend': [
                {
                    'bg-blend': scaleBlendMode()
                }
            ],
            /**
       * Mask Clip
       * @see https://tailwindcss.com/docs/mask-clip
       */ 'mask-clip': [
                {
                    'mask-clip': [
                        'border',
                        'padding',
                        'content',
                        'fill',
                        'stroke',
                        'view'
                    ]
                },
                'mask-no-clip'
            ],
            /**
       * Mask Composite
       * @see https://tailwindcss.com/docs/mask-composite
       */ 'mask-composite': [
                {
                    mask: [
                        'add',
                        'subtract',
                        'intersect',
                        'exclude'
                    ]
                }
            ],
            /**
       * Mask Image
       * @see https://tailwindcss.com/docs/mask-image
       */ 'mask-image-linear-pos': [
                {
                    'mask-linear': [
                        isNumber
                    ]
                }
            ],
            'mask-image-linear-from-pos': [
                {
                    'mask-linear-from': scaleMaskImagePosition()
                }
            ],
            'mask-image-linear-to-pos': [
                {
                    'mask-linear-to': scaleMaskImagePosition()
                }
            ],
            'mask-image-linear-from-color': [
                {
                    'mask-linear-from': scaleColor()
                }
            ],
            'mask-image-linear-to-color': [
                {
                    'mask-linear-to': scaleColor()
                }
            ],
            'mask-image-t-from-pos': [
                {
                    'mask-t-from': scaleMaskImagePosition()
                }
            ],
            'mask-image-t-to-pos': [
                {
                    'mask-t-to': scaleMaskImagePosition()
                }
            ],
            'mask-image-t-from-color': [
                {
                    'mask-t-from': scaleColor()
                }
            ],
            'mask-image-t-to-color': [
                {
                    'mask-t-to': scaleColor()
                }
            ],
            'mask-image-r-from-pos': [
                {
                    'mask-r-from': scaleMaskImagePosition()
                }
            ],
            'mask-image-r-to-pos': [
                {
                    'mask-r-to': scaleMaskImagePosition()
                }
            ],
            'mask-image-r-from-color': [
                {
                    'mask-r-from': scaleColor()
                }
            ],
            'mask-image-r-to-color': [
                {
                    'mask-r-to': scaleColor()
                }
            ],
            'mask-image-b-from-pos': [
                {
                    'mask-b-from': scaleMaskImagePosition()
                }
            ],
            'mask-image-b-to-pos': [
                {
                    'mask-b-to': scaleMaskImagePosition()
                }
            ],
            'mask-image-b-from-color': [
                {
                    'mask-b-from': scaleColor()
                }
            ],
            'mask-image-b-to-color': [
                {
                    'mask-b-to': scaleColor()
                }
            ],
            'mask-image-l-from-pos': [
                {
                    'mask-l-from': scaleMaskImagePosition()
                }
            ],
            'mask-image-l-to-pos': [
                {
                    'mask-l-to': scaleMaskImagePosition()
                }
            ],
            'mask-image-l-from-color': [
                {
                    'mask-l-from': scaleColor()
                }
            ],
            'mask-image-l-to-color': [
                {
                    'mask-l-to': scaleColor()
                }
            ],
            'mask-image-x-from-pos': [
                {
                    'mask-x-from': scaleMaskImagePosition()
                }
            ],
            'mask-image-x-to-pos': [
                {
                    'mask-x-to': scaleMaskImagePosition()
                }
            ],
            'mask-image-x-from-color': [
                {
                    'mask-x-from': scaleColor()
                }
            ],
            'mask-image-x-to-color': [
                {
                    'mask-x-to': scaleColor()
                }
            ],
            'mask-image-y-from-pos': [
                {
                    'mask-y-from': scaleMaskImagePosition()
                }
            ],
            'mask-image-y-to-pos': [
                {
                    'mask-y-to': scaleMaskImagePosition()
                }
            ],
            'mask-image-y-from-color': [
                {
                    'mask-y-from': scaleColor()
                }
            ],
            'mask-image-y-to-color': [
                {
                    'mask-y-to': scaleColor()
                }
            ],
            'mask-image-radial': [
                {
                    'mask-radial': [
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            'mask-image-radial-from-pos': [
                {
                    'mask-radial-from': scaleMaskImagePosition()
                }
            ],
            'mask-image-radial-to-pos': [
                {
                    'mask-radial-to': scaleMaskImagePosition()
                }
            ],
            'mask-image-radial-from-color': [
                {
                    'mask-radial-from': scaleColor()
                }
            ],
            'mask-image-radial-to-color': [
                {
                    'mask-radial-to': scaleColor()
                }
            ],
            'mask-image-radial-shape': [
                {
                    'mask-radial': [
                        'circle',
                        'ellipse'
                    ]
                }
            ],
            'mask-image-radial-size': [
                {
                    'mask-radial': [
                        {
                            closest: [
                                'side',
                                'corner'
                            ],
                            farthest: [
                                'side',
                                'corner'
                            ]
                        }
                    ]
                }
            ],
            'mask-image-radial-pos': [
                {
                    'mask-radial-at': scalePosition()
                }
            ],
            'mask-image-conic-pos': [
                {
                    'mask-conic': [
                        isNumber
                    ]
                }
            ],
            'mask-image-conic-from-pos': [
                {
                    'mask-conic-from': scaleMaskImagePosition()
                }
            ],
            'mask-image-conic-to-pos': [
                {
                    'mask-conic-to': scaleMaskImagePosition()
                }
            ],
            'mask-image-conic-from-color': [
                {
                    'mask-conic-from': scaleColor()
                }
            ],
            'mask-image-conic-to-color': [
                {
                    'mask-conic-to': scaleColor()
                }
            ],
            /**
       * Mask Mode
       * @see https://tailwindcss.com/docs/mask-mode
       */ 'mask-mode': [
                {
                    mask: [
                        'alpha',
                        'luminance',
                        'match'
                    ]
                }
            ],
            /**
       * Mask Origin
       * @see https://tailwindcss.com/docs/mask-origin
       */ 'mask-origin': [
                {
                    'mask-origin': [
                        'border',
                        'padding',
                        'content',
                        'fill',
                        'stroke',
                        'view'
                    ]
                }
            ],
            /**
       * Mask Position
       * @see https://tailwindcss.com/docs/mask-position
       */ 'mask-position': [
                {
                    mask: scaleBgPosition()
                }
            ],
            /**
       * Mask Repeat
       * @see https://tailwindcss.com/docs/mask-repeat
       */ 'mask-repeat': [
                {
                    mask: scaleBgRepeat()
                }
            ],
            /**
       * Mask Size
       * @see https://tailwindcss.com/docs/mask-size
       */ 'mask-size': [
                {
                    mask: scaleBgSize()
                }
            ],
            /**
       * Mask Type
       * @see https://tailwindcss.com/docs/mask-type
       */ 'mask-type': [
                {
                    'mask-type': [
                        'alpha',
                        'luminance'
                    ]
                }
            ],
            /**
       * Mask Image
       * @see https://tailwindcss.com/docs/mask-image
       */ 'mask-image': [
                {
                    mask: [
                        'none',
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            // ---------------
            // --- Filters ---
            // ---------------
            /**
       * Filter
       * @see https://tailwindcss.com/docs/filter
       */ filter: [
                {
                    filter: [
                        // Deprecated since Tailwind CSS v3.0.0
                        '',
                        'none',
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            /**
       * Blur
       * @see https://tailwindcss.com/docs/blur
       */ blur: [
                {
                    blur: scaleBlur()
                }
            ],
            /**
       * Brightness
       * @see https://tailwindcss.com/docs/brightness
       */ brightness: [
                {
                    brightness: [
                        isNumber,
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            /**
       * Contrast
       * @see https://tailwindcss.com/docs/contrast
       */ contrast: [
                {
                    contrast: [
                        isNumber,
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            /**
       * Drop Shadow
       * @see https://tailwindcss.com/docs/drop-shadow
       */ 'drop-shadow': [
                {
                    'drop-shadow': [
                        // Deprecated since Tailwind CSS v4.0.0
                        '',
                        'none',
                        themeDropShadow,
                        isArbitraryVariableShadow,
                        isArbitraryShadow
                    ]
                }
            ],
            /**
       * Drop Shadow Color
       * @see https://tailwindcss.com/docs/filter-drop-shadow#setting-the-shadow-color
       */ 'drop-shadow-color': [
                {
                    'drop-shadow': scaleColor()
                }
            ],
            /**
       * Grayscale
       * @see https://tailwindcss.com/docs/grayscale
       */ grayscale: [
                {
                    grayscale: [
                        '',
                        isNumber,
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            /**
       * Hue Rotate
       * @see https://tailwindcss.com/docs/hue-rotate
       */ 'hue-rotate': [
                {
                    'hue-rotate': [
                        isNumber,
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            /**
       * Invert
       * @see https://tailwindcss.com/docs/invert
       */ invert: [
                {
                    invert: [
                        '',
                        isNumber,
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            /**
       * Saturate
       * @see https://tailwindcss.com/docs/saturate
       */ saturate: [
                {
                    saturate: [
                        isNumber,
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            /**
       * Sepia
       * @see https://tailwindcss.com/docs/sepia
       */ sepia: [
                {
                    sepia: [
                        '',
                        isNumber,
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            /**
       * Backdrop Filter
       * @see https://tailwindcss.com/docs/backdrop-filter
       */ 'backdrop-filter': [
                {
                    'backdrop-filter': [
                        // Deprecated since Tailwind CSS v3.0.0
                        '',
                        'none',
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            /**
       * Backdrop Blur
       * @see https://tailwindcss.com/docs/backdrop-blur
       */ 'backdrop-blur': [
                {
                    'backdrop-blur': scaleBlur()
                }
            ],
            /**
       * Backdrop Brightness
       * @see https://tailwindcss.com/docs/backdrop-brightness
       */ 'backdrop-brightness': [
                {
                    'backdrop-brightness': [
                        isNumber,
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            /**
       * Backdrop Contrast
       * @see https://tailwindcss.com/docs/backdrop-contrast
       */ 'backdrop-contrast': [
                {
                    'backdrop-contrast': [
                        isNumber,
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            /**
       * Backdrop Grayscale
       * @see https://tailwindcss.com/docs/backdrop-grayscale
       */ 'backdrop-grayscale': [
                {
                    'backdrop-grayscale': [
                        '',
                        isNumber,
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            /**
       * Backdrop Hue Rotate
       * @see https://tailwindcss.com/docs/backdrop-hue-rotate
       */ 'backdrop-hue-rotate': [
                {
                    'backdrop-hue-rotate': [
                        isNumber,
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            /**
       * Backdrop Invert
       * @see https://tailwindcss.com/docs/backdrop-invert
       */ 'backdrop-invert': [
                {
                    'backdrop-invert': [
                        '',
                        isNumber,
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            /**
       * Backdrop Opacity
       * @see https://tailwindcss.com/docs/backdrop-opacity
       */ 'backdrop-opacity': [
                {
                    'backdrop-opacity': [
                        isNumber,
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            /**
       * Backdrop Saturate
       * @see https://tailwindcss.com/docs/backdrop-saturate
       */ 'backdrop-saturate': [
                {
                    'backdrop-saturate': [
                        isNumber,
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            /**
       * Backdrop Sepia
       * @see https://tailwindcss.com/docs/backdrop-sepia
       */ 'backdrop-sepia': [
                {
                    'backdrop-sepia': [
                        '',
                        isNumber,
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            // --------------
            // --- Tables ---
            // --------------
            /**
       * Border Collapse
       * @see https://tailwindcss.com/docs/border-collapse
       */ 'border-collapse': [
                {
                    border: [
                        'collapse',
                        'separate'
                    ]
                }
            ],
            /**
       * Border Spacing
       * @see https://tailwindcss.com/docs/border-spacing
       */ 'border-spacing': [
                {
                    'border-spacing': scaleUnambiguousSpacing()
                }
            ],
            /**
       * Border Spacing X
       * @see https://tailwindcss.com/docs/border-spacing
       */ 'border-spacing-x': [
                {
                    'border-spacing-x': scaleUnambiguousSpacing()
                }
            ],
            /**
       * Border Spacing Y
       * @see https://tailwindcss.com/docs/border-spacing
       */ 'border-spacing-y': [
                {
                    'border-spacing-y': scaleUnambiguousSpacing()
                }
            ],
            /**
       * Table Layout
       * @see https://tailwindcss.com/docs/table-layout
       */ 'table-layout': [
                {
                    table: [
                        'auto',
                        'fixed'
                    ]
                }
            ],
            /**
       * Caption Side
       * @see https://tailwindcss.com/docs/caption-side
       */ caption: [
                {
                    caption: [
                        'top',
                        'bottom'
                    ]
                }
            ],
            // ---------------------------------
            // --- Transitions and Animation ---
            // ---------------------------------
            /**
       * Transition Property
       * @see https://tailwindcss.com/docs/transition-property
       */ transition: [
                {
                    transition: [
                        '',
                        'all',
                        'colors',
                        'opacity',
                        'shadow',
                        'transform',
                        'none',
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            /**
       * Transition Behavior
       * @see https://tailwindcss.com/docs/transition-behavior
       */ 'transition-behavior': [
                {
                    transition: [
                        'normal',
                        'discrete'
                    ]
                }
            ],
            /**
       * Transition Duration
       * @see https://tailwindcss.com/docs/transition-duration
       */ duration: [
                {
                    duration: [
                        isNumber,
                        'initial',
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            /**
       * Transition Timing Function
       * @see https://tailwindcss.com/docs/transition-timing-function
       */ ease: [
                {
                    ease: [
                        'linear',
                        'initial',
                        themeEase,
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            /**
       * Transition Delay
       * @see https://tailwindcss.com/docs/transition-delay
       */ delay: [
                {
                    delay: [
                        isNumber,
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            /**
       * Animation
       * @see https://tailwindcss.com/docs/animation
       */ animate: [
                {
                    animate: [
                        'none',
                        themeAnimate,
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            // ------------------
            // --- Transforms ---
            // ------------------
            /**
       * Backface Visibility
       * @see https://tailwindcss.com/docs/backface-visibility
       */ backface: [
                {
                    backface: [
                        'hidden',
                        'visible'
                    ]
                }
            ],
            /**
       * Perspective
       * @see https://tailwindcss.com/docs/perspective
       */ perspective: [
                {
                    perspective: [
                        themePerspective,
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            /**
       * Perspective Origin
       * @see https://tailwindcss.com/docs/perspective-origin
       */ 'perspective-origin': [
                {
                    'perspective-origin': scalePositionWithArbitrary()
                }
            ],
            /**
       * Rotate
       * @see https://tailwindcss.com/docs/rotate
       */ rotate: [
                {
                    rotate: scaleRotate()
                }
            ],
            /**
       * Rotate X
       * @see https://tailwindcss.com/docs/rotate
       */ 'rotate-x': [
                {
                    'rotate-x': scaleRotate()
                }
            ],
            /**
       * Rotate Y
       * @see https://tailwindcss.com/docs/rotate
       */ 'rotate-y': [
                {
                    'rotate-y': scaleRotate()
                }
            ],
            /**
       * Rotate Z
       * @see https://tailwindcss.com/docs/rotate
       */ 'rotate-z': [
                {
                    'rotate-z': scaleRotate()
                }
            ],
            /**
       * Scale
       * @see https://tailwindcss.com/docs/scale
       */ scale: [
                {
                    scale: scaleScale()
                }
            ],
            /**
       * Scale X
       * @see https://tailwindcss.com/docs/scale
       */ 'scale-x': [
                {
                    'scale-x': scaleScale()
                }
            ],
            /**
       * Scale Y
       * @see https://tailwindcss.com/docs/scale
       */ 'scale-y': [
                {
                    'scale-y': scaleScale()
                }
            ],
            /**
       * Scale Z
       * @see https://tailwindcss.com/docs/scale
       */ 'scale-z': [
                {
                    'scale-z': scaleScale()
                }
            ],
            /**
       * Scale 3D
       * @see https://tailwindcss.com/docs/scale
       */ 'scale-3d': [
                'scale-3d'
            ],
            /**
       * Skew
       * @see https://tailwindcss.com/docs/skew
       */ skew: [
                {
                    skew: scaleSkew()
                }
            ],
            /**
       * Skew X
       * @see https://tailwindcss.com/docs/skew
       */ 'skew-x': [
                {
                    'skew-x': scaleSkew()
                }
            ],
            /**
       * Skew Y
       * @see https://tailwindcss.com/docs/skew
       */ 'skew-y': [
                {
                    'skew-y': scaleSkew()
                }
            ],
            /**
       * Transform
       * @see https://tailwindcss.com/docs/transform
       */ transform: [
                {
                    transform: [
                        isArbitraryVariable,
                        isArbitraryValue,
                        '',
                        'none',
                        'gpu',
                        'cpu'
                    ]
                }
            ],
            /**
       * Transform Origin
       * @see https://tailwindcss.com/docs/transform-origin
       */ 'transform-origin': [
                {
                    origin: scalePositionWithArbitrary()
                }
            ],
            /**
       * Transform Style
       * @see https://tailwindcss.com/docs/transform-style
       */ 'transform-style': [
                {
                    transform: [
                        '3d',
                        'flat'
                    ]
                }
            ],
            /**
       * Translate
       * @see https://tailwindcss.com/docs/translate
       */ translate: [
                {
                    translate: scaleTranslate()
                }
            ],
            /**
       * Translate X
       * @see https://tailwindcss.com/docs/translate
       */ 'translate-x': [
                {
                    'translate-x': scaleTranslate()
                }
            ],
            /**
       * Translate Y
       * @see https://tailwindcss.com/docs/translate
       */ 'translate-y': [
                {
                    'translate-y': scaleTranslate()
                }
            ],
            /**
       * Translate Z
       * @see https://tailwindcss.com/docs/translate
       */ 'translate-z': [
                {
                    'translate-z': scaleTranslate()
                }
            ],
            /**
       * Translate None
       * @see https://tailwindcss.com/docs/translate
       */ 'translate-none': [
                'translate-none'
            ],
            // ---------------------
            // --- Interactivity ---
            // ---------------------
            /**
       * Accent Color
       * @see https://tailwindcss.com/docs/accent-color
       */ accent: [
                {
                    accent: scaleColor()
                }
            ],
            /**
       * Appearance
       * @see https://tailwindcss.com/docs/appearance
       */ appearance: [
                {
                    appearance: [
                        'none',
                        'auto'
                    ]
                }
            ],
            /**
       * Caret Color
       * @see https://tailwindcss.com/docs/just-in-time-mode#caret-color-utilities
       */ 'caret-color': [
                {
                    caret: scaleColor()
                }
            ],
            /**
       * Color Scheme
       * @see https://tailwindcss.com/docs/color-scheme
       */ 'color-scheme': [
                {
                    scheme: [
                        'normal',
                        'dark',
                        'light',
                        'light-dark',
                        'only-dark',
                        'only-light'
                    ]
                }
            ],
            /**
       * Cursor
       * @see https://tailwindcss.com/docs/cursor
       */ cursor: [
                {
                    cursor: [
                        'auto',
                        'default',
                        'pointer',
                        'wait',
                        'text',
                        'move',
                        'help',
                        'not-allowed',
                        'none',
                        'context-menu',
                        'progress',
                        'cell',
                        'crosshair',
                        'vertical-text',
                        'alias',
                        'copy',
                        'no-drop',
                        'grab',
                        'grabbing',
                        'all-scroll',
                        'col-resize',
                        'row-resize',
                        'n-resize',
                        'e-resize',
                        's-resize',
                        'w-resize',
                        'ne-resize',
                        'nw-resize',
                        'se-resize',
                        'sw-resize',
                        'ew-resize',
                        'ns-resize',
                        'nesw-resize',
                        'nwse-resize',
                        'zoom-in',
                        'zoom-out',
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            /**
       * Field Sizing
       * @see https://tailwindcss.com/docs/field-sizing
       */ 'field-sizing': [
                {
                    'field-sizing': [
                        'fixed',
                        'content'
                    ]
                }
            ],
            /**
       * Pointer Events
       * @see https://tailwindcss.com/docs/pointer-events
       */ 'pointer-events': [
                {
                    'pointer-events': [
                        'auto',
                        'none'
                    ]
                }
            ],
            /**
       * Resize
       * @see https://tailwindcss.com/docs/resize
       */ resize: [
                {
                    resize: [
                        'none',
                        '',
                        'y',
                        'x'
                    ]
                }
            ],
            /**
       * Scroll Behavior
       * @see https://tailwindcss.com/docs/scroll-behavior
       */ 'scroll-behavior': [
                {
                    scroll: [
                        'auto',
                        'smooth'
                    ]
                }
            ],
            /**
       * Scroll Margin
       * @see https://tailwindcss.com/docs/scroll-margin
       */ 'scroll-m': [
                {
                    'scroll-m': scaleUnambiguousSpacing()
                }
            ],
            /**
       * Scroll Margin Inline
       * @see https://tailwindcss.com/docs/scroll-margin
       */ 'scroll-mx': [
                {
                    'scroll-mx': scaleUnambiguousSpacing()
                }
            ],
            /**
       * Scroll Margin Block
       * @see https://tailwindcss.com/docs/scroll-margin
       */ 'scroll-my': [
                {
                    'scroll-my': scaleUnambiguousSpacing()
                }
            ],
            /**
       * Scroll Margin Inline Start
       * @see https://tailwindcss.com/docs/scroll-margin
       */ 'scroll-ms': [
                {
                    'scroll-ms': scaleUnambiguousSpacing()
                }
            ],
            /**
       * Scroll Margin Inline End
       * @see https://tailwindcss.com/docs/scroll-margin
       */ 'scroll-me': [
                {
                    'scroll-me': scaleUnambiguousSpacing()
                }
            ],
            /**
       * Scroll Margin Block Start
       * @see https://tailwindcss.com/docs/scroll-margin
       */ 'scroll-mbs': [
                {
                    'scroll-mbs': scaleUnambiguousSpacing()
                }
            ],
            /**
       * Scroll Margin Block End
       * @see https://tailwindcss.com/docs/scroll-margin
       */ 'scroll-mbe': [
                {
                    'scroll-mbe': scaleUnambiguousSpacing()
                }
            ],
            /**
       * Scroll Margin Top
       * @see https://tailwindcss.com/docs/scroll-margin
       */ 'scroll-mt': [
                {
                    'scroll-mt': scaleUnambiguousSpacing()
                }
            ],
            /**
       * Scroll Margin Right
       * @see https://tailwindcss.com/docs/scroll-margin
       */ 'scroll-mr': [
                {
                    'scroll-mr': scaleUnambiguousSpacing()
                }
            ],
            /**
       * Scroll Margin Bottom
       * @see https://tailwindcss.com/docs/scroll-margin
       */ 'scroll-mb': [
                {
                    'scroll-mb': scaleUnambiguousSpacing()
                }
            ],
            /**
       * Scroll Margin Left
       * @see https://tailwindcss.com/docs/scroll-margin
       */ 'scroll-ml': [
                {
                    'scroll-ml': scaleUnambiguousSpacing()
                }
            ],
            /**
       * Scroll Padding
       * @see https://tailwindcss.com/docs/scroll-padding
       */ 'scroll-p': [
                {
                    'scroll-p': scaleUnambiguousSpacing()
                }
            ],
            /**
       * Scroll Padding Inline
       * @see https://tailwindcss.com/docs/scroll-padding
       */ 'scroll-px': [
                {
                    'scroll-px': scaleUnambiguousSpacing()
                }
            ],
            /**
       * Scroll Padding Block
       * @see https://tailwindcss.com/docs/scroll-padding
       */ 'scroll-py': [
                {
                    'scroll-py': scaleUnambiguousSpacing()
                }
            ],
            /**
       * Scroll Padding Inline Start
       * @see https://tailwindcss.com/docs/scroll-padding
       */ 'scroll-ps': [
                {
                    'scroll-ps': scaleUnambiguousSpacing()
                }
            ],
            /**
       * Scroll Padding Inline End
       * @see https://tailwindcss.com/docs/scroll-padding
       */ 'scroll-pe': [
                {
                    'scroll-pe': scaleUnambiguousSpacing()
                }
            ],
            /**
       * Scroll Padding Block Start
       * @see https://tailwindcss.com/docs/scroll-padding
       */ 'scroll-pbs': [
                {
                    'scroll-pbs': scaleUnambiguousSpacing()
                }
            ],
            /**
       * Scroll Padding Block End
       * @see https://tailwindcss.com/docs/scroll-padding
       */ 'scroll-pbe': [
                {
                    'scroll-pbe': scaleUnambiguousSpacing()
                }
            ],
            /**
       * Scroll Padding Top
       * @see https://tailwindcss.com/docs/scroll-padding
       */ 'scroll-pt': [
                {
                    'scroll-pt': scaleUnambiguousSpacing()
                }
            ],
            /**
       * Scroll Padding Right
       * @see https://tailwindcss.com/docs/scroll-padding
       */ 'scroll-pr': [
                {
                    'scroll-pr': scaleUnambiguousSpacing()
                }
            ],
            /**
       * Scroll Padding Bottom
       * @see https://tailwindcss.com/docs/scroll-padding
       */ 'scroll-pb': [
                {
                    'scroll-pb': scaleUnambiguousSpacing()
                }
            ],
            /**
       * Scroll Padding Left
       * @see https://tailwindcss.com/docs/scroll-padding
       */ 'scroll-pl': [
                {
                    'scroll-pl': scaleUnambiguousSpacing()
                }
            ],
            /**
       * Scroll Snap Align
       * @see https://tailwindcss.com/docs/scroll-snap-align
       */ 'snap-align': [
                {
                    snap: [
                        'start',
                        'end',
                        'center',
                        'align-none'
                    ]
                }
            ],
            /**
       * Scroll Snap Stop
       * @see https://tailwindcss.com/docs/scroll-snap-stop
       */ 'snap-stop': [
                {
                    snap: [
                        'normal',
                        'always'
                    ]
                }
            ],
            /**
       * Scroll Snap Type
       * @see https://tailwindcss.com/docs/scroll-snap-type
       */ 'snap-type': [
                {
                    snap: [
                        'none',
                        'x',
                        'y',
                        'both'
                    ]
                }
            ],
            /**
       * Scroll Snap Type Strictness
       * @see https://tailwindcss.com/docs/scroll-snap-type
       */ 'snap-strictness': [
                {
                    snap: [
                        'mandatory',
                        'proximity'
                    ]
                }
            ],
            /**
       * Touch Action
       * @see https://tailwindcss.com/docs/touch-action
       */ touch: [
                {
                    touch: [
                        'auto',
                        'none',
                        'manipulation'
                    ]
                }
            ],
            /**
       * Touch Action X
       * @see https://tailwindcss.com/docs/touch-action
       */ 'touch-x': [
                {
                    'touch-pan': [
                        'x',
                        'left',
                        'right'
                    ]
                }
            ],
            /**
       * Touch Action Y
       * @see https://tailwindcss.com/docs/touch-action
       */ 'touch-y': [
                {
                    'touch-pan': [
                        'y',
                        'up',
                        'down'
                    ]
                }
            ],
            /**
       * Touch Action Pinch Zoom
       * @see https://tailwindcss.com/docs/touch-action
       */ 'touch-pz': [
                'touch-pinch-zoom'
            ],
            /**
       * User Select
       * @see https://tailwindcss.com/docs/user-select
       */ select: [
                {
                    select: [
                        'none',
                        'text',
                        'all',
                        'auto'
                    ]
                }
            ],
            /**
       * Will Change
       * @see https://tailwindcss.com/docs/will-change
       */ 'will-change': [
                {
                    'will-change': [
                        'auto',
                        'scroll',
                        'contents',
                        'transform',
                        isArbitraryVariable,
                        isArbitraryValue
                    ]
                }
            ],
            // -----------
            // --- SVG ---
            // -----------
            /**
       * Fill
       * @see https://tailwindcss.com/docs/fill
       */ fill: [
                {
                    fill: [
                        'none',
                        ...scaleColor()
                    ]
                }
            ],
            /**
       * Stroke Width
       * @see https://tailwindcss.com/docs/stroke-width
       */ 'stroke-w': [
                {
                    stroke: [
                        isNumber,
                        isArbitraryVariableLength,
                        isArbitraryLength,
                        isArbitraryNumber
                    ]
                }
            ],
            /**
       * Stroke
       * @see https://tailwindcss.com/docs/stroke
       */ stroke: [
                {
                    stroke: [
                        'none',
                        ...scaleColor()
                    ]
                }
            ],
            // ---------------------
            // --- Accessibility ---
            // ---------------------
            /**
       * Forced Color Adjust
       * @see https://tailwindcss.com/docs/forced-color-adjust
       */ 'forced-color-adjust': [
                {
                    'forced-color-adjust': [
                        'auto',
                        'none'
                    ]
                }
            ]
        },
        conflictingClassGroups: {
            overflow: [
                'overflow-x',
                'overflow-y'
            ],
            overscroll: [
                'overscroll-x',
                'overscroll-y'
            ],
            inset: [
                'inset-x',
                'inset-y',
                'inset-bs',
                'inset-be',
                'start',
                'end',
                'top',
                'right',
                'bottom',
                'left'
            ],
            'inset-x': [
                'right',
                'left'
            ],
            'inset-y': [
                'top',
                'bottom'
            ],
            flex: [
                'basis',
                'grow',
                'shrink'
            ],
            gap: [
                'gap-x',
                'gap-y'
            ],
            p: [
                'px',
                'py',
                'ps',
                'pe',
                'pbs',
                'pbe',
                'pt',
                'pr',
                'pb',
                'pl'
            ],
            px: [
                'pr',
                'pl'
            ],
            py: [
                'pt',
                'pb'
            ],
            m: [
                'mx',
                'my',
                'ms',
                'me',
                'mbs',
                'mbe',
                'mt',
                'mr',
                'mb',
                'ml'
            ],
            mx: [
                'mr',
                'ml'
            ],
            my: [
                'mt',
                'mb'
            ],
            size: [
                'w',
                'h'
            ],
            'font-size': [
                'leading'
            ],
            'fvn-normal': [
                'fvn-ordinal',
                'fvn-slashed-zero',
                'fvn-figure',
                'fvn-spacing',
                'fvn-fraction'
            ],
            'fvn-ordinal': [
                'fvn-normal'
            ],
            'fvn-slashed-zero': [
                'fvn-normal'
            ],
            'fvn-figure': [
                'fvn-normal'
            ],
            'fvn-spacing': [
                'fvn-normal'
            ],
            'fvn-fraction': [
                'fvn-normal'
            ],
            'line-clamp': [
                'display',
                'overflow'
            ],
            rounded: [
                'rounded-s',
                'rounded-e',
                'rounded-t',
                'rounded-r',
                'rounded-b',
                'rounded-l',
                'rounded-ss',
                'rounded-se',
                'rounded-ee',
                'rounded-es',
                'rounded-tl',
                'rounded-tr',
                'rounded-br',
                'rounded-bl'
            ],
            'rounded-s': [
                'rounded-ss',
                'rounded-es'
            ],
            'rounded-e': [
                'rounded-se',
                'rounded-ee'
            ],
            'rounded-t': [
                'rounded-tl',
                'rounded-tr'
            ],
            'rounded-r': [
                'rounded-tr',
                'rounded-br'
            ],
            'rounded-b': [
                'rounded-br',
                'rounded-bl'
            ],
            'rounded-l': [
                'rounded-tl',
                'rounded-bl'
            ],
            'border-spacing': [
                'border-spacing-x',
                'border-spacing-y'
            ],
            'border-w': [
                'border-w-x',
                'border-w-y',
                'border-w-s',
                'border-w-e',
                'border-w-bs',
                'border-w-be',
                'border-w-t',
                'border-w-r',
                'border-w-b',
                'border-w-l'
            ],
            'border-w-x': [
                'border-w-r',
                'border-w-l'
            ],
            'border-w-y': [
                'border-w-t',
                'border-w-b'
            ],
            'border-color': [
                'border-color-x',
                'border-color-y',
                'border-color-s',
                'border-color-e',
                'border-color-bs',
                'border-color-be',
                'border-color-t',
                'border-color-r',
                'border-color-b',
                'border-color-l'
            ],
            'border-color-x': [
                'border-color-r',
                'border-color-l'
            ],
            'border-color-y': [
                'border-color-t',
                'border-color-b'
            ],
            translate: [
                'translate-x',
                'translate-y',
                'translate-none'
            ],
            'translate-none': [
                'translate',
                'translate-x',
                'translate-y',
                'translate-z'
            ],
            'scroll-m': [
                'scroll-mx',
                'scroll-my',
                'scroll-ms',
                'scroll-me',
                'scroll-mbs',
                'scroll-mbe',
                'scroll-mt',
                'scroll-mr',
                'scroll-mb',
                'scroll-ml'
            ],
            'scroll-mx': [
                'scroll-mr',
                'scroll-ml'
            ],
            'scroll-my': [
                'scroll-mt',
                'scroll-mb'
            ],
            'scroll-p': [
                'scroll-px',
                'scroll-py',
                'scroll-ps',
                'scroll-pe',
                'scroll-pbs',
                'scroll-pbe',
                'scroll-pt',
                'scroll-pr',
                'scroll-pb',
                'scroll-pl'
            ],
            'scroll-px': [
                'scroll-pr',
                'scroll-pl'
            ],
            'scroll-py': [
                'scroll-pt',
                'scroll-pb'
            ],
            touch: [
                'touch-x',
                'touch-y',
                'touch-pz'
            ],
            'touch-x': [
                'touch'
            ],
            'touch-y': [
                'touch'
            ],
            'touch-pz': [
                'touch'
            ]
        },
        conflictingClassGroupModifiers: {
            'font-size': [
                'leading'
            ]
        },
        orderSensitiveModifiers: [
            '*',
            '**',
            'after',
            'backdrop',
            'before',
            'details-content',
            'file',
            'first-letter',
            'first-line',
            'marker',
            'placeholder',
            'selection'
        ]
    };
};
/**
 * @param baseConfig Config where other config will be merged into. This object will be mutated.
 * @param configExtension Partial config to merge into the `baseConfig`.
 */ const mergeConfigs = (baseConfig, { cacheSize, prefix, experimentalParseClassName, extend = {}, override = {} })=>{
    overrideProperty(baseConfig, 'cacheSize', cacheSize);
    overrideProperty(baseConfig, 'prefix', prefix);
    overrideProperty(baseConfig, 'experimentalParseClassName', experimentalParseClassName);
    overrideConfigProperties(baseConfig.theme, override.theme);
    overrideConfigProperties(baseConfig.classGroups, override.classGroups);
    overrideConfigProperties(baseConfig.conflictingClassGroups, override.conflictingClassGroups);
    overrideConfigProperties(baseConfig.conflictingClassGroupModifiers, override.conflictingClassGroupModifiers);
    overrideProperty(baseConfig, 'orderSensitiveModifiers', override.orderSensitiveModifiers);
    mergeConfigProperties(baseConfig.theme, extend.theme);
    mergeConfigProperties(baseConfig.classGroups, extend.classGroups);
    mergeConfigProperties(baseConfig.conflictingClassGroups, extend.conflictingClassGroups);
    mergeConfigProperties(baseConfig.conflictingClassGroupModifiers, extend.conflictingClassGroupModifiers);
    mergeArrayProperties(baseConfig, extend, 'orderSensitiveModifiers');
    return baseConfig;
};
const overrideProperty = (baseObject, overrideKey, overrideValue)=>{
    if (overrideValue !== undefined) {
        baseObject[overrideKey] = overrideValue;
    }
};
const overrideConfigProperties = (baseObject, overrideObject)=>{
    if (overrideObject) {
        for(const key in overrideObject){
            overrideProperty(baseObject, key, overrideObject[key]);
        }
    }
};
const mergeConfigProperties = (baseObject, mergeObject)=>{
    if (mergeObject) {
        for(const key in mergeObject){
            mergeArrayProperties(baseObject, mergeObject, key);
        }
    }
};
const mergeArrayProperties = (baseObject, mergeObject, key)=>{
    const mergeValue = mergeObject[key];
    if (mergeValue !== undefined) {
        baseObject[key] = baseObject[key] ? baseObject[key].concat(mergeValue) : mergeValue;
    }
};
const extendTailwindMerge = (configExtension, ...createConfig)=>typeof configExtension === 'function' ? createTailwindMerge(getDefaultConfig, configExtension, ...createConfig) : createTailwindMerge(()=>mergeConfigs(getDefaultConfig(), configExtension), ...createConfig);
const twMerge = /*#__PURE__*/ createTailwindMerge(getDefaultConfig);
;
}),
"[project]/node_modules/@hugeicons/react/dist/esm/HugeiconsIcon.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HugeiconsIcon",
    ()=>HugeiconsIcon,
    "default",
    ()=>HugeiconsIcon
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
const defaultAttributes = {
    xmlns: 'http://www.w3.org/2000/svg',
    width: 24,
    height: 24,
    viewBox: '0 0 24 24',
    fill: 'none'
};
const HugeiconsIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(({ color = 'currentColor', size = 24, strokeWidth, absoluteStrokeWidth = false, className = '', altIcon, showAlt = false, icon, primaryColor, secondaryColor, disableSecondaryOpacity = false, ...rest }, ref)=>{
    const calculatedStrokeWidth = strokeWidth !== undefined ? absoluteStrokeWidth ? Number(strokeWidth) * 24 / Number(size) : strokeWidth : undefined;
    const strokeProps = calculatedStrokeWidth !== undefined ? {
        strokeWidth: calculatedStrokeWidth,
        stroke: 'currentColor'
    } : {};
    const elementProps = {
        ref,
        ...defaultAttributes,
        width: size,
        height: size,
        color: primaryColor || color,
        className,
        ...strokeProps,
        ...rest
    };
    const currentIcon = showAlt && altIcon ? altIcon : icon;
    // Create SVG children with color handling for two-tone icons
    const svgChildren = [
        ...currentIcon
    ].sort(([, a], [, b])=>{
        const hasOpacityA = a.opacity !== undefined;
        const hasOpacityB = b.opacity !== undefined;
        return hasOpacityB ? 1 : hasOpacityA ? -1 : 0;
    }).map(([tag, attrs])=>{
        const isSecondaryPath = attrs.opacity !== undefined;
        const pathOpacity = isSecondaryPath && !disableSecondaryOpacity ? attrs.opacity : undefined;
        // Handle both stroke and fill properties based on element type
        const fillProps = secondaryColor ? {
            ...attrs.stroke !== undefined ? {
                stroke: isSecondaryPath ? secondaryColor : primaryColor || color
            } : {
                fill: isSecondaryPath ? secondaryColor : primaryColor || color
            }
        } : {};
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(tag, {
            ...attrs,
            ...strokeProps,
            ...fillProps,
            opacity: pathOpacity,
            key: attrs.key
        });
    });
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])('svg', elementProps, svgChildren);
});
HugeiconsIcon.displayName = 'HugeiconsIcon';
;
}),
"[project]/node_modules/@hugeicons/react/dist/esm/index.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hugeicons$2f$react$2f$dist$2f$esm$2f$HugeiconsIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@hugeicons/react/dist/esm/HugeiconsIcon.js [app-client] (ecmascript)");
;
}),
"[project]/node_modules/@hugeicons/core-free-icons/dist/esm/Leaf01Icon.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Leaf01Icon
]);
const Leaf01Icon = /*#__PURE__*/ [
    [
        "path",
        {
            d: "M7.64584 15.7108C7.23279 14.8966 7 13.9755 7 13C7 9.78484 9.5 7.5 13 7C17.0817 6.4169 18.8333 4.16667 20 3C23.5 16 17 19 13 19C11.9071 19 10.8825 18.7078 10 18.1973",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "0"
        }
    ],
    [
        "path",
        {
            d: "M3 21C3.5 18 5.45791 16.1355 10 15C13.2167 14.1958 15.4634 12.1791 17 10.0549",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeWidth: "1.5",
            key: "1"
        }
    ]
];
;
}),
"[project]/node_modules/@hugeicons/core-free-icons/dist/esm/Leaf01Icon.js [app-client] (ecmascript) <export default as Leaf01Icon>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Leaf01Icon",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hugeicons$2f$core$2d$free$2d$icons$2f$dist$2f$esm$2f$Leaf01Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hugeicons$2f$core$2d$free$2d$icons$2f$dist$2f$esm$2f$Leaf01Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@hugeicons/core-free-icons/dist/esm/Leaf01Icon.js [app-client] (ecmascript)");
}),
"[project]/node_modules/@hugeicons/core-free-icons/dist/esm/Tree06Icon.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Tree06Icon
]);
const Tree06Icon = /*#__PURE__*/ [
    [
        "path",
        {
            d: "M12 22V9",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "0"
        }
    ],
    [
        "path",
        {
            d: "M9.00195 18.002C7.3451 18.002 6.00195 16.6234 6.00195 14.9665C4.30581 14.7239 3.00195 13.2652 3.00195 11.502C3.00195 10.0052 3.94147 8.7279 5.26293 8.22759C5.09522 7.85339 5.00195 7.43856 5.00195 7.00195C5.00195 5.3451 6.3451 4.00195 8.00195 4.00195C8.3922 4.00195 8.76505 4.07647 9.10703 4.21204C9.45374 2.93842 10.6185 2.00195 12.002 2.00195C13.3854 2.00195 14.5502 2.93842 14.8969 4.21204C15.2389 4.07647 15.6117 4.00195 16.002 4.00195C17.6588 4.00195 19.002 5.3451 19.002 7.00195C19.002 7.43856 18.9087 7.85339 18.741 8.22759C20.0624 8.7279 21.002 10.0052 21.002 11.502C21.002 13.2653 19.698 14.724 18.0017 14.9665C18.0017 16.6234 16.6588 18.002 15.002 18.002",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "1"
        }
    ],
    [
        "path",
        {
            d: "M12 15L14.5 12.5",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "2"
        }
    ],
    [
        "path",
        {
            d: "M12 13L9.5 10.5",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "3"
        }
    ],
    [
        "path",
        {
            d: "M10 22H14",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "4"
        }
    ]
];
;
}),
"[project]/node_modules/@hugeicons/core-free-icons/dist/esm/Tree06Icon.js [app-client] (ecmascript) <export default as Tree06Icon>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Tree06Icon",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hugeicons$2f$core$2d$free$2d$icons$2f$dist$2f$esm$2f$Tree06Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hugeicons$2f$core$2d$free$2d$icons$2f$dist$2f$esm$2f$Tree06Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@hugeicons/core-free-icons/dist/esm/Tree06Icon.js [app-client] (ecmascript)");
}),
"[project]/node_modules/@hugeicons/core-free-icons/dist/esm/Yoga01Icon.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Yoga01Icon
]);
const Yoga01Icon = /*#__PURE__*/ [
    [
        "path",
        {
            d: "M9.0923 16C8.78292 16.6819 8.0701 16.986 7.43887 17.3162L3.79262 19.2233C2.32845 19.9891 3.05949 22 4.62985 22C8.12204 22 10.8836 20.3064 14.0404 19C14.835 18.6711 15.2201 18.7415 16 19.0912",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "0"
        }
    ],
    [
        "path",
        {
            d: "M9 19.0912C9.77995 18.7415 10.165 18.6711 10.9596 19C14.1164 20.3064 16.878 22 20.3702 22C21.9405 22 22.6715 19.9891 21.2074 19.2233L17.5611 17.3162C16.9299 16.986 16.2171 16.6819 15.9077 16",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "1"
        }
    ],
    [
        "path",
        {
            d: "M10 4C10 5.10457 10.8954 6 12 6C13.1046 6 14 5.10457 14 4C14 2.89543 13.1046 2 12 2C10.8954 2 10 2.89543 10 4Z",
            stroke: "currentColor",
            strokeWidth: "1.5",
            key: "2"
        }
    ],
    [
        "path",
        {
            d: "M12 8C8.68629 8 6 10.6863 6 14C9.31371 14 12 11.3137 12 8Z",
            stroke: "currentColor",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "3"
        }
    ],
    [
        "path",
        {
            d: "M12 8C15.3137 8 18 10.6863 18 14C14.6863 14 12 11.3137 12 8Z",
            stroke: "currentColor",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "4"
        }
    ]
];
;
}),
"[project]/node_modules/@hugeicons/core-free-icons/dist/esm/Yoga01Icon.js [app-client] (ecmascript) <export default as Yoga01Icon>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Yoga01Icon",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hugeicons$2f$core$2d$free$2d$icons$2f$dist$2f$esm$2f$Yoga01Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hugeicons$2f$core$2d$free$2d$icons$2f$dist$2f$esm$2f$Yoga01Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@hugeicons/core-free-icons/dist/esm/Yoga01Icon.js [app-client] (ecmascript)");
}),
"[project]/node_modules/@hugeicons/core-free-icons/dist/esm/SparklesIcon.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SparklesIcon
]);
const SparklesIcon = /*#__PURE__*/ [
    [
        "path",
        {
            d: "M15 2L15.5387 4.39157C15.9957 6.42015 17.5798 8.00431 19.6084 8.46127L22 9L19.6084 9.53873C17.5798 9.99569 15.9957 11.5798 15.5387 13.6084L15 16L14.4613 13.6084C14.0043 11.5798 12.4202 9.99569 10.3916 9.53873L8 9L10.3916 8.46127C12.4201 8.00431 14.0043 6.42015 14.4613 4.39158L15 2Z",
            stroke: "currentColor",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "0"
        }
    ],
    [
        "path",
        {
            d: "M7 12L7.38481 13.7083C7.71121 15.1572 8.84275 16.2888 10.2917 16.6152L12 17L10.2917 17.3848C8.84275 17.7112 7.71121 18.8427 7.38481 20.2917L7 22L6.61519 20.2917C6.28879 18.8427 5.15725 17.7112 3.70827 17.3848L2 17L3.70827 16.6152C5.15725 16.2888 6.28879 15.1573 6.61519 13.7083L7 12Z",
            stroke: "currentColor",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "1"
        }
    ]
];
;
}),
"[project]/node_modules/@hugeicons/core-free-icons/dist/esm/SparklesIcon.js [app-client] (ecmascript) <export default as SparklesIcon>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SparklesIcon",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hugeicons$2f$core$2d$free$2d$icons$2f$dist$2f$esm$2f$SparklesIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hugeicons$2f$core$2d$free$2d$icons$2f$dist$2f$esm$2f$SparklesIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@hugeicons/core-free-icons/dist/esm/SparklesIcon.js [app-client] (ecmascript)");
}),
"[project]/node_modules/@hugeicons/core-free-icons/dist/esm/FlowerPotIcon.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>FlowerPotIcon
]);
const FlowerPotIcon = /*#__PURE__*/ [
    [
        "path",
        {
            d: "M12 9C12 4.5 14 4 16 4C16 7 14.5 9 12 9ZM12 9C12 4.5 10 4 8 4C8 7 9.5 9 12 9Z",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "0"
        }
    ],
    [
        "path",
        {
            d: "M10 4C10 4 10.5 2.5 12 2C13.5 2.5 14 4 14 4",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "1"
        }
    ],
    [
        "path",
        {
            d: "M12 9V15",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "2"
        }
    ],
    [
        "path",
        {
            d: "M12 13C12.25 12.3333 13.2 11 15 11",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "3"
        }
    ],
    [
        "path",
        {
            d: "M13.1509 15H10.8491C8.79675 15 7.77055 15 7.2641 15.5967C6.75765 16.1934 7.03957 17.0703 7.6034 18.8242L7.69704 19.1154C8.14071 20.4955 8.36255 21.1855 8.95349 21.5878L8.97997 21.6055C9.57752 22 10.385 22 12 22C13.615 22 14.4225 22 15.02 21.6055L15.0465 21.5878C15.6375 21.1855 15.8593 20.4955 16.303 19.1154L16.3966 18.8242C16.9604 17.0703 17.2423 16.1934 16.7359 15.5967C16.2294 15 15.2033 15 13.1509 15Z",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "4"
        }
    ]
];
;
}),
"[project]/node_modules/@hugeicons/core-free-icons/dist/esm/FlowerPotIcon.js [app-client] (ecmascript) <export default as FlowerPotIcon>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FlowerPotIcon",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hugeicons$2f$core$2d$free$2d$icons$2f$dist$2f$esm$2f$FlowerPotIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hugeicons$2f$core$2d$free$2d$icons$2f$dist$2f$esm$2f$FlowerPotIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@hugeicons/core-free-icons/dist/esm/FlowerPotIcon.js [app-client] (ecmascript)");
}),
"[project]/node_modules/@hugeicons/core-free-icons/dist/esm/Book01Icon.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Book01Icon
]);
const Book01Icon = /*#__PURE__*/ [
    [
        "path",
        {
            d: "M20 22H6C4.89543 22 4 21.1046 4 20M4 20C4 18.8954 4.89543 18 6 18H18C19.1046 18 20 17.1046 20 16V2C20 3.10457 19.1046 4 18 4L10 4C7.17157 4 5.75736 4 4.87868 4.87868C4 5.75736 4 7.17157 4 10V20Z",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "0"
        }
    ],
    [
        "path",
        {
            d: "M18.5 18C18.5 18 17.5 18.7628 17.5 20C17.5 21.2372 18.5 22 18.5 22",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "1"
        }
    ],
    [
        "path",
        {
            d: "M9 4V8",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "2"
        }
    ]
];
;
}),
"[project]/node_modules/@hugeicons/core-free-icons/dist/esm/Book01Icon.js [app-client] (ecmascript) <export default as Book01Icon>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Book01Icon",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hugeicons$2f$core$2d$free$2d$icons$2f$dist$2f$esm$2f$Book01Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hugeicons$2f$core$2d$free$2d$icons$2f$dist$2f$esm$2f$Book01Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@hugeicons/core-free-icons/dist/esm/Book01Icon.js [app-client] (ecmascript)");
}),
"[project]/node_modules/@hugeicons/core-free-icons/dist/esm/Coins01Icon.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Coins01Icon
]);
const Coins01Icon = /*#__PURE__*/ [
    [
        "ellipse",
        {
            cx: "15.5",
            cy: "11",
            rx: "6.5",
            ry: "2",
            stroke: "currentColor",
            strokeWidth: "1.5",
            key: "0"
        }
    ],
    [
        "path",
        {
            d: "M22 15.5C22 16.6046 19.0899 17.5 15.5 17.5C11.9101 17.5 9 16.6046 9 15.5",
            stroke: "currentColor",
            strokeWidth: "1.5",
            key: "1"
        }
    ],
    [
        "path",
        {
            d: "M22 11V19.8C22 21.015 19.0899 22 15.5 22C11.9101 22 9 21.015 9 19.8V11",
            stroke: "currentColor",
            strokeWidth: "1.5",
            key: "2"
        }
    ],
    [
        "ellipse",
        {
            cx: "8.5",
            cy: "4",
            rx: "6.5",
            ry: "2",
            stroke: "currentColor",
            strokeWidth: "1.5",
            key: "3"
        }
    ],
    [
        "path",
        {
            d: "M6 11C4.10819 10.7698 2.36991 10.1745 2 9M6 16C4.10819 15.7698 2.36991 15.1745 2 14",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeWidth: "1.5",
            key: "4"
        }
    ],
    [
        "path",
        {
            d: "M6 21C4.10819 20.7698 2.36991 20.1745 2 19L2 4",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeWidth: "1.5",
            key: "5"
        }
    ],
    [
        "path",
        {
            d: "M15 6V4",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeWidth: "1.5",
            key: "6"
        }
    ]
];
;
}),
"[project]/node_modules/@hugeicons/core-free-icons/dist/esm/Coins01Icon.js [app-client] (ecmascript) <export default as Coins01Icon>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Coins01Icon",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hugeicons$2f$core$2d$free$2d$icons$2f$dist$2f$esm$2f$Coins01Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hugeicons$2f$core$2d$free$2d$icons$2f$dist$2f$esm$2f$Coins01Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@hugeicons/core-free-icons/dist/esm/Coins01Icon.js [app-client] (ecmascript)");
}),
"[project]/node_modules/@base-ui/react/esm/field/index.parts.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
;
;
;
;
;
;
}),
"[project]/node_modules/@base-ui/react/esm/field/control/FieldControlDataAttributes.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FieldControlDataAttributes",
    ()=>FieldControlDataAttributes
]);
let FieldControlDataAttributes = /*#__PURE__*/ function(FieldControlDataAttributes) {
    /**
   * Present when the field is disabled.
   */ FieldControlDataAttributes["disabled"] = "data-disabled";
    /**
   * Present when the field is in valid state.
   */ FieldControlDataAttributes["valid"] = "data-valid";
    /**
   * Present when the field is in invalid state.
   */ FieldControlDataAttributes["invalid"] = "data-invalid";
    /**
   * Present when the field has been touched.
   */ FieldControlDataAttributes["touched"] = "data-touched";
    /**
   * Present when the field's value has changed.
   */ FieldControlDataAttributes["dirty"] = "data-dirty";
    /**
   * Present when the field is filled.
   */ FieldControlDataAttributes["filled"] = "data-filled";
    /**
   * Present when the field control is focused.
   */ FieldControlDataAttributes["focused"] = "data-focused";
    return FieldControlDataAttributes;
}({});
}),
"[project]/node_modules/@base-ui/react/esm/field/utils/constants.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEFAULT_FIELD_ROOT_STATE",
    ()=>DEFAULT_FIELD_ROOT_STATE,
    "DEFAULT_FIELD_STATE_ATTRIBUTES",
    ()=>DEFAULT_FIELD_STATE_ATTRIBUTES,
    "DEFAULT_VALIDITY_STATE",
    ()=>DEFAULT_VALIDITY_STATE,
    "fieldValidityMapping",
    ()=>fieldValidityMapping
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$control$2f$FieldControlDataAttributes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/field/control/FieldControlDataAttributes.js [app-client] (ecmascript)");
;
const DEFAULT_VALIDITY_STATE = {
    badInput: false,
    customError: false,
    patternMismatch: false,
    rangeOverflow: false,
    rangeUnderflow: false,
    stepMismatch: false,
    tooLong: false,
    tooShort: false,
    typeMismatch: false,
    valid: null,
    valueMissing: false
};
const DEFAULT_FIELD_STATE_ATTRIBUTES = {
    valid: null,
    touched: false,
    dirty: false,
    filled: false,
    focused: false
};
const DEFAULT_FIELD_ROOT_STATE = {
    disabled: false,
    ...DEFAULT_FIELD_STATE_ATTRIBUTES
};
const fieldValidityMapping = {
    valid (value) {
        if (value === null) {
            return null;
        }
        if (value) {
            return {
                [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$control$2f$FieldControlDataAttributes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FieldControlDataAttributes"].valid]: ''
            };
        }
        return {
            [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$control$2f$FieldControlDataAttributes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FieldControlDataAttributes"].invalid]: ''
        };
    }
};
}),
"[project]/node_modules/@base-ui/react/esm/field/root/FieldRootContext.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FieldRootContext",
    ()=>FieldRootContext,
    "useFieldRootContext",
    ()=>useFieldRootContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$empty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/empty.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$utils$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/field/utils/constants.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
const FieldRootContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"]({
    invalid: undefined,
    name: undefined,
    validityData: {
        state: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$utils$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_VALIDITY_STATE"],
        errors: [],
        error: '',
        value: '',
        initialValue: null
    },
    setValidityData: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$empty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NOOP"],
    disabled: undefined,
    touched: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$utils$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_FIELD_STATE_ATTRIBUTES"].touched,
    setTouched: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$empty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NOOP"],
    dirty: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$utils$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_FIELD_STATE_ATTRIBUTES"].dirty,
    setDirty: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$empty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NOOP"],
    filled: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$utils$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_FIELD_STATE_ATTRIBUTES"].filled,
    setFilled: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$empty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NOOP"],
    focused: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$utils$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_FIELD_STATE_ATTRIBUTES"].focused,
    setFocused: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$empty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NOOP"],
    validate: ()=>null,
    validationMode: 'onSubmit',
    validationDebounceTime: 0,
    shouldValidateOnChange: ()=>false,
    state: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$utils$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_FIELD_ROOT_STATE"],
    markedDirtyRef: {
        current: false
    },
    validation: {
        getValidationProps: (props = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$empty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_OBJECT"])=>props,
        getInputValidationProps: (props = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$empty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_OBJECT"])=>props,
        inputRef: {
            current: null
        },
        commit: async ()=>{}
    }
});
if ("TURBOPACK compile-time truthy", 1) FieldRootContext.displayName = "FieldRootContext";
function useFieldRootContext(optional = true) {
    const context = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](FieldRootContext);
    if (context.setValidityData === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$empty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NOOP"] && !optional) {
        throw new Error(("TURBOPACK compile-time truthy", 1) ? 'Base UI: FieldRootContext is missing. Field parts must be placed within <Field.Root>.' : "TURBOPACK unreachable");
    }
    return context;
}
}),
"[project]/node_modules/@base-ui/react/esm/fieldset/root/FieldsetRootContext.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FieldsetRootContext",
    ()=>FieldsetRootContext,
    "useFieldsetRootContext",
    ()=>useFieldsetRootContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
'use client';
;
;
const FieldsetRootContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"]({
    legendId: undefined,
    setLegendId: ()=>{},
    disabled: undefined
});
if ("TURBOPACK compile-time truthy", 1) FieldsetRootContext.displayName = "FieldsetRootContext";
function useFieldsetRootContext(optional = false) {
    const context = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](FieldsetRootContext);
    if (!context && !optional) {
        throw new Error(("TURBOPACK compile-time truthy", 1) ? 'Base UI: FieldsetRootContext is missing. Fieldset parts must be placed within <Fieldset.Root>.' : "TURBOPACK unreachable");
    }
    return context;
}
}),
"[project]/node_modules/@base-ui/react/esm/form/FormContext.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FormContext",
    ()=>FormContext,
    "useFormContext",
    ()=>useFormContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$empty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/empty.js [app-client] (ecmascript)");
'use client';
;
;
const FormContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"]({
    formRef: {
        current: {
            fields: new Map()
        }
    },
    errors: {},
    clearErrors: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$empty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NOOP"],
    validationMode: 'onSubmit',
    submitAttemptedRef: {
        current: false
    }
});
if ("TURBOPACK compile-time truthy", 1) FormContext.displayName = "FormContext";
function useFormContext() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](FormContext);
}
}),
"[project]/node_modules/@base-ui/utils/esm/useId.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useId",
    ()=>useId
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$safeReact$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/safeReact.js [app-client] (ecmascript)");
'use client';
;
;
let globalId = 0;
// TODO React 17: Remove `useGlobalId` once React 17 support is removed
function useGlobalId(idOverride, prefix = 'mui') {
    const [defaultId, setDefaultId] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](idOverride);
    const id = idOverride || defaultId;
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "useGlobalId.useEffect": ()=>{
            if (defaultId == null) {
                // Fallback to this default id when possible.
                // Use the incrementing value for client-side rendering only.
                // We can't use it server-side.
                // If you want to use random values please consider the Birthday Problem: https://en.wikipedia.org/wiki/Birthday_problem
                globalId += 1;
                setDefaultId(`${prefix}-${globalId}`);
            }
        }
    }["useGlobalId.useEffect"], [
        defaultId,
        prefix
    ]);
    return id;
}
const maybeReactUseId = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$safeReact$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SafeReact"].useId;
function useId(idOverride, prefix) {
    // React.useId() is only available from React 17.0.0.
    if (maybeReactUseId !== undefined) {
        const reactId = maybeReactUseId();
        return idOverride ?? (prefix ? `${prefix}-${reactId}` : reactId);
    }
    // TODO: uncomment once we enable eslint-plugin-react-compiler // eslint-disable-next-line react-compiler/react-compiler
    // eslint-disable-next-line react-hooks/rules-of-hooks -- `React.useId` is invariant at runtime.
    return useGlobalId(idOverride, prefix);
}
}),
"[project]/node_modules/@base-ui/react/esm/utils/useBaseUiId.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useBaseUiId",
    ()=>useBaseUiId
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/useId.js [app-client] (ecmascript)");
'use client';
;
function useBaseUiId(idOverride) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])(idOverride, 'base-ui');
}
}),
"[project]/node_modules/@base-ui/react/esm/labelable-provider/LabelableContext.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LabelableContext",
    ()=>LabelableContext,
    "useLabelableContext",
    ()=>useLabelableContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$empty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/empty.js [app-client] (ecmascript)");
'use client';
;
;
const LabelableContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"]({
    controlId: undefined,
    registerControlId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$empty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NOOP"],
    labelId: undefined,
    setLabelId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$empty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NOOP"],
    messageIds: [],
    setMessageIds: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$empty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NOOP"],
    getDescriptionProps: (externalProps)=>externalProps
});
if ("TURBOPACK compile-time truthy", 1) LabelableContext.displayName = "LabelableContext";
function useLabelableContext() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](LabelableContext);
}
}),
"[project]/node_modules/@base-ui/react/esm/labelable-provider/LabelableProvider.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LabelableProvider",
    ()=>LabelableProvider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useStableCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/useStableCallback.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useRefWithInit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/useRefWithInit.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$merge$2d$props$2f$mergeProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/merge-props/mergeProps.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$useBaseUiId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/utils/useBaseUiId.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$labelable$2d$provider$2f$LabelableContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/labelable-provider/LabelableContext.js [app-client] (ecmascript)");
/**
 * @internal
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
const LabelableProvider = function LabelableProvider(props) {
    const defaultId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$useBaseUiId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBaseUiId"])();
    const initialControlId = props.controlId === undefined ? defaultId : props.controlId;
    const [controlId, setControlIdState] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](initialControlId);
    const [labelId, setLabelId] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](props.labelId);
    const [messageIds, setMessageIds] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]([]);
    const registrationsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useRefWithInit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRefWithInit"])({
        "LabelableProvider.useRefWithInit[registrationsRef]": ()=>new Map()
    }["LabelableProvider.useRefWithInit[registrationsRef]"]);
    const { messageIds: parentMessageIds } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$labelable$2d$provider$2f$LabelableContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLabelableContext"])();
    const registerControlId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useStableCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "LabelableProvider.useStableCallback[registerControlId]": (source, nextId)=>{
            const registrations = registrationsRef.current;
            if (nextId === undefined) {
                registrations.delete(source);
                return;
            }
            registrations.set(source, nextId);
            // Only flush when registering, not when unregistering.
            // This prevents loops during rapid unmount/remount cycles (e.g. React Activity).
            // The next registration will pick up the correct state.
            setControlIdState({
                "LabelableProvider.useStableCallback[registerControlId]": (prev)=>{
                    if (registrations.size === 0) {
                        return undefined;
                    }
                    let nextControlId;
                    for (const id of registrations.values()){
                        if (prev !== undefined && id === prev) {
                            return prev;
                        }
                        if (nextControlId === undefined) {
                            nextControlId = id;
                        }
                    }
                    return nextControlId;
                }
            }["LabelableProvider.useStableCallback[registerControlId]"]);
        }
    }["LabelableProvider.useStableCallback[registerControlId]"]);
    const getDescriptionProps = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "LabelableProvider.useCallback[getDescriptionProps]": (externalProps)=>{
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$merge$2d$props$2f$mergeProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeProps"])({
                'aria-describedby': parentMessageIds.concat(messageIds).join(' ') || undefined
            }, externalProps);
        }
    }["LabelableProvider.useCallback[getDescriptionProps]"], [
        parentMessageIds,
        messageIds
    ]);
    const contextValue = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "LabelableProvider.useMemo[contextValue]": ()=>({
                controlId,
                registerControlId,
                labelId,
                setLabelId,
                messageIds,
                setMessageIds,
                getDescriptionProps
            })
    }["LabelableProvider.useMemo[contextValue]"], [
        controlId,
        registerControlId,
        labelId,
        setLabelId,
        messageIds,
        setMessageIds,
        getDescriptionProps
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$labelable$2d$provider$2f$LabelableContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LabelableContext"].Provider, {
        value: contextValue,
        children: props.children
    });
};
if ("TURBOPACK compile-time truthy", 1) LabelableProvider.displayName = "LabelableProvider";
}),
"[project]/node_modules/@base-ui/utils/esm/useOnMount.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useOnMount",
    ()=>useOnMount
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
'use client';
;
const EMPTY = [];
function useOnMount(fn) {
    // TODO: uncomment once we enable eslint-plugin-react-compiler // eslint-disable-next-line react-compiler/react-compiler -- no need to put `fn` in the dependency array
    /* eslint-disable react-hooks/exhaustive-deps */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"](fn, EMPTY);
/* eslint-enable react-hooks/exhaustive-deps */ }
}),
"[project]/node_modules/@base-ui/utils/esm/useTimeout.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Timeout",
    ()=>Timeout,
    "useTimeout",
    ()=>useTimeout
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useRefWithInit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/useRefWithInit.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useOnMount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/useOnMount.js [app-client] (ecmascript)");
'use client';
;
;
const EMPTY = 0;
class Timeout {
    static create() {
        return new Timeout();
    }
    currentId = EMPTY;
    /**
   * Executes `fn` after `delay`, clearing any previously scheduled call.
   */ start(delay, fn) {
        this.clear();
        this.currentId = setTimeout(()=>{
            this.currentId = EMPTY;
            fn();
        }, delay); /* Node.js types are enabled in development */ 
    }
    isStarted() {
        return this.currentId !== EMPTY;
    }
    clear = ()=>{
        if (this.currentId !== EMPTY) {
            clearTimeout(this.currentId);
            this.currentId = EMPTY;
        }
    };
    disposeEffect = ()=>{
        return this.clear;
    };
}
function useTimeout() {
    const timeout = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useRefWithInit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRefWithInit"])(Timeout.create).current;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useOnMount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnMount"])(timeout.disposeEffect);
    return timeout;
}
}),
"[project]/node_modules/@base-ui/react/esm/field/utils/getCombinedFieldValidityData.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Combines the field's client-side, stateful validity data with the external invalid state to
 * determine the field's true validity.
 */ __turbopack_context__.s([
    "getCombinedFieldValidityData",
    ()=>getCombinedFieldValidityData
]);
function getCombinedFieldValidityData(validityData, invalid) {
    return {
        ...validityData,
        state: {
            ...validityData.state,
            valid: !invalid && validityData.state.valid
        }
    };
}
}),
"[project]/node_modules/@base-ui/react/esm/field/root/useFieldValidation.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useFieldValidation",
    ()=>useFieldValidation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$empty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/empty.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useTimeout$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/useTimeout.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useStableCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/useStableCallback.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$labelable$2d$provider$2f$LabelableContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/labelable-provider/LabelableContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$merge$2d$props$2f$mergeProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/merge-props/mergeProps.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$utils$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/field/utils/constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$form$2f$FormContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/form/FormContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$utils$2f$getCombinedFieldValidityData$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/field/utils/getCombinedFieldValidityData.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
const validityKeys = Object.keys(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$utils$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_VALIDITY_STATE"]);
function isOnlyValueMissing(state) {
    if (!state || state.valid || !state.valueMissing) {
        return false;
    }
    let onlyValueMissing = false;
    for (const key of validityKeys){
        if (key === 'valid') {
            continue;
        }
        if (key === 'valueMissing') {
            onlyValueMissing = state[key];
        }
        if (state[key]) {
            onlyValueMissing = false;
        }
    }
    return onlyValueMissing;
}
function useFieldValidation(params) {
    const { formRef, clearErrors } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$form$2f$FormContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormContext"])();
    const { setValidityData, validate, validityData, validationDebounceTime, invalid, markedDirtyRef, state, name, shouldValidateOnChange } = params;
    const { controlId, getDescriptionProps } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$labelable$2d$provider$2f$LabelableContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLabelableContext"])();
    const timeout = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useTimeout$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTimeout"])();
    const inputRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const commit = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useStableCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "useFieldValidation.useStableCallback[commit]": async (value, revalidate = false)=>{
            const element = inputRef.current;
            if (!element) {
                return;
            }
            if (revalidate) {
                if (state.valid !== false) {
                    return;
                }
                const currentNativeValidity = element.validity;
                if (!currentNativeValidity.valueMissing) {
                    // The 'valueMissing' (required) condition has been resolved by the user typing.
                    // Temporarily mark the field as valid for this onChange event.
                    // Other native errors (e.g., typeMismatch) will be caught by full validation on blur or submit.
                    const nextValidityData = {
                        value,
                        state: {
                            ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$utils$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_VALIDITY_STATE"],
                            valid: true
                        },
                        error: '',
                        errors: [],
                        initialValue: validityData.initialValue
                    };
                    element.setCustomValidity('');
                    if (controlId) {
                        const currentFieldData = formRef.current.fields.get(controlId);
                        if (currentFieldData) {
                            formRef.current.fields.set(controlId, {
                                ...currentFieldData,
                                ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$utils$2f$getCombinedFieldValidityData$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCombinedFieldValidityData"])(nextValidityData, false) // invalid = false
                            });
                        }
                    }
                    setValidityData(nextValidityData);
                    return;
                }
                // Value is still missing, or other conditions apply.
                // Let's use a representation of current validity for isOnlyValueMissing.
                const currentNativeValidityObject = validityKeys.reduce({
                    "useFieldValidation.useStableCallback[commit].currentNativeValidityObject": (acc, key)=>{
                        acc[key] = currentNativeValidity[key];
                        return acc;
                    }
                }["useFieldValidation.useStableCallback[commit].currentNativeValidityObject"], {});
                // If it's (still) natively invalid due to something other than just valueMissing,
                // then bail from this revalidation on change to avoid "scolding" for other errors.
                if (!currentNativeValidityObject.valid && !isOnlyValueMissing(currentNativeValidityObject)) {
                    return;
                }
            // If valueMissing is still true AND it's the only issue, or if the field is now natively valid,
            // let it fall through to the main validation logic below.
            }
            function getState(el) {
                const computedState = validityKeys.reduce({
                    "useFieldValidation.useStableCallback[commit].getState.computedState": (acc, key)=>{
                        acc[key] = el.validity[key];
                        return acc;
                    }
                }["useFieldValidation.useStableCallback[commit].getState.computedState"], {});
                let hasOnlyValueMissingError = false;
                for (const key of validityKeys){
                    if (key === 'valid') {
                        continue;
                    }
                    if (key === 'valueMissing' && computedState[key]) {
                        hasOnlyValueMissingError = true;
                    } else if (computedState[key]) {
                        return computedState;
                    }
                }
                // Only make `valueMissing` mark the field invalid if it's been changed
                // to reduce error noise.
                if (hasOnlyValueMissingError && !markedDirtyRef.current) {
                    computedState.valid = true;
                    computedState.valueMissing = false;
                }
                return computedState;
            }
            timeout.clear();
            let result = null;
            let validationErrors = [];
            const nextState = getState(element);
            let defaultValidationMessage;
            const validateOnChange = shouldValidateOnChange();
            if (element.validationMessage && !validateOnChange) {
                // not validating on change, if there is a `validationMessage` from
                // native validity, set errors and skip calling the custom validate fn
                defaultValidationMessage = element.validationMessage;
                validationErrors = [
                    element.validationMessage
                ];
            } else {
                // call the validate function because either
                // - validating on change, or
                // - native constraint validations passed, custom validity check is next
                const formValues = Array.from(formRef.current.fields.values()).reduce({
                    "useFieldValidation.useStableCallback[commit].formValues": (acc, field)=>{
                        if (field.name) {
                            acc[field.name] = field.getValue();
                        }
                        return acc;
                    }
                }["useFieldValidation.useStableCallback[commit].formValues"], {});
                const resultOrPromise = validate(value, formValues);
                if (typeof resultOrPromise === 'object' && resultOrPromise !== null && 'then' in resultOrPromise) {
                    result = await resultOrPromise;
                } else {
                    result = resultOrPromise;
                }
                if (result !== null) {
                    nextState.valid = false;
                    nextState.customError = true;
                    if (Array.isArray(result)) {
                        validationErrors = result;
                        element.setCustomValidity(result.join('\n'));
                    } else if (result) {
                        validationErrors = [
                            result
                        ];
                        element.setCustomValidity(result);
                    }
                } else if (validateOnChange) {
                    // validate function returned no errors, if validating on change
                    // we need to clear the custom validity state
                    element.setCustomValidity('');
                    nextState.customError = false;
                    if (element.validationMessage) {
                        defaultValidationMessage = element.validationMessage;
                        validationErrors = [
                            element.validationMessage
                        ];
                    } else if (element.validity.valid && !nextState.valid) {
                        nextState.valid = true;
                    }
                }
            }
            const nextValidityData = {
                value,
                state: nextState,
                error: defaultValidationMessage ?? (Array.isArray(result) ? result[0] : result ?? ''),
                errors: validationErrors,
                initialValue: validityData.initialValue
            };
            if (controlId) {
                const currentFieldData = formRef.current.fields.get(controlId);
                if (currentFieldData) {
                    formRef.current.fields.set(controlId, {
                        ...currentFieldData,
                        // Keep Form-level errors part of overall field validity for submit blocking/focus logic.
                        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$utils$2f$getCombinedFieldValidityData$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCombinedFieldValidityData"])(nextValidityData, invalid)
                    });
                }
            }
            setValidityData(nextValidityData);
        }
    }["useFieldValidation.useStableCallback[commit]"]);
    const getValidationProps = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "useFieldValidation.useCallback[getValidationProps]": (externalProps = {})=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$merge$2d$props$2f$mergeProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeProps"])(getDescriptionProps, state.valid === false ? {
                'aria-invalid': true
            } : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$empty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_OBJECT"], externalProps)
    }["useFieldValidation.useCallback[getValidationProps]"], [
        getDescriptionProps,
        state.valid
    ]);
    const getInputValidationProps = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "useFieldValidation.useCallback[getInputValidationProps]": (externalProps = {})=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$merge$2d$props$2f$mergeProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeProps"])({
                onChange (event) {
                    // Workaround for https://github.com/facebook/react/issues/9023
                    if (event.nativeEvent.defaultPrevented) {
                        return;
                    }
                    clearErrors(name);
                    if (!shouldValidateOnChange()) {
                        commit(event.currentTarget.value, true);
                        return;
                    }
                    // When validating on change, run client-side validation even if
                    // externally invalid
                    const element = event.currentTarget;
                    if (element.value === '') {
                        // Ignore the debounce time for empty values.
                        commit(element.value);
                        return;
                    }
                    timeout.clear();
                    if (validationDebounceTime) {
                        timeout.start(validationDebounceTime, {
                            "useFieldValidation.useCallback[getInputValidationProps]": ()=>{
                                commit(element.value);
                            }
                        }["useFieldValidation.useCallback[getInputValidationProps]"]);
                    } else {
                        commit(element.value);
                    }
                }
            }, getValidationProps(externalProps))
    }["useFieldValidation.useCallback[getInputValidationProps]"], [
        getValidationProps,
        clearErrors,
        name,
        timeout,
        commit,
        validationDebounceTime,
        shouldValidateOnChange
    ]);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "useFieldValidation.useMemo": ()=>({
                getValidationProps,
                getInputValidationProps,
                inputRef,
                commit
            })
    }["useFieldValidation.useMemo"], [
        getValidationProps,
        getInputValidationProps,
        commit
    ]);
}
}),
"[project]/node_modules/@base-ui/react/esm/field/root/FieldRoot.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FieldRoot",
    ()=>FieldRoot
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useStableCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/useStableCallback.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$root$2f$FieldRootContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/field/root/FieldRootContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$utils$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/field/utils/constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$fieldset$2f$root$2f$FieldsetRootContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/fieldset/root/FieldsetRootContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$form$2f$FormContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/form/FormContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$labelable$2d$provider$2f$LabelableProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/labelable-provider/LabelableProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$useRenderElement$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/utils/useRenderElement.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$root$2f$useFieldValidation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/field/root/useFieldValidation.js [app-client] (ecmascript)");
/**
 * @internal
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
const FieldRootInner = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function FieldRootInner(componentProps, forwardedRef) {
    const { errors, validationMode: formValidationMode, submitAttemptedRef } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$form$2f$FormContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormContext"])();
    const { render, className, validate: validateProp, validationDebounceTime = 0, validationMode = formValidationMode, name, disabled: disabledProp = false, invalid: invalidProp, dirty: dirtyProp, touched: touchedProp, actionsRef, ...elementProps } = componentProps;
    const { disabled: disabledFieldset } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$fieldset$2f$root$2f$FieldsetRootContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFieldsetRootContext"])();
    const validate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useStableCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])(validateProp || ({
        "FieldRootInner.FieldRootInner.useStableCallback[validate]": ()=>null
    })["FieldRootInner.FieldRootInner.useStableCallback[validate]"]);
    const disabled = disabledFieldset || disabledProp;
    const [touchedState, setTouchedUnwrapped] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](false);
    const [dirtyState, setDirtyUnwrapped] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](false);
    const [filled, setFilled] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](false);
    const [focused, setFocused] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](false);
    const dirty = dirtyProp ?? dirtyState;
    const touched = touchedProp ?? touchedState;
    const markedDirtyRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](false);
    const setDirty = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useStableCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "FieldRootInner.FieldRootInner.useStableCallback[setDirty]": (value)=>{
            if (dirtyProp !== undefined) {
                return;
            }
            if (value) {
                markedDirtyRef.current = true;
            }
            setDirtyUnwrapped(value);
        }
    }["FieldRootInner.FieldRootInner.useStableCallback[setDirty]"]);
    const setTouched = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useStableCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "FieldRootInner.FieldRootInner.useStableCallback[setTouched]": (value)=>{
            if (touchedProp !== undefined) {
                return;
            }
            setTouchedUnwrapped(value);
        }
    }["FieldRootInner.FieldRootInner.useStableCallback[setTouched]"]);
    const shouldValidateOnChange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useStableCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "FieldRootInner.FieldRootInner.useStableCallback[shouldValidateOnChange]": ()=>validationMode === 'onChange' || validationMode === 'onSubmit' && submitAttemptedRef.current
    }["FieldRootInner.FieldRootInner.useStableCallback[shouldValidateOnChange]"]);
    const hasFormError = !!name && Object.hasOwn(errors, name) && errors[name] !== undefined;
    const invalid = invalidProp === true || hasFormError;
    const [validityData, setValidityData] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]({
        state: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$utils$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_VALIDITY_STATE"],
        error: '',
        errors: [],
        value: null,
        initialValue: null
    });
    const valid = !invalid && validityData.state.valid;
    const state = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "FieldRootInner.FieldRootInner.useMemo[state]": ()=>({
                disabled,
                touched,
                dirty,
                valid,
                filled,
                focused
            })
    }["FieldRootInner.FieldRootInner.useMemo[state]"], [
        disabled,
        touched,
        dirty,
        valid,
        filled,
        focused
    ]);
    const validation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$root$2f$useFieldValidation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFieldValidation"])({
        setValidityData,
        validate,
        validityData,
        validationDebounceTime,
        invalid,
        markedDirtyRef,
        state,
        name,
        shouldValidateOnChange
    });
    const handleImperativeValidate = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "FieldRootInner.FieldRootInner.useCallback[handleImperativeValidate]": ()=>{
            markedDirtyRef.current = true;
            validation.commit(validityData.value);
        }
    }["FieldRootInner.FieldRootInner.useCallback[handleImperativeValidate]"], [
        validation,
        validityData
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"](actionsRef, {
        "FieldRootInner.FieldRootInner.useImperativeHandle": ()=>({
                validate: handleImperativeValidate
            })
    }["FieldRootInner.FieldRootInner.useImperativeHandle"], [
        handleImperativeValidate
    ]);
    const contextValue = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "FieldRootInner.FieldRootInner.useMemo[contextValue]": ()=>({
                invalid,
                name,
                validityData,
                setValidityData,
                disabled,
                touched,
                setTouched,
                dirty,
                setDirty,
                filled,
                setFilled,
                focused,
                setFocused,
                validate,
                validationMode,
                validationDebounceTime,
                shouldValidateOnChange,
                state,
                markedDirtyRef,
                validation
            })
    }["FieldRootInner.FieldRootInner.useMemo[contextValue]"], [
        invalid,
        name,
        validityData,
        disabled,
        touched,
        setTouched,
        dirty,
        setDirty,
        filled,
        setFilled,
        focused,
        setFocused,
        validate,
        validationMode,
        validationDebounceTime,
        shouldValidateOnChange,
        state,
        validation
    ]);
    const element = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$useRenderElement$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('div', componentProps, {
        ref: forwardedRef,
        state,
        props: elementProps,
        stateAttributesMapping: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$utils$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fieldValidityMapping"]
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$root$2f$FieldRootContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FieldRootContext"].Provider, {
        value: contextValue,
        children: element
    });
});
/**
 * Groups all parts of the field.
 * Renders a `<div>` element.
 *
 * Documentation: [Base UI Field](https://base-ui.com/react/components/field)
 */ if ("TURBOPACK compile-time truthy", 1) FieldRootInner.displayName = "FieldRootInner";
const FieldRoot = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function FieldRoot(componentProps, forwardedRef) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$labelable$2d$provider$2f$LabelableProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LabelableProvider"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(FieldRootInner, {
            ...componentProps,
            ref: forwardedRef
        })
    });
});
if ("TURBOPACK compile-time truthy", 1) FieldRoot.displayName = "FieldRoot";
}),
"[project]/node_modules/@base-ui/utils/esm/owner.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ownerDocument",
    ()=>ownerDocument
]);
;
function ownerDocument(node) {
    return node?.ownerDocument || document;
}
}),
"[project]/node_modules/@base-ui/utils/esm/detectBrowser.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isAndroid",
    ()=>isAndroid,
    "isEdge",
    ()=>isEdge,
    "isFirefox",
    ()=>isFirefox,
    "isIOS",
    ()=>isIOS,
    "isJSDOM",
    ()=>isJSDOM,
    "isMac",
    ()=>isMac,
    "isSafari",
    ()=>isSafari,
    "isWebKit",
    ()=>isWebKit
]);
const hasNavigator = typeof navigator !== 'undefined';
const nav = getNavigatorData();
const platform = getPlatform();
const userAgent = getUserAgent();
const isWebKit = typeof CSS === 'undefined' || !CSS.supports ? false : CSS.supports('-webkit-backdrop-filter:none');
const isIOS = // iPads can claim to be MacIntel
nav.platform === 'MacIntel' && nav.maxTouchPoints > 1 ? true : /iP(hone|ad|od)|iOS/.test(nav.platform);
const isFirefox = hasNavigator && /firefox/i.test(userAgent);
const isSafari = hasNavigator && /apple/i.test(navigator.vendor);
const isEdge = hasNavigator && /Edg/i.test(userAgent);
const isAndroid = hasNavigator && /android/i.test(platform) || /android/i.test(userAgent);
const isMac = hasNavigator && platform.toLowerCase().startsWith('mac') && !navigator.maxTouchPoints;
const isJSDOM = userAgent.includes('jsdom/');
// Avoid Chrome DevTools blue warning.
function getNavigatorData() {
    if (!hasNavigator) {
        return {
            platform: '',
            maxTouchPoints: -1
        };
    }
    const uaData = navigator.userAgentData;
    if (uaData?.platform) {
        return {
            platform: uaData.platform,
            maxTouchPoints: navigator.maxTouchPoints
        };
    }
    return {
        platform: navigator.platform ?? '',
        maxTouchPoints: navigator.maxTouchPoints ?? -1
    };
}
function getUserAgent() {
    if (!hasNavigator) {
        return '';
    }
    const uaData = navigator.userAgentData;
    if (uaData && Array.isArray(uaData.brands)) {
        return uaData.brands.map(({ brand, version })=>`${brand}/${version}`).join(' ');
    }
    return navigator.userAgent;
}
function getPlatform() {
    if (!hasNavigator) {
        return '';
    }
    const uaData = navigator.userAgentData;
    if (uaData?.platform) {
        return uaData.platform;
    }
    return navigator.platform ?? '';
}
}),
"[project]/node_modules/@base-ui/react/esm/floating-ui-react/utils/constants.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ACTIVE_KEY",
    ()=>ACTIVE_KEY,
    "ARROW_DOWN",
    ()=>ARROW_DOWN,
    "ARROW_LEFT",
    ()=>ARROW_LEFT,
    "ARROW_RIGHT",
    ()=>ARROW_RIGHT,
    "ARROW_UP",
    ()=>ARROW_UP,
    "FOCUSABLE_ATTRIBUTE",
    ()=>FOCUSABLE_ATTRIBUTE,
    "SELECTED_KEY",
    ()=>SELECTED_KEY,
    "TYPEABLE_SELECTOR",
    ()=>TYPEABLE_SELECTOR
]);
const FOCUSABLE_ATTRIBUTE = 'data-base-ui-focusable';
const ACTIVE_KEY = 'active';
const SELECTED_KEY = 'selected';
const TYPEABLE_SELECTOR = "input:not([type='hidden']):not([disabled])," + "[contenteditable]:not([contenteditable='false']),textarea:not([disabled])";
const ARROW_LEFT = 'ArrowLeft';
const ARROW_RIGHT = 'ArrowRight';
const ARROW_UP = 'ArrowUp';
const ARROW_DOWN = 'ArrowDown';
}),
"[project]/node_modules/@base-ui/react/esm/floating-ui-react/utils/element.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "activeElement",
    ()=>activeElement,
    "contains",
    ()=>contains,
    "getFloatingFocusElement",
    ()=>getFloatingFocusElement,
    "getTarget",
    ()=>getTarget,
    "isEventTargetWithin",
    ()=>isEventTargetWithin,
    "isRootElement",
    ()=>isRootElement,
    "isTargetInsideEnabledTrigger",
    ()=>isTargetInsideEnabledTrigger,
    "isTypeableCombobox",
    ()=>isTypeableCombobox,
    "isTypeableElement",
    ()=>isTypeableElement,
    "matchesFocusVisible",
    ()=>matchesFocusVisible
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@floating-ui/utils/dist/floating-ui.utils.dom.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$detectBrowser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/detectBrowser.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$floating$2d$ui$2d$react$2f$utils$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/floating-ui-react/utils/constants.js [app-client] (ecmascript)");
;
;
;
function activeElement(doc) {
    let element = doc.activeElement;
    while(element?.shadowRoot?.activeElement != null){
        element = element.shadowRoot.activeElement;
    }
    return element;
}
function contains(parent, child) {
    if (!parent || !child) {
        return false;
    }
    const rootNode = child.getRootNode?.();
    // First, attempt with faster native method
    if (parent.contains(child)) {
        return true;
    }
    // then fallback to custom implementation with Shadow DOM support
    if (rootNode && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isShadowRoot"])(rootNode)) {
        let next = child;
        while(next){
            if (parent === next) {
                return true;
            }
            next = next.parentNode || next.host;
        }
    }
    // Give up, the result is false
    return false;
}
function isTargetInsideEnabledTrigger(target, triggerElements) {
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isElement"])(target)) {
        return false;
    }
    const targetElement = target;
    if (triggerElements.hasElement(targetElement)) {
        return !targetElement.hasAttribute('data-trigger-disabled');
    }
    for (const [, trigger] of triggerElements.entries()){
        if (contains(trigger, targetElement)) {
            return !trigger.hasAttribute('data-trigger-disabled');
        }
    }
    return false;
}
function getTarget(event) {
    if ('composedPath' in event) {
        return event.composedPath()[0];
    }
    // TS thinks `event` is of type never as it assumes all browsers support
    // `composedPath()`, but browsers without shadow DOM don't.
    return event.target;
}
function isEventTargetWithin(event, node) {
    if (node == null) {
        return false;
    }
    if ('composedPath' in event) {
        return event.composedPath().includes(node);
    }
    // TS thinks `event` is of type never as it assumes all browsers support composedPath, but browsers without shadow dom don't
    const eventAgain = event;
    return eventAgain.target != null && node.contains(eventAgain.target);
}
function isRootElement(element) {
    return element.matches('html,body');
}
function isTypeableElement(element) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLElement"])(element) && element.matches(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$floating$2d$ui$2d$react$2f$utils$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TYPEABLE_SELECTOR"]);
}
function isTypeableCombobox(element) {
    if (!element) {
        return false;
    }
    return element.getAttribute('role') === 'combobox' && isTypeableElement(element);
}
function matchesFocusVisible(element) {
    // We don't want to block focus from working with `visibleOnly`
    // (JSDOM doesn't match `:focus-visible` when the element has `:focus`)
    if (!element || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$detectBrowser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isJSDOM"]) {
        return true;
    }
    try {
        return element.matches(':focus-visible');
    } catch (_e) {
        return true;
    }
}
function getFloatingFocusElement(floatingElement) {
    if (!floatingElement) {
        return null;
    }
    // Try to find the element that has `{...getFloatingProps()}` spread on it.
    // This indicates the floating element is acting as a positioning wrapper, and
    // so focus should be managed on the child element with the event handlers and
    // aria props.
    return floatingElement.hasAttribute(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$floating$2d$ui$2d$react$2f$utils$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FOCUSABLE_ATTRIBUTE"]) ? floatingElement : floatingElement.querySelector(`[${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$floating$2d$ui$2d$react$2f$utils$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FOCUSABLE_ATTRIBUTE"]}]`) || floatingElement;
}
}),
"[project]/node_modules/@base-ui/react/esm/utils/useRegisteredLabelId.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useRegisteredLabelId",
    ()=>useRegisteredLabelId
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useIsoLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/useIsoLayoutEffect.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$useBaseUiId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/utils/useBaseUiId.js [app-client] (ecmascript)");
'use client';
;
;
function useRegisteredLabelId(idProp, setLabelId) {
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$useBaseUiId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBaseUiId"])(idProp);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useIsoLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "useRegisteredLabelId.useIsoLayoutEffect": ()=>{
            setLabelId(id);
            return ({
                "useRegisteredLabelId.useIsoLayoutEffect": ()=>{
                    setLabelId(undefined);
                }
            })["useRegisteredLabelId.useIsoLayoutEffect"];
        }
    }["useRegisteredLabelId.useIsoLayoutEffect"], [
        id,
        setLabelId
    ]);
    return id;
}
}),
"[project]/node_modules/@base-ui/react/esm/labelable-provider/useLabel.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "focusElementWithVisible",
    ()=>focusElementWithVisible,
    "useLabel",
    ()=>useLabel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@floating-ui/utils/dist/floating-ui.utils.dom.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/owner.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useStableCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/useStableCallback.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$floating$2d$ui$2d$react$2f$utils$2f$element$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/floating-ui-react/utils/element.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$useRegisteredLabelId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/utils/useRegisteredLabelId.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$labelable$2d$provider$2f$LabelableContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/labelable-provider/LabelableContext.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
function useLabel(params = {}) {
    const { id: idProp, fallbackControlId, native = false, setLabelId: setLabelIdProp, focusControl: focusControlProp } = params;
    const { controlId: contextControlId, setLabelId: setContextLabelId } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$labelable$2d$provider$2f$LabelableContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLabelableContext"])();
    const syncLabelId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useStableCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "useLabel.useStableCallback[syncLabelId]": (nextLabelId)=>{
            setContextLabelId(nextLabelId);
            setLabelIdProp?.(nextLabelId);
        }
    }["useLabel.useStableCallback[syncLabelId]"]);
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$useRegisteredLabelId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRegisteredLabelId"])(idProp, syncLabelId);
    const resolvedControlId = contextControlId ?? fallbackControlId;
    function focusControl(event) {
        if (focusControlProp) {
            focusControlProp(event, resolvedControlId);
            return;
        }
        if (!resolvedControlId) {
            return;
        }
        const controlElement = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ownerDocument"])(event.currentTarget).getElementById(resolvedControlId);
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLElement"])(controlElement)) {
            focusElementWithVisible(controlElement);
        }
    }
    function handleInteraction(event) {
        const target = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$floating$2d$ui$2d$react$2f$utils$2f$element$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTarget"])(event.nativeEvent);
        if (target?.closest('button,input,select,textarea')) {
            return;
        }
        // Prevent text selection when double clicking label.
        if (!event.defaultPrevented && event.detail > 1) {
            event.preventDefault();
        }
        if (native) {
            return;
        }
        focusControl(event);
    }
    return native ? {
        id,
        htmlFor: resolvedControlId ?? undefined,
        onMouseDown: handleInteraction
    } : {
        id,
        onClick: handleInteraction,
        onPointerDown (event) {
            event.preventDefault();
        }
    };
}
function focusElementWithVisible(element) {
    element.focus({
        // Available from Chrome 144+ (January 2026).
        // Safari and Firefox already support it.
        // @ts-expect-error not available in types yet
        focusVisible: true
    });
}
}),
"[project]/node_modules/@base-ui/react/esm/field/label/FieldLabel.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FieldLabel",
    ()=>FieldLabel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$error$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/error.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$safeReact$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/safeReact.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$root$2f$FieldRootContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/field/root/FieldRootContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$utils$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/field/utils/constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$useRenderElement$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/utils/useRenderElement.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$labelable$2d$provider$2f$LabelableContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/labelable-provider/LabelableContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$labelable$2d$provider$2f$useLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/labelable-provider/useLabel.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
const FieldLabel = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function FieldLabel(componentProps, forwardedRef) {
    const { render, className, id: idProp, nativeLabel = true, ...elementProps } = componentProps;
    const fieldRootContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$root$2f$FieldRootContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFieldRootContext"])(false);
    const { labelId } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$labelable$2d$provider$2f$LabelableContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLabelableContext"])();
    const labelRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const labelProps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$labelable$2d$provider$2f$useLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLabel"])({
        id: labelId ?? idProp,
        native: nativeLabel
    });
    if ("TURBOPACK compile-time truthy", 1) {
        // eslint-disable-next-line react-hooks/rules-of-hooks
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
            "FieldLabel.FieldLabel.useEffect": ()=>{
                if (!labelRef.current) {
                    return;
                }
                const isLabelTag = labelRef.current.tagName === 'LABEL';
                if (nativeLabel) {
                    if (!isLabelTag) {
                        const ownerStackMessage = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$safeReact$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SafeReact"].captureOwnerStack?.() || '';
                        const message = '<Field.Label> expected a <label> element because the `nativeLabel` prop is true. ' + 'Rendering a non-<label> disables native label association, so `htmlFor` will not ' + 'work. Use a real <label> in the `render` prop, or set `nativeLabel` to `false`.';
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$error$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["error"])(`${message}${ownerStackMessage}`);
                    }
                } else if (isLabelTag) {
                    const ownerStackMessage = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$safeReact$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SafeReact"].captureOwnerStack?.() || '';
                    const message = '<Field.Label> expected a non-<label> element because the `nativeLabel` prop is false. ' + 'Rendering a <label> assumes native label behavior while Base UI treats it as ' + 'non-native, which can cause unexpected pointer behavior. Use a non-<label> in the ' + '`render` prop, or set `nativeLabel` to `true`.';
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$error$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["error"])(`${message}${ownerStackMessage}`);
                }
            }
        }["FieldLabel.FieldLabel.useEffect"], [
            nativeLabel
        ]);
    }
    const element = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$useRenderElement$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('label', componentProps, {
        ref: [
            forwardedRef,
            labelRef
        ],
        state: fieldRootContext.state,
        props: [
            labelProps,
            elementProps
        ],
        stateAttributesMapping: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$utils$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fieldValidityMapping"]
    });
    return element;
});
if ("TURBOPACK compile-time truthy", 1) FieldLabel.displayName = "FieldLabel";
}),
"[project]/node_modules/@base-ui/utils/esm/useAnimationFrame.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AnimationFrame",
    ()=>AnimationFrame,
    "useAnimationFrame",
    ()=>useAnimationFrame
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useRefWithInit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/useRefWithInit.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useOnMount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/useOnMount.js [app-client] (ecmascript)");
'use client';
;
;
/** Unlike `setTimeout`, rAF doesn't guarantee a positive integer return value, so we can't have
 * a monomorphic `uint` type with `0` meaning empty.
 * See warning note at:
 * https://developer.mozilla.org/en-US/docs/Web/API/Window/requestAnimationFrame#return_value */ const EMPTY = null;
let LAST_RAF = globalThis.requestAnimationFrame;
class Scheduler {
    /* This implementation uses an array as a backing data-structure for frame callbacks.
   * It allows `O(1)` callback cancelling by inserting a `null` in the array, though it
   * never calls the native `cancelAnimationFrame` if there are no frames left. This can
   * be much more efficient if there is a call pattern that alterns as
   * "request-cancel-request-cancel-…".
   * But in the case of "request-request-…-cancel-cancel-…", it leaves the final animation
   * frame to run anyway. We turn that frame into a `O(1)` no-op via `callbacksCount`. */ callbacks = [];
    callbacksCount = 0;
    nextId = 1;
    startId = 1;
    isScheduled = false;
    tick = (timestamp)=>{
        this.isScheduled = false;
        const currentCallbacks = this.callbacks;
        const currentCallbacksCount = this.callbacksCount;
        // Update these before iterating, callbacks could call `requestAnimationFrame` again.
        this.callbacks = [];
        this.callbacksCount = 0;
        this.startId = this.nextId;
        if (currentCallbacksCount > 0) {
            for(let i = 0; i < currentCallbacks.length; i += 1){
                currentCallbacks[i]?.(timestamp);
            }
        }
    };
    request(fn) {
        const id = this.nextId;
        this.nextId += 1;
        this.callbacks.push(fn);
        this.callbacksCount += 1;
        /* In a test environment with fake timers, a fake `requestAnimationFrame` can be called
     * but there's no guarantee that the animation frame will actually run before the fake
     * timers are teared, which leaves `isScheduled` set, but won't run our `tick()`. */ const didRAFChange = ("TURBOPACK compile-time value", "development") !== 'production' && LAST_RAF !== requestAnimationFrame && (LAST_RAF = requestAnimationFrame, true);
        if (!this.isScheduled || didRAFChange) {
            requestAnimationFrame(this.tick);
            this.isScheduled = true;
        }
        return id;
    }
    cancel(id) {
        const index = id - this.startId;
        if (index < 0 || index >= this.callbacks.length) {
            return;
        }
        this.callbacks[index] = null;
        this.callbacksCount -= 1;
    }
}
const scheduler = new Scheduler();
class AnimationFrame {
    static create() {
        return new AnimationFrame();
    }
    static request(fn) {
        return scheduler.request(fn);
    }
    static cancel(id) {
        return scheduler.cancel(id);
    }
    currentId = EMPTY;
    /**
   * Executes `fn` after `delay`, clearing any previously scheduled call.
   */ request(fn) {
        this.cancel();
        this.currentId = scheduler.request(()=>{
            this.currentId = EMPTY;
            fn();
        });
    }
    cancel = ()=>{
        if (this.currentId !== EMPTY) {
            scheduler.cancel(this.currentId);
            this.currentId = EMPTY;
        }
    };
    disposeEffect = ()=>{
        return this.cancel;
    };
}
function useAnimationFrame() {
    const timeout = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useRefWithInit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRefWithInit"])(AnimationFrame.create).current;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useOnMount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnMount"])(timeout.disposeEffect);
    return timeout;
}
}),
"[project]/node_modules/@base-ui/react/esm/utils/resolveRef.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * If the provided argument is a ref object, returns its `current` value.
 * Otherwise, returns the argument itself.
 */ __turbopack_context__.s([
    "resolveRef",
    ()=>resolveRef
]);
function resolveRef(maybeRef) {
    if (maybeRef == null) {
        return maybeRef;
    }
    return 'current' in maybeRef ? maybeRef.current : maybeRef;
}
}),
"[project]/node_modules/@base-ui/react/esm/utils/stateAttributesMapping.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TransitionStatusDataAttributes",
    ()=>TransitionStatusDataAttributes,
    "transitionStatusMapping",
    ()=>transitionStatusMapping
]);
let TransitionStatusDataAttributes = /*#__PURE__*/ function(TransitionStatusDataAttributes) {
    /**
   * Present when the component is animating in.
   */ TransitionStatusDataAttributes["startingStyle"] = "data-starting-style";
    /**
   * Present when the component is animating out.
   */ TransitionStatusDataAttributes["endingStyle"] = "data-ending-style";
    return TransitionStatusDataAttributes;
}({});
const STARTING_HOOK = {
    [TransitionStatusDataAttributes.startingStyle]: ''
};
const ENDING_HOOK = {
    [TransitionStatusDataAttributes.endingStyle]: ''
};
const transitionStatusMapping = {
    transitionStatus (value) {
        if (value === 'starting') {
            return STARTING_HOOK;
        }
        if (value === 'ending') {
            return ENDING_HOOK;
        }
        return null;
    }
};
}),
"[project]/node_modules/@base-ui/react/esm/utils/useAnimationsFinished.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useAnimationsFinished",
    ()=>useAnimationsFinished
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useAnimationFrame$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/useAnimationFrame.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useStableCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/useStableCallback.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$resolveRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/utils/resolveRef.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$stateAttributesMapping$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/utils/stateAttributesMapping.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
function useAnimationsFinished(elementOrRef, waitForStartingStyleRemoved = false, treatAbortedAsFinished = true) {
    const frame = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useAnimationFrame$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAnimationFrame"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useStableCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "useAnimationsFinished.useStableCallback": (fnToExecute, /**
   * An optional [AbortSignal](https://developer.mozilla.org/en-US/docs/Web/API/AbortSignal) that
   * can be used to abort `fnToExecute` before all the animations have finished.
   * @default null
   */ signal = null)=>{
            frame.cancel();
            function done() {
                // Synchronously flush the unmounting of the component so that the browser doesn't
                // paint: https://github.com/mui/base-ui/issues/979
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["flushSync"](fnToExecute);
            }
            const element = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$resolveRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resolveRef"])(elementOrRef);
            if (element == null) {
                return;
            }
            const resolvedElement = element;
            if (typeof resolvedElement.getAnimations !== 'function' || globalThis.BASE_UI_ANIMATIONS_DISABLED) {
                fnToExecute();
            } else {
                function execWaitForStartingStyleRemoved() {
                    const startingStyleAttribute = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$stateAttributesMapping$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TransitionStatusDataAttributes"].startingStyle;
                    // If `[data-starting-style]` isn't present, fall back to waiting one more frame
                    // to give "open" animations a chance to be registered.
                    if (!resolvedElement.hasAttribute(startingStyleAttribute)) {
                        frame.request(exec);
                        return;
                    }
                    // Wait for `[data-starting-style]` to have been removed.
                    const attributeObserver = new MutationObserver({
                        "useAnimationsFinished.useStableCallback.execWaitForStartingStyleRemoved": ()=>{
                            if (!resolvedElement.hasAttribute(startingStyleAttribute)) {
                                attributeObserver.disconnect();
                                exec();
                            }
                        }
                    }["useAnimationsFinished.useStableCallback.execWaitForStartingStyleRemoved"]);
                    attributeObserver.observe(resolvedElement, {
                        attributes: true,
                        attributeFilter: [
                            startingStyleAttribute
                        ]
                    });
                    signal?.addEventListener('abort', {
                        "useAnimationsFinished.useStableCallback.execWaitForStartingStyleRemoved": ()=>attributeObserver.disconnect()
                    }["useAnimationsFinished.useStableCallback.execWaitForStartingStyleRemoved"], {
                        once: true
                    });
                }
                function exec() {
                    Promise.all(resolvedElement.getAnimations().map({
                        "useAnimationsFinished.useStableCallback.exec": (anim)=>anim.finished
                    }["useAnimationsFinished.useStableCallback.exec"])).then({
                        "useAnimationsFinished.useStableCallback.exec": ()=>{
                            if (signal?.aborted) {
                                return;
                            }
                            done();
                        }
                    }["useAnimationsFinished.useStableCallback.exec"]).catch({
                        "useAnimationsFinished.useStableCallback.exec": ()=>{
                            const currentAnimations = resolvedElement.getAnimations();
                            if (treatAbortedAsFinished) {
                                if (signal?.aborted) {
                                    return;
                                }
                                done();
                            } else if (currentAnimations.length > 0 && currentAnimations.some({
                                "useAnimationsFinished.useStableCallback.exec": (anim)=>anim.pending || anim.playState !== 'finished'
                            }["useAnimationsFinished.useStableCallback.exec"])) {
                                // Sometimes animations can be aborted because a property they depend on changes while the animation plays.
                                // In such cases, we need to re-check if any new animations have started.
                                exec();
                            }
                        }
                    }["useAnimationsFinished.useStableCallback.exec"]);
                }
                if (waitForStartingStyleRemoved) {
                    execWaitForStartingStyleRemoved();
                    return;
                }
                frame.request(exec);
            }
        }
    }["useAnimationsFinished.useStableCallback"]);
}
}),
"[project]/node_modules/@base-ui/react/esm/utils/useOpenChangeComplete.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useOpenChangeComplete",
    ()=>useOpenChangeComplete
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useStableCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/useStableCallback.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$useAnimationsFinished$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/utils/useAnimationsFinished.js [app-client] (ecmascript)");
'use client';
;
;
;
function useOpenChangeComplete(parameters) {
    const { enabled = true, open, ref, onComplete: onCompleteParam } = parameters;
    const onComplete = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useStableCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])(onCompleteParam);
    const runOnceAnimationsFinish = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$useAnimationsFinished$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAnimationsFinished"])(ref, open, false);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "useOpenChangeComplete.useEffect": ()=>{
            if (!enabled) {
                return undefined;
            }
            const abortController = new AbortController();
            runOnceAnimationsFinish(onComplete, abortController.signal);
            return ({
                "useOpenChangeComplete.useEffect": ()=>{
                    abortController.abort();
                }
            })["useOpenChangeComplete.useEffect"];
        }
    }["useOpenChangeComplete.useEffect"], [
        enabled,
        open,
        onComplete,
        runOnceAnimationsFinish
    ]);
}
}),
"[project]/node_modules/@base-ui/react/esm/utils/useTransitionStatus.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useTransitionStatus",
    ()=>useTransitionStatus
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useIsoLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/useIsoLayoutEffect.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useAnimationFrame$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/useAnimationFrame.js [app-client] (ecmascript)");
'use client';
;
;
;
function useTransitionStatus(open, enableIdleState = false, deferEndingState = false) {
    const [transitionStatus, setTransitionStatus] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](open && enableIdleState ? 'idle' : undefined);
    const [mounted, setMounted] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](open);
    if (open && !mounted) {
        setMounted(true);
        setTransitionStatus('starting');
    }
    if (!open && mounted && transitionStatus !== 'ending' && !deferEndingState) {
        setTransitionStatus('ending');
    }
    if (!open && !mounted && transitionStatus === 'ending') {
        setTransitionStatus(undefined);
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useIsoLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "useTransitionStatus.useIsoLayoutEffect": ()=>{
            if (!open && mounted && transitionStatus !== 'ending' && deferEndingState) {
                const frame = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useAnimationFrame$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimationFrame"].request({
                    "useTransitionStatus.useIsoLayoutEffect.frame": ()=>{
                        setTransitionStatus('ending');
                    }
                }["useTransitionStatus.useIsoLayoutEffect.frame"]);
                return ({
                    "useTransitionStatus.useIsoLayoutEffect": ()=>{
                        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useAnimationFrame$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimationFrame"].cancel(frame);
                    }
                })["useTransitionStatus.useIsoLayoutEffect"];
            }
            return undefined;
        }
    }["useTransitionStatus.useIsoLayoutEffect"], [
        open,
        mounted,
        transitionStatus,
        deferEndingState
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useIsoLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "useTransitionStatus.useIsoLayoutEffect": ()=>{
            if (!open || enableIdleState) {
                return undefined;
            }
            const frame = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useAnimationFrame$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimationFrame"].request({
                "useTransitionStatus.useIsoLayoutEffect.frame": ()=>{
                    // Avoid `flushSync` here due to Firefox.
                    // See https://github.com/mui/base-ui/pull/3424
                    setTransitionStatus(undefined);
                }
            }["useTransitionStatus.useIsoLayoutEffect.frame"]);
            return ({
                "useTransitionStatus.useIsoLayoutEffect": ()=>{
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useAnimationFrame$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimationFrame"].cancel(frame);
                }
            })["useTransitionStatus.useIsoLayoutEffect"];
        }
    }["useTransitionStatus.useIsoLayoutEffect"], [
        enableIdleState,
        open
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useIsoLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "useTransitionStatus.useIsoLayoutEffect": ()=>{
            if (!open || !enableIdleState) {
                return undefined;
            }
            if (open && mounted && transitionStatus !== 'idle') {
                setTransitionStatus('starting');
            }
            const frame = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useAnimationFrame$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimationFrame"].request({
                "useTransitionStatus.useIsoLayoutEffect.frame": ()=>{
                    setTransitionStatus('idle');
                }
            }["useTransitionStatus.useIsoLayoutEffect.frame"]);
            return ({
                "useTransitionStatus.useIsoLayoutEffect": ()=>{
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useAnimationFrame$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimationFrame"].cancel(frame);
                }
            })["useTransitionStatus.useIsoLayoutEffect"];
        }
    }["useTransitionStatus.useIsoLayoutEffect"], [
        enableIdleState,
        open,
        mounted,
        setTransitionStatus,
        transitionStatus
    ]);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "useTransitionStatus.useMemo": ()=>({
                mounted,
                setMounted,
                transitionStatus
            })
    }["useTransitionStatus.useMemo"], [
        mounted,
        transitionStatus
    ]);
}
}),
"[project]/node_modules/@base-ui/react/esm/field/error/FieldError.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FieldError",
    ()=>FieldError
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useIsoLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/useIsoLayoutEffect.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$root$2f$FieldRootContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/field/root/FieldRootContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$labelable$2d$provider$2f$LabelableContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/labelable-provider/LabelableContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$utils$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/field/utils/constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$form$2f$FormContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/form/FormContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$useRenderElement$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/utils/useRenderElement.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$useBaseUiId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/utils/useBaseUiId.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$useOpenChangeComplete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/utils/useOpenChangeComplete.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$stateAttributesMapping$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/utils/stateAttributesMapping.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$useTransitionStatus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/utils/useTransitionStatus.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
const stateAttributesMapping = {
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$utils$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fieldValidityMapping"],
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$stateAttributesMapping$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["transitionStatusMapping"]
};
const FieldError = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function FieldError(componentProps, forwardedRef) {
    const { render, id: idProp, className, match, ...elementProps } = componentProps;
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$useBaseUiId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBaseUiId"])(idProp);
    const { validityData, state: fieldState, name } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$root$2f$FieldRootContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFieldRootContext"])(false);
    const { setMessageIds } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$labelable$2d$provider$2f$LabelableContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLabelableContext"])();
    const { errors } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$form$2f$FormContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormContext"])();
    const formError = name ? errors[name] : null;
    let rendered = false;
    if (formError || match === true) {
        rendered = true;
    } else if (match) {
        rendered = Boolean(validityData.state[match]);
    } else {
        rendered = validityData.state.valid === false;
    }
    const { mounted, transitionStatus, setMounted } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$useTransitionStatus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTransitionStatus"])(rendered);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useIsoLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "FieldError.FieldError.useIsoLayoutEffect": ()=>{
            if (!rendered || !id) {
                return undefined;
            }
            setMessageIds({
                "FieldError.FieldError.useIsoLayoutEffect": (v)=>v.concat(id)
            }["FieldError.FieldError.useIsoLayoutEffect"]);
            return ({
                "FieldError.FieldError.useIsoLayoutEffect": ()=>{
                    setMessageIds({
                        "FieldError.FieldError.useIsoLayoutEffect": (v)=>v.filter({
                                "FieldError.FieldError.useIsoLayoutEffect": (item)=>item !== id
                            }["FieldError.FieldError.useIsoLayoutEffect"])
                    }["FieldError.FieldError.useIsoLayoutEffect"]);
                }
            })["FieldError.FieldError.useIsoLayoutEffect"];
        }
    }["FieldError.FieldError.useIsoLayoutEffect"], [
        rendered,
        id,
        setMessageIds
    ]);
    const errorRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const [lastRenderedMessage, setLastRenderedMessage] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](null);
    const [lastRenderedMessageKey, setLastRenderedMessageKey] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](null);
    const errorMessage = formError || (validityData.errors.length > 1 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("ul", {
        children: validityData.errors.map((message)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("li", {
                children: message
            }, message))
    }) : validityData.error);
    let errorKey = validityData.error;
    if (formError != null) {
        errorKey = Array.isArray(formError) ? JSON.stringify(formError) : formError;
    } else if (validityData.errors.length > 1) {
        errorKey = JSON.stringify(validityData.errors);
    }
    if (rendered && errorKey !== lastRenderedMessageKey) {
        setLastRenderedMessageKey(errorKey);
        setLastRenderedMessage(errorMessage);
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$useOpenChangeComplete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOpenChangeComplete"])({
        open: rendered,
        ref: errorRef,
        onComplete () {
            if (!rendered) {
                setMounted(false);
            }
        }
    });
    const state = {
        ...fieldState,
        transitionStatus
    };
    const element = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$useRenderElement$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('div', componentProps, {
        ref: [
            forwardedRef,
            errorRef
        ],
        state,
        props: [
            {
                id,
                children: rendered ? errorMessage : lastRenderedMessage
            },
            elementProps
        ],
        stateAttributesMapping,
        enabled: mounted
    });
    if (!mounted) {
        return null;
    }
    return element;
});
if ("TURBOPACK compile-time truthy", 1) FieldError.displayName = "FieldError";
}),
"[project]/node_modules/@base-ui/react/esm/field/description/FieldDescription.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FieldDescription",
    ()=>FieldDescription
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useIsoLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/useIsoLayoutEffect.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$root$2f$FieldRootContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/field/root/FieldRootContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$labelable$2d$provider$2f$LabelableContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/labelable-provider/LabelableContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$utils$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/field/utils/constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$useBaseUiId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/utils/useBaseUiId.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$useRenderElement$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/utils/useRenderElement.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
const FieldDescription = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function FieldDescription(componentProps, forwardedRef) {
    const { render, id: idProp, className, ...elementProps } = componentProps;
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$useBaseUiId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBaseUiId"])(idProp);
    const fieldRootContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$root$2f$FieldRootContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFieldRootContext"])(false);
    const { setMessageIds } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$labelable$2d$provider$2f$LabelableContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLabelableContext"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useIsoLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "FieldDescription.FieldDescription.useIsoLayoutEffect": ()=>{
            if (!id) {
                return undefined;
            }
            setMessageIds({
                "FieldDescription.FieldDescription.useIsoLayoutEffect": (v)=>v.concat(id)
            }["FieldDescription.FieldDescription.useIsoLayoutEffect"]);
            return ({
                "FieldDescription.FieldDescription.useIsoLayoutEffect": ()=>{
                    setMessageIds({
                        "FieldDescription.FieldDescription.useIsoLayoutEffect": (v)=>v.filter({
                                "FieldDescription.FieldDescription.useIsoLayoutEffect": (item)=>item !== id
                            }["FieldDescription.FieldDescription.useIsoLayoutEffect"])
                    }["FieldDescription.FieldDescription.useIsoLayoutEffect"]);
                }
            })["FieldDescription.FieldDescription.useIsoLayoutEffect"];
        }
    }["FieldDescription.FieldDescription.useIsoLayoutEffect"], [
        id,
        setMessageIds
    ]);
    const element = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$useRenderElement$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('p', componentProps, {
        ref: forwardedRef,
        state: fieldRootContext.state,
        props: [
            {
                id
            },
            elementProps
        ],
        stateAttributesMapping: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$utils$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fieldValidityMapping"]
    });
    return element;
});
if ("TURBOPACK compile-time truthy", 1) FieldDescription.displayName = "FieldDescription";
}),
"[project]/node_modules/@base-ui/utils/esm/useControlled.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useControlled",
    ()=>useControlled
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
// TODO: uncomment once we enable eslint-plugin-react-compiler // eslint-disable-next-line react-compiler/react-compiler -- process.env never changes, dependency arrays are intentionally ignored
/* eslint-disable react-hooks/rules-of-hooks, react-hooks/exhaustive-deps */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
'use client';
;
function useControlled({ controlled, default: defaultProp, name, state = 'value' }) {
    // isControlled is ignored in the hook dependency lists as it should never change.
    const { current: isControlled } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](controlled !== undefined);
    const [valueState, setValue] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](defaultProp);
    const value = isControlled ? controlled : valueState;
    if ("TURBOPACK compile-time truthy", 1) {
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
            "useControlled.useEffect": ()=>{
                if (isControlled !== (controlled !== undefined)) {
                    console.error([
                        `Base UI: A component is changing the ${isControlled ? '' : 'un'}controlled ${state} state of ${name} to be ${isControlled ? 'un' : ''}controlled.`,
                        'Elements should not switch from uncontrolled to controlled (or vice versa).',
                        `Decide between using a controlled or uncontrolled ${name} ` + 'element for the lifetime of the component.',
                        "The nature of the state is determined during the first render. It's considered controlled if the value is not `undefined`.",
                        'More info: https://fb.me/react-controlled-components'
                    ].join('\n'));
                }
            }
        }["useControlled.useEffect"], [
            state,
            name,
            controlled
        ]);
        const { current: defaultValue } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](defaultProp);
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
            "useControlled.useEffect": ()=>{
                // See https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/is for more details.
                if (!isControlled && JSON.stringify(defaultValue) !== JSON.stringify(defaultProp)) {
                    console.error([
                        `Base UI: A component is changing the default ${state} state of an uncontrolled ${name} after being initialized. ` + `To suppress this warning opt to use a controlled ${name}.`
                    ].join('\n'));
                }
            }
        }["useControlled.useEffect"], [
            JSON.stringify(defaultProp)
        ]);
    }
    const setValueIfUncontrolled = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "useControlled.useCallback[setValueIfUncontrolled]": (newValue)=>{
            if (!isControlled) {
                setValue(newValue);
            }
        }
    }["useControlled.useCallback[setValueIfUncontrolled]"], []);
    return [
        value,
        setValueIfUncontrolled
    ];
}
}),
"[project]/node_modules/@base-ui/react/esm/labelable-provider/useLabelableId.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useLabelableId",
    ()=>useLabelableId
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useIsoLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/useIsoLayoutEffect.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useStableCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/useStableCallback.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useRefWithInit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/useRefWithInit.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@floating-ui/utils/dist/floating-ui.utils.dom.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$empty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/empty.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$useBaseUiId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/utils/useBaseUiId.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$labelable$2d$provider$2f$LabelableContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/labelable-provider/LabelableContext.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
function useLabelableId(params = {}) {
    const { id, implicit = false, controlRef } = params;
    const { controlId, registerControlId } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$labelable$2d$provider$2f$LabelableContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLabelableContext"])();
    const defaultId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$useBaseUiId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBaseUiId"])(id);
    const controlIdForEffect = implicit ? controlId : undefined;
    const controlSourceRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useRefWithInit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRefWithInit"])({
        "useLabelableId.useRefWithInit[controlSourceRef]": ()=>Symbol('labelable-control')
    }["useLabelableId.useRefWithInit[controlSourceRef]"]);
    const hasRegisteredRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](false);
    const hadExplicitIdRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](id != null);
    const unregisterControlId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useStableCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "useLabelableId.useStableCallback[unregisterControlId]": ()=>{
            if (!hasRegisteredRef.current || registerControlId === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$empty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NOOP"]) {
                return;
            }
            hasRegisteredRef.current = false;
            registerControlId(controlSourceRef.current, undefined);
        }
    }["useLabelableId.useStableCallback[unregisterControlId]"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useIsoLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "useLabelableId.useIsoLayoutEffect": ()=>{
            if (registerControlId === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$empty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NOOP"]) {
                return undefined;
            }
            let nextId;
            if (implicit) {
                const elem = controlRef?.current;
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isElement"])(elem) && elem.closest('label') != null) {
                    nextId = id ?? null;
                } else {
                    nextId = controlIdForEffect ?? defaultId;
                }
            } else if (id != null) {
                hadExplicitIdRef.current = true;
                nextId = id;
            } else if (hadExplicitIdRef.current) {
                nextId = defaultId;
            } else {
                unregisterControlId();
                return undefined;
            }
            if (nextId === undefined) {
                unregisterControlId();
                return undefined;
            }
            hasRegisteredRef.current = true;
            registerControlId(controlSourceRef.current, nextId);
            return undefined;
        }
    }["useLabelableId.useIsoLayoutEffect"], [
        id,
        controlRef,
        controlIdForEffect,
        registerControlId,
        implicit,
        defaultId,
        controlSourceRef,
        unregisterControlId
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "useLabelableId.useEffect": ()=>{
            return unregisterControlId;
        }
    }["useLabelableId.useEffect"], [
        unregisterControlId
    ]);
    return controlId ?? defaultId;
}
}),
"[project]/node_modules/@base-ui/react/esm/field/useField.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useField",
    ()=>useField
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useIsoLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/useIsoLayoutEffect.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useStableCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/useStableCallback.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$utils$2f$getCombinedFieldValidityData$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/field/utils/getCombinedFieldValidityData.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$form$2f$FormContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/form/FormContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$root$2f$FieldRootContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/field/root/FieldRootContext.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
function useField(params) {
    const { enabled = true, value, id, name, controlRef, commit } = params;
    const { formRef } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$form$2f$FormContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormContext"])();
    const { invalid, markedDirtyRef, validityData, setValidityData } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$root$2f$FieldRootContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFieldRootContext"])();
    const getValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useStableCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])(params.getValue);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useIsoLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "useField.useIsoLayoutEffect": ()=>{
            if (!enabled) {
                return;
            }
            let initialValue = value;
            if (initialValue === undefined) {
                initialValue = getValue();
            }
            if (validityData.initialValue === null && initialValue !== null) {
                setValidityData({
                    "useField.useIsoLayoutEffect": (prev)=>({
                            ...prev,
                            initialValue
                        })
                }["useField.useIsoLayoutEffect"]);
            }
        }
    }["useField.useIsoLayoutEffect"], [
        enabled,
        setValidityData,
        value,
        validityData.initialValue,
        getValue
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useIsoLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "useField.useIsoLayoutEffect": ()=>{
            if (!enabled || !id) {
                return;
            }
            formRef.current.fields.set(id, {
                getValue,
                name,
                controlRef,
                validityData: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$utils$2f$getCombinedFieldValidityData$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCombinedFieldValidityData"])(validityData, invalid),
                validate (flushSync = true) {
                    let nextValue = value;
                    if (nextValue === undefined) {
                        nextValue = getValue();
                    }
                    markedDirtyRef.current = true;
                    if (!flushSync) {
                        commit(nextValue);
                    } else {
                        // Synchronously update the validity state so the submit event can be prevented.
                        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["flushSync"]({
                            "useField.useIsoLayoutEffect": ()=>commit(nextValue)
                        }["useField.useIsoLayoutEffect"]);
                    }
                }
            });
        }
    }["useField.useIsoLayoutEffect"], [
        commit,
        controlRef,
        enabled,
        formRef,
        getValue,
        id,
        invalid,
        markedDirtyRef,
        name,
        validityData,
        value
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useIsoLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "useField.useIsoLayoutEffect": ()=>{
            const fields = formRef.current.fields;
            return ({
                "useField.useIsoLayoutEffect": ()=>{
                    if (id) {
                        fields.delete(id);
                    }
                }
            })["useField.useIsoLayoutEffect"];
        }
    }["useField.useIsoLayoutEffect"], [
        formRef,
        id
    ]);
}
}),
"[project]/node_modules/@base-ui/react/esm/utils/createBaseUIEventDetails.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createChangeEventDetails",
    ()=>createChangeEventDetails,
    "createGenericEventDetails",
    ()=>createGenericEventDetails
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$empty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/empty.js [app-client] (ecmascript)");
;
;
function createChangeEventDetails(reason, event, trigger, customProperties) {
    let canceled = false;
    let allowPropagation = false;
    const custom = customProperties ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$empty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_OBJECT"];
    const details = {
        reason,
        event: event ?? new Event('base-ui'),
        cancel () {
            canceled = true;
        },
        allowPropagation () {
            allowPropagation = true;
        },
        get isCanceled () {
            return canceled;
        },
        get isPropagationAllowed () {
            return allowPropagation;
        },
        trigger,
        ...custom
    };
    return details;
}
function createGenericEventDetails(reason, event, customProperties) {
    const custom = customProperties ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$empty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_OBJECT"];
    const details = {
        reason,
        event: event ?? new Event('base-ui'),
        ...custom
    };
    return details;
}
}),
"[project]/node_modules/@base-ui/react/esm/utils/reason-parts.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cancelOpen",
    ()=>cancelOpen,
    "chipRemovePress",
    ()=>chipRemovePress,
    "clearPress",
    ()=>clearPress,
    "closePress",
    ()=>closePress,
    "closeWatcher",
    ()=>closeWatcher,
    "decrementPress",
    ()=>decrementPress,
    "disabled",
    ()=>disabled,
    "drag",
    ()=>drag,
    "escapeKey",
    ()=>escapeKey,
    "focusOut",
    ()=>focusOut,
    "imperativeAction",
    ()=>imperativeAction,
    "incrementPress",
    ()=>incrementPress,
    "inputBlur",
    ()=>inputBlur,
    "inputChange",
    ()=>inputChange,
    "inputClear",
    ()=>inputClear,
    "inputPaste",
    ()=>inputPaste,
    "inputPress",
    ()=>inputPress,
    "itemPress",
    ()=>itemPress,
    "keyboard",
    ()=>keyboard,
    "linkPress",
    ()=>linkPress,
    "listNavigation",
    ()=>listNavigation,
    "none",
    ()=>none,
    "outsidePress",
    ()=>outsidePress,
    "pointer",
    ()=>pointer,
    "scrub",
    ()=>scrub,
    "siblingOpen",
    ()=>siblingOpen,
    "swipe",
    ()=>swipe,
    "trackPress",
    ()=>trackPress,
    "triggerFocus",
    ()=>triggerFocus,
    "triggerHover",
    ()=>triggerHover,
    "triggerPress",
    ()=>triggerPress,
    "wheel",
    ()=>wheel,
    "windowResize",
    ()=>windowResize
]);
const none = 'none';
const triggerPress = 'trigger-press';
const triggerHover = 'trigger-hover';
const triggerFocus = 'trigger-focus';
const outsidePress = 'outside-press';
const itemPress = 'item-press';
const closePress = 'close-press';
const linkPress = 'link-press';
const clearPress = 'clear-press';
const chipRemovePress = 'chip-remove-press';
const trackPress = 'track-press';
const incrementPress = 'increment-press';
const decrementPress = 'decrement-press';
const inputChange = 'input-change';
const inputClear = 'input-clear';
const inputBlur = 'input-blur';
const inputPaste = 'input-paste';
const inputPress = 'input-press';
const focusOut = 'focus-out';
const escapeKey = 'escape-key';
const closeWatcher = 'close-watcher';
const listNavigation = 'list-navigation';
const keyboard = 'keyboard';
const pointer = 'pointer';
const drag = 'drag';
const wheel = 'wheel';
const scrub = 'scrub';
const cancelOpen = 'cancel-open';
const siblingOpen = 'sibling-open';
const disabled = 'disabled';
const imperativeAction = 'imperative-action';
const swipe = 'swipe';
const windowResize = 'window-resize';
}),
"[project]/node_modules/@base-ui/react/esm/utils/reason-parts.js [app-client] (ecmascript) <export * as REASONS>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "REASONS",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$reason$2d$parts$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$reason$2d$parts$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/utils/reason-parts.js [app-client] (ecmascript)");
}),
"[project]/node_modules/@base-ui/react/esm/field/control/FieldControl.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FieldControl",
    ()=>FieldControl
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useControlled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/useControlled.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useIsoLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/useIsoLayoutEffect.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/utils/esm/owner.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$root$2f$FieldRootContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/field/root/FieldRootContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$labelable$2d$provider$2f$LabelableContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/labelable-provider/LabelableContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$labelable$2d$provider$2f$useLabelableId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/labelable-provider/useLabelableId.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$utils$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/field/utils/constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$useRenderElement$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/utils/useRenderElement.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$useField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/field/useField.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$createBaseUIEventDetails$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/utils/createBaseUIEventDetails.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$reason$2d$parts$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/utils/reason-parts.js [app-client] (ecmascript) <export * as REASONS>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$floating$2d$ui$2d$react$2f$utils$2f$element$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/floating-ui-react/utils/element.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
const FieldControl = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function FieldControl(componentProps, forwardedRef) {
    const { render, className, id: idProp, name: nameProp, value: valueProp, disabled: disabledProp = false, onValueChange, defaultValue, autoFocus = false, ...elementProps } = componentProps;
    const { state: fieldState, name: fieldName, disabled: fieldDisabled, setTouched, setDirty, validityData, setFocused, setFilled, validationMode, validation } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$root$2f$FieldRootContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFieldRootContext"])();
    const disabled = fieldDisabled || disabledProp;
    const name = fieldName ?? nameProp;
    const state = {
        ...fieldState,
        disabled
    };
    const { labelId } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$labelable$2d$provider$2f$LabelableContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLabelableContext"])();
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$labelable$2d$provider$2f$useLabelableId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLabelableId"])({
        id: idProp
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useIsoLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "FieldControl.FieldControl.useIsoLayoutEffect": ()=>{
            const hasExternalValue = valueProp != null;
            if (validation.inputRef.current?.value || hasExternalValue && valueProp !== '') {
                setFilled(true);
            } else if (hasExternalValue && valueProp === '') {
                setFilled(false);
            }
        }
    }["FieldControl.FieldControl.useIsoLayoutEffect"], [
        validation.inputRef,
        setFilled,
        valueProp
    ]);
    const inputRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useIsoLayoutEffect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "FieldControl.FieldControl.useIsoLayoutEffect": ()=>{
            if (autoFocus && inputRef.current === (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$floating$2d$ui$2d$react$2f$utils$2f$element$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["activeElement"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ownerDocument"])(inputRef.current))) {
                setFocused(true);
            }
        }
    }["FieldControl.FieldControl.useIsoLayoutEffect"], [
        autoFocus,
        setFocused
    ]);
    const [valueUnwrapped] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$utils$2f$esm$2f$useControlled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useControlled"])({
        controlled: valueProp,
        default: defaultValue,
        name: 'FieldControl',
        state: 'value'
    });
    const isControlled = valueProp !== undefined;
    const value = isControlled ? valueUnwrapped : undefined;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$useField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useField"])({
        id,
        name,
        commit: validation.commit,
        value,
        getValue: {
            "FieldControl.FieldControl.useField": ()=>validation.inputRef.current?.value
        }["FieldControl.FieldControl.useField"],
        controlRef: validation.inputRef
    });
    const element = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$useRenderElement$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('input', componentProps, {
        ref: [
            forwardedRef,
            inputRef
        ],
        state,
        props: [
            {
                id,
                disabled,
                name,
                ref: validation.inputRef,
                'aria-labelledby': labelId,
                autoFocus,
                ...isControlled ? {
                    value
                } : {
                    defaultValue
                },
                onChange (event) {
                    const inputValue = event.currentTarget.value;
                    onValueChange?.(inputValue, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$createBaseUIEventDetails$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createChangeEventDetails"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$reason$2d$parts$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].none, event.nativeEvent));
                    setDirty(inputValue !== validityData.initialValue);
                    setFilled(inputValue !== '');
                },
                onFocus () {
                    setFocused(true);
                },
                onBlur (event) {
                    setTouched(true);
                    setFocused(false);
                    if (validationMode === 'onBlur') {
                        validation.commit(event.currentTarget.value);
                    }
                },
                onKeyDown (event) {
                    if (event.currentTarget.tagName === 'INPUT' && event.key === 'Enter') {
                        setTouched(true);
                        validation.commit(event.currentTarget.value);
                    }
                }
            },
            validation.getInputValidationProps(),
            elementProps
        ],
        stateAttributesMapping: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$utils$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fieldValidityMapping"]
    });
    return element;
});
if ("TURBOPACK compile-time truthy", 1) FieldControl.displayName = "FieldControl";
}),
"[project]/node_modules/@base-ui/react/esm/field/validity/FieldValidity.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FieldValidity",
    ()=>FieldValidity
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$root$2f$FieldRootContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/field/root/FieldRootContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$utils$2f$getCombinedFieldValidityData$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/field/utils/getCombinedFieldValidityData.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$useTransitionStatus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/utils/useTransitionStatus.js [app-client] (ecmascript)");
/**
 * Used to display a custom message based on the field’s validity.
 * Requires `children` to be a function that accepts field validity state as an argument.
 *
 * Documentation: [Base UI Field](https://base-ui.com/react/components/field)
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
const FieldValidity = function FieldValidity(props) {
    const { children } = props;
    const { validityData, invalid } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$root$2f$FieldRootContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFieldRootContext"])(false);
    const combinedFieldValidityData = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "FieldValidity.useMemo[combinedFieldValidityData]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$utils$2f$getCombinedFieldValidityData$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCombinedFieldValidityData"])(validityData, invalid)
    }["FieldValidity.useMemo[combinedFieldValidityData]"], [
        validityData,
        invalid
    ]);
    const isInvalid = combinedFieldValidityData.state.valid === false;
    const { transitionStatus } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$useTransitionStatus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTransitionStatus"])(isInvalid);
    const fieldValidityState = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "FieldValidity.useMemo[fieldValidityState]": ()=>{
            return {
                ...combinedFieldValidityData,
                validity: combinedFieldValidityData.state,
                transitionStatus
            };
        }
    }["FieldValidity.useMemo[fieldValidityState]"], [
        combinedFieldValidityData,
        transitionStatus
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: children(fieldValidityState)
    });
};
if ("TURBOPACK compile-time truthy", 1) FieldValidity.displayName = "FieldValidity";
}),
"[project]/node_modules/@base-ui/react/esm/field/item/FieldItemContext.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FieldItemContext",
    ()=>FieldItemContext,
    "useFieldItemContext",
    ()=>useFieldItemContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
'use client';
;
const FieldItemContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"]({
    disabled: false
});
if ("TURBOPACK compile-time truthy", 1) FieldItemContext.displayName = "FieldItemContext";
function useFieldItemContext() {
    const context = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](FieldItemContext);
    return context;
}
}),
"[project]/node_modules/@base-ui/react/esm/checkbox-group/CheckboxGroupContext.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CheckboxGroupContext",
    ()=>CheckboxGroupContext,
    "useCheckboxGroupContext",
    ()=>useCheckboxGroupContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
'use client';
;
;
const CheckboxGroupContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](undefined);
if ("TURBOPACK compile-time truthy", 1) CheckboxGroupContext.displayName = "CheckboxGroupContext";
function useCheckboxGroupContext(optional = true) {
    const context = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](CheckboxGroupContext);
    if (context === undefined && !optional) {
        throw new Error(("TURBOPACK compile-time truthy", 1) ? 'Base UI: CheckboxGroupContext is missing. CheckboxGroup parts must be placed within <CheckboxGroup>.' : "TURBOPACK unreachable");
    }
    return context;
}
}),
"[project]/node_modules/@base-ui/react/esm/field/item/FieldItem.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FieldItem",
    ()=>FieldItem
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$root$2f$FieldRootContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/field/root/FieldRootContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$utils$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/field/utils/constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$useRenderElement$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/utils/useRenderElement.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$item$2f$FieldItemContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/field/item/FieldItemContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$labelable$2d$provider$2f$LabelableProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/labelable-provider/LabelableProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$checkbox$2d$group$2f$CheckboxGroupContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/checkbox-group/CheckboxGroupContext.js [app-client] (ecmascript)");
/**
 * Groups individual items in a checkbox group or radio group with a label and description.
 * Renders a `<div>` element.
 *
 * Documentation: [Base UI Field](https://base-ui.com/react/components/field)
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
const FieldItem = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function FieldItem(componentProps, forwardedRef) {
    const { render, className, disabled: disabledProp = false, ...elementProps } = componentProps;
    const { state, disabled: rootDisabled } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$root$2f$FieldRootContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFieldRootContext"])(false);
    const disabled = rootDisabled || disabledProp;
    const checkboxGroupContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$checkbox$2d$group$2f$CheckboxGroupContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCheckboxGroupContext"])();
    // checkboxGroupContext.parent is truthy even if no parent checkbox is involved
    const parentId = checkboxGroupContext?.parent.id;
    // this a more reliable check
    const hasParentCheckbox = checkboxGroupContext?.allValues !== undefined;
    const controlId = hasParentCheckbox ? parentId : undefined;
    const fieldItemContext = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "FieldItem.FieldItem.useMemo[fieldItemContext]": ()=>({
                disabled
            })
    }["FieldItem.FieldItem.useMemo[fieldItemContext]"], [
        disabled
    ]);
    const element = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$utils$2f$useRenderElement$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('div', componentProps, {
        ref: forwardedRef,
        state,
        props: elementProps,
        stateAttributesMapping: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$utils$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fieldValidityMapping"]
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$labelable$2d$provider$2f$LabelableProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LabelableProvider"], {
        controlId: controlId,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$item$2f$FieldItemContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FieldItemContext"].Provider, {
            value: fieldItemContext,
            children: element
        })
    });
});
if ("TURBOPACK compile-time truthy", 1) FieldItem.displayName = "FieldItem";
}),
"[project]/node_modules/@base-ui/react/esm/field/index.parts.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Control",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$control$2f$FieldControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FieldControl"],
    "Description",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$description$2f$FieldDescription$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FieldDescription"],
    "Error",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$error$2f$FieldError$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FieldError"],
    "Item",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$item$2f$FieldItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FieldItem"],
    "Label",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$label$2f$FieldLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FieldLabel"],
    "Root",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$root$2f$FieldRoot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FieldRoot"],
    "Validity",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$validity$2f$FieldValidity$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FieldValidity"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$index$2e$parts$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/field/index.parts.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$root$2f$FieldRoot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/field/root/FieldRoot.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$label$2f$FieldLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/field/label/FieldLabel.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$error$2f$FieldError$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/field/error/FieldError.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$description$2f$FieldDescription$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/field/description/FieldDescription.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$control$2f$FieldControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/field/control/FieldControl.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$validity$2f$FieldValidity$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/field/validity/FieldValidity.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$item$2f$FieldItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/field/item/FieldItem.js [app-client] (ecmascript)");
}),
"[project]/node_modules/@base-ui/react/esm/field/index.parts.js [app-client] (ecmascript) <export * as Field>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Field",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$index$2e$parts$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$index$2e$parts$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/field/index.parts.js [app-client] (ecmascript)");
}),
"[project]/node_modules/@base-ui/react/esm/input/Input.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Input",
    ()=>Input
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$index$2e$parts$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Field$3e$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/field/index.parts.js [app-client] (ecmascript) <export * as Field>");
/**
 * A native input element that automatically works with [Field](https://base-ui.com/react/components/field).
 * Renders an `<input>` element.
 *
 * Documentation: [Base UI Input](https://base-ui.com/react/components/input)
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
const Input = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function Input(props, forwardedRef) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$field$2f$index$2e$parts$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Field$3e$__["Field"].Control, {
        ref: forwardedRef,
        ...props
    });
});
if ("TURBOPACK compile-time truthy", 1) Input.displayName = "Input";
}),
"[project]/node_modules/@hugeicons/core-free-icons/dist/esm/User02Icon.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>User02Icon
]);
const User02Icon = /*#__PURE__*/ [
    [
        "path",
        {
            d: "M18.5 20V17.9704C18.5 16.7281 17.9407 15.5099 16.8103 14.9946C15.4315 14.3661 13.7779 14 12 14C10.2221 14 8.5685 14.3661 7.18968 14.9946C6.05927 15.5099 5.5 16.7281 5.5 17.9704V20",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "0"
        }
    ],
    [
        "circle",
        {
            cx: "12",
            cy: "7.5",
            r: "3.5",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "1"
        }
    ]
];
;
}),
"[project]/node_modules/@hugeicons/core-free-icons/dist/esm/User02Icon.js [app-client] (ecmascript) <export default as User02Icon>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "User02Icon",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hugeicons$2f$core$2d$free$2d$icons$2f$dist$2f$esm$2f$User02Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hugeicons$2f$core$2d$free$2d$icons$2f$dist$2f$esm$2f$User02Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@hugeicons/core-free-icons/dist/esm/User02Icon.js [app-client] (ecmascript)");
}),
"[project]/node_modules/@hugeicons/core-free-icons/dist/esm/Wallet01Icon.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Wallet01Icon
]);
const Wallet01Icon = /*#__PURE__*/ [
    [
        "path",
        {
            d: "M14 3H5C3.89543 3 3 3.89543 3 5C3 6.10457 3.89543 7 5 7H18C18 6.07003 18 5.60504 17.8978 5.22354C17.6204 4.18827 16.8117 3.37962 15.7765 3.10222C15.395 3 14.93 3 14 3Z",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "0"
        }
    ],
    [
        "path",
        {
            d: "M3 5V15C3 17.8284 3 19.2426 3.87868 20.1213C4.75736 21 6.17157 21 9 21H15C17.8284 21 19.2426 21 20.1213 20.1213C21 19.2426 21 17.8284 21 15V13C21 10.1716 21 8.75736 20.1213 7.87868C19.2426 7 17.8284 7 15 7H7",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "1"
        }
    ],
    [
        "path",
        {
            d: "M21 12H19C18.535 12 18.3025 12 18.1118 12.0511C17.5941 12.1898 17.1898 12.5941 17.0511 13.1118C17 13.3025 17 13.535 17 14C17 14.465 17 14.6975 17.0511 14.8882C17.1898 15.4059 17.5941 15.8102 18.1118 15.9489C18.3025 16 18.535 16 19 16H21",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "2"
        }
    ]
];
;
}),
"[project]/node_modules/@hugeicons/core-free-icons/dist/esm/Wallet01Icon.js [app-client] (ecmascript) <export default as Wallet01Icon>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Wallet01Icon",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hugeicons$2f$core$2d$free$2d$icons$2f$dist$2f$esm$2f$Wallet01Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hugeicons$2f$core$2d$free$2d$icons$2f$dist$2f$esm$2f$Wallet01Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@hugeicons/core-free-icons/dist/esm/Wallet01Icon.js [app-client] (ecmascript)");
}),
"[project]/node_modules/@hugeicons/core-free-icons/dist/esm/Home01Icon.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Home01Icon
]);
const Home01Icon = /*#__PURE__*/ [
    [
        "path",
        {
            d: "M3 11.9896V14.5C3 17.7998 3 19.4497 4.02513 20.4749C5.05025 21.5 6.70017 21.5 10 21.5H14C17.2998 21.5 18.9497 21.5 19.9749 20.4749C21 19.4497 21 17.7998 21 14.5V11.9896C21 10.3083 21 9.46773 20.6441 8.74005C20.2882 8.01237 19.6247 7.49628 18.2976 6.46411L16.2976 4.90855C14.2331 3.30285 13.2009 2.5 12 2.5C10.7991 2.5 9.76689 3.30285 7.70242 4.90855L5.70241 6.46411C4.37533 7.49628 3.71179 8.01237 3.3559 8.74005C3 9.46773 3 10.3083 3 11.9896Z",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "0"
        }
    ],
    [
        "path",
        {
            d: "M15.0002 17C14.2007 17.6224 13.1504 18 12.0002 18C10.8499 18 9.79971 17.6224 9.00018 17",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "1"
        }
    ]
];
;
}),
"[project]/node_modules/@hugeicons/core-free-icons/dist/esm/Home01Icon.js [app-client] (ecmascript) <export default as Home01Icon>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Home01Icon",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hugeicons$2f$core$2d$free$2d$icons$2f$dist$2f$esm$2f$Home01Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hugeicons$2f$core$2d$free$2d$icons$2f$dist$2f$esm$2f$Home01Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@hugeicons/core-free-icons/dist/esm/Home01Icon.js [app-client] (ecmascript)");
}),
"[project]/node_modules/@hugeicons/core-free-icons/dist/esm/Store01Icon.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Store01Icon
]);
const Store01Icon = /*#__PURE__*/ [
    [
        "path",
        {
            d: "M3.50002 10V15C3.50002 17.8284 3.50002 19.2426 4.37869 20.1213C5.25737 21 6.67159 21 9.50002 21H14.5C17.3284 21 18.7427 21 19.6213 20.1213C20.5 19.2426 20.5 17.8284 20.5 15V10",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "0"
        }
    ],
    [
        "path",
        {
            d: "M17 7.50184C17 8.88255 15.8807 9.99997 14.5 9.99997C13.1193 9.99997 12 8.88068 12 7.49997C12 8.88068 10.8807 9.99997 9.50002 9.99997C8.1193 9.99997 7.00002 8.88068 7.00002 7.49997C7.00002 8.88068 5.82655 9.99997 4.37901 9.99997C3.59984 9.99997 2.90008 9.67567 2.42 9.16087C1.59462 8.2758 2.12561 6.97403 2.81448 5.98842L3.20202 5.45851C4.08386 4.2527 4.52478 3.6498 5.16493 3.32494C5.80508 3.00008 6.55201 3.00018 8.04587 3.00038L15.9551 3.00143C17.4485 3.00163 18.1952 3.00173 18.8351 3.32658C19.475 3.65143 19.9158 4.25414 20.7974 5.45957L21.1855 5.99029C21.8744 6.97589 22.4054 8.27766 21.58 9.16273C21.0999 9.67754 20.4002 10.0018 19.621 10.0018C18.1734 10.0018 17 8.88255 17 7.50184Z",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "1"
        }
    ],
    [
        "path",
        {
            d: "M14.9971 17C14.3133 17.6072 13.2247 18 11.9985 18C10.7723 18 9.68376 17.6072 9 17",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "2"
        }
    ]
];
;
}),
"[project]/node_modules/@hugeicons/core-free-icons/dist/esm/Store01Icon.js [app-client] (ecmascript) <export default as Store01Icon>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Store01Icon",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hugeicons$2f$core$2d$free$2d$icons$2f$dist$2f$esm$2f$Store01Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hugeicons$2f$core$2d$free$2d$icons$2f$dist$2f$esm$2f$Store01Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@hugeicons/core-free-icons/dist/esm/Store01Icon.js [app-client] (ecmascript)");
}),
"[project]/node_modules/@hugeicons/core-free-icons/dist/esm/CheckmarkCircle02Icon.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CheckmarkCircle02Icon
]);
const CheckmarkCircle02Icon = /*#__PURE__*/ [
    [
        "path",
        {
            d: "M22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22C17.5228 22 22 17.5228 22 12Z",
            stroke: "currentColor",
            strokeWidth: "1.5",
            key: "0"
        }
    ],
    [
        "path",
        {
            d: "M8 12.5L10.5 15L16 9",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "1"
        }
    ]
];
;
}),
"[project]/node_modules/@hugeicons/core-free-icons/dist/esm/CheckmarkCircle02Icon.js [app-client] (ecmascript) <export default as CheckmarkCircle02Icon>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CheckmarkCircle02Icon",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hugeicons$2f$core$2d$free$2d$icons$2f$dist$2f$esm$2f$CheckmarkCircle02Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hugeicons$2f$core$2d$free$2d$icons$2f$dist$2f$esm$2f$CheckmarkCircle02Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@hugeicons/core-free-icons/dist/esm/CheckmarkCircle02Icon.js [app-client] (ecmascript)");
}),
"[project]/node_modules/@hugeicons/core-free-icons/dist/esm/Restaurant01Icon.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Restaurant01Icon
]);
const Restaurant01Icon = /*#__PURE__*/ [
    [
        "path",
        {
            d: "M15 10L4 21.001",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "0"
        }
    ],
    [
        "path",
        {
            d: "M17.9999 3.00098L14.9999 6.00098C14.4547 6.54623 14.1821 6.81885 14.0363 7.11295C13.759 7.6725 13.759 8.32945 14.0363 8.88901C14.1821 9.1831 14.4547 9.45573 14.9999 10.001C15.5452 10.5462 15.8178 10.8189 16.1119 10.9646C16.6715 11.2419 17.3284 11.2419 17.888 10.9646C18.1821 10.8189 18.4547 10.5462 18.9999 10.001L21.9999 7.00098",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "1"
        }
    ],
    [
        "path",
        {
            d: "M20 4.99902L17 7.99902",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "2"
        }
    ],
    [
        "path",
        {
            d: "M8.84473 9.84571C7.47968 11.2108 5.60771 11.552 3.90145 9.84571C2.19514 8.13939 1.30058 5.03166 2.66563 3.66661C4.03069 2.30156 7.13841 3.19611 8.84473 4.90243C10.551 6.60868 10.2098 8.48065 8.84473 9.84571ZM8.84473 9.84571L20 21.001",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeWidth: "1.5",
            key: "3"
        }
    ]
];
;
}),
"[project]/node_modules/@hugeicons/core-free-icons/dist/esm/Restaurant01Icon.js [app-client] (ecmascript) <export default as Restaurant01Icon>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Restaurant01Icon",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hugeicons$2f$core$2d$free$2d$icons$2f$dist$2f$esm$2f$Restaurant01Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hugeicons$2f$core$2d$free$2d$icons$2f$dist$2f$esm$2f$Restaurant01Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@hugeicons/core-free-icons/dist/esm/Restaurant01Icon.js [app-client] (ecmascript)");
}),
"[project]/node_modules/@hugeicons/core-free-icons/dist/esm/Briefcase01Icon.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Briefcase01Icon
]);
const Briefcase01Icon = /*#__PURE__*/ [
    [
        "path",
        {
            d: "M2.00127 8.5L1.99911 13.997C1.99782 17.2979 1.99717 18.9484 3.02235 19.974C4.04754 20.9996 5.69801 20.9996 8.99895 20.9997L15 20.9998C18.2994 20.9999 19.949 21 20.9741 19.9751C21.9992 18.9502 21.9996 17.3005 22.0002 14.0012L22.0013 8.5",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "0"
        }
    ],
    [
        "path",
        {
            d: "M8.49857 6.5C8.49857 5.09554 8.49857 4.39331 8.83563 3.88886C8.98154 3.67048 9.16904 3.48298 9.38743 3.33706C9.89187 3 10.5941 3 11.9986 3C13.403 3 14.1053 3 14.6097 3.33706C14.8281 3.48298 15.0156 3.67048 15.1615 3.88886C15.4986 4.39331 15.4986 5.09554 15.4986 6.5",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "1"
        }
    ],
    [
        "path",
        {
            d: "M19.998 6.50016L3.99885 6.5C2.8944 6.50007 1.99876 7.39568 1.99866 8.50013C1.99876 10.7091 3.79005 12.5004 5.99901 12.5006H17.9978C20.2068 12.5005 21.998 10.7093 21.9981 8.5003C21.998 7.39582 21.1024 6.50023 19.998 6.50016Z",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "2"
        }
    ],
    [
        "path",
        {
            d: "M9.99857 12.5V13.5C9.99857 13.965 9.99857 14.1975 10.0497 14.3882C10.1884 14.9059 10.5927 15.3102 11.1103 15.4489C11.3011 15.5 11.5336 15.5 11.9986 15.5C12.4636 15.5 12.696 15.5 12.8868 15.4489C13.4044 15.3102 13.8088 14.9059 13.9475 14.3882C13.9986 14.1975 13.9986 13.965 13.9986 13.5V12.5",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "3"
        }
    ]
];
;
}),
"[project]/node_modules/@hugeicons/core-free-icons/dist/esm/Briefcase01Icon.js [app-client] (ecmascript) <export default as Briefcase01Icon>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Briefcase01Icon",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hugeicons$2f$core$2d$free$2d$icons$2f$dist$2f$esm$2f$Briefcase01Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hugeicons$2f$core$2d$free$2d$icons$2f$dist$2f$esm$2f$Briefcase01Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@hugeicons/core-free-icons/dist/esm/Briefcase01Icon.js [app-client] (ecmascript)");
}),
"[project]/node_modules/@hugeicons/core-free-icons/dist/esm/LaptopIcon.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>LaptopIcon
]);
const LaptopIcon = /*#__PURE__*/ [
    [
        "path",
        {
            d: "M20.4999 16.5V8.5C20.4999 6.14298 20.4999 4.96447 19.7676 4.23223C19.0354 3.5 17.8569 3.5 15.4999 3.5H8.49988C6.14286 3.5 4.96434 3.5 4.23211 4.23223C3.49988 4.96447 3.49988 6.14298 3.49988 8.5V16.5",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "0"
        }
    ],
    [
        "path",
        {
            d: "M21.9841 20.5H2.01567C1.63273 20.5 1.38367 20.1088 1.55493 19.7764L3.49988 16.5H20.4999L22.4448 19.7764C22.6161 20.1088 22.367 20.5 21.9841 20.5Z",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "1"
        }
    ]
];
;
}),
"[project]/node_modules/@hugeicons/core-free-icons/dist/esm/LaptopIcon.js [app-client] (ecmascript) <export default as LaptopIcon>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LaptopIcon",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hugeicons$2f$core$2d$free$2d$icons$2f$dist$2f$esm$2f$LaptopIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hugeicons$2f$core$2d$free$2d$icons$2f$dist$2f$esm$2f$LaptopIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@hugeicons/core-free-icons/dist/esm/LaptopIcon.js [app-client] (ecmascript)");
}),
"[project]/node_modules/input-otp/dist/index.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "OTPInput",
    ()=>Lt,
    "OTPInputContext",
    ()=>jt,
    "REGEXP_ONLY_CHARS",
    ()=>Jt,
    "REGEXP_ONLY_DIGITS",
    ()=>Kt,
    "REGEXP_ONLY_DIGITS_AND_CHARS",
    ()=>Qt
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var Bt = Object.defineProperty, At = Object.defineProperties;
var kt = Object.getOwnPropertyDescriptors;
var Y = Object.getOwnPropertySymbols;
var gt = Object.prototype.hasOwnProperty, Et = Object.prototype.propertyIsEnumerable;
var vt = (r, s, e)=>s in r ? Bt(r, s, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : r[s] = e, St = (r, s)=>{
    for(var e in s || (s = {}))gt.call(s, e) && vt(r, e, s[e]);
    if (Y) for (var e of Y(s))Et.call(s, e) && vt(r, e, s[e]);
    return r;
}, bt = (r, s)=>At(r, kt(s));
var Pt = (r, s)=>{
    var e = {};
    for(var u in r)gt.call(r, u) && s.indexOf(u) < 0 && (e[u] = r[u]);
    if (r != null && Y) for (var u of Y(r))s.indexOf(u) < 0 && Et.call(r, u) && (e[u] = r[u]);
    return e;
};
;
function ht(r) {
    let s = setTimeout(r, 0), e = setTimeout(r, 10), u = setTimeout(r, 50);
    return [
        s,
        e,
        u
    ];
}
;
function _t(r) {
    let s = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"]();
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "_t.useEffect": ()=>{
            s.current = r;
        }
    }["_t.useEffect"]), s.current;
}
;
var Ot = 18, wt = 40, Gt = `${wt}px`, xt = [
    "[data-lastpass-icon-root]",
    "com-1password-button",
    "[data-dashlanecreated]",
    '[style$="2147483647 !important;"]'
].join(",");
function Tt({ containerRef: r, inputRef: s, pushPasswordManagerStrategy: e, isFocused: u }) {
    let [P, D] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](!1), [G, H] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](!1), [F, W] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](!1), Z = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Tt.useMemo[Z]": ()=>e === "none" ? !1 : (e === "increase-width" || e === "experimental-no-flickering") && P && G
    }["Tt.useMemo[Z]"], [
        P,
        G,
        e
    ]), T = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Tt.useCallback[T]": ()=>{
            let f = r.current, h = s.current;
            if (!f || !h || F || e === "none") return;
            let a = f, B = a.getBoundingClientRect().left + a.offsetWidth, A = a.getBoundingClientRect().top + a.offsetHeight / 2, z = B - Ot, q = A;
            document.querySelectorAll(xt).length === 0 && document.elementFromPoint(z, q) === f || (D(!0), W(!0));
        }
    }["Tt.useCallback[T]"], [
        r,
        s,
        F,
        e
    ]);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "Tt.useEffect": ()=>{
            let f = r.current;
            if (!f || e === "none") return;
            function h() {
                let A = window.innerWidth - f.getBoundingClientRect().right;
                H(A >= wt);
            }
            h();
            let a = setInterval(h, 1e3);
            return ({
                "Tt.useEffect": ()=>{
                    clearInterval(a);
                }
            })["Tt.useEffect"];
        }
    }["Tt.useEffect"], [
        r,
        e
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "Tt.useEffect": ()=>{
            let f = u || document.activeElement === s.current;
            if (e === "none" || !f) return;
            let h = setTimeout(T, 0), a = setTimeout(T, 2e3), B = setTimeout(T, 5e3), A = setTimeout({
                "Tt.useEffect.A": ()=>{
                    W(!0);
                }
            }["Tt.useEffect.A"], 6e3);
            return ({
                "Tt.useEffect": ()=>{
                    clearTimeout(h), clearTimeout(a), clearTimeout(B), clearTimeout(A);
                }
            })["Tt.useEffect"];
        }
    }["Tt.useEffect"], [
        s,
        u,
        e,
        T
    ]), {
        hasPWMBadge: P,
        willPushPWMBadge: Z,
        PWM_BADGE_SPACE_WIDTH: Gt
    };
}
var jt = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"]({}), Lt = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"]((A, B)=>{
    var z = A, { value: r, onChange: s, maxLength: e, textAlign: u = "left", pattern: P, placeholder: D, inputMode: G = "numeric", onComplete: H, pushPasswordManagerStrategy: F = "increase-width", pasteTransformer: W, containerClassName: Z, noScriptCSSFallback: T = Nt, render: f, children: h } = z, a = Pt(z, [
        "value",
        "onChange",
        "maxLength",
        "textAlign",
        "pattern",
        "placeholder",
        "inputMode",
        "onComplete",
        "pushPasswordManagerStrategy",
        "pasteTransformer",
        "containerClassName",
        "noScriptCSSFallback",
        "render",
        "children"
    ]);
    var X, lt, ut, dt, ft;
    let [q, nt] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](typeof a.defaultValue == "string" ? a.defaultValue : ""), i = r != null ? r : q, I = _t(i), x = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Lt.useCallback[x]": (t)=>{
            s == null || s(t), nt(t);
        }
    }["Lt.useCallback[x]"], [
        s
    ]), m = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Lt.useMemo[m]": ()=>P ? typeof P == "string" ? new RegExp(P) : P : null
    }["Lt.useMemo[m]"], [
        P
    ]), l = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null), K = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null), J = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"]({
        value: i,
        onChange: x,
        isIOS: typeof window != "undefined" && ((lt = (X = window == null ? void 0 : window.CSS) == null ? void 0 : X.supports) == null ? void 0 : lt.call(X, "-webkit-touch-callout", "none"))
    }), V = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"]({
        prev: [
            (ut = l.current) == null ? void 0 : ut.selectionStart,
            (dt = l.current) == null ? void 0 : dt.selectionEnd,
            (ft = l.current) == null ? void 0 : ft.selectionDirection
        ]
    });
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"](B, {
        "Lt.useImperativeHandle": ()=>l.current
    }["Lt.useImperativeHandle"], []), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "Lt.useEffect": ()=>{
            let t = l.current, o = K.current;
            if (!t || !o) return;
            J.current.value !== t.value && J.current.onChange(t.value), V.current.prev = [
                t.selectionStart,
                t.selectionEnd,
                t.selectionDirection
            ];
            function d() {
                if (document.activeElement !== t) {
                    L(null), N(null);
                    return;
                }
                let c = t.selectionStart, b = t.selectionEnd, mt = t.selectionDirection, v = t.maxLength, C = t.value, _ = V.current.prev, g = -1, E = -1, w;
                if (C.length !== 0 && c !== null && b !== null) {
                    let Dt = c === b, Ht = c === C.length && C.length < v;
                    if (Dt && !Ht) {
                        let y = c;
                        if (y === 0) g = 0, E = 1, w = "forward";
                        else if (y === v) g = y - 1, E = y, w = "backward";
                        else if (v > 1 && C.length > 1) {
                            let et = 0;
                            if (_[0] !== null && _[1] !== null) {
                                w = y < _[1] ? "backward" : "forward";
                                let Wt = _[0] === _[1] && _[0] < v;
                                w === "backward" && !Wt && (et = -1);
                            }
                            g = et + y, E = et + y + 1;
                        }
                    }
                    g !== -1 && E !== -1 && g !== E && l.current.setSelectionRange(g, E, w);
                }
                let pt = g !== -1 ? g : c, Rt = E !== -1 ? E : b, yt = w != null ? w : mt;
                L(pt), N(Rt), V.current.prev = [
                    pt,
                    Rt,
                    yt
                ];
            }
            if (document.addEventListener("selectionchange", d, {
                capture: !0
            }), d(), document.activeElement === t && Q(!0), !document.getElementById("input-otp-style")) {
                let c = document.createElement("style");
                if (c.id = "input-otp-style", document.head.appendChild(c), c.sheet) {
                    let b = "background: transparent !important; color: transparent !important; border-color: transparent !important; opacity: 0 !important; box-shadow: none !important; -webkit-box-shadow: none !important; -webkit-text-fill-color: transparent !important;";
                    $(c.sheet, "[data-input-otp]::selection { background: transparent !important; color: transparent !important; }"), $(c.sheet, `[data-input-otp]:autofill { ${b} }`), $(c.sheet, `[data-input-otp]:-webkit-autofill { ${b} }`), $(c.sheet, "@supports (-webkit-touch-callout: none) { [data-input-otp] { letter-spacing: -.6em !important; font-weight: 100 !important; font-stretch: ultra-condensed; font-optical-sizing: none !important; left: -1px !important; right: 1px !important; } }"), $(c.sheet, "[data-input-otp] + * { pointer-events: all !important; }");
                }
            }
            let R = {
                "Lt.useEffect.R": ()=>{
                    o && o.style.setProperty("--root-height", `${t.clientHeight}px`);
                }
            }["Lt.useEffect.R"];
            R();
            let p = new ResizeObserver(R);
            return p.observe(t), ({
                "Lt.useEffect": ()=>{
                    document.removeEventListener("selectionchange", d, {
                        capture: !0
                    }), p.disconnect();
                }
            })["Lt.useEffect"];
        }
    }["Lt.useEffect"], []);
    let [ot, rt] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](!1), [j, Q] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](!1), [M, L] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](null), [k, N] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](null);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "Lt.useEffect": ()=>{
            ht({
                "Lt.useEffect": ()=>{
                    var R, p, c, b;
                    (R = l.current) == null || R.dispatchEvent(new Event("input"));
                    let t = (p = l.current) == null ? void 0 : p.selectionStart, o = (c = l.current) == null ? void 0 : c.selectionEnd, d = (b = l.current) == null ? void 0 : b.selectionDirection;
                    t !== null && o !== null && (L(t), N(o), V.current.prev = [
                        t,
                        o,
                        d
                    ]);
                }
            }["Lt.useEffect"]);
        }
    }["Lt.useEffect"], [
        i,
        j
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "Lt.useEffect": ()=>{
            I !== void 0 && i !== I && I.length < e && i.length === e && (H == null || H(i));
        }
    }["Lt.useEffect"], [
        e,
        H,
        I,
        i
    ]);
    let O = Tt({
        containerRef: K,
        inputRef: l,
        pushPasswordManagerStrategy: F,
        isFocused: j
    }), st = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Lt.useCallback[st]": (t)=>{
            let o = t.currentTarget.value.slice(0, e);
            if (o.length > 0 && m && !m.test(o)) {
                t.preventDefault();
                return;
            }
            typeof I == "string" && o.length < I.length && document.dispatchEvent(new Event("selectionchange")), x(o);
        }
    }["Lt.useCallback[st]"], [
        e,
        x,
        I,
        m
    ]), at = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Lt.useCallback[at]": ()=>{
            var t;
            if (l.current) {
                let o = Math.min(l.current.value.length, e - 1), d = l.current.value.length;
                (t = l.current) == null || t.setSelectionRange(o, d), L(o), N(d);
            }
            Q(!0);
        }
    }["Lt.useCallback[at]"], [
        e
    ]), ct = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Lt.useCallback[ct]": (t)=>{
            var g, E;
            let o = l.current;
            if (!W && (!J.current.isIOS || !t.clipboardData || !o)) return;
            let d = t.clipboardData.getData("text/plain"), R = W ? W(d) : d;
            t.preventDefault();
            let p = (g = l.current) == null ? void 0 : g.selectionStart, c = (E = l.current) == null ? void 0 : E.selectionEnd, v = (p !== c ? i.slice(0, p) + R + i.slice(c) : i.slice(0, p) + R + i.slice(p)).slice(0, e);
            if (v.length > 0 && m && !m.test(v)) return;
            o.value = v, x(v);
            let C = Math.min(v.length, e - 1), _ = v.length;
            o.setSelectionRange(C, _), L(C), N(_);
        }
    }["Lt.useCallback[ct]"], [
        e,
        x,
        m,
        i
    ]), It = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Lt.useMemo[It]": ()=>({
                position: "relative",
                cursor: a.disabled ? "default" : "text",
                userSelect: "none",
                WebkitUserSelect: "none",
                pointerEvents: "none"
            })
    }["Lt.useMemo[It]"], [
        a.disabled
    ]), it = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Lt.useMemo[it]": ()=>({
                position: "absolute",
                inset: 0,
                width: O.willPushPWMBadge ? `calc(100% + ${O.PWM_BADGE_SPACE_WIDTH})` : "100%",
                clipPath: O.willPushPWMBadge ? `inset(0 ${O.PWM_BADGE_SPACE_WIDTH} 0 0)` : void 0,
                height: "100%",
                display: "flex",
                textAlign: u,
                opacity: "1",
                color: "transparent",
                pointerEvents: "all",
                background: "transparent",
                caretColor: "transparent",
                border: "0 solid transparent",
                outline: "0 solid transparent",
                boxShadow: "none",
                lineHeight: "1",
                letterSpacing: "-.5em",
                fontSize: "var(--root-height)",
                fontFamily: "monospace",
                fontVariantNumeric: "tabular-nums"
            })
    }["Lt.useMemo[it]"], [
        O.PWM_BADGE_SPACE_WIDTH,
        O.willPushPWMBadge,
        u
    ]), Mt = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Lt.useMemo[Mt]": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"]("input", bt(St({
                autoComplete: a.autoComplete || "one-time-code"
            }, a), {
                "data-input-otp": !0,
                "data-input-otp-placeholder-shown": i.length === 0 || void 0,
                "data-input-otp-mss": M,
                "data-input-otp-mse": k,
                inputMode: G,
                pattern: m == null ? void 0 : m.source,
                "aria-placeholder": D,
                style: it,
                maxLength: e,
                value: i,
                ref: l,
                onPaste: {
                    "Lt.useMemo[Mt]": (t)=>{
                        var o;
                        ct(t), (o = a.onPaste) == null || o.call(a, t);
                    }
                }["Lt.useMemo[Mt]"],
                onChange: st,
                onMouseOver: {
                    "Lt.useMemo[Mt]": (t)=>{
                        var o;
                        rt(!0), (o = a.onMouseOver) == null || o.call(a, t);
                    }
                }["Lt.useMemo[Mt]"],
                onMouseLeave: {
                    "Lt.useMemo[Mt]": (t)=>{
                        var o;
                        rt(!1), (o = a.onMouseLeave) == null || o.call(a, t);
                    }
                }["Lt.useMemo[Mt]"],
                onFocus: {
                    "Lt.useMemo[Mt]": (t)=>{
                        var o;
                        at(), (o = a.onFocus) == null || o.call(a, t);
                    }
                }["Lt.useMemo[Mt]"],
                onBlur: {
                    "Lt.useMemo[Mt]": (t)=>{
                        var o;
                        Q(!1), (o = a.onBlur) == null || o.call(a, t);
                    }
                }["Lt.useMemo[Mt]"]
            }))
    }["Lt.useMemo[Mt]"], [
        st,
        at,
        ct,
        G,
        it,
        e,
        k,
        M,
        a,
        m == null ? void 0 : m.source,
        i
    ]), tt = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Lt.useMemo[tt]": ()=>({
                slots: Array.from({
                    length: e
                }).map({
                    "Lt.useMemo[tt]": (t, o)=>{
                        var c;
                        let d = j && M !== null && k !== null && (M === k && o === M || o >= M && o < k), R = i[o] !== void 0 ? i[o] : null, p = i[0] !== void 0 ? null : (c = D == null ? void 0 : D[o]) != null ? c : null;
                        return {
                            char: R,
                            placeholderChar: p,
                            isActive: d,
                            hasFakeCaret: d && R === null
                        };
                    }
                }["Lt.useMemo[tt]"]),
                isFocused: j,
                isHovering: !a.disabled && ot
            })
    }["Lt.useMemo[tt]"], [
        j,
        ot,
        e,
        k,
        M,
        a.disabled,
        i
    ]), Ct = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Lt.useMemo[Ct]": ()=>f ? f(tt) : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"](jt.Provider, {
                value: tt
            }, h)
    }["Lt.useMemo[Ct]"], [
        h,
        tt,
        f
    ]);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], null, T !== null && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"]("noscript", null, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"]("style", null, T)), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"]("div", {
        ref: K,
        "data-input-otp-container": !0,
        style: It,
        className: Z
    }, Ct, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"]("div", {
        style: {
            position: "absolute",
            inset: 0,
            pointerEvents: "none"
        }
    }, Mt)));
});
Lt.displayName = "Input";
function $(r, s) {
    try {
        r.insertRule(s);
    } catch (e) {
        console.error("input-otp could not insert CSS rule:", s);
    }
}
var Nt = `
[data-input-otp] {
  --nojs-bg: white !important;
  --nojs-fg: black !important;

  background-color: var(--nojs-bg) !important;
  color: var(--nojs-fg) !important;
  caret-color: var(--nojs-fg) !important;
  letter-spacing: .25em !important;
  text-align: center !important;
  border: 1px solid var(--nojs-fg) !important;
  border-radius: 4px !important;
  width: 100% !important;
}
@media (prefers-color-scheme: dark) {
  [data-input-otp] {
    --nojs-bg: black !important;
    --nojs-fg: white !important;
  }
}`;
var Kt = "^\\d+$", Jt = "^[a-zA-Z]+$", Qt = "^[a-zA-Z0-9]+$";
;
}),
"[project]/node_modules/lucide-react/dist/esm/shared/src/utils/mergeClasses.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "mergeClasses",
    ()=>mergeClasses
]);
/**
 * @license lucide-react v1.7.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const mergeClasses = (...classes)=>classes.filter((className, index, array)=>{
        return Boolean(className) && className.trim() !== "" && array.indexOf(className) === index;
    }).join(" ").trim();
;
}),
"[project]/node_modules/lucide-react/dist/esm/shared/src/utils/toKebabCase.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "toKebabCase",
    ()=>toKebabCase
]);
/**
 * @license lucide-react v1.7.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const toKebabCase = (string)=>string.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();
;
}),
"[project]/node_modules/lucide-react/dist/esm/shared/src/utils/toCamelCase.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "toCamelCase",
    ()=>toCamelCase
]);
/**
 * @license lucide-react v1.7.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const toCamelCase = (string)=>string.replace(/^([A-Z])|[\s-_]+(\w)/g, (match, p1, p2)=>p2 ? p2.toUpperCase() : p1.toLowerCase());
;
}),
"[project]/node_modules/lucide-react/dist/esm/shared/src/utils/toPascalCase.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "toPascalCase",
    ()=>toPascalCase
]);
/**
 * @license lucide-react v1.7.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$shared$2f$src$2f$utils$2f$toCamelCase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/shared/src/utils/toCamelCase.js [app-client] (ecmascript)");
;
const toPascalCase = (string)=>{
    const camelCase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$shared$2f$src$2f$utils$2f$toCamelCase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toCamelCase"])(string);
    return camelCase.charAt(0).toUpperCase() + camelCase.slice(1);
};
;
}),
"[project]/node_modules/lucide-react/dist/esm/defaultAttributes.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>defaultAttributes
]);
/**
 * @license lucide-react v1.7.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var defaultAttributes = {
    xmlns: "http://www.w3.org/2000/svg",
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 2,
    strokeLinecap: "round",
    strokeLinejoin: "round"
};
;
}),
"[project]/node_modules/lucide-react/dist/esm/shared/src/utils/hasA11yProp.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "hasA11yProp",
    ()=>hasA11yProp
]);
/**
 * @license lucide-react v1.7.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const hasA11yProp = (props)=>{
    for(const prop in props){
        if (prop.startsWith("aria-") || prop === "role" || prop === "title") {
            return true;
        }
    }
    return false;
};
;
}),
"[project]/node_modules/lucide-react/dist/esm/context.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LucideProvider",
    ()=>LucideProvider,
    "useLucideContext",
    ()=>useLucideContext
]);
/**
 * @license lucide-react v1.7.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
"use strict";
"use client";
;
const LucideContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])({});
function LucideProvider({ children, size, color, strokeWidth, absoluteStrokeWidth, className }) {
    const value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "LucideProvider.useMemo[value]": ()=>({
                size,
                color,
                strokeWidth,
                absoluteStrokeWidth,
                className
            })
    }["LucideProvider.useMemo[value]"], [
        size,
        color,
        strokeWidth,
        absoluteStrokeWidth,
        className
    ]);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(LucideContext.Provider, {
        value
    }, children);
}
const useLucideContext = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(LucideContext);
;
}),
"[project]/node_modules/lucide-react/dist/esm/Icon.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Icon
]);
/**
 * @license lucide-react v1.7.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$defaultAttributes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/defaultAttributes.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$shared$2f$src$2f$utils$2f$hasA11yProp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/shared/src/utils/hasA11yProp.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$shared$2f$src$2f$utils$2f$mergeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/shared/src/utils/mergeClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/context.js [app-client] (ecmascript)");
"use strict";
"use client";
;
;
;
;
;
const Icon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(({ color, size, strokeWidth, absoluteStrokeWidth, className = "", children, iconNode, ...rest }, ref)=>{
    const { size: contextSize = 24, strokeWidth: contextStrokeWidth = 2, absoluteStrokeWidth: contextAbsoluteStrokeWidth = false, color: contextColor = "currentColor", className: contextClass = "" } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLucideContext"])() ?? {};
    const calculatedStrokeWidth = absoluteStrokeWidth ?? contextAbsoluteStrokeWidth ? Number(strokeWidth ?? contextStrokeWidth) * 24 / Number(size ?? contextSize) : strokeWidth ?? contextStrokeWidth;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("svg", {
        ref,
        ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$defaultAttributes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        width: size ?? contextSize ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$defaultAttributes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].width,
        height: size ?? contextSize ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$defaultAttributes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].height,
        stroke: color ?? contextColor,
        strokeWidth: calculatedStrokeWidth,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$shared$2f$src$2f$utils$2f$mergeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeClasses"])("lucide", contextClass, className),
        ...!children && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$shared$2f$src$2f$utils$2f$hasA11yProp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasA11yProp"])(rest) && {
            "aria-hidden": "true"
        },
        ...rest
    }, [
        ...iconNode.map(([tag, attrs])=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(tag, attrs)),
        ...Array.isArray(children) ? children : [
            children
        ]
    ]);
});
;
}),
"[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>createLucideIcon
]);
/**
 * @license lucide-react v1.7.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$shared$2f$src$2f$utils$2f$mergeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/shared/src/utils/mergeClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$shared$2f$src$2f$utils$2f$toKebabCase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/shared/src/utils/toKebabCase.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$shared$2f$src$2f$utils$2f$toPascalCase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/shared/src/utils/toPascalCase.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/Icon.js [app-client] (ecmascript)");
;
;
;
;
;
const createLucideIcon = (iconName, iconNode)=>{
    const Component = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(({ className, ...props }, ref)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            ref,
            iconNode,
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$shared$2f$src$2f$utils$2f$mergeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeClasses"])(`lucide-${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$shared$2f$src$2f$utils$2f$toKebabCase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toKebabCase"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$shared$2f$src$2f$utils$2f$toPascalCase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toPascalCase"])(iconName))}`, `lucide-${iconName}`, className),
            ...props
        }));
    Component.displayName = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$shared$2f$src$2f$utils$2f$toPascalCase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toPascalCase"])(iconName);
    return Component;
};
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/minus.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Minus
]);
/**
 * @license lucide-react v1.7.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M5 12h14",
            key: "1ays0h"
        }
    ]
];
const Minus = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("minus", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/minus.js [app-client] (ecmascript) <export default as MinusIcon>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MinusIcon",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$minus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$minus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/minus.js [app-client] (ecmascript)");
}),
"[project]/node_modules/@hugeicons/core-free-icons/dist/esm/SmartPhone01Icon.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SmartPhone01Icon
]);
const SmartPhone01Icon = /*#__PURE__*/ [
    [
        "path",
        {
            d: "M13.5 2H10.5C8.14298 2 6.96447 2 6.23223 2.73223C5.5 3.46447 5.5 4.64298 5.5 7V17C5.5 19.357 5.5 20.5355 6.23223 21.2678C6.96447 22 8.14298 22 10.5 22H13.5C15.857 22 17.0355 22 17.7678 21.2678C18.5 20.5355 18.5 19.357 18.5 17V7C18.5 4.64298 18.5 3.46447 17.7678 2.73223C17.0355 2 15.857 2 13.5 2Z",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "0"
        }
    ],
    [
        "path",
        {
            d: "M12.125 19H12M12.25 19C12.25 19.1381 12.1381 19.25 12 19.25C11.8619 19.25 11.75 19.1381 11.75 19C11.75 18.8619 11.8619 18.75 12 18.75C12.1381 18.75 12.25 18.8619 12.25 19Z",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.5",
            key: "1"
        }
    ]
];
;
}),
"[project]/node_modules/@hugeicons/core-free-icons/dist/esm/SmartPhone01Icon.js [app-client] (ecmascript) <export default as SmartPhone01Icon>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SmartPhone01Icon",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hugeicons$2f$core$2d$free$2d$icons$2f$dist$2f$esm$2f$SmartPhone01Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$hugeicons$2f$core$2d$free$2d$icons$2f$dist$2f$esm$2f$SmartPhone01Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@hugeicons/core-free-icons/dist/esm/SmartPhone01Icon.js [app-client] (ecmascript)");
}),
"[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// This file must be bundled in the app's client layer, it shouldn't be directly
// imported by the server.
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    callServer: null,
    createServerReference: null,
    findSourceMapURL: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    callServer: function() {
        return _appcallserver.callServer;
    },
    createServerReference: function() {
        return _client.createServerReference;
    },
    findSourceMapURL: function() {
        return _appfindsourcemapurl.findSourceMapURL;
    }
});
const _appcallserver = __turbopack_context__.r("[project]/node_modules/next/dist/client/app-call-server.js [app-client] (ecmascript)");
const _appfindsourcemapurl = __turbopack_context__.r("[project]/node_modules/next/dist/client/app-find-source-map-url.js [app-client] (ecmascript)");
const _client = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react-server-dom-turbopack/client.js [app-client] (ecmascript)");
}),
"[project]/node_modules/libphonenumber-js/metadata.min.json.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// This file is a workaround for a bug in web browsers' "native"
// ES6 importing system which is uncapable of importing "*.json" files.
// https://github.com/catamphetamine/libphonenumber-js/issues/239
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
const __TURBOPACK__default__export__ = {
    "version": 4,
    "country_calling_codes": {
        "1": [
            "US",
            "AG",
            "AI",
            "AS",
            "BB",
            "BM",
            "BS",
            "CA",
            "DM",
            "DO",
            "GD",
            "GU",
            "JM",
            "KN",
            "KY",
            "LC",
            "MP",
            "MS",
            "PR",
            "SX",
            "TC",
            "TT",
            "VC",
            "VG",
            "VI"
        ],
        "7": [
            "RU",
            "KZ"
        ],
        "20": [
            "EG"
        ],
        "27": [
            "ZA"
        ],
        "30": [
            "GR"
        ],
        "31": [
            "NL"
        ],
        "32": [
            "BE"
        ],
        "33": [
            "FR"
        ],
        "34": [
            "ES"
        ],
        "36": [
            "HU"
        ],
        "39": [
            "IT",
            "VA"
        ],
        "40": [
            "RO"
        ],
        "41": [
            "CH"
        ],
        "43": [
            "AT"
        ],
        "44": [
            "GB",
            "GG",
            "IM",
            "JE"
        ],
        "45": [
            "DK"
        ],
        "46": [
            "SE"
        ],
        "47": [
            "NO",
            "SJ"
        ],
        "48": [
            "PL"
        ],
        "49": [
            "DE"
        ],
        "51": [
            "PE"
        ],
        "52": [
            "MX"
        ],
        "53": [
            "CU"
        ],
        "54": [
            "AR"
        ],
        "55": [
            "BR"
        ],
        "56": [
            "CL"
        ],
        "57": [
            "CO"
        ],
        "58": [
            "VE"
        ],
        "60": [
            "MY"
        ],
        "61": [
            "AU",
            "CC",
            "CX"
        ],
        "62": [
            "ID"
        ],
        "63": [
            "PH"
        ],
        "64": [
            "NZ"
        ],
        "65": [
            "SG"
        ],
        "66": [
            "TH"
        ],
        "81": [
            "JP"
        ],
        "82": [
            "KR"
        ],
        "84": [
            "VN"
        ],
        "86": [
            "CN"
        ],
        "90": [
            "TR"
        ],
        "91": [
            "IN"
        ],
        "92": [
            "PK"
        ],
        "93": [
            "AF"
        ],
        "94": [
            "LK"
        ],
        "95": [
            "MM"
        ],
        "98": [
            "IR"
        ],
        "211": [
            "SS"
        ],
        "212": [
            "MA",
            "EH"
        ],
        "213": [
            "DZ"
        ],
        "216": [
            "TN"
        ],
        "218": [
            "LY"
        ],
        "220": [
            "GM"
        ],
        "221": [
            "SN"
        ],
        "222": [
            "MR"
        ],
        "223": [
            "ML"
        ],
        "224": [
            "GN"
        ],
        "225": [
            "CI"
        ],
        "226": [
            "BF"
        ],
        "227": [
            "NE"
        ],
        "228": [
            "TG"
        ],
        "229": [
            "BJ"
        ],
        "230": [
            "MU"
        ],
        "231": [
            "LR"
        ],
        "232": [
            "SL"
        ],
        "233": [
            "GH"
        ],
        "234": [
            "NG"
        ],
        "235": [
            "TD"
        ],
        "236": [
            "CF"
        ],
        "237": [
            "CM"
        ],
        "238": [
            "CV"
        ],
        "239": [
            "ST"
        ],
        "240": [
            "GQ"
        ],
        "241": [
            "GA"
        ],
        "242": [
            "CG"
        ],
        "243": [
            "CD"
        ],
        "244": [
            "AO"
        ],
        "245": [
            "GW"
        ],
        "246": [
            "IO"
        ],
        "247": [
            "AC"
        ],
        "248": [
            "SC"
        ],
        "249": [
            "SD"
        ],
        "250": [
            "RW"
        ],
        "251": [
            "ET"
        ],
        "252": [
            "SO"
        ],
        "253": [
            "DJ"
        ],
        "254": [
            "KE"
        ],
        "255": [
            "TZ"
        ],
        "256": [
            "UG"
        ],
        "257": [
            "BI"
        ],
        "258": [
            "MZ"
        ],
        "260": [
            "ZM"
        ],
        "261": [
            "MG"
        ],
        "262": [
            "RE",
            "YT"
        ],
        "263": [
            "ZW"
        ],
        "264": [
            "NA"
        ],
        "265": [
            "MW"
        ],
        "266": [
            "LS"
        ],
        "267": [
            "BW"
        ],
        "268": [
            "SZ"
        ],
        "269": [
            "KM"
        ],
        "290": [
            "SH",
            "TA"
        ],
        "291": [
            "ER"
        ],
        "297": [
            "AW"
        ],
        "298": [
            "FO"
        ],
        "299": [
            "GL"
        ],
        "350": [
            "GI"
        ],
        "351": [
            "PT"
        ],
        "352": [
            "LU"
        ],
        "353": [
            "IE"
        ],
        "354": [
            "IS"
        ],
        "355": [
            "AL"
        ],
        "356": [
            "MT"
        ],
        "357": [
            "CY"
        ],
        "358": [
            "FI",
            "AX"
        ],
        "359": [
            "BG"
        ],
        "370": [
            "LT"
        ],
        "371": [
            "LV"
        ],
        "372": [
            "EE"
        ],
        "373": [
            "MD"
        ],
        "374": [
            "AM"
        ],
        "375": [
            "BY"
        ],
        "376": [
            "AD"
        ],
        "377": [
            "MC"
        ],
        "378": [
            "SM"
        ],
        "380": [
            "UA"
        ],
        "381": [
            "RS"
        ],
        "382": [
            "ME"
        ],
        "383": [
            "XK"
        ],
        "385": [
            "HR"
        ],
        "386": [
            "SI"
        ],
        "387": [
            "BA"
        ],
        "389": [
            "MK"
        ],
        "420": [
            "CZ"
        ],
        "421": [
            "SK"
        ],
        "423": [
            "LI"
        ],
        "500": [
            "FK"
        ],
        "501": [
            "BZ"
        ],
        "502": [
            "GT"
        ],
        "503": [
            "SV"
        ],
        "504": [
            "HN"
        ],
        "505": [
            "NI"
        ],
        "506": [
            "CR"
        ],
        "507": [
            "PA"
        ],
        "508": [
            "PM"
        ],
        "509": [
            "HT"
        ],
        "590": [
            "GP",
            "BL",
            "MF"
        ],
        "591": [
            "BO"
        ],
        "592": [
            "GY"
        ],
        "593": [
            "EC"
        ],
        "594": [
            "GF"
        ],
        "595": [
            "PY"
        ],
        "596": [
            "MQ"
        ],
        "597": [
            "SR"
        ],
        "598": [
            "UY"
        ],
        "599": [
            "CW",
            "BQ"
        ],
        "670": [
            "TL"
        ],
        "672": [
            "NF"
        ],
        "673": [
            "BN"
        ],
        "674": [
            "NR"
        ],
        "675": [
            "PG"
        ],
        "676": [
            "TO"
        ],
        "677": [
            "SB"
        ],
        "678": [
            "VU"
        ],
        "679": [
            "FJ"
        ],
        "680": [
            "PW"
        ],
        "681": [
            "WF"
        ],
        "682": [
            "CK"
        ],
        "683": [
            "NU"
        ],
        "685": [
            "WS"
        ],
        "686": [
            "KI"
        ],
        "687": [
            "NC"
        ],
        "688": [
            "TV"
        ],
        "689": [
            "PF"
        ],
        "690": [
            "TK"
        ],
        "691": [
            "FM"
        ],
        "692": [
            "MH"
        ],
        "850": [
            "KP"
        ],
        "852": [
            "HK"
        ],
        "853": [
            "MO"
        ],
        "855": [
            "KH"
        ],
        "856": [
            "LA"
        ],
        "880": [
            "BD"
        ],
        "886": [
            "TW"
        ],
        "960": [
            "MV"
        ],
        "961": [
            "LB"
        ],
        "962": [
            "JO"
        ],
        "963": [
            "SY"
        ],
        "964": [
            "IQ"
        ],
        "965": [
            "KW"
        ],
        "966": [
            "SA"
        ],
        "967": [
            "YE"
        ],
        "968": [
            "OM"
        ],
        "970": [
            "PS"
        ],
        "971": [
            "AE"
        ],
        "972": [
            "IL"
        ],
        "973": [
            "BH"
        ],
        "974": [
            "QA"
        ],
        "975": [
            "BT"
        ],
        "976": [
            "MN"
        ],
        "977": [
            "NP"
        ],
        "992": [
            "TJ"
        ],
        "993": [
            "TM"
        ],
        "994": [
            "AZ"
        ],
        "995": [
            "GE"
        ],
        "996": [
            "KG"
        ],
        "998": [
            "UZ"
        ]
    },
    "countries": {
        "AC": [
            "247",
            "00",
            "(?:[01589]\\d|[46])\\d{4}",
            [
                5,
                6
            ]
        ],
        "AD": [
            "376",
            "00",
            "(?:1|6\\d)\\d{7}|[135-9]\\d{5}",
            [
                6,
                8,
                9
            ],
            [
                [
                    "(\\d{3})(\\d{3})",
                    "$1 $2",
                    [
                        "[135-9]"
                    ]
                ],
                [
                    "(\\d{4})(\\d{4})",
                    "$1 $2",
                    [
                        "1"
                    ]
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "6"
                    ]
                ]
            ]
        ],
        "AE": [
            "971",
            "00",
            "(?:[4-7]\\d|9[0-689])\\d{7}|800\\d{2,9}|[2-4679]\\d{7}",
            [
                5,
                6,
                7,
                8,
                9,
                10,
                11,
                12
            ],
            [
                [
                    "(\\d{3})(\\d{2,9})",
                    "$1 $2",
                    [
                        "60|8"
                    ]
                ],
                [
                    "(\\d)(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "[236]|[479][2-8]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d)(\\d{5})",
                    "$1 $2 $3",
                    [
                        "[479]"
                    ]
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "5"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "AF": [
            "93",
            "00",
            "[2-7]\\d{8}",
            [
                9
            ],
            [
                [
                    "(\\d{2})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "[2-7]"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "AG": [
            "1",
            "011",
            "(?:268|[58]\\d\\d|900)\\d{7}",
            [
                10
            ],
            0,
            "1",
            0,
            "([457]\\d{6})$|1",
            "268$1",
            0,
            "268"
        ],
        "AI": [
            "1",
            "011",
            "(?:264|[58]\\d\\d|900)\\d{7}",
            [
                10
            ],
            0,
            "1",
            0,
            "([2457]\\d{6})$|1",
            "264$1",
            0,
            "264"
        ],
        "AL": [
            "355",
            "00",
            "(?:700\\d\\d|900)\\d{3}|8\\d{5,7}|(?:[2-5]|6\\d)\\d{7}",
            [
                6,
                7,
                8,
                9
            ],
            [
                [
                    "(\\d{3})(\\d{3,4})",
                    "$1 $2",
                    [
                        "80|9"
                    ],
                    "0$1"
                ],
                [
                    "(\\d)(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "4[2-6]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "[2358][2-5]|4"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{5})",
                    "$1 $2",
                    [
                        "[23578]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "6"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "AM": [
            "374",
            "00",
            "(?:[1-489]\\d|55|60|77)\\d{6}",
            [
                8
            ],
            [
                [
                    "(\\d{3})(\\d{2})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "[89]0"
                    ],
                    "0 $1"
                ],
                [
                    "(\\d{3})(\\d{5})",
                    "$1 $2",
                    [
                        "2|3[12]"
                    ],
                    "(0$1)"
                ],
                [
                    "(\\d{2})(\\d{6})",
                    "$1 $2",
                    [
                        "1|47"
                    ],
                    "(0$1)"
                ],
                [
                    "(\\d{2})(\\d{6})",
                    "$1 $2",
                    [
                        "[3-9]"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "AO": [
            "244",
            "00",
            "[29]\\d{8}",
            [
                9
            ],
            [
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "[29]"
                    ]
                ]
            ]
        ],
        "AR": [
            "54",
            "00",
            "(?:11|[89]\\d\\d)\\d{8}|[2368]\\d{9}",
            [
                10,
                11
            ],
            [
                [
                    "(\\d{4})(\\d{2})(\\d{4})",
                    "$1 $2-$3",
                    [
                        "2(?:2[024-9]|3[0-59]|47|6[245]|9[02-8])|3(?:3[28]|4[03-9]|5[2-46-8]|7[1-578]|8[2-9])",
                        "2(?:[23]02|6(?:[25]|4[6-8])|9(?:[02356]|4[02568]|72|8[23]))|3(?:3[28]|4(?:[04679]|3[5-8]|5[4-68]|8[2379])|5(?:[2467]|3[237]|8[2-5])|7[1-578]|8(?:[2469]|3[2578]|5[4-8]|7[36-8]|8[5-8]))|2(?:2[24-9]|3[1-59]|47)",
                        "2(?:[23]02|6(?:[25]|4(?:64|[78]))|9(?:[02356]|4(?:[0268]|5[2-6])|72|8[23]))|3(?:3[28]|4(?:[04679]|3[78]|5(?:4[46]|8)|8[2379])|5(?:[2467]|3[237]|8[23])|7[1-578]|8(?:[2469]|3[278]|5[56][46]|86[3-6]))|2(?:2[24-9]|3[1-59]|47)|38(?:[58][78]|7[378])|3(?:4[35][56]|58[45]|8(?:[38]5|54|76))[4-6]",
                        "2(?:[23]02|6(?:[25]|4(?:64|[78]))|9(?:[02356]|4(?:[0268]|5[2-6])|72|8[23]))|3(?:3[28]|4(?:[04679]|3(?:5(?:4[0-25689]|[56])|[78])|58|8[2379])|5(?:[2467]|3[237]|8(?:[23]|4(?:[45]|60)|5(?:4[0-39]|5|64)))|7[1-578]|8(?:[2469]|3[278]|54(?:4|5[13-7]|6[89])|86[3-6]))|2(?:2[24-9]|3[1-59]|47)|38(?:[58][78]|7[378])|3(?:454|85[56])[46]|3(?:4(?:36|5[56])|8(?:[38]5|76))[4-6]"
                    ],
                    "0$1",
                    1
                ],
                [
                    "(\\d{2})(\\d{4})(\\d{4})",
                    "$1 $2-$3",
                    [
                        "1"
                    ],
                    "0$1",
                    1
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{4})",
                    "$1-$2-$3",
                    [
                        "[68]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{4})",
                    "$1 $2-$3",
                    [
                        "[23]"
                    ],
                    "0$1",
                    1
                ],
                [
                    "(\\d)(\\d{4})(\\d{2})(\\d{4})",
                    "$2 15-$3-$4",
                    [
                        "9(?:2[2-469]|3[3-578])",
                        "9(?:2(?:2[024-9]|3[0-59]|47|6[245]|9[02-8])|3(?:3[28]|4[03-9]|5[2-46-8]|7[1-578]|8[2-9]))",
                        "9(?:2(?:[23]02|6(?:[25]|4[6-8])|9(?:[02356]|4[02568]|72|8[23]))|3(?:3[28]|4(?:[04679]|3[5-8]|5[4-68]|8[2379])|5(?:[2467]|3[237]|8[2-5])|7[1-578]|8(?:[2469]|3[2578]|5[4-8]|7[36-8]|8[5-8])))|92(?:2[24-9]|3[1-59]|47)",
                        "9(?:2(?:[23]02|6(?:[25]|4(?:64|[78]))|9(?:[02356]|4(?:[0268]|5[2-6])|72|8[23]))|3(?:3[28]|4(?:[04679]|3[78]|5(?:4[46]|8)|8[2379])|5(?:[2467]|3[237]|8[23])|7[1-578]|8(?:[2469]|3[278]|5(?:[56][46]|[78])|7[378]|8(?:6[3-6]|[78]))))|92(?:2[24-9]|3[1-59]|47)|93(?:4[35][56]|58[45]|8(?:[38]5|54|76))[4-6]",
                        "9(?:2(?:[23]02|6(?:[25]|4(?:64|[78]))|9(?:[02356]|4(?:[0268]|5[2-6])|72|8[23]))|3(?:3[28]|4(?:[04679]|3(?:5(?:4[0-25689]|[56])|[78])|5(?:4[46]|8)|8[2379])|5(?:[2467]|3[237]|8(?:[23]|4(?:[45]|60)|5(?:4[0-39]|5|64)))|7[1-578]|8(?:[2469]|3[278]|5(?:4(?:4|5[13-7]|6[89])|[56][46]|[78])|7[378]|8(?:6[3-6]|[78]))))|92(?:2[24-9]|3[1-59]|47)|93(?:4(?:36|5[56])|8(?:[38]5|76))[4-6]"
                    ],
                    "0$1",
                    0,
                    "$1 $2 $3-$4"
                ],
                [
                    "(\\d)(\\d{2})(\\d{4})(\\d{4})",
                    "$2 15-$3-$4",
                    [
                        "91"
                    ],
                    "0$1",
                    0,
                    "$1 $2 $3-$4"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{5})",
                    "$1-$2-$3",
                    [
                        "8"
                    ],
                    "0$1"
                ],
                [
                    "(\\d)(\\d{3})(\\d{3})(\\d{4})",
                    "$2 15-$3-$4",
                    [
                        "9"
                    ],
                    "0$1",
                    0,
                    "$1 $2 $3-$4"
                ]
            ],
            "0",
            0,
            "0?(?:(11|2(?:2(?:02?|[13]|2[13-79]|4[1-6]|5[2457]|6[124-8]|7[1-4]|8[13-6]|9[1267])|3(?:02?|1[467]|2[03-6]|3[13-8]|[49][2-6]|5[2-8]|[67])|4(?:7[3-578]|9)|6(?:[0136]|2[24-6]|4[6-8]?|5[15-8])|80|9(?:0[1-3]|[19]|2\\d|3[1-6]|4[02568]?|5[2-4]|6[2-46]|72?|8[23]?))|3(?:3(?:2[79]|6|8[2578])|4(?:0[0-24-9]|[12]|3[5-8]?|4[24-7]|5[4-68]?|6[02-9]|7[126]|8[2379]?|9[1-36-8])|5(?:1|2[1245]|3[237]?|4[1-46-9]|6[2-4]|7[1-6]|8[2-5]?)|6[24]|7(?:[069]|1[1568]|2[15]|3[145]|4[13]|5[14-8]|7[2-57]|8[126])|8(?:[01]|2[15-7]|3[2578]?|4[13-6]|5[4-8]?|6[1-357-9]|7[36-8]?|8[5-8]?|9[124])))15)?",
            "9$1"
        ],
        "AS": [
            "1",
            "011",
            "(?:[58]\\d\\d|684|900)\\d{7}",
            [
                10
            ],
            0,
            "1",
            0,
            "([267]\\d{6})$|1",
            "684$1",
            0,
            "684"
        ],
        "AT": [
            "43",
            "00",
            "1\\d{3,12}|2\\d{6,12}|43(?:(?:0\\d|5[02-9])\\d{3,9}|2\\d{4,5}|[3467]\\d{4}|8\\d{4,6}|9\\d{4,7})|5\\d{4,12}|8\\d{7,12}|9\\d{8,12}|(?:[367]\\d|4[0-24-9])\\d{4,11}",
            [
                4,
                5,
                6,
                7,
                8,
                9,
                10,
                11,
                12,
                13
            ],
            [
                [
                    "(\\d)(\\d{3,12})",
                    "$1 $2",
                    [
                        "1(?:11|[2-9])"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{2})",
                    "$1 $2",
                    [
                        "517"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3,5})",
                    "$1 $2",
                    [
                        "5[079]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3,10})",
                    "$1 $2",
                    [
                        "(?:31|4)6|51|6(?:48|5[0-3579]|[6-9])|7(?:20|32|8)|[89]",
                        "(?:31|4)6|51|6(?:485|5[0-3579]|[6-9])|7(?:20|32|8)|[89]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{4})(\\d{3,9})",
                    "$1 $2",
                    [
                        "[2-467]|5[2-6]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{3,4})",
                    "$1 $2 $3",
                    [
                        "5"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{4})(\\d{4,7})",
                    "$1 $2 $3",
                    [
                        "5"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "AU": [
            "61",
            "001[14-689]|14(?:1[14]|34|4[17]|[56]6|7[47]|88)0011",
            "1(?:[0-79]\\d{7}(?:\\d(?:\\d{2})?)?|8[0-24-9]\\d{7})|[2-478]\\d{8}|1\\d{4,7}",
            [
                5,
                6,
                7,
                8,
                9,
                10,
                12
            ],
            [
                [
                    "(\\d{2})(\\d{3,4})",
                    "$1 $2",
                    [
                        "16"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{2,4})",
                    "$1 $2 $3",
                    [
                        "16"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "14|4"
                    ],
                    "0$1"
                ],
                [
                    "(\\d)(\\d{4})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "[2378]"
                    ],
                    "(0$1)"
                ],
                [
                    "(\\d{4})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "1(?:30|[89])"
                    ]
                ]
            ],
            "0",
            0,
            "(183[12])|0",
            0,
            0,
            0,
            [
                [
                    "(?:(?:241|349)0\\d\\d|8(?:51(?:0(?:0[03-9]|[12479]\\d|3[2-9]|5[0-8]|6[1-9]|8[0-7])|1(?:[0235689]\\d|1[0-69]|4[0-589]|7[0-47-9])|2(?:0[0-79]|[18][13579]|2[14-9]|3[0-46-9]|[4-6]\\d|7[89]|9[0-4])|[34]\\d\\d)|91(?:(?:[0-58]\\d|6[0135-9])\\d|7(?:0[0-24-9]|[1-9]\\d)|9(?:[0-46-9]\\d|5[0-79]))))\\d{3}|(?:2(?:[0-26-9]\\d|3[0-8]|4[02-9]|5[0135-9])|3(?:[0-3589]\\d|4[0-578]|6[1-9]|7[0-35-9])|7(?:[013-57-9]\\d|2[0-8])|8(?:55|6[0-8]|[78]\\d|9[02-9]))\\d{6}",
                    [
                        9
                    ]
                ],
                [
                    "4(?:79[01]|83[0-36-9]|95[0-3])\\d{5}|4(?:[0-36]\\d|4[047-9]|[58][0-24-9]|7[02-8]|9[0-47-9])\\d{6}",
                    [
                        9
                    ]
                ],
                [
                    "180(?:0\\d{3}|2)\\d{3}",
                    [
                        7,
                        10
                    ]
                ],
                [
                    "190[0-26]\\d{6}",
                    [
                        10
                    ]
                ],
                0,
                0,
                0,
                [
                    "163\\d{2,6}",
                    [
                        5,
                        6,
                        7,
                        8,
                        9
                    ]
                ],
                [
                    "14(?:5(?:1[0458]|[23][458])|71\\d)\\d{4}",
                    [
                        9
                    ]
                ],
                [
                    "13(?:00\\d{6}(?:\\d{2})?|45[0-4]\\d{3})|13\\d{4}",
                    [
                        6,
                        8,
                        10,
                        12
                    ]
                ]
            ],
            "0011"
        ],
        "AW": [
            "297",
            "00",
            "(?:[25-79]\\d\\d|800)\\d{4}",
            [
                7
            ],
            [
                [
                    "(\\d{3})(\\d{4})",
                    "$1 $2",
                    [
                        "[25-9]"
                    ]
                ]
            ]
        ],
        "AX": [
            "358",
            "00|99(?:[01469]|5(?:[14]1|3[23]|5[59]|77|88|9[09]))",
            "2\\d{4,9}|35\\d{4,5}|(?:60\\d\\d|800)\\d{4,6}|7\\d{5,11}|(?:[14]\\d|3[0-46-9]|50)\\d{4,8}",
            [
                5,
                6,
                7,
                8,
                9,
                10,
                11,
                12
            ],
            0,
            "0",
            0,
            0,
            0,
            0,
            "18",
            0,
            "00"
        ],
        "AZ": [
            "994",
            "00",
            "365\\d{6}|(?:[124579]\\d|60|88)\\d{7}",
            [
                9
            ],
            [
                [
                    "(\\d{3})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "90"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "1[28]|2|365|46",
                        "1[28]|2|365[45]|46",
                        "1[28]|2|365(?:4|5[02])|46"
                    ],
                    "(0$1)"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "[13-9]"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "BA": [
            "387",
            "00",
            "6\\d{8}|(?:[35689]\\d|49|70)\\d{6}",
            [
                8,
                9
            ],
            [
                [
                    "(\\d{2})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "6[1-3]|[7-9]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{3})",
                    "$1 $2-$3",
                    [
                        "[3-5]|6[56]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{2})(\\d{2})(\\d{3})",
                    "$1 $2 $3 $4",
                    [
                        "6"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "BB": [
            "1",
            "011",
            "(?:246|[58]\\d\\d|900)\\d{7}",
            [
                10
            ],
            0,
            "1",
            0,
            "([2-9]\\d{6})$|1",
            "246$1",
            0,
            "246"
        ],
        "BD": [
            "880",
            "00",
            "[1-469]\\d{9}|8[0-79]\\d{7,8}|[2-79]\\d{8}|[2-9]\\d{7}|[3-9]\\d{6}|[57-9]\\d{5}",
            [
                6,
                7,
                8,
                9,
                10
            ],
            [
                [
                    "(\\d{2})(\\d{4,6})",
                    "$1-$2",
                    [
                        "31[5-8]|[459]1"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3,7})",
                    "$1-$2",
                    [
                        "3(?:[67]|8[013-9])|4(?:6[168]|7|[89][18])|5(?:6[128]|9)|6(?:[15]|28|4[14])|7[2-589]|8(?:0[014-9]|[12])|9[358]|(?:3[2-5]|4[235]|5[2-578]|6[0389]|76|8[3-7]|9[24])1|(?:44|66)[01346-9]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{4})(\\d{3,6})",
                    "$1-$2",
                    [
                        "[13-9]|2[23]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d)(\\d{7,8})",
                    "$1-$2",
                    [
                        "2"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "BE": [
            "32",
            "00",
            "4\\d{8}|[1-9]\\d{7}",
            [
                8,
                9
            ],
            [
                [
                    "(\\d{3})(\\d{2})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "(?:80|9)0"
                    ],
                    "0$1"
                ],
                [
                    "(\\d)(\\d{3})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "[239]|4[23]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "[15-8]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "4"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "BF": [
            "226",
            "00",
            "[024-7]\\d{7}",
            [
                8
            ],
            [
                [
                    "(\\d{2})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "[024-7]"
                    ]
                ]
            ]
        ],
        "BG": [
            "359",
            "00",
            "00800\\d{7}|[2-7]\\d{6,7}|[89]\\d{6,8}|2\\d{5}",
            [
                6,
                7,
                8,
                9,
                12
            ],
            [
                [
                    "(\\d)(\\d)(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "2"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{4})",
                    "$1 $2",
                    [
                        "43[1-6]|70[1-9]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d)(\\d{3})(\\d{3,4})",
                    "$1 $2 $3",
                    [
                        "2"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{2,3})",
                    "$1 $2 $3",
                    [
                        "[356]|4[124-7]|7[1-9]|8[1-6]|9[1-7]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{2})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "(?:70|8)0"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{2})",
                    "$1 $2 $3",
                    [
                        "43[1-7]|7"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{3,4})",
                    "$1 $2 $3",
                    [
                        "[48]|9[08]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "9"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "BH": [
            "973",
            "00",
            "[136-9]\\d{7}",
            [
                8
            ],
            [
                [
                    "(\\d{4})(\\d{4})",
                    "$1 $2",
                    [
                        "[13679]|8[02-4679]"
                    ]
                ]
            ]
        ],
        "BI": [
            "257",
            "00",
            "(?:[267]\\d|31)\\d{6}",
            [
                8
            ],
            [
                [
                    "(\\d{2})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "[2367]"
                    ]
                ]
            ]
        ],
        "BJ": [
            "229",
            "00",
            "(?:01\\d|8)\\d{7}",
            [
                8,
                10
            ],
            [
                [
                    "(\\d{2})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "8"
                    ]
                ],
                [
                    "(\\d{2})(\\d{2})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4 $5",
                    [
                        "0"
                    ]
                ]
            ]
        ],
        "BL": [
            "590",
            "00",
            "7090\\d{5}|(?:[56]9|[89]\\d)\\d{7}",
            [
                9
            ],
            0,
            "0",
            0,
            0,
            0,
            0,
            0,
            [
                [
                    "(?:59(?:0(?:2[7-9]|3[3-7]|5[12]|87)|87\\d)|80[6-9]\\d\\d)\\d{4}"
                ],
                [
                    "(?:69(?:0\\d\\d|1(?:2[2-9]|3[0-5]))|7090[0-4])\\d{4}"
                ],
                [
                    "80[0-5]\\d{6}"
                ],
                [
                    "8[129]\\d{7}"
                ],
                0,
                0,
                0,
                0,
                [
                    "9(?:(?:39[5-7]|76[018])\\d|475[0-6])\\d{4}"
                ]
            ]
        ],
        "BM": [
            "1",
            "011",
            "(?:441|[58]\\d\\d|900)\\d{7}",
            [
                10
            ],
            0,
            "1",
            0,
            "([2-9]\\d{6})$|1",
            "441$1",
            0,
            "441"
        ],
        "BN": [
            "673",
            "00",
            "[2-578]\\d{6}",
            [
                7
            ],
            [
                [
                    "(\\d{3})(\\d{4})",
                    "$1 $2",
                    [
                        "[2-578]"
                    ]
                ]
            ]
        ],
        "BO": [
            "591",
            "00(?:1\\d)?",
            "8001\\d{5}|(?:[2-467]\\d|50)\\d{6}",
            [
                8,
                9
            ],
            [
                [
                    "(\\d)(\\d{7})",
                    "$1 $2",
                    [
                        "[235]|4[46]"
                    ]
                ],
                [
                    "(\\d{8})",
                    "$1",
                    [
                        "[67]"
                    ]
                ],
                [
                    "(\\d{3})(\\d{2})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "8"
                    ]
                ]
            ],
            "0",
            0,
            "0(1\\d)?"
        ],
        "BQ": [
            "599",
            "00",
            "(?:[34]1|7\\d)\\d{5}",
            [
                7
            ],
            0,
            0,
            0,
            0,
            0,
            0,
            "[347]"
        ],
        "BR": [
            "55",
            "00(?:1[245]|2[1-35]|31|4[13]|[56]5|99)",
            "[1-467]\\d{9,10}|55[0-46-9]\\d{8}|[34]\\d{7}|55\\d{7,8}|(?:5[0-46-9]|[89]\\d)\\d{7,9}",
            [
                8,
                9,
                10,
                11
            ],
            [
                [
                    "(\\d{4})(\\d{4})",
                    "$1-$2",
                    [
                        "300|4(?:0[02]|37|86)",
                        "300|4(?:0(?:0|20)|370|864)"
                    ]
                ],
                [
                    "(\\d{3})(\\d{2,3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "(?:[358]|90)0"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{4})(\\d{4})",
                    "$1 $2-$3",
                    [
                        "(?:[14689][1-9]|2[12478]|3[1-578]|5[13-5]|7[13-579])[2-57]"
                    ],
                    "($1)"
                ],
                [
                    "(\\d{2})(\\d{5})(\\d{4})",
                    "$1 $2-$3",
                    [
                        "[16][1-9]|[2-57-9]"
                    ],
                    "($1)"
                ]
            ],
            "0",
            0,
            "(?:0|90)(?:(1[245]|2[1-35]|31|4[13]|[56]5|99)(\\d{10,11}))?",
            "$2"
        ],
        "BS": [
            "1",
            "011",
            "(?:242|[58]\\d\\d|900)\\d{7}",
            [
                10
            ],
            0,
            "1",
            0,
            "([3-8]\\d{6})$|1",
            "242$1",
            0,
            "242"
        ],
        "BT": [
            "975",
            "00",
            "[178]\\d{7}|[2-8]\\d{6}",
            [
                7,
                8
            ],
            [
                [
                    "(\\d)(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "[2-6]|7[246]|8[2-4]"
                    ]
                ],
                [
                    "(\\d{2})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "1[67]|[78]"
                    ]
                ]
            ]
        ],
        "BW": [
            "267",
            "00",
            "(?:0800|(?:[37]|800)\\d)\\d{6}|(?:[2-6]\\d|90)\\d{5}",
            [
                7,
                8,
                10
            ],
            [
                [
                    "(\\d{2})(\\d{5})",
                    "$1 $2",
                    [
                        "90"
                    ]
                ],
                [
                    "(\\d{3})(\\d{4})",
                    "$1 $2",
                    [
                        "[24-6]|3[15-9]"
                    ]
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "[37]"
                    ]
                ],
                [
                    "(\\d{4})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "0"
                    ]
                ],
                [
                    "(\\d{3})(\\d{4})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "8"
                    ]
                ]
            ]
        ],
        "BY": [
            "375",
            "810",
            "(?:[12]\\d|33|44|902)\\d{7}|8(?:0[0-79]\\d{5,7}|[1-7]\\d{9})|8(?:1[0-489]|[5-79]\\d)\\d{7}|8[1-79]\\d{6,7}|8[0-79]\\d{5}|8\\d{5}",
            [
                6,
                7,
                8,
                9,
                10,
                11
            ],
            [
                [
                    "(\\d{3})(\\d{3})",
                    "$1 $2",
                    [
                        "800"
                    ],
                    "8 $1"
                ],
                [
                    "(\\d{3})(\\d{2})(\\d{2,4})",
                    "$1 $2 $3",
                    [
                        "800"
                    ],
                    "8 $1"
                ],
                [
                    "(\\d{4})(\\d{2})(\\d{3})",
                    "$1 $2-$3",
                    [
                        "1(?:5[169]|6[3-5]|7[179])|2(?:1[35]|2[34]|3[3-5])",
                        "1(?:5[169]|6(?:3[1-3]|4|5[125])|7(?:1[3-9]|7[0-24-6]|9[2-7]))|2(?:1[35]|2[34]|3[3-5])"
                    ],
                    "8 0$1"
                ],
                [
                    "(\\d{3})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2-$3-$4",
                    [
                        "1(?:[56]|7[467])|2[1-3]"
                    ],
                    "8 0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{2})(\\d{2})",
                    "$1 $2-$3-$4",
                    [
                        "[1-4]"
                    ],
                    "8 0$1"
                ],
                [
                    "(\\d{3})(\\d{3,4})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "[89]"
                    ],
                    "8 $1"
                ]
            ],
            "8",
            0,
            "0|80?",
            0,
            0,
            0,
            0,
            "8~10"
        ],
        "BZ": [
            "501",
            "00",
            "(?:0800\\d|[2-8])\\d{6}",
            [
                7,
                11
            ],
            [
                [
                    "(\\d{3})(\\d{4})",
                    "$1-$2",
                    [
                        "[2-8]"
                    ]
                ],
                [
                    "(\\d)(\\d{3})(\\d{4})(\\d{3})",
                    "$1-$2-$3-$4",
                    [
                        "0"
                    ]
                ]
            ]
        ],
        "CA": [
            "1",
            "011",
            "[2-9]\\d{9}|3\\d{6}",
            [
                7,
                10
            ],
            0,
            "1",
            0,
            0,
            0,
            0,
            0,
            [
                [
                    "(?:2(?:04|[23]6|[48]9|5[07]|63)|3(?:06|43|54|6[578]|82)|4(?:03|1[68]|[26]8|3[178]|50|74)|5(?:06|1[49]|48|79|8[147])|6(?:04|[18]3|39|47|72)|7(?:0[59]|42|53|78|8[02])|8(?:[06]7|19|25|7[39])|9(?:0[25]|42))[2-9]\\d{6}",
                    [
                        10
                    ]
                ],
                [
                    "",
                    [
                        10
                    ]
                ],
                [
                    "8(?:00|33|44|55|66|77|88)[2-9]\\d{6}",
                    [
                        10
                    ]
                ],
                [
                    "900[2-9]\\d{6}",
                    [
                        10
                    ]
                ],
                [
                    "52(?:3(?:[2-46-9][02-9]\\d|5(?:[02-46-9]\\d|5[0-46-9]))|4(?:[2-478][02-9]\\d|5(?:[034]\\d|2[024-9]|5[0-46-9])|6(?:0[1-9]|[2-9]\\d)|9(?:[05-9]\\d|2[0-5]|49)))\\d{4}|52[34][2-9]1[02-9]\\d{4}|(?:5(?:2[125-9]|3[23]|44|66|77|88)|6(?:22|33))[2-9]\\d{6}",
                    [
                        10
                    ]
                ],
                0,
                [
                    "310\\d{4}",
                    [
                        7
                    ]
                ],
                0,
                [
                    "600[2-9]\\d{6}",
                    [
                        10
                    ]
                ]
            ]
        ],
        "CC": [
            "61",
            "001[14-689]|14(?:1[14]|34|4[17]|[56]6|7[47]|88)0011",
            "1(?:[0-79]\\d{8}(?:\\d{2})?|8[0-24-9]\\d{7})|[148]\\d{8}|1\\d{5,7}",
            [
                6,
                7,
                8,
                9,
                10,
                12
            ],
            0,
            "0",
            0,
            "([59]\\d{7})$|0",
            "8$1",
            0,
            0,
            [
                [
                    "8(?:51(?:0(?:02|31|60|89)|1(?:18|76)|223)|91(?:0(?:1[0-2]|29)|1(?:[28]2|50|79)|2(?:10|64)|3(?:[06]8|22)|4[29]8|62\\d|70[23]|959))\\d{3}",
                    [
                        9
                    ]
                ],
                [
                    "4(?:79[01]|83[0-36-9]|95[0-3])\\d{5}|4(?:[0-36]\\d|4[047-9]|[58][0-24-9]|7[02-8]|9[0-47-9])\\d{6}",
                    [
                        9
                    ]
                ],
                [
                    "180(?:0\\d{3}|2)\\d{3}",
                    [
                        7,
                        10
                    ]
                ],
                [
                    "190[0-26]\\d{6}",
                    [
                        10
                    ]
                ],
                0,
                0,
                0,
                0,
                [
                    "14(?:5(?:1[0458]|[23][458])|71\\d)\\d{4}",
                    [
                        9
                    ]
                ],
                [
                    "13(?:00\\d{6}(?:\\d{2})?|45[0-4]\\d{3})|13\\d{4}",
                    [
                        6,
                        8,
                        10,
                        12
                    ]
                ]
            ],
            "0011"
        ],
        "CD": [
            "243",
            "00",
            "(?:(?:[189]|5\\d)\\d|2)\\d{7}|[1-68]\\d{6}",
            [
                7,
                8,
                9,
                10
            ],
            [
                [
                    "(\\d{2})(\\d{2})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "88"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{5})",
                    "$1 $2",
                    [
                        "[1-6]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{2})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "2"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "1"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "[89]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{2})(\\d{3})(\\d{3})",
                    "$1 $2 $3 $4",
                    [
                        "5"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "CF": [
            "236",
            "00",
            "8776\\d{4}|(?:[27]\\d|61)\\d{6}",
            [
                8
            ],
            [
                [
                    "(\\d{2})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "[26-8]"
                    ]
                ]
            ]
        ],
        "CG": [
            "242",
            "00",
            "222\\d{6}|(?:0\\d|80)\\d{7}",
            [
                9
            ],
            [
                [
                    "(\\d)(\\d{4})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "8"
                    ]
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "[02]"
                    ]
                ]
            ]
        ],
        "CH": [
            "41",
            "00",
            "8\\d{11}|[2-9]\\d{8}",
            [
                9,
                12
            ],
            [
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "8[047]|90"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "[2-79]|81"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{2})(\\d{3})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4 $5",
                    [
                        "8"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "CI": [
            "225",
            "00",
            "[02]\\d{9}",
            [
                10
            ],
            [
                [
                    "(\\d{2})(\\d{2})(\\d)(\\d{5})",
                    "$1 $2 $3 $4",
                    [
                        "2"
                    ]
                ],
                [
                    "(\\d{2})(\\d{2})(\\d{2})(\\d{4})",
                    "$1 $2 $3 $4",
                    [
                        "0"
                    ]
                ]
            ]
        ],
        "CK": [
            "682",
            "00",
            "[2-578]\\d{4}",
            [
                5
            ],
            [
                [
                    "(\\d{2})(\\d{3})",
                    "$1 $2",
                    [
                        "[2-578]"
                    ]
                ]
            ]
        ],
        "CL": [
            "56",
            "(?:0|1(?:1[0-69]|2[02-5]|5[13-58]|69|7[0167]|8[018]))0",
            "12300\\d{6}|6\\d{9,10}|[2-9]\\d{8}",
            [
                9,
                10,
                11
            ],
            [
                [
                    "(\\d{5})(\\d{4})",
                    "$1 $2",
                    [
                        "219",
                        "2196"
                    ],
                    "($1)"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "60|809"
                    ]
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "44"
                    ]
                ],
                [
                    "(\\d)(\\d{4})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "2[1-36]"
                    ],
                    "($1)"
                ],
                [
                    "(\\d)(\\d{4})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "9(?:10|[2-9])"
                    ]
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "3[2-5]|[47]|5[1-3578]|6[13-57]|8(?:0[1-8]|[1-9])"
                    ],
                    "($1)"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3,4})",
                    "$1 $2 $3",
                    [
                        "60|8"
                    ]
                ],
                [
                    "(\\d{4})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "1"
                    ]
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{2})(\\d{3})",
                    "$1 $2 $3 $4",
                    [
                        "60"
                    ]
                ]
            ]
        ],
        "CM": [
            "237",
            "00",
            "[26]\\d{8}|88\\d{6,7}",
            [
                8,
                9
            ],
            [
                [
                    "(\\d{2})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "88"
                    ]
                ],
                [
                    "(\\d)(\\d{2})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4 $5",
                    [
                        "[26]|88"
                    ]
                ]
            ]
        ],
        "CN": [
            "86",
            "00|1(?:[12]\\d|79)\\d\\d00",
            "(?:(?:1[03-689]|2\\d)\\d\\d|6)\\d{8}|1\\d{10}|[126]\\d{6}(?:\\d(?:\\d{2})?)?|86\\d{5,6}|(?:[3-579]\\d|8[0-57-9])\\d{5,9}",
            [
                7,
                8,
                9,
                10,
                11,
                12
            ],
            [
                [
                    "(\\d{2})(\\d{5,6})",
                    "$1 $2",
                    [
                        "(?:10|2[0-57-9])[19]|3(?:[157]|35|49|9[1-68])|4(?:1[124-9]|2[179]|6[47-9]|7|8[23])|5(?:[1357]|2[37]|4[36]|6[1-46]|80)|6(?:3[1-5]|6[0238]|9[12])|7(?:01|[1579]|2[248]|3[014-9]|4[3-6]|6[023689])|8(?:07|1[236-8]|2[5-7]|[37]|8[36-8]|9[1-8])|9(?:0[1-3689]|1[1-79]|3|4[13]|5[1-5]|7[0-79]|9[0-35-9])|(?:4[35]|59|85)[1-9]",
                        "(?:10|2[0-57-9])(?:1[02]|9[56])|8078|(?:3(?:[157]\\d|35|49|9[1-68])|4(?:1[124-9]|2[179]|[35][1-9]|6[47-9]|7\\d|8[23])|5(?:[1357]\\d|2[37]|4[36]|6[1-46]|80|9[1-9])|6(?:3[1-5]|6[0238]|9[12])|7(?:01|[1579]\\d|2[248]|3[014-9]|4[3-6]|6[023689])|8(?:1[236-8]|2[5-7]|[37]\\d|5[1-9]|8[36-8]|9[1-8])|9(?:0[1-3689]|1[1-79]|3\\d|4[13]|5[1-5]|7[0-79]|9[0-35-9]))1",
                        "10(?:1(?:0|23)|9[56])|2[0-57-9](?:1(?:00|23)|9[56])|80781|(?:3(?:[157]\\d|35|49|9[1-68])|4(?:1[124-9]|2[179]|[35][1-9]|6[47-9]|7\\d|8[23])|5(?:[1357]\\d|2[37]|4[36]|6[1-46]|80|9[1-9])|6(?:3[1-5]|6[0238]|9[12])|7(?:01|[1579]\\d|2[248]|3[014-9]|4[3-6]|6[023689])|8(?:1[236-8]|2[5-7]|[37]\\d|5[1-9]|8[36-8]|9[1-8])|9(?:0[1-3689]|1[1-79]|3\\d|4[13]|5[1-5]|7[0-79]|9[0-35-9]))12",
                        "10(?:1(?:0|23)|9[56])|2[0-57-9](?:1(?:00|23)|9[56])|807812|(?:3(?:[157]\\d|35|49|9[1-68])|4(?:1[124-9]|2[179]|[35][1-9]|6[47-9]|7\\d|8[23])|5(?:[1357]\\d|2[37]|4[36]|6[1-46]|80|9[1-9])|6(?:3[1-5]|6[0238]|9[12])|7(?:01|[1579]\\d|2[248]|3[014-9]|4[3-6]|6[023689])|8(?:1[236-8]|2[5-7]|[37]\\d|5[1-9]|8[36-8]|9[1-8])|9(?:0[1-3689]|1[1-79]|3\\d|4[13]|5[1-5]|7[0-79]|9[0-35-9]))123",
                        "10(?:1(?:0|23)|9[56])|2[0-57-9](?:1(?:00|23)|9[56])|(?:3(?:[157]\\d|35|49|9[1-68])|4(?:1[124-9]|2[179]|[35][1-9]|6[47-9]|7\\d|8[23])|5(?:[1357]\\d|2[37]|4[36]|6[1-46]|80|9[1-9])|6(?:3[1-5]|6[0238]|9[12])|7(?:01|[1579]\\d|2[248]|3[014-9]|4[3-6]|6[023689])|8(?:078|1[236-8]|2[5-7]|[37]\\d|5[1-9]|8[36-8]|9[1-8])|9(?:0[1-3689]|1[1-79]|3\\d|4[13]|5[1-5]|7[0-79]|9[0-35-9]))123"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{5,6})",
                    "$1 $2",
                    [
                        "3(?:[157]|35|49|9[1-68])|4(?:[17]|2[179]|6[47-9]|8[23])|5(?:[1357]|2[37]|4[36]|6[1-46]|80)|6(?:3[1-5]|6[0238]|9[12])|7(?:01|[1579]|2[248]|3[014-9]|4[3-6]|6[023689])|8(?:1[236-8]|2[5-7]|[37]|8[36-8]|9[1-8])|9(?:0[1-3689]|1[1-79]|[379]|4[13]|5[1-5])|(?:4[35]|59|85)[1-9]",
                        "(?:3(?:[157]\\d|35|49|9[1-68])|4(?:[17]\\d|2[179]|[35][1-9]|6[47-9]|8[23])|5(?:[1357]\\d|2[37]|4[36]|6[1-46]|80|9[1-9])|6(?:3[1-5]|6[0238]|9[12])|7(?:01|[1579]\\d|2[248]|3[014-9]|4[3-6]|6[023689])|8(?:1[236-8]|2[5-7]|[37]\\d|5[1-9]|8[36-8]|9[1-8])|9(?:0[1-3689]|1[1-79]|[379]\\d|4[13]|5[1-5]))[19]",
                        "85[23](?:10|95)|(?:3(?:[157]\\d|35|49|9[1-68])|4(?:[17]\\d|2[179]|[35][1-9]|6[47-9]|8[23])|5(?:[1357]\\d|2[37]|4[36]|6[1-46]|80|9[1-9])|6(?:3[1-5]|6[0238]|9[12])|7(?:01|[1579]\\d|2[248]|3[014-9]|4[3-6]|6[023689])|8(?:1[236-8]|2[5-7]|[37]\\d|5[14-9]|8[36-8]|9[1-8])|9(?:0[1-3689]|1[1-79]|[379]\\d|4[13]|5[1-5]))(?:10|9[56])",
                        "85[23](?:100|95)|(?:3(?:[157]\\d|35|49|9[1-68])|4(?:[17]\\d|2[179]|[35][1-9]|6[47-9]|8[23])|5(?:[1357]\\d|2[37]|4[36]|6[1-46]|80|9[1-9])|6(?:3[1-5]|6[0238]|9[12])|7(?:01|[1579]\\d|2[248]|3[014-9]|4[3-6]|6[023689])|8(?:1[236-8]|2[5-7]|[37]\\d|5[14-9]|8[36-8]|9[1-8])|9(?:0[1-3689]|1[1-79]|[379]\\d|4[13]|5[1-5]))(?:100|9[56])"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "(?:4|80)0"
                    ]
                ],
                [
                    "(\\d{2})(\\d{4})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "10|2(?:[02-57-9]|1[1-9])",
                        "10|2(?:[02-57-9]|1[1-9])",
                        "10[0-79]|2(?:[02-57-9]|1[1-79])|(?:10|21)8(?:0[1-9]|[1-9])"
                    ],
                    "0$1",
                    1
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "3(?:[3-59]|7[02-68])|4(?:[26-8]|3[3-9]|5[2-9])|5(?:3[03-9]|[468]|7[028]|9[2-46-9])|6|7(?:[0-247]|3[04-9]|5[0-4689]|6[2368])|8(?:[1-358]|9[1-7])|9(?:[013479]|5[1-5])|(?:[34]1|55|79|87)[02-9]"
                    ],
                    "0$1",
                    1
                ],
                [
                    "(\\d{3})(\\d{7,8})",
                    "$1 $2",
                    [
                        "9"
                    ]
                ],
                [
                    "(\\d{4})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "80"
                    ],
                    "0$1",
                    1
                ],
                [
                    "(\\d{3})(\\d{4})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "[3-578]"
                    ],
                    "0$1",
                    1
                ],
                [
                    "(\\d{3})(\\d{4})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "1[3-9]"
                    ]
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{3})(\\d{4})",
                    "$1 $2 $3 $4",
                    [
                        "[12]"
                    ],
                    "0$1",
                    1
                ]
            ],
            "0",
            0,
            "(1(?:[12]\\d|79)\\d\\d)|0",
            0,
            0,
            0,
            0,
            "00"
        ],
        "CO": [
            "57",
            "00(?:4(?:[14]4|56)|[579])",
            "(?:46|60\\d\\d)\\d{6}|(?:1\\d|[39])\\d{9}",
            [
                8,
                10,
                11
            ],
            [
                [
                    "(\\d{4})(\\d{4})",
                    "$1 $2",
                    [
                        "46"
                    ]
                ],
                [
                    "(\\d{3})(\\d{7})",
                    "$1 $2",
                    [
                        "6|90"
                    ],
                    "($1)"
                ],
                [
                    "(\\d{3})(\\d{7})",
                    "$1 $2",
                    [
                        "3[0-357]|9[14]"
                    ]
                ],
                [
                    "(\\d)(\\d{3})(\\d{7})",
                    "$1-$2-$3",
                    [
                        "1"
                    ],
                    "0$1",
                    0,
                    "$1 $2 $3"
                ]
            ],
            "0",
            0,
            "0([3579]|4(?:[14]4|56))?"
        ],
        "CR": [
            "506",
            "00",
            "(?:8\\d|90)\\d{8}|(?:[24-8]\\d{3}|3005)\\d{4}",
            [
                8,
                10
            ],
            [
                [
                    "(\\d{4})(\\d{4})",
                    "$1 $2",
                    [
                        "[2-7]|8[3-9]"
                    ]
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{4})",
                    "$1-$2-$3",
                    [
                        "[89]"
                    ]
                ]
            ],
            0,
            0,
            "(19(?:0[0-2468]|1[09]|20|66|77|99))"
        ],
        "CU": [
            "53",
            "119",
            "(?:[2-7]|8\\d\\d)\\d{7}|[2-47]\\d{6}|[34]\\d{5}",
            [
                6,
                7,
                8,
                10
            ],
            [
                [
                    "(\\d{2})(\\d{4,6})",
                    "$1 $2",
                    [
                        "2[1-4]|[34]"
                    ],
                    "(0$1)"
                ],
                [
                    "(\\d)(\\d{6,7})",
                    "$1 $2",
                    [
                        "7"
                    ],
                    "(0$1)"
                ],
                [
                    "(\\d)(\\d{7})",
                    "$1 $2",
                    [
                        "[56]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{7})",
                    "$1 $2",
                    [
                        "8"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "CV": [
            "238",
            "0",
            "(?:[2-59]\\d\\d|800)\\d{4}",
            [
                7
            ],
            [
                [
                    "(\\d{3})(\\d{2})(\\d{2})",
                    "$1 $2 $3",
                    [
                        "[2-589]"
                    ]
                ]
            ]
        ],
        "CW": [
            "599",
            "00",
            "(?:[34]1|60|(?:7|9\\d)\\d)\\d{5}",
            [
                7,
                8
            ],
            [
                [
                    "(\\d{3})(\\d{4})",
                    "$1 $2",
                    [
                        "[3467]"
                    ]
                ],
                [
                    "(\\d)(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "9[4-8]"
                    ]
                ]
            ],
            0,
            0,
            0,
            0,
            0,
            "[69]"
        ],
        "CX": [
            "61",
            "001[14-689]|14(?:1[14]|34|4[17]|[56]6|7[47]|88)0011",
            "1(?:[0-79]\\d{8}(?:\\d{2})?|8[0-24-9]\\d{7})|[148]\\d{8}|1\\d{5,7}",
            [
                6,
                7,
                8,
                9,
                10,
                12
            ],
            0,
            "0",
            0,
            "([59]\\d{7})$|0",
            "8$1",
            0,
            0,
            [
                [
                    "8(?:51(?:0(?:01|30|59|88)|1(?:17|46|75)|2(?:22|35))|91(?:00[6-9]|1(?:[28]1|49|78)|2(?:09|63)|3(?:12|26|75)|4(?:56|97)|64\\d|7(?:0[01]|1[0-2])|958))\\d{3}",
                    [
                        9
                    ]
                ],
                [
                    "4(?:79[01]|83[0-36-9]|95[0-3])\\d{5}|4(?:[0-36]\\d|4[047-9]|[58][0-24-9]|7[02-8]|9[0-47-9])\\d{6}",
                    [
                        9
                    ]
                ],
                [
                    "180(?:0\\d{3}|2)\\d{3}",
                    [
                        7,
                        10
                    ]
                ],
                [
                    "190[0-26]\\d{6}",
                    [
                        10
                    ]
                ],
                0,
                0,
                0,
                0,
                [
                    "14(?:5(?:1[0458]|[23][458])|71\\d)\\d{4}",
                    [
                        9
                    ]
                ],
                [
                    "13(?:00\\d{6}(?:\\d{2})?|45[0-4]\\d{3})|13\\d{4}",
                    [
                        6,
                        8,
                        10,
                        12
                    ]
                ]
            ],
            "0011"
        ],
        "CY": [
            "357",
            "00",
            "(?:[279]\\d|[58]0)\\d{6}",
            [
                8
            ],
            [
                [
                    "(\\d{2})(\\d{6})",
                    "$1 $2",
                    [
                        "[257-9]"
                    ]
                ]
            ]
        ],
        "CZ": [
            "420",
            "00",
            "(?:[2-578]\\d|60)\\d{7}|9\\d{8,11}",
            [
                9,
                10,
                11,
                12
            ],
            [
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "[2-8]|9[015-7]"
                    ]
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{3})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "96"
                    ]
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3 $4",
                    [
                        "9"
                    ]
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3 $4",
                    [
                        "9"
                    ]
                ]
            ]
        ],
        "DE": [
            "49",
            "00",
            "[2579]\\d{5,14}|49(?:[34]0|69|8\\d)\\d\\d?|49(?:37|49|60|7[089]|9\\d)\\d{1,3}|49(?:2[024-9]|3[2-689]|7[1-7])\\d{1,8}|(?:1|[368]\\d|4[0-8])\\d{3,13}|49(?:[015]\\d|2[13]|31|[46][1-8])\\d{1,9}",
            [
                4,
                5,
                6,
                7,
                8,
                9,
                10,
                11,
                12,
                13,
                14,
                15
            ],
            [
                [
                    "(\\d{2})(\\d{3,13})",
                    "$1 $2",
                    [
                        "3[02]|40|[68]9"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3,12})",
                    "$1 $2",
                    [
                        "2(?:0[1-389]|1[124]|2[18]|3[14])|3(?:[35-9][15]|4[015])|906|(?:2[4-9]|4[2-9]|[579][1-9]|[68][1-8])1",
                        "2(?:0[1-389]|12[0-8])|3(?:[35-9][15]|4[015])|906|2(?:[13][14]|2[18])|(?:2[4-9]|4[2-9]|[579][1-9]|[68][1-8])1"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{4})(\\d{2,11})",
                    "$1 $2",
                    [
                        "[24-6]|3(?:[3569][02-46-9]|4[2-4679]|7[2-467]|8[2-46-8])|70[2-8]|8(?:0[2-9]|[1-8])|90[7-9]|[79][1-9]",
                        "[24-6]|3(?:3(?:0[1-467]|2[127-9]|3[124578]|7[1257-9]|8[1256]|9[145])|4(?:2[135]|4[13578]|9[1346])|5(?:0[14]|2[1-3589]|6[1-4]|7[13468]|8[13568])|6(?:2[1-489]|3[124-6]|6[13]|7[12579]|8[1-356]|9[135])|7(?:2[1-7]|4[145]|6[1-5]|7[1-4])|8(?:21|3[1468]|6|7[1467]|8[136])|9(?:0[12479]|2[1358]|4[134679]|6[1-9]|7[136]|8[147]|9[1468]))|70[2-8]|8(?:0[2-9]|[1-8])|90[7-9]|[79][1-9]|3[68]4[1347]|3(?:47|60)[1356]|3(?:3[46]|46|5[49])[1246]|3[4579]3[1357]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{4})",
                    "$1 $2",
                    [
                        "138"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{5})(\\d{2,10})",
                    "$1 $2",
                    [
                        "3"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{5,11})",
                    "$1 $2",
                    [
                        "181"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d)(\\d{4,10})",
                    "$1 $2 $3",
                    [
                        "1(?:3|80)|9"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{7,8})",
                    "$1 $2",
                    [
                        "1[67]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{7,12})",
                    "$1 $2",
                    [
                        "8"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{5})(\\d{6})",
                    "$1 $2",
                    [
                        "185",
                        "1850",
                        "18500"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{4})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "7"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{4})(\\d{7})",
                    "$1 $2",
                    [
                        "18[68]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{4})(\\d{7})",
                    "$1 $2",
                    [
                        "15[1279]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{5})(\\d{6})",
                    "$1 $2",
                    [
                        "15[03568]",
                        "15(?:[0568]|3[13])"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{8})",
                    "$1 $2",
                    [
                        "18"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{2})(\\d{7,8})",
                    "$1 $2 $3",
                    [
                        "1(?:6[023]|7)"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{4})(\\d{2})(\\d{7})",
                    "$1 $2 $3",
                    [
                        "15[279]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{2})(\\d{8})",
                    "$1 $2 $3",
                    [
                        "15"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "DJ": [
            "253",
            "00",
            "(?:2\\d|77)\\d{6}",
            [
                8
            ],
            [
                [
                    "(\\d{2})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "[27]"
                    ]
                ]
            ]
        ],
        "DK": [
            "45",
            "00",
            "[2-9]\\d{7}",
            [
                8
            ],
            [
                [
                    "(\\d{2})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "[2-9]"
                    ]
                ]
            ]
        ],
        "DM": [
            "1",
            "011",
            "(?:[58]\\d\\d|767|900)\\d{7}",
            [
                10
            ],
            0,
            "1",
            0,
            "([2-7]\\d{6})$|1",
            "767$1",
            0,
            "767"
        ],
        "DO": [
            "1",
            "011",
            "(?:[58]\\d\\d|900)\\d{7}",
            [
                10
            ],
            0,
            "1",
            0,
            0,
            0,
            0,
            "8001|8[024]9"
        ],
        "DZ": [
            "213",
            "00",
            "(?:[1-4]|[5-79]\\d|80)\\d{7}",
            [
                8,
                9
            ],
            [
                [
                    "(\\d{2})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "[1-4]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "9"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "[5-8]"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "EC": [
            "593",
            "00",
            "1\\d{9,10}|(?:[2-7]|9\\d)\\d{7}",
            [
                8,
                9,
                10,
                11
            ],
            [
                [
                    "(\\d)(\\d{3})(\\d{4})",
                    "$1 $2-$3",
                    [
                        "[2-7]"
                    ],
                    "(0$1)",
                    0,
                    "$1-$2-$3"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "9"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{4})(\\d{3})(\\d{3,4})",
                    "$1 $2 $3",
                    [
                        "1"
                    ]
                ]
            ],
            "0"
        ],
        "EE": [
            "372",
            "00",
            "8\\d{9}|[4578]\\d{7}|(?:[3-8]\\d|90)\\d{5}",
            [
                7,
                8,
                10
            ],
            [
                [
                    "(\\d{3})(\\d{4})",
                    "$1 $2",
                    [
                        "[369]|4[3-8]|5(?:[0-2]|5[0-478]|6[45])|7[1-9]|88",
                        "[369]|4[3-8]|5(?:[02]|1(?:[0-8]|95)|5[0-478]|6(?:4[0-4]|5[1-589]))|7[1-9]|88"
                    ]
                ],
                [
                    "(\\d{4})(\\d{3,4})",
                    "$1 $2",
                    [
                        "[45]|8(?:00|[1-49])",
                        "[45]|8(?:00[1-9]|[1-49])"
                    ]
                ],
                [
                    "(\\d{2})(\\d{2})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "7"
                    ]
                ],
                [
                    "(\\d{4})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "8"
                    ]
                ]
            ]
        ],
        "EG": [
            "20",
            "00",
            "[189]\\d{8,9}|[24-6]\\d{8}|[135]\\d{7}",
            [
                8,
                9,
                10
            ],
            [
                [
                    "(\\d)(\\d{7,8})",
                    "$1 $2",
                    [
                        "[23]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{6,7})",
                    "$1 $2",
                    [
                        "1[35]|[4-6]|8[2468]|9[235-7]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "[89]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{8})",
                    "$1 $2",
                    [
                        "1"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "EH": [
            "212",
            "00",
            "[5-8]\\d{8}",
            [
                9
            ],
            0,
            "0",
            0,
            0,
            0,
            0,
            0,
            [
                [
                    "528[89]\\d{5}"
                ],
                [
                    "(?:6(?:[0-79]\\d|8[0-247-9])|7(?:[016-8]\\d|2[0-8]|5[0-5]))\\d{6}"
                ],
                [
                    "80[0-7]\\d{6}"
                ],
                [
                    "89\\d{7}"
                ],
                0,
                0,
                0,
                0,
                [
                    "(?:592(?:4[0-2]|93)|80[89]\\d\\d)\\d{4}"
                ]
            ]
        ],
        "ER": [
            "291",
            "00",
            "[178]\\d{6}",
            [
                7
            ],
            [
                [
                    "(\\d)(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "[178]"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "ES": [
            "34",
            "00",
            "[5-9]\\d{8}",
            [
                9
            ],
            [
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "[89]00"
                    ]
                ],
                [
                    "(\\d{3})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "[5-9]"
                    ]
                ]
            ]
        ],
        "ET": [
            "251",
            "00",
            "(?:11|[2-579]\\d)\\d{7}",
            [
                9
            ],
            [
                [
                    "(\\d{2})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "[1-579]"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "FI": [
            "358",
            "00|99(?:[01469]|5(?:[14]1|3[23]|5[59]|77|88|9[09]))",
            "[1-35689]\\d{4}|7\\d{10,11}|(?:[124-7]\\d|3[0-46-9])\\d{8}|[1-9]\\d{5,8}",
            [
                5,
                6,
                7,
                8,
                9,
                10,
                11,
                12
            ],
            [
                [
                    "(\\d{5})",
                    "$1",
                    [
                        "20[2-59]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3,7})",
                    "$1 $2",
                    [
                        "(?:[1-3]0|[68])0|70[07-9]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{4,8})",
                    "$1 $2",
                    [
                        "[14]|2[09]|50|7[135]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{6,10})",
                    "$1 $2",
                    [
                        "7"
                    ],
                    "0$1"
                ],
                [
                    "(\\d)(\\d{4,9})",
                    "$1 $2",
                    [
                        "(?:19|[2568])[1-8]|3(?:0[1-9]|[1-9])|9"
                    ],
                    "0$1"
                ]
            ],
            "0",
            0,
            0,
            0,
            0,
            "1[03-79]|[2-9]",
            0,
            "00"
        ],
        "FJ": [
            "679",
            "0(?:0|52)",
            "45\\d{5}|(?:0800\\d|[235-9])\\d{6}",
            [
                7,
                11
            ],
            [
                [
                    "(\\d{3})(\\d{4})",
                    "$1 $2",
                    [
                        "[235-9]|45"
                    ]
                ],
                [
                    "(\\d{4})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "0"
                    ]
                ]
            ],
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            "00"
        ],
        "FK": [
            "500",
            "00",
            "[2-7]\\d{4}",
            [
                5
            ]
        ],
        "FM": [
            "691",
            "00",
            "(?:[39]\\d\\d|820)\\d{4}",
            [
                7
            ],
            [
                [
                    "(\\d{3})(\\d{4})",
                    "$1 $2",
                    [
                        "[389]"
                    ]
                ]
            ]
        ],
        "FO": [
            "298",
            "00",
            "[2-9]\\d{5}",
            [
                6
            ],
            [
                [
                    "(\\d{6})",
                    "$1",
                    [
                        "[2-9]"
                    ]
                ]
            ],
            0,
            0,
            "(10(?:01|[12]0|88))"
        ],
        "FR": [
            "33",
            "00",
            "[1-9]\\d{8}",
            [
                9
            ],
            [
                [
                    "(\\d{3})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "8"
                    ],
                    "0 $1"
                ],
                [
                    "(\\d)(\\d{2})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4 $5",
                    [
                        "[1-79]"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "GA": [
            "241",
            "00",
            "(?:[067]\\d|11)\\d{6}|[2-7]\\d{6}",
            [
                7,
                8
            ],
            [
                [
                    "(\\d)(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "[2-7]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "0"
                    ]
                ],
                [
                    "(\\d{2})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "11|[67]"
                    ],
                    "0$1"
                ]
            ],
            0,
            0,
            "0(11\\d{6}|60\\d{6}|61\\d{6}|6[256]\\d{6}|7[467]\\d{6})",
            "$1"
        ],
        "GB": [
            "44",
            "00",
            "[1-357-9]\\d{9}|[18]\\d{8}|8\\d{6}",
            [
                7,
                9,
                10
            ],
            [
                [
                    "(\\d{3})(\\d{4})",
                    "$1 $2",
                    [
                        "800",
                        "8001",
                        "80011",
                        "800111",
                        "8001111"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{2})(\\d{2})",
                    "$1 $2 $3",
                    [
                        "845",
                        "8454",
                        "84546",
                        "845464"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{6})",
                    "$1 $2",
                    [
                        "800"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{5})(\\d{4,5})",
                    "$1 $2",
                    [
                        "1(?:38|5[23]|69|76|94)",
                        "1(?:(?:38|69)7|5(?:24|39)|768|946)",
                        "1(?:3873|5(?:242|39[4-6])|(?:697|768)[347]|9467)"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{4})(\\d{5,6})",
                    "$1 $2",
                    [
                        "1(?:[2-69][02-9]|[78])"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{4})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "[25]|7(?:0|6[02-9])",
                        "[25]|7(?:0|6(?:[03-9]|2[356]))"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{4})(\\d{6})",
                    "$1 $2",
                    [
                        "7"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "[1389]"
                    ],
                    "0$1"
                ]
            ],
            "0",
            0,
            "0|180020",
            0,
            0,
            0,
            [
                [
                    "(?:1(?:1(?:3(?:[0-58]\\d\\d|73[0-5])|4(?:(?:[0-5]\\d|70)\\d|69[7-9])|(?:(?:5[0-26-9]|[78][0-49])\\d|6(?:[0-4]\\d|5[01]))\\d)|(?:2(?:(?:0[024-9]|2[3-9]|3[3-79]|4[1-689]|[58][02-9]|6[0-47-9]|7[013-9]|9\\d)\\d|1(?:[0-7]\\d|8[0-3]))|(?:3(?:0\\d|1[0-8]|[25][02-9]|3[02-579]|[468][0-46-9]|7[1-35-79]|9[2-578])|4(?:0[03-9]|[137]\\d|[28][02-57-9]|4[02-69]|5[0-8]|[69][0-79])|5(?:0[1-35-9]|[16]\\d|2[024-9]|3[015689]|4[02-9]|5[03-9]|7[0-35-9]|8[0-468]|9[0-57-9])|6(?:0[034689]|1\\d|2[0-35689]|[38][013-9]|4[1-467]|5[0-69]|6[13-9]|7[0-8]|9[0-24578])|7(?:0[0246-9]|2\\d|3[0236-8]|4[03-9]|5[0-46-9]|6[013-9]|7[0-35-9]|8[024-9]|9[02-9])|8(?:0[35-9]|2[1-57-9]|3[02-578]|4[0-578]|5[124-9]|6[2-69]|7\\d|8[02-9]|9[02569])|9(?:0[02-589]|[18]\\d|2[02-689]|3[1-57-9]|4[2-9]|5[0-579]|6[2-47-9]|7[0-24578]|9[2-57]))\\d)\\d)|2(?:0[013478]|3[0189]|4[017]|8[0-46-9]|9[0-2])\\d{3})\\d{4}|1(?:2(?:0(?:46[1-4]|87[2-9])|545[1-79]|76(?:2\\d|3[1-8]|6[1-6])|9(?:7(?:2[0-4]|3[2-5])|8(?:2[2-8]|7[0-47-9]|8[3-5])))|3(?:6(?:38[2-5]|47[23])|8(?:47[04-9]|64[0157-9]))|4(?:044[1-7]|20(?:2[23]|8\\d)|6(?:0(?:30|5[2-57]|6[1-8]|7[2-8])|140)|8(?:052|87[1-3]))|5(?:2(?:4(?:3[2-79]|6\\d)|76\\d)|6(?:26[06-9]|686))|6(?:06(?:4\\d|7[4-79])|295[5-7]|35[34]\\d|47(?:24|61)|59(?:5[08]|6[67]|74)|9(?:55[0-4]|77[23]))|7(?:26(?:6[13-9]|7[0-7])|(?:442|688)\\d|50(?:2[0-3]|[3-68]2|76))|8(?:27[56]\\d|37(?:5[2-5]|8[239])|843[2-58])|9(?:0(?:0(?:6[1-8]|85)|52\\d)|3583|4(?:66[1-8]|9(?:2[01]|81))|63(?:23|3[1-4])|9561))\\d{3}",
                    [
                        9,
                        10
                    ]
                ],
                [
                    "7(?:457[0-57-9]|700[01]|911[028])\\d{5}|7(?:[1-3]\\d\\d|4(?:[0-46-9]\\d|5[0-689])|5(?:0[0-8]|[13-9]\\d|2[0-35-9])|7(?:0[1-9]|[1-7]\\d|8[02-9]|9[0-689])|8(?:[014-9]\\d|[23][0-8])|9(?:[024-9]\\d|1[02-9]|3[0-689]))\\d{6}",
                    [
                        10
                    ]
                ],
                [
                    "80[08]\\d{7}|800\\d{6}|8001111"
                ],
                [
                    "(?:8(?:4[2-5]|7[0-3])|9(?:[01]\\d|8[2-49]))\\d{7}|845464\\d",
                    [
                        7,
                        10
                    ]
                ],
                [
                    "70\\d{8}",
                    [
                        10
                    ]
                ],
                0,
                [
                    "(?:3[0347]|55)\\d{8}",
                    [
                        10
                    ]
                ],
                [
                    "76(?:464|652)\\d{5}|76(?:0[0-28]|2[356]|34|4[01347]|5[49]|6[0-369]|77|8[14]|9[139])\\d{6}",
                    [
                        10
                    ]
                ],
                [
                    "56\\d{8}",
                    [
                        10
                    ]
                ]
            ],
            0,
            " x"
        ],
        "GD": [
            "1",
            "011",
            "(?:473|[58]\\d\\d|900)\\d{7}",
            [
                10
            ],
            0,
            "1",
            0,
            "([2-9]\\d{6})$|1",
            "473$1",
            0,
            "473"
        ],
        "GE": [
            "995",
            "00",
            "(?:[3-57]\\d\\d|800)\\d{6}",
            [
                9
            ],
            [
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "70"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "32"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "[57]"
                    ]
                ],
                [
                    "(\\d{3})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "[348]"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "GF": [
            "594",
            "00",
            "(?:694\\d|7093)\\d{5}|(?:59|[89]\\d)\\d{7}",
            [
                9
            ],
            [
                [
                    "(\\d{3})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "[5-7]|80[6-9]|9[47]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "[89]"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "GG": [
            "44",
            "00",
            "(?:1481|[357-9]\\d{3})\\d{6}|8\\d{6}(?:\\d{2})?",
            [
                7,
                9,
                10
            ],
            0,
            "0",
            0,
            "([25-9]\\d{5})$|0|180020",
            "1481$1",
            0,
            0,
            [
                [
                    "1481[25-9]\\d{5}",
                    [
                        10
                    ]
                ],
                [
                    "7(?:(?:781|839)\\d|911[17])\\d{5}",
                    [
                        10
                    ]
                ],
                [
                    "80[08]\\d{7}|800\\d{6}|8001111"
                ],
                [
                    "(?:8(?:4[2-5]|7[0-3])|9(?:[01]\\d|8[0-3]))\\d{7}|845464\\d",
                    [
                        7,
                        10
                    ]
                ],
                [
                    "70\\d{8}",
                    [
                        10
                    ]
                ],
                0,
                [
                    "(?:3[0347]|55)\\d{8}",
                    [
                        10
                    ]
                ],
                [
                    "76(?:464|652)\\d{5}|76(?:0[0-28]|2[356]|34|4[01347]|5[49]|6[0-369]|77|8[14]|9[139])\\d{6}",
                    [
                        10
                    ]
                ],
                [
                    "56\\d{8}",
                    [
                        10
                    ]
                ]
            ]
        ],
        "GH": [
            "233",
            "00",
            "[235]\\d{8}|800\\d{5,6}",
            [
                8,
                9
            ],
            [
                [
                    "(\\d{3})(\\d{5})",
                    "$1 $2",
                    [
                        "8"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "[2358]"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "GI": [
            "350",
            "00",
            "(?:[25]\\d|60)\\d{6}",
            [
                8
            ],
            [
                [
                    "(\\d{3})(\\d{5})",
                    "$1 $2",
                    [
                        "2"
                    ]
                ]
            ]
        ],
        "GL": [
            "299",
            "00",
            "(?:19|[2-689]\\d|70)\\d{4}",
            [
                6
            ],
            [
                [
                    "(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3",
                    [
                        "19|[2-9]"
                    ]
                ]
            ]
        ],
        "GM": [
            "220",
            "00",
            "[2-9]\\d{6}",
            [
                7
            ],
            [
                [
                    "(\\d{3})(\\d{4})",
                    "$1 $2",
                    [
                        "[2-9]"
                    ]
                ]
            ]
        ],
        "GN": [
            "224",
            "00",
            "722\\d{6}|(?:3|6\\d)\\d{7}",
            [
                8,
                9
            ],
            [
                [
                    "(\\d{2})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "3"
                    ]
                ],
                [
                    "(\\d{3})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "[67]"
                    ]
                ]
            ]
        ],
        "GP": [
            "590",
            "00",
            "7090\\d{5}|(?:[56]9|[89]\\d)\\d{7}",
            [
                9
            ],
            [
                [
                    "(\\d{3})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "[5-79]|80[6-9]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "8"
                    ],
                    "0$1"
                ]
            ],
            "0",
            0,
            0,
            0,
            0,
            0,
            [
                [
                    "(?:59(?:0(?:0[1-68]|[14][0-24-9]|2[0-68]|3[1-9]|5[3-579]|[68][0-689]|7[08]|9\\d)|87\\d)|80[6-9]\\d\\d)\\d{4}"
                ],
                [
                    "(?:69(?:0\\d\\d|1(?:2[2-9]|3[0-5]))|7090[0-4])\\d{4}"
                ],
                [
                    "80[0-5]\\d{6}"
                ],
                [
                    "8[129]\\d{7}"
                ],
                0,
                0,
                0,
                0,
                [
                    "9(?:(?:39[5-7]|76[018])\\d|475[0-6])\\d{4}"
                ]
            ]
        ],
        "GQ": [
            "240",
            "00",
            "222\\d{6}|(?:3\\d|55|[89]0)\\d{7}",
            [
                9
            ],
            [
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "[235]"
                    ]
                ],
                [
                    "(\\d{3})(\\d{6})",
                    "$1 $2",
                    [
                        "[89]"
                    ]
                ]
            ]
        ],
        "GR": [
            "30",
            "00",
            "5005000\\d{3}|8\\d{9,11}|(?:[269]\\d|70)\\d{8}",
            [
                10,
                11,
                12
            ],
            [
                [
                    "(\\d{2})(\\d{4})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "21|7"
                    ]
                ],
                [
                    "(\\d{4})(\\d{6})",
                    "$1 $2",
                    [
                        "2(?:2|3[2-57-9]|4[2-469]|5[2-59]|6[2-9]|7[2-69]|8[2-49])|5"
                    ]
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "[2689]"
                    ]
                ],
                [
                    "(\\d{3})(\\d{3,4})(\\d{5})",
                    "$1 $2 $3",
                    [
                        "8"
                    ]
                ]
            ]
        ],
        "GT": [
            "502",
            "00",
            "80\\d{6}|(?:1\\d{3}|[2-7])\\d{7}",
            [
                8,
                11
            ],
            [
                [
                    "(\\d{4})(\\d{4})",
                    "$1 $2",
                    [
                        "[2-8]"
                    ]
                ],
                [
                    "(\\d{4})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "1"
                    ]
                ]
            ]
        ],
        "GU": [
            "1",
            "011",
            "(?:[58]\\d\\d|671|900)\\d{7}",
            [
                10
            ],
            0,
            "1",
            0,
            "([2-9]\\d{6})$|1",
            "671$1",
            0,
            "671"
        ],
        "GW": [
            "245",
            "00",
            "[49]\\d{8}|4\\d{6}",
            [
                7,
                9
            ],
            [
                [
                    "(\\d{3})(\\d{4})",
                    "$1 $2",
                    [
                        "40"
                    ]
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "[49]"
                    ]
                ]
            ]
        ],
        "GY": [
            "592",
            "001",
            "(?:[2-8]\\d{3}|9008)\\d{3}",
            [
                7
            ],
            [
                [
                    "(\\d{3})(\\d{4})",
                    "$1 $2",
                    [
                        "[2-9]"
                    ]
                ]
            ]
        ],
        "HK": [
            "852",
            "00(?:30|5[09]|[126-9]?)",
            "8[0-46-9]\\d{6,7}|9\\d{4,7}|(?:[2-7]|9\\d{3})\\d{7}",
            [
                5,
                6,
                7,
                8,
                9,
                11
            ],
            [
                [
                    "(\\d{3})(\\d{2,5})",
                    "$1 $2",
                    [
                        "900",
                        "9003"
                    ]
                ],
                [
                    "(\\d{4})(\\d{4})",
                    "$1 $2",
                    [
                        "[2-7]|8[1-4]|9(?:0[1-9]|[1-8])"
                    ]
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "8"
                    ]
                ],
                [
                    "(\\d{3})(\\d{2})(\\d{3})(\\d{3})",
                    "$1 $2 $3 $4",
                    [
                        "9"
                    ]
                ]
            ],
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            "00"
        ],
        "HN": [
            "504",
            "00",
            "8\\d{10}|[237-9]\\d{7}",
            [
                8,
                11
            ],
            [
                [
                    "(\\d{4})(\\d{4})",
                    "$1-$2",
                    [
                        "[237-9]"
                    ]
                ]
            ]
        ],
        "HR": [
            "385",
            "00",
            "[2-69]\\d{8}|80\\d{5,7}|[1-79]\\d{7}|6\\d{6}",
            [
                7,
                8,
                9
            ],
            [
                [
                    "(\\d{2})(\\d{2})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "6[01]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{2})(\\d{2,3})",
                    "$1 $2 $3",
                    [
                        "8"
                    ],
                    "0$1"
                ],
                [
                    "(\\d)(\\d{4})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "1"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{3,4})",
                    "$1 $2 $3",
                    [
                        "6|7[245]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{3,4})",
                    "$1 $2 $3",
                    [
                        "9"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{3,4})",
                    "$1 $2 $3",
                    [
                        "[2-57]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "8"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "HT": [
            "509",
            "00",
            "[2-589]\\d{7}",
            [
                8
            ],
            [
                [
                    "(\\d{2})(\\d{2})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "[2-589]"
                    ]
                ]
            ]
        ],
        "HU": [
            "36",
            "00",
            "[235-7]\\d{8}|[1-9]\\d{7}",
            [
                8,
                9
            ],
            [
                [
                    "(\\d)(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "1"
                    ],
                    "(06 $1)"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "[27][2-9]|3[2-7]|4[24-9]|5[2-79]|6|8[2-57-9]|9[2-69]"
                    ],
                    "(06 $1)"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{3,4})",
                    "$1 $2 $3",
                    [
                        "[2-9]"
                    ],
                    "06 $1"
                ]
            ],
            "06"
        ],
        "ID": [
            "62",
            "00[89]",
            "00[1-9]\\d{9,14}|(?:[1-36]|8\\d{5})\\d{6}|00\\d{9}|[1-9]\\d{8,10}|[2-9]\\d{7}",
            [
                7,
                8,
                9,
                10,
                11,
                12,
                13,
                14,
                15,
                16,
                17
            ],
            [
                [
                    "(\\d)(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "15"
                    ]
                ],
                [
                    "(\\d{2})(\\d{5,9})",
                    "$1 $2",
                    [
                        "2[124]|[36]1"
                    ],
                    "(0$1)"
                ],
                [
                    "(\\d{3})(\\d{5,7})",
                    "$1 $2",
                    [
                        "800"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{5,8})",
                    "$1 $2",
                    [
                        "[2-79]"
                    ],
                    "(0$1)"
                ],
                [
                    "(\\d{3})(\\d{3,4})(\\d{3})",
                    "$1-$2-$3",
                    [
                        "8[1-35-9]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{6,8})",
                    "$1 $2",
                    [
                        "1"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "804"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d)(\\d{3})(\\d{3})",
                    "$1 $2 $3 $4",
                    [
                        "80"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{4})(\\d{4,5})",
                    "$1-$2-$3",
                    [
                        "8"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "IE": [
            "353",
            "00",
            "(?:1\\d|[2569])\\d{6,8}|4\\d{6,9}|7\\d{8}|8\\d{8,9}",
            [
                7,
                8,
                9,
                10
            ],
            [
                [
                    "(\\d{2})(\\d{5})",
                    "$1 $2",
                    [
                        "2[24-9]|47|58|6[237-9]|9[35-9]"
                    ],
                    "(0$1)"
                ],
                [
                    "(\\d{3})(\\d{5})",
                    "$1 $2",
                    [
                        "[45]0"
                    ],
                    "(0$1)"
                ],
                [
                    "(\\d)(\\d{3,4})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "1"
                    ],
                    "(0$1)"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{3,4})",
                    "$1 $2 $3",
                    [
                        "[2569]|4[1-69]|7[14]"
                    ],
                    "(0$1)"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "70"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "81"
                    ],
                    "(0$1)"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "[78]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{4})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "1"
                    ]
                ],
                [
                    "(\\d{2})(\\d{4})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "4"
                    ],
                    "(0$1)"
                ],
                [
                    "(\\d{2})(\\d)(\\d{3})(\\d{4})",
                    "$1 $2 $3 $4",
                    [
                        "8"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "IL": [
            "972",
            "0(?:0|1[2-9])",
            "1\\d{6}(?:\\d{3,5})?|[57]\\d{8}|[1-489]\\d{7}",
            [
                7,
                8,
                9,
                10,
                11,
                12
            ],
            [
                [
                    "(\\d{4})(\\d{3})",
                    "$1-$2",
                    [
                        "125"
                    ]
                ],
                [
                    "(\\d{4})(\\d{2})(\\d{2})",
                    "$1-$2-$3",
                    [
                        "121"
                    ]
                ],
                [
                    "(\\d)(\\d{3})(\\d{4})",
                    "$1-$2-$3",
                    [
                        "[2-489]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{4})",
                    "$1-$2-$3",
                    [
                        "[57]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{4})(\\d{3})(\\d{3})",
                    "$1-$2-$3",
                    [
                        "12"
                    ]
                ],
                [
                    "(\\d{4})(\\d{6})",
                    "$1-$2",
                    [
                        "159"
                    ]
                ],
                [
                    "(\\d)(\\d{3})(\\d{3})(\\d{3})",
                    "$1-$2-$3-$4",
                    [
                        "1[7-9]"
                    ]
                ],
                [
                    "(\\d{3})(\\d{1,2})(\\d{3})(\\d{4})",
                    "$1-$2 $3-$4",
                    [
                        "15"
                    ]
                ]
            ],
            "0"
        ],
        "IM": [
            "44",
            "00",
            "1624\\d{6}|(?:[3578]\\d|90)\\d{8}",
            [
                10
            ],
            0,
            "0",
            0,
            "([25-8]\\d{5})$|0|180020",
            "1624$1",
            0,
            "74576|(?:16|7[56])24"
        ],
        "IN": [
            "91",
            "00",
            "(?:000800|[2-9]\\d\\d)\\d{7}|1\\d{7,12}",
            [
                8,
                9,
                10,
                11,
                12,
                13
            ],
            [
                [
                    "(\\d{8})",
                    "$1",
                    [
                        "5(?:0|2[23]|3[03]|[67]1|88)",
                        "5(?:0|2(?:21|3)|3(?:0|3[23])|616|717|888)",
                        "5(?:0|2(?:21|3)|3(?:0|3[23])|616|717|8888)"
                    ],
                    0,
                    1
                ],
                [
                    "(\\d{4})(\\d{4,5})",
                    "$1 $2",
                    [
                        "180",
                        "1800"
                    ],
                    0,
                    1
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "140"
                    ],
                    0,
                    1
                ],
                [
                    "(\\d{2})(\\d{4})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "11|2[02]|33|4[04]|79[1-7]|80[2-46]",
                        "11|2[02]|33|4[04]|79(?:[1-6]|7[19])|80(?:[2-4]|6[0-589])",
                        "11|2[02]|33|4[04]|79(?:[124-6]|3(?:[02-9]|1[0-24-9])|7(?:1|9[1-6]))|80(?:[2-4]|6[0-589])"
                    ],
                    "0$1",
                    1
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "1(?:2[0-249]|3[0-25]|4[145]|[68]|7[1257])|2(?:1[257]|3[013]|4[01]|5[0137]|6[0158]|78|8[1568])|3(?:26|4[1-3]|5[34]|6[01489]|7[02-46]|8[159])|4(?:1[36]|2[1-47]|5[12]|6[0-26-9]|7[0-24-9]|8[013-57]|9[014-7])|5(?:1[025]|22|[36][25]|4[28]|5[12]|[78]1)|6(?:12|[2-4]1|5[17]|6[13]|80)|7(?:12|3[134]|4[47]|61|88)|8(?:16|2[014]|3[126]|6[136]|7[078]|8[34]|91)|(?:43|59|75)[15]|(?:1[59]|29|67|72)[14]",
                        "1(?:2[0-24]|3[0-25]|4[145]|[59][14]|6[1-9]|7[1257]|8[1-57-9])|2(?:1[257]|3[013]|4[01]|5[0137]|6[058]|78|8[1568]|9[14])|3(?:26|4[1-3]|5[34]|6[01489]|7[02-46]|8[159])|4(?:1[36]|2[1-47]|3[15]|5[12]|6[0-26-9]|7[0-24-9]|8[013-57]|9[014-7])|5(?:1[025]|22|[36][25]|4[28]|[578]1|9[15])|674|7(?:(?:2[14]|3[34]|5[15])[2-6]|61[346]|88[0-8])|8(?:70[2-6]|84[235-7]|91[3-7])|(?:1(?:29|60|8[06])|261|552|6(?:12|[2-47]1|5[17]|6[13]|80)|7(?:12|31|4[47])|8(?:16|2[014]|3[126]|6[136]|7[78]|83))[2-7]",
                        "1(?:2[0-24]|3[0-25]|4[145]|[59][14]|6[1-9]|7[1257]|8[1-57-9])|2(?:1[257]|3[013]|4[01]|5[0137]|6[058]|78|8[1568]|9[14])|3(?:26|4[1-3]|5[34]|6[01489]|7[02-46]|8[159])|4(?:1[36]|2[1-47]|3[15]|5[12]|6[0-26-9]|7[0-24-9]|8[013-57]|9[014-7])|5(?:1[025]|22|[36][25]|4[28]|[578]1|9[15])|6(?:12(?:[2-6]|7[0-8])|74[2-7])|7(?:(?:2[14]|5[15])[2-6]|3171|61[346]|88(?:[2-7]|82))|8(?:70[2-6]|84(?:[2356]|7[19])|91(?:[3-6]|7[19]))|73[134][2-6]|(?:74[47]|8(?:16|2[014]|3[126]|6[136]|7[78]|83))(?:[2-6]|7[19])|(?:1(?:29|60|8[06])|261|552|6(?:[2-4]1|5[17]|6[13]|7(?:1|4[0189])|80)|7(?:12|88[01]))[2-7]"
                    ],
                    "0$1",
                    1
                ],
                [
                    "(\\d{4})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "1(?:[2-479]|5[0235-9])|[2-5]|6(?:1[1358]|2[2457-9]|3[2-5]|4[235-7]|5[2-689]|6[24578]|7[235689]|8[1-6])|7(?:1[013-9]|28|3[129]|4[1-35689]|5[29]|6[02-5]|70)|807",
                        "1(?:[2-479]|5[0235-9])|[2-5]|6(?:1[1358]|2(?:[2457]|84|95)|3(?:[2-4]|55)|4[235-7]|5[2-689]|6[24578]|7[235689]|8[1-6])|7(?:1(?:[013-8]|9[6-9])|28[6-8]|3(?:17|2[0-49]|9[2-57])|4(?:1[2-4]|[29][0-7]|3[0-8]|[56]|8[0-24-7])|5(?:2[1-3]|9[0-6])|6(?:0[5689]|2[5-9]|3[02-8]|4|5[0-367])|70[13-7])|807[19]",
                        "1(?:[2-479]|5(?:[0236-9]|5[013-9]))|[2-5]|6(?:2(?:84|95)|355|8(?:28[235-7]|3))|73179|807(?:1|9[1-3])|(?:1552|6(?:(?:1[1358]|2[2457]|3[2-4]|4[235-7]|5[2-689]|6[24578]|7[235689])\\d|8(?:[14-6]\\d|2[0-79]))|7(?:1(?:[013-8]\\d|9[6-9])|28[6-8]|3(?:2[0-49]|9[2-57])|4(?:1[2-4]|[29][0-7]|3[0-8]|[56]\\d|8[0-24-7])|5(?:2[1-3]|9[0-6])|6(?:0[5689]|2[5-9]|3[02-8]|4\\d|5[0-367])|70[13-7]))[2-7]"
                    ],
                    "0$1",
                    1
                ],
                [
                    "(\\d{5})(\\d{5})",
                    "$1 $2",
                    [
                        "16|[6-9]"
                    ],
                    "0$1",
                    1
                ],
                [
                    "(\\d{4})(\\d{2,4})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "18[06]",
                        "18[06]0"
                    ],
                    0,
                    1
                ],
                [
                    "(\\d{4})(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3 $4",
                    [
                        "18"
                    ],
                    0,
                    1
                ]
            ],
            "0"
        ],
        "IO": [
            "246",
            "00",
            "3\\d{6}",
            [
                7
            ],
            [
                [
                    "(\\d{3})(\\d{4})",
                    "$1 $2",
                    [
                        "3"
                    ]
                ]
            ]
        ],
        "IQ": [
            "964",
            "00",
            "(?:1|7\\d\\d)\\d{7}|[2-6]\\d{7,8}",
            [
                8,
                9,
                10
            ],
            [
                [
                    "(\\d)(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "1"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{3,4})",
                    "$1 $2 $3",
                    [
                        "[2-6]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "7"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "IR": [
            "98",
            "00",
            "[1-9]\\d{9}|(?:[1-8]\\d\\d|9)\\d{3,4}",
            [
                4,
                5,
                6,
                7,
                10
            ],
            [
                [
                    "(\\d{4,5})",
                    "$1",
                    [
                        "96"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{4,5})",
                    "$1 $2",
                    [
                        "(?:1[137]|2[13-68]|3[1458]|4[145]|5[1468]|6[16]|7[1467]|8[13467])[12689]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3,4})",
                    "$1 $2 $3",
                    [
                        "9"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{4})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "[1-8]"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "IS": [
            "354",
            "00|1(?:0(?:01|[12]0)|100)",
            "(?:38\\d|[4-9])\\d{6}",
            [
                7,
                9
            ],
            [
                [
                    "(\\d{3})(\\d{4})",
                    "$1 $2",
                    [
                        "[4-9]"
                    ]
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "3"
                    ]
                ]
            ],
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            "00"
        ],
        "IT": [
            "39",
            "00",
            "0\\d{5,11}|1\\d{8,10}|3(?:[0-8]\\d{7,10}|9\\d{7,8})|(?:43|55|70)\\d{8}|8\\d{5}(?:\\d{2,4})?",
            [
                6,
                7,
                8,
                9,
                10,
                11,
                12
            ],
            [
                [
                    "(\\d{2})(\\d{4,6})",
                    "$1 $2",
                    [
                        "0[26]"
                    ]
                ],
                [
                    "(\\d{3})(\\d{3,6})",
                    "$1 $2",
                    [
                        "0[13-57-9][0159]|8(?:03|4[17]|9[2-5])",
                        "0[13-57-9][0159]|8(?:03|4[17]|9(?:2|3[04]|[45][0-4]))"
                    ]
                ],
                [
                    "(\\d{4})(\\d{2,6})",
                    "$1 $2",
                    [
                        "0(?:[13-579][2-46-8]|8[236-8])"
                    ]
                ],
                [
                    "(\\d{4})(\\d{4})",
                    "$1 $2",
                    [
                        "894"
                    ]
                ],
                [
                    "(\\d{2})(\\d{3,4})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "0[26]|5"
                    ]
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3,4})",
                    "$1 $2 $3",
                    [
                        "1(?:44|[679])|[378]|43"
                    ]
                ],
                [
                    "(\\d{3})(\\d{3,4})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "0[13-57-9][0159]|14"
                    ]
                ],
                [
                    "(\\d{2})(\\d{4})(\\d{5})",
                    "$1 $2 $3",
                    [
                        "0[26]"
                    ]
                ],
                [
                    "(\\d{4})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "0"
                    ]
                ],
                [
                    "(\\d{3})(\\d{4})(\\d{4,5})",
                    "$1 $2 $3",
                    [
                        "[03]"
                    ]
                ]
            ],
            0,
            0,
            0,
            0,
            0,
            0,
            [
                [
                    "0(?:669[0-79]\\d{1,6}|831\\d{2,8})|0(?:1(?:[0159]\\d|[27][1-5]|31|4[1-4]|6[1356]|8[2-57])|2\\d\\d|3(?:[0159]\\d|2[1-4]|3[12]|[48][1-6]|6[2-59]|7[1-7])|4(?:[0159]\\d|[23][1-9]|4[245]|6[1-5]|7[1-4]|81)|5(?:[0159]\\d|2[1-5]|3[2-6]|4[1-79]|6[4-6]|7[1-578]|8[3-8])|6(?:[0-57-9]\\d|6[0-8])|7(?:[0159]\\d|2[12]|3[1-7]|4[2-46]|6[13569]|7[13-6]|8[1-59])|8(?:[0159]\\d|2[3-578]|3[2356]|[6-8][1-5])|9(?:[0159]\\d|[238][1-5]|4[12]|6[1-8]|7[1-6]))\\d{2,7}"
                ],
                [
                    "3[2-9]\\d{7,8}|(?:31|43)\\d{8}",
                    [
                        9,
                        10
                    ]
                ],
                [
                    "80(?:0\\d{3}|3)\\d{3}",
                    [
                        6,
                        9
                    ]
                ],
                [
                    "(?:0878\\d{3}|89(?:2\\d|3[04]|4(?:[0-4]|[5-9]\\d\\d)|5[0-4]))\\d\\d|(?:1(?:44|6[346])|89(?:38|5[5-9]|9))\\d{6}",
                    [
                        6,
                        8,
                        9,
                        10
                    ]
                ],
                [
                    "1(?:78\\d|99)\\d{6}",
                    [
                        9,
                        10
                    ]
                ],
                [
                    "3[2-8]\\d{9,10}",
                    [
                        11,
                        12
                    ]
                ],
                0,
                0,
                [
                    "55\\d{8}",
                    [
                        10
                    ]
                ],
                [
                    "84(?:[08]\\d{3}|[17])\\d{3}",
                    [
                        6,
                        9
                    ]
                ]
            ]
        ],
        "JE": [
            "44",
            "00",
            "1534\\d{6}|(?:[3578]\\d|90)\\d{8}",
            [
                10
            ],
            0,
            "0",
            0,
            "([0-24-8]\\d{5})$|0|180020",
            "1534$1",
            0,
            0,
            [
                [
                    "1534[0-24-8]\\d{5}"
                ],
                [
                    "7(?:(?:(?:50|82)9|937)\\d|7(?:00[378]|97\\d))\\d{5}"
                ],
                [
                    "80(?:07(?:35|81)|8901)\\d{4}"
                ],
                [
                    "(?:8(?:4(?:4(?:4(?:05|42|69)|703)|5(?:041|800))|7(?:0002|1206))|90(?:066[59]|1810|71(?:07|55)))\\d{4}"
                ],
                [
                    "701511\\d{4}"
                ],
                0,
                [
                    "(?:3(?:0(?:07(?:35|81)|8901)|3\\d{4}|4(?:4(?:4(?:05|42|69)|703)|5(?:041|800))|7(?:0002|1206))|55\\d{4})\\d{4}"
                ],
                [
                    "76(?:464|652)\\d{5}|76(?:0[0-28]|2[356]|34|4[01347]|5[49]|6[0-369]|77|8[14]|9[139])\\d{6}"
                ],
                [
                    "56\\d{8}"
                ]
            ]
        ],
        "JM": [
            "1",
            "011",
            "(?:[58]\\d\\d|658|900)\\d{7}",
            [
                10
            ],
            0,
            "1",
            0,
            0,
            0,
            0,
            "658|876"
        ],
        "JO": [
            "962",
            "00",
            "(?:(?:[2689]|7\\d)\\d|32|427|53)\\d{6}",
            [
                8,
                9
            ],
            [
                [
                    "(\\d)(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "[2356]|87"
                    ],
                    "(0$1)"
                ],
                [
                    "(\\d{3})(\\d{5,6})",
                    "$1 $2",
                    [
                        "[89]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{7})",
                    "$1 $2",
                    [
                        "70"
                    ],
                    "0$1"
                ],
                [
                    "(\\d)(\\d{4})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "[47]"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "JP": [
            "81",
            "010",
            "00[1-9]\\d{6,14}|[25-9]\\d{9}|(?:00|[1-9]\\d\\d)\\d{6}",
            [
                8,
                9,
                10,
                11,
                12,
                13,
                14,
                15,
                16,
                17
            ],
            [
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1-$2-$3",
                    [
                        "(?:12|57|99)0"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{4})(\\d)(\\d{4})",
                    "$1-$2-$3",
                    [
                        "1(?:26|3[79]|4[56]|5[4-68]|6[3-5])|499|5(?:76|97)|746|8(?:3[89]|47|51)|9(?:80|9[16])",
                        "1(?:267|3(?:7[247]|9[278])|466|5(?:47|58|64)|6(?:3[245]|48|5[4-68]))|499[2468]|5(?:76|97)9|7468|8(?:3(?:8[7-9]|96)|477|51[2-9])|9(?:802|9(?:1[23]|69))|1(?:45|58)[67]",
                        "1(?:267|3(?:7[247]|9[278])|466|5(?:47|58|64)|6(?:3[245]|48|5[4-68]))|499[2468]|5(?:769|979[2-69])|7468|8(?:3(?:8[7-9]|96[2457-9])|477|51[2-9])|9(?:802|9(?:1[23]|69))|1(?:45|58)[67]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{4})",
                    "$1-$2-$3",
                    [
                        "60"
                    ],
                    "0$1"
                ],
                [
                    "(\\d)(\\d{4})(\\d{4})",
                    "$1-$2-$3",
                    [
                        "3|4(?:2[09]|7[01])|6[1-9]",
                        "3|4(?:2(?:0|9[02-69])|7(?:0[019]|1))|6[1-9]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{4})",
                    "$1-$2-$3",
                    [
                        "1(?:1|5[45]|77|88|9[69])|2(?:2[1-37]|3[0-269]|4[59]|5|6[24]|7[1-358]|8[1369]|9[0-38])|4(?:[28][1-9]|3[0-57]|[45]|6[248]|7[2-579]|9[29])|5(?:2|3[0459]|4[0-369]|5[29]|8[02389]|9[0-389])|7(?:2[02-46-9]|34|[58]|6[0249]|7[57]|9[2-6])|8(?:2[124589]|3[26-9]|49|51|6|7[0-468]|8[68]|9[019])|9(?:[23][1-9]|4[15]|5[138]|6[1-3]|7[156]|8[189]|9[1-489])",
                        "1(?:1|5(?:4[018]|5[017])|77|88|9[69])|2(?:2(?:[127]|3[014-9])|3[0-269]|4[59]|5(?:[1-3]|5[0-69]|9[19])|62|7(?:[1-35]|8[0189])|8(?:[16]|3[0134]|9[0-5])|9(?:[028]|17))|4(?:2(?:[13-79]|8[014-6])|3[0-57]|[45]|6[248]|7[2-47]|8[1-9]|9[29])|5(?:2|3(?:[045]|9[0-8])|4[0-369]|5[29]|8[02389]|9[0-3])|7(?:2[02-46-9]|34|[58]|6[0249]|7[57]|9(?:[23]|4[0-59]|5[01569]|6[0167]))|8(?:2(?:[1258]|4[0-39]|9[0-2469])|3(?:[29]|60)|49|51|6(?:[0-24]|36|5[0-3589]|7[23]|9[01459])|7[0-468]|8[68])|9(?:[23][1-9]|4[15]|5[138]|6[1-3]|7[156]|8[189]|9(?:[1289]|3[34]|4[0178]))|(?:264|837)[016-9]|2(?:57|93)[015-9]|(?:25[0468]|422|838)[01]|(?:47[59]|59[89]|8(?:6[68]|9))[019]",
                        "1(?:1|5(?:4[018]|5[017])|77|88|9[69])|2(?:2[127]|3[0-269]|4[59]|5(?:[1-3]|5[0-69]|9(?:17|99))|6(?:2|4[016-9])|7(?:[1-35]|8[0189])|8(?:[16]|3[0134]|9[0-5])|9(?:[028]|17))|4(?:2(?:[13-79]|8[014-6])|3[0-57]|[45]|6[248]|7[2-47]|9[29])|5(?:2|3(?:[045]|9(?:[0-58]|6[4-9]|7[0-35689]))|4[0-369]|5[29]|8[02389]|9[0-3])|7(?:2[02-46-9]|34|[58]|6[0249]|7[57]|9(?:[23]|4[0-59]|5[01569]|6[0167]))|8(?:2(?:[1258]|4[0-39]|9[0169])|3(?:[29]|60|7(?:[017-9]|6[6-8]))|49|51|6(?:[0-24]|36[2-57-9]|5(?:[0-389]|5[23])|6(?:[01]|9[178])|7(?:2[2-468]|3[78])|9[0145])|7[0-468]|8[68])|9(?:4[15]|5[138]|7[156]|8[189]|9(?:[1289]|3(?:31|4[357])|4[0178]))|(?:8294|96)[1-3]|2(?:57|93)[015-9]|(?:223|8699)[014-9]|(?:25[0468]|422|838)[01]|(?:48|8292|9[23])[1-9]|(?:47[59]|59[89]|8(?:68|9))[019]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{2})(\\d{4})",
                    "$1-$2-$3",
                    [
                        "[14]|[289][2-9]|5[3-9]|7[2-4679]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{4})",
                    "$1-$2-$3",
                    [
                        "800"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{4})(\\d{4})",
                    "$1-$2-$3",
                    [
                        "[25-9]"
                    ],
                    "0$1"
                ]
            ],
            "0",
            0,
            "(000[2569]\\d{4,6})$|(?:(?:003768)0?)|0",
            "$1"
        ],
        "KE": [
            "254",
            "000",
            "(?:[17]\\d\\d|900)\\d{6}|(?:2|80)0\\d{6,7}|[4-6]\\d{6,8}",
            [
                7,
                8,
                9,
                10
            ],
            [
                [
                    "(\\d{2})(\\d{5,7})",
                    "$1 $2",
                    [
                        "[24-6]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{6})",
                    "$1 $2",
                    [
                        "[17]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3,4})",
                    "$1 $2 $3",
                    [
                        "[89]"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "KG": [
            "996",
            "00",
            "8\\d{9}|[235-9]\\d{8}",
            [
                9,
                10
            ],
            [
                [
                    "(\\d{4})(\\d{5})",
                    "$1 $2",
                    [
                        "3(?:1[346]|[24-79])"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "[235-79]|88"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d)(\\d{2,3})",
                    "$1 $2 $3 $4",
                    [
                        "8"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "KH": [
            "855",
            "00[14-9]",
            "1\\d{9}|[1-9]\\d{7,8}",
            [
                8,
                9,
                10
            ],
            [
                [
                    "(\\d{2})(\\d{3})(\\d{3,4})",
                    "$1 $2 $3",
                    [
                        "[1-9]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{4})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "1"
                    ]
                ]
            ],
            "0"
        ],
        "KI": [
            "686",
            "00",
            "(?:[37]\\d|6[0-79])\\d{6}|(?:[2-48]\\d|50)\\d{3}",
            [
                5,
                8
            ],
            0,
            "0"
        ],
        "KM": [
            "269",
            "00",
            "[3478]\\d{6}",
            [
                7
            ],
            [
                [
                    "(\\d{3})(\\d{2})(\\d{2})",
                    "$1 $2 $3",
                    [
                        "[3478]"
                    ]
                ]
            ]
        ],
        "KN": [
            "1",
            "011",
            "(?:[58]\\d\\d|900)\\d{7}",
            [
                10
            ],
            0,
            "1",
            0,
            "([2-7]\\d{6})$|1",
            "869$1",
            0,
            "869"
        ],
        "KP": [
            "850",
            "00|99",
            "85\\d{6}|(?:19\\d|[2-7])\\d{7}",
            [
                8,
                10
            ],
            [
                [
                    "(\\d{2})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "8"
                    ],
                    "0$1"
                ],
                [
                    "(\\d)(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "[2-7]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "1"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "KR": [
            "82",
            "00(?:[125689]|3(?:[46]5|91)|7(?:00|27|3|55|6[126]))",
            "00[1-9]\\d{8,11}|(?:[12]|5\\d{3})\\d{7}|[13-6]\\d{9}|(?:[1-6]\\d|80)\\d{7}|[3-6]\\d{4,5}|(?:00|7)0\\d{8}",
            [
                5,
                6,
                8,
                9,
                10,
                11,
                12,
                13,
                14
            ],
            [
                [
                    "(\\d{2})(\\d{3,4})",
                    "$1-$2",
                    [
                        "(?:3[1-3]|[46][1-4]|5[1-5])1"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{4})(\\d{4})",
                    "$1-$2",
                    [
                        "1"
                    ]
                ],
                [
                    "(\\d)(\\d{3,4})(\\d{4})",
                    "$1-$2-$3",
                    [
                        "2"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{4})",
                    "$1-$2-$3",
                    [
                        "[36]0|8"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3,4})(\\d{4})",
                    "$1-$2-$3",
                    [
                        "[1346]|5[1-5]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{4})(\\d{4})",
                    "$1-$2-$3",
                    [
                        "[57]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{5})(\\d{4})",
                    "$1-$2-$3",
                    [
                        "5"
                    ],
                    "0$1"
                ]
            ],
            "0",
            0,
            "0(8(?:[1-46-8]|5\\d\\d))?"
        ],
        "KW": [
            "965",
            "00",
            "18\\d{5}|(?:[2569]\\d|41)\\d{6}",
            [
                7,
                8
            ],
            [
                [
                    "(\\d{4})(\\d{3,4})",
                    "$1 $2",
                    [
                        "[169]|2(?:[235]|4[1-35-9])|52"
                    ]
                ],
                [
                    "(\\d{3})(\\d{5})",
                    "$1 $2",
                    [
                        "[245]"
                    ]
                ]
            ]
        ],
        "KY": [
            "1",
            "011",
            "(?:345|[58]\\d\\d|900)\\d{7}",
            [
                10
            ],
            0,
            "1",
            0,
            "([2-9]\\d{6})$|1",
            "345$1",
            0,
            "345"
        ],
        "KZ": [
            "7",
            "810",
            "8\\d{13}|[78]\\d{9}",
            [
                10,
                14
            ],
            0,
            "8",
            0,
            0,
            0,
            0,
            "7",
            0,
            "8~10"
        ],
        "LA": [
            "856",
            "00",
            "[23]\\d{9}|3\\d{8}|(?:[235-8]\\d|41)\\d{6}",
            [
                8,
                9,
                10
            ],
            [
                [
                    "(\\d{2})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "2[13]|3[14]|[4-8]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{2})(\\d{2})(\\d{3})",
                    "$1 $2 $3 $4",
                    [
                        "3"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{2})(\\d{3})(\\d{3})",
                    "$1 $2 $3 $4",
                    [
                        "[23]"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "LB": [
            "961",
            "00",
            "[27-9]\\d{7}|[13-9]\\d{6}",
            [
                7,
                8
            ],
            [
                [
                    "(\\d)(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "[13-69]|7(?:[2-57]|62|8[0-6]|9[04-9])|8[02-9]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "[27-9]"
                    ]
                ]
            ],
            "0"
        ],
        "LC": [
            "1",
            "011",
            "(?:[58]\\d\\d|758|900)\\d{7}",
            [
                10
            ],
            0,
            "1",
            0,
            "([2-8]\\d{6})$|1",
            "758$1",
            0,
            "758"
        ],
        "LI": [
            "423",
            "00",
            "[68]\\d{8}|(?:[2378]\\d|90)\\d{5}",
            [
                7,
                9
            ],
            [
                [
                    "(\\d{3})(\\d{2})(\\d{2})",
                    "$1 $2 $3",
                    [
                        "[2379]|8(?:0[09]|7)",
                        "[2379]|8(?:0(?:02|9)|7)"
                    ]
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "8"
                    ]
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "69"
                    ]
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "6"
                    ]
                ]
            ],
            "0",
            0,
            "(1001)|0"
        ],
        "LK": [
            "94",
            "00",
            "[1-9]\\d{8}",
            [
                9
            ],
            [
                [
                    "(\\d{2})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "7"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "[1-689]"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "LR": [
            "231",
            "00",
            "(?:[2457]\\d|33|88)\\d{7}|(?:2\\d|[4-6])\\d{6}",
            [
                7,
                8,
                9
            ],
            [
                [
                    "(\\d)(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "4[67]|[56]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "2"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "[2-578]"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "LS": [
            "266",
            "00",
            "(?:[256]\\d\\d|800)\\d{5}",
            [
                8
            ],
            [
                [
                    "(\\d{4})(\\d{4})",
                    "$1 $2",
                    [
                        "[2568]"
                    ]
                ]
            ]
        ],
        "LT": [
            "370",
            "00",
            "(?:[3469]\\d|52|[78]0)\\d{6}",
            [
                8
            ],
            [
                [
                    "(\\d)(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "52[0-7]"
                    ],
                    "(0-$1)",
                    1
                ],
                [
                    "(\\d{3})(\\d{2})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "[7-9]"
                    ],
                    "0 $1",
                    1
                ],
                [
                    "(\\d{2})(\\d{6})",
                    "$1 $2",
                    [
                        "37|4(?:[15]|6[1-8])"
                    ],
                    "(0-$1)",
                    1
                ],
                [
                    "(\\d{3})(\\d{5})",
                    "$1 $2",
                    [
                        "[3-6]"
                    ],
                    "(0-$1)",
                    1
                ]
            ],
            "0",
            0,
            "[08]"
        ],
        "LU": [
            "352",
            "00",
            "35[013-9]\\d{4,8}|6\\d{8}|35\\d{2,4}|(?:[2457-9]\\d|3[0-46-9])\\d{2,9}",
            [
                4,
                5,
                6,
                7,
                8,
                9,
                10,
                11
            ],
            [
                [
                    "(\\d{2})(\\d{3})",
                    "$1 $2",
                    [
                        "2(?:0[2-689]|[2-9])|[3-57]|8(?:0[2-9]|[13-9])|9(?:0[89]|[2-579])"
                    ]
                ],
                [
                    "(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3",
                    [
                        "2(?:0[2-689]|[2-9])|[3-57]|8(?:0[2-9]|[13-9])|9(?:0[89]|[2-579])"
                    ]
                ],
                [
                    "(\\d{2})(\\d{2})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "20[2-689]"
                    ]
                ],
                [
                    "(\\d{2})(\\d{2})(\\d{2})(\\d{1,2})",
                    "$1 $2 $3 $4",
                    [
                        "20"
                    ]
                ],
                [
                    "(\\d{2})(\\d{2})(\\d{2})(\\d{1,5})",
                    "$1 $2 $3 $4",
                    [
                        "[3-57]|8[13-9]|9(?:0[89]|[2-579])|(?:2|80)[2-9]"
                    ]
                ],
                [
                    "(\\d{3})(\\d{2})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "80[01]|90[015]"
                    ]
                ],
                [
                    "(\\d{2})(\\d{2})(\\d{2})(\\d{3})",
                    "$1 $2 $3 $4",
                    [
                        "20"
                    ]
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "6"
                    ]
                ],
                [
                    "(\\d{2})(\\d{2})(\\d{2})(\\d{2})(\\d{1,2})",
                    "$1 $2 $3 $4 $5",
                    [
                        "20"
                    ]
                ]
            ],
            0,
            0,
            "(15(?:0[06]|1[12]|[35]5|4[04]|6[26]|77|88|99)\\d)"
        ],
        "LV": [
            "371",
            "00",
            "(?:[268]\\d|78|90)\\d{6}",
            [
                8
            ],
            [
                [
                    "(\\d{2})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "[2679]|8[01]"
                    ]
                ]
            ]
        ],
        "LY": [
            "218",
            "00",
            "[2-9]\\d{8}",
            [
                9
            ],
            [
                [
                    "(\\d{2})(\\d{7})",
                    "$1-$2",
                    [
                        "[2-9]"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "MA": [
            "212",
            "00",
            "[5-8]\\d{8}",
            [
                9
            ],
            [
                [
                    "(\\d{4})(\\d{5})",
                    "$1-$2",
                    [
                        "892"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{7})",
                    "$1-$2",
                    [
                        "8(?:0[0-7]|9)"
                    ],
                    "0$1"
                ],
                [
                    "(\\d)(\\d{2})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4 $5",
                    [
                        "[5-8]"
                    ],
                    "0$1"
                ]
            ],
            "0",
            0,
            0,
            0,
            0,
            "[5-8]"
        ],
        "MC": [
            "377",
            "00",
            "(?:[3489]|[67]\\d)\\d{7}",
            [
                8,
                9
            ],
            [
                [
                    "(\\d{2})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "4"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "[389]"
                    ]
                ],
                [
                    "(\\d)(\\d{2})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4 $5",
                    [
                        "[67]"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "MD": [
            "373",
            "00",
            "(?:[235-7]\\d|[89]0)\\d{6}",
            [
                8
            ],
            [
                [
                    "(\\d{3})(\\d{5})",
                    "$1 $2",
                    [
                        "[89]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "22|3"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{2})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "[25-7]"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "ME": [
            "382",
            "00",
            "(?:20|[3-79]\\d)\\d{6}|80\\d{6,7}",
            [
                8,
                9
            ],
            [
                [
                    "(\\d{2})(\\d{3})(\\d{3,4})",
                    "$1 $2 $3",
                    [
                        "[2-9]"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "MF": [
            "590",
            "00",
            "7090\\d{5}|(?:[56]9|[89]\\d)\\d{7}",
            [
                9
            ],
            0,
            "0",
            0,
            0,
            0,
            0,
            0,
            [
                [
                    "(?:59(?:0(?:0[079]|[14]3|[27][79]|3[03-7]|5[0-268]|87)|87\\d)|80[6-9]\\d\\d)\\d{4}"
                ],
                [
                    "(?:69(?:0\\d\\d|1(?:2[2-9]|3[0-5]))|7090[0-4])\\d{4}"
                ],
                [
                    "80[0-5]\\d{6}"
                ],
                [
                    "8[129]\\d{7}"
                ],
                0,
                0,
                0,
                0,
                [
                    "9(?:(?:39[5-7]|76[018])\\d|475[0-6])\\d{4}"
                ]
            ]
        ],
        "MG": [
            "261",
            "00",
            "[23]\\d{8}",
            [
                9
            ],
            [
                [
                    "(\\d{2})(\\d{2})(\\d{3})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "[23]"
                    ],
                    "0$1"
                ]
            ],
            "0",
            0,
            "([24-9]\\d{6})$|0",
            "20$1"
        ],
        "MH": [
            "692",
            "011",
            "329\\d{4}|(?:[256]\\d|45)\\d{5}",
            [
                7
            ],
            [
                [
                    "(\\d{3})(\\d{4})",
                    "$1-$2",
                    [
                        "[2-6]"
                    ]
                ]
            ],
            "1"
        ],
        "MK": [
            "389",
            "00",
            "[2-578]\\d{7}",
            [
                8
            ],
            [
                [
                    "(\\d)(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "2|34[47]|4(?:[37]7|5[47]|64)"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "[347]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d)(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "[58]"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "ML": [
            "223",
            "00",
            "[24-9]\\d{7}",
            [
                8
            ],
            [
                [
                    "(\\d{2})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "[24-9]"
                    ]
                ]
            ]
        ],
        "MM": [
            "95",
            "00",
            "1\\d{5,7}|95\\d{6}|(?:[4-7]|9[0-46-9])\\d{6,8}|(?:2|8\\d)\\d{5,8}",
            [
                6,
                7,
                8,
                9,
                10
            ],
            [
                [
                    "(\\d)(\\d{2})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "16|2"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{2})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "4(?:[2-46]|5[3-5])|5|6(?:[1-689]|7[235-7])|7(?:[0-4]|5[2-7])|8[1-5]|(?:60|86)[23]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d)(\\d{3})(\\d{3,4})",
                    "$1 $2 $3",
                    [
                        "[12]|452|678|86",
                        "[12]|452|6788|86"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{3,4})",
                    "$1 $2 $3",
                    [
                        "[4-7]|8[1-35]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d)(\\d{3})(\\d{4,6})",
                    "$1 $2 $3",
                    [
                        "9(?:2[0-4]|[35-9]|4[137-9])"
                    ],
                    "0$1"
                ],
                [
                    "(\\d)(\\d{4})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "2"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "8"
                    ],
                    "0$1"
                ],
                [
                    "(\\d)(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3 $4",
                    [
                        "92"
                    ],
                    "0$1"
                ],
                [
                    "(\\d)(\\d{5})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "9"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "MN": [
            "976",
            "001",
            "[12]\\d{7,9}|[5-9]\\d{7}",
            [
                8,
                9,
                10
            ],
            [
                [
                    "(\\d{2})(\\d{2})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "11|2[16]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{4})(\\d{4})",
                    "$1 $2",
                    [
                        "[5-9]"
                    ]
                ],
                [
                    "(\\d{3})(\\d{5,6})",
                    "$1 $2",
                    [
                        "[12]2[1-3]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{4})(\\d{5,6})",
                    "$1 $2",
                    [
                        "[12](?:27|3[2-8]|4[2-68]|5[1-4689])",
                        "[12](?:27|3[2-8]|4[2-68]|5[1-4689])[0-3]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{5})(\\d{4,5})",
                    "$1 $2",
                    [
                        "[12]"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "MO": [
            "853",
            "00",
            "0800\\d{3}|(?:28|[68]\\d)\\d{6}",
            [
                7,
                8
            ],
            [
                [
                    "(\\d{4})(\\d{3})",
                    "$1 $2",
                    [
                        "0"
                    ]
                ],
                [
                    "(\\d{4})(\\d{4})",
                    "$1 $2",
                    [
                        "[268]"
                    ]
                ]
            ]
        ],
        "MP": [
            "1",
            "011",
            "[58]\\d{9}|(?:67|90)0\\d{7}",
            [
                10
            ],
            0,
            "1",
            0,
            "([2-9]\\d{6})$|1",
            "670$1",
            0,
            "670"
        ],
        "MQ": [
            "596",
            "00",
            "7091\\d{5}|(?:[56]9|[89]\\d)\\d{7}",
            [
                9
            ],
            [
                [
                    "(\\d{3})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "[5-79]|8(?:0[6-9]|[36])"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "8"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "MR": [
            "222",
            "00",
            "(?:[2-4]\\d\\d|800)\\d{5}",
            [
                8
            ],
            [
                [
                    "(\\d{2})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "[2-48]"
                    ]
                ]
            ]
        ],
        "MS": [
            "1",
            "011",
            "(?:[58]\\d\\d|664|900)\\d{7}",
            [
                10
            ],
            0,
            "1",
            0,
            "([34]\\d{6})$|1",
            "664$1",
            0,
            "664"
        ],
        "MT": [
            "356",
            "00",
            "3550\\d{4}|(?:[2579]\\d\\d|800)\\d{5}",
            [
                8
            ],
            [
                [
                    "(\\d{4})(\\d{4})",
                    "$1 $2",
                    [
                        "[2357-9]"
                    ]
                ]
            ]
        ],
        "MU": [
            "230",
            "0(?:0|[24-7]0|3[03])",
            "(?:[57]|8\\d\\d)\\d{7}|[2-468]\\d{6}",
            [
                7,
                8,
                10
            ],
            [
                [
                    "(\\d{3})(\\d{4})",
                    "$1 $2",
                    [
                        "[2-46]|8[013]"
                    ]
                ],
                [
                    "(\\d{4})(\\d{4})",
                    "$1 $2",
                    [
                        "[57]"
                    ]
                ],
                [
                    "(\\d{5})(\\d{5})",
                    "$1 $2",
                    [
                        "8"
                    ]
                ]
            ],
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            "020"
        ],
        "MV": [
            "960",
            "0(?:0|19)",
            "(?:800|9[0-57-9]\\d)\\d{7}|[34679]\\d{6}",
            [
                7,
                10
            ],
            [
                [
                    "(\\d{3})(\\d{4})",
                    "$1-$2",
                    [
                        "[34679]"
                    ]
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "[89]"
                    ]
                ]
            ],
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            "00"
        ],
        "MW": [
            "265",
            "00",
            "(?:[1289]\\d|31|77)\\d{7}|1\\d{6}",
            [
                7,
                9
            ],
            [
                [
                    "(\\d)(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "1[2-9]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "2"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "[137-9]"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "MX": [
            "52",
            "0[09]",
            "[2-9]\\d{9}",
            [
                10
            ],
            [
                [
                    "(\\d{2})(\\d{4})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "33|5[56]|81"
                    ]
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "[2-9]"
                    ]
                ]
            ],
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            "00"
        ],
        "MY": [
            "60",
            "00",
            "1\\d{8,9}|(?:3\\d|[4-9])\\d{7}",
            [
                8,
                9,
                10
            ],
            [
                [
                    "(\\d)(\\d{3})(\\d{4})",
                    "$1-$2 $3",
                    [
                        "[4-79]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{3,4})",
                    "$1-$2 $3",
                    [
                        "1(?:[02469]|[378][1-9]|53)|8",
                        "1(?:[02469]|[37][1-9]|53|8(?:[1-46-9]|5[7-9]))|8"
                    ],
                    "0$1"
                ],
                [
                    "(\\d)(\\d{4})(\\d{4})",
                    "$1-$2 $3",
                    [
                        "3"
                    ],
                    "0$1"
                ],
                [
                    "(\\d)(\\d{3})(\\d{2})(\\d{4})",
                    "$1-$2-$3-$4",
                    [
                        "1(?:[367]|80)"
                    ]
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{4})",
                    "$1-$2 $3",
                    [
                        "15"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{4})(\\d{4})",
                    "$1-$2 $3",
                    [
                        "1"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "MZ": [
            "258",
            "00",
            "(?:2|8\\d)\\d{7}",
            [
                8,
                9
            ],
            [
                [
                    "(\\d{2})(\\d{3})(\\d{3,4})",
                    "$1 $2 $3",
                    [
                        "2|8[2-79]"
                    ]
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "8"
                    ]
                ]
            ]
        ],
        "NA": [
            "264",
            "00",
            "[68]\\d{7,8}",
            [
                8,
                9
            ],
            [
                [
                    "(\\d{2})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "88"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{3,4})",
                    "$1 $2 $3",
                    [
                        "6"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "87"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "8"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "NC": [
            "687",
            "00",
            "(?:050|[2-57-9]\\d\\d)\\d{3}",
            [
                6
            ],
            [
                [
                    "(\\d{2})(\\d{2})(\\d{2})",
                    "$1.$2.$3",
                    [
                        "[02-57-9]"
                    ]
                ]
            ]
        ],
        "NE": [
            "227",
            "00",
            "[027-9]\\d{7}",
            [
                8
            ],
            [
                [
                    "(\\d{2})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "08"
                    ]
                ],
                [
                    "(\\d{2})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "[089]|2[013]|7[0467]"
                    ]
                ]
            ]
        ],
        "NF": [
            "672",
            "00",
            "[13]\\d{5}",
            [
                6
            ],
            [
                [
                    "(\\d{2})(\\d{4})",
                    "$1 $2",
                    [
                        "1[0-3]"
                    ]
                ],
                [
                    "(\\d)(\\d{5})",
                    "$1 $2",
                    [
                        "[13]"
                    ]
                ]
            ],
            0,
            0,
            "([0-258]\\d{4})$",
            "3$1"
        ],
        "NG": [
            "234",
            "009",
            "(?:20|9\\d)\\d{8}|[78]\\d{9,13}",
            [
                10,
                11,
                12,
                13,
                14
            ],
            [
                [
                    "(\\d{3})(\\d{3})(\\d{3,4})",
                    "$1 $2 $3",
                    [
                        "[7-9]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "20[129]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{4})(\\d{2})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "2"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{4})(\\d{4,5})",
                    "$1 $2 $3",
                    [
                        "[78]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{5})(\\d{5,6})",
                    "$1 $2 $3",
                    [
                        "[78]"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "NI": [
            "505",
            "00",
            "(?:1800|[25-8]\\d{3})\\d{4}",
            [
                8
            ],
            [
                [
                    "(\\d{4})(\\d{4})",
                    "$1 $2",
                    [
                        "[125-8]"
                    ]
                ]
            ]
        ],
        "NL": [
            "31",
            "00",
            "(?:[124-7]\\d\\d|3(?:[02-9]\\d|1[0-8]))\\d{6}|8\\d{6,9}|9\\d{6,10}|1\\d{4,5}",
            [
                5,
                6,
                7,
                8,
                9,
                10,
                11
            ],
            [
                [
                    "(\\d{3})(\\d{4,7})",
                    "$1 $2",
                    [
                        "[89]0"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{7})",
                    "$1 $2",
                    [
                        "66"
                    ],
                    "0$1"
                ],
                [
                    "(\\d)(\\d{8})",
                    "$1 $2",
                    [
                        "6"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "1[16-8]|2[259]|3[124]|4[17-9]|5[124679]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "[1-578]|91"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{5})",
                    "$1 $2 $3",
                    [
                        "9"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "NO": [
            "47",
            "00",
            "(?:0|[2-9]\\d{3})\\d{4}",
            [
                5,
                8
            ],
            [
                [
                    "(\\d{3})(\\d{2})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "8"
                    ]
                ],
                [
                    "(\\d{2})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "[2-79]"
                    ]
                ]
            ],
            0,
            0,
            0,
            0,
            0,
            "[02-689]|7[0-8]"
        ],
        "NP": [
            "977",
            "00",
            "(?:1\\d|9)\\d{9}|[1-9]\\d{7}",
            [
                8,
                10,
                11
            ],
            [
                [
                    "(\\d)(\\d{7})",
                    "$1-$2",
                    [
                        "1[2-6]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{6})",
                    "$1-$2",
                    [
                        "1[01]|[2-8]|9(?:[1-59]|[67][2-6])"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{7})",
                    "$1-$2",
                    [
                        "9"
                    ]
                ]
            ],
            "0"
        ],
        "NR": [
            "674",
            "00",
            "(?:222|444|(?:55|8\\d)\\d|666|777|999)\\d{4}",
            [
                7
            ],
            [
                [
                    "(\\d{3})(\\d{4})",
                    "$1 $2",
                    [
                        "[24-9]"
                    ]
                ]
            ]
        ],
        "NU": [
            "683",
            "00",
            "(?:[4-7]|888\\d)\\d{3}",
            [
                4,
                7
            ],
            [
                [
                    "(\\d{3})(\\d{4})",
                    "$1 $2",
                    [
                        "8"
                    ]
                ]
            ]
        ],
        "NZ": [
            "64",
            "0(?:0|161)",
            "[1289]\\d{9}|50\\d{5}(?:\\d{2,3})?|[27-9]\\d{7,8}|(?:[34]\\d|6[0-35-9])\\d{6}|8\\d{4,6}",
            [
                5,
                6,
                7,
                8,
                9,
                10
            ],
            [
                [
                    "(\\d{2})(\\d{3,8})",
                    "$1 $2",
                    [
                        "8[1-79]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{2})(\\d{2,3})",
                    "$1 $2 $3",
                    [
                        "50[036-8]|8|90",
                        "50(?:[0367]|88)|8|90"
                    ],
                    "0$1"
                ],
                [
                    "(\\d)(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "24|[346]|7[2-57-9]|9[2-9]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3,4})",
                    "$1 $2 $3",
                    [
                        "2(?:10|74)|[589]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3,4})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "1|2[028]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{3,5})",
                    "$1 $2 $3",
                    [
                        "2(?:[169]|7[0-35-9])|7"
                    ],
                    "0$1"
                ]
            ],
            "0",
            0,
            0,
            0,
            0,
            0,
            0,
            "00"
        ],
        "OM": [
            "968",
            "00",
            "(?:1505|[279]\\d{3}|500)\\d{4}|800\\d{5,6}",
            [
                7,
                8,
                9
            ],
            [
                [
                    "(\\d{3})(\\d{4,6})",
                    "$1 $2",
                    [
                        "[58]"
                    ]
                ],
                [
                    "(\\d{2})(\\d{6})",
                    "$1 $2",
                    [
                        "2"
                    ]
                ],
                [
                    "(\\d{4})(\\d{4})",
                    "$1 $2",
                    [
                        "[179]"
                    ]
                ]
            ]
        ],
        "PA": [
            "507",
            "00",
            "(?:00800|8\\d{3})\\d{6}|[68]\\d{7}|[1-57-9]\\d{6}",
            [
                7,
                8,
                10,
                11
            ],
            [
                [
                    "(\\d{3})(\\d{4})",
                    "$1-$2",
                    [
                        "[1-57-9]"
                    ]
                ],
                [
                    "(\\d{4})(\\d{4})",
                    "$1-$2",
                    [
                        "[68]"
                    ]
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "8"
                    ]
                ]
            ]
        ],
        "PE": [
            "51",
            "00|19(?:1[124]|77|90)00",
            "(?:[14-8]|9\\d)\\d{7}",
            [
                8,
                9
            ],
            [
                [
                    "(\\d{3})(\\d{5})",
                    "$1 $2",
                    [
                        "80"
                    ],
                    "(0$1)"
                ],
                [
                    "(\\d)(\\d{7})",
                    "$1 $2",
                    [
                        "1"
                    ],
                    "(0$1)"
                ],
                [
                    "(\\d{2})(\\d{6})",
                    "$1 $2",
                    [
                        "[4-8]"
                    ],
                    "(0$1)"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "9"
                    ]
                ]
            ],
            "0",
            0,
            0,
            0,
            0,
            0,
            0,
            "00",
            " Anexo "
        ],
        "PF": [
            "689",
            "00",
            "4\\d{5}(?:\\d{2})?|8\\d{7,8}",
            [
                6,
                8,
                9
            ],
            [
                [
                    "(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3",
                    [
                        "44"
                    ]
                ],
                [
                    "(\\d{2})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "4|8[7-9]"
                    ]
                ],
                [
                    "(\\d{3})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "8"
                    ]
                ]
            ]
        ],
        "PG": [
            "675",
            "00|140[1-3]",
            "(?:180|[78]\\d{3})\\d{4}|(?:[2-589]\\d|64)\\d{5}",
            [
                7,
                8
            ],
            [
                [
                    "(\\d{3})(\\d{4})",
                    "$1 $2",
                    [
                        "18|[2-69]|85"
                    ]
                ],
                [
                    "(\\d{4})(\\d{4})",
                    "$1 $2",
                    [
                        "[78]"
                    ]
                ]
            ],
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            "00"
        ],
        "PH": [
            "63",
            "00",
            "(?:[2-7]|9\\d)\\d{8}|2\\d{5}|(?:1800|8)\\d{7,9}",
            [
                6,
                8,
                9,
                10,
                11,
                12,
                13
            ],
            [
                [
                    "(\\d)(\\d{5})",
                    "$1 $2",
                    [
                        "2"
                    ],
                    "(0$1)"
                ],
                [
                    "(\\d{4})(\\d{4,6})",
                    "$1 $2",
                    [
                        "3(?:23|39|46)|4(?:2[3-6]|[35]9|4[26]|76)|544|88[245]|(?:52|64|86)2",
                        "3(?:230|397|461)|4(?:2(?:35|[46]4|51)|396|4(?:22|63)|59[347]|76[15])|5(?:221|446)|642[23]|8(?:622|8(?:[24]2|5[13]))"
                    ],
                    "(0$1)"
                ],
                [
                    "(\\d{5})(\\d{4})",
                    "$1 $2",
                    [
                        "346|4(?:27|9[35])|883",
                        "3469|4(?:279|9(?:30|56))|8834"
                    ],
                    "(0$1)"
                ],
                [
                    "(\\d)(\\d{4})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "2"
                    ],
                    "(0$1)"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "[3-7]|8[2-8]"
                    ],
                    "(0$1)"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "[89]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{4})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "1"
                    ]
                ],
                [
                    "(\\d{4})(\\d{1,2})(\\d{3})(\\d{4})",
                    "$1 $2 $3 $4",
                    [
                        "1"
                    ]
                ]
            ],
            "0"
        ],
        "PK": [
            "92",
            "00",
            "122\\d{6}|[24-8]\\d{10,11}|9(?:[013-9]\\d{8,10}|2(?:[01]\\d\\d|2(?:[06-8]\\d|1[01]))\\d{7})|(?:[2-8]\\d{3}|92(?:[0-7]\\d|8[1-9]))\\d{6}|[24-9]\\d{8}|[89]\\d{7}",
            [
                8,
                9,
                10,
                11,
                12
            ],
            [
                [
                    "(\\d{3})(\\d{3})(\\d{2,7})",
                    "$1 $2 $3",
                    [
                        "[89]0"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{4})(\\d{5})",
                    "$1 $2",
                    [
                        "1"
                    ]
                ],
                [
                    "(\\d{3})(\\d{6,7})",
                    "$1 $2",
                    [
                        "2(?:3[2358]|4[2-4]|9[2-8])|45[3479]|54[2-467]|60[468]|72[236]|8(?:2[2-689]|3[23578]|4[3478]|5[2356])|9(?:2[2-8]|3[27-9]|4[2-6]|6[3569]|9[25-8])",
                        "9(?:2[3-8]|98)|(?:2(?:3[2358]|4[2-4]|9[2-8])|45[3479]|54[2-467]|60[468]|72[236]|8(?:2[2-689]|3[23578]|4[3478]|5[2356])|9(?:22|3[27-9]|4[2-6]|6[3569]|9[25-7]))[2-9]"
                    ],
                    "(0$1)"
                ],
                [
                    "(\\d{2})(\\d{7,8})",
                    "$1 $2",
                    [
                        "(?:2[125]|4[0-246-9]|5[1-35-7]|6[1-8]|7[14]|8[16]|91)[2-9]"
                    ],
                    "(0$1)"
                ],
                [
                    "(\\d{5})(\\d{5})",
                    "$1 $2",
                    [
                        "58"
                    ],
                    "(0$1)"
                ],
                [
                    "(\\d{3})(\\d{7})",
                    "$1 $2",
                    [
                        "3"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3 $4",
                    [
                        "2[125]|4[0-246-9]|5[1-35-7]|6[1-8]|7[14]|8[16]|91"
                    ],
                    "(0$1)"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3 $4",
                    [
                        "[24-9]"
                    ],
                    "(0$1)"
                ]
            ],
            "0"
        ],
        "PL": [
            "48",
            "00",
            "(?:6|8\\d\\d)\\d{7}|[1-9]\\d{6}(?:\\d{2})?|[26]\\d{5}",
            [
                6,
                7,
                8,
                9,
                10
            ],
            [
                [
                    "(\\d{5})",
                    "$1",
                    [
                        "19"
                    ]
                ],
                [
                    "(\\d{3})(\\d{3})",
                    "$1 $2",
                    [
                        "11|20|64"
                    ]
                ],
                [
                    "(\\d{2})(\\d{2})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "30|(?:1[2-8]|2[2-69]|3[2-4]|4[1-468]|5[24-689]|6[1-3578]|7[14-7]|8[1-79]|9[145])1",
                        "30|(?:1[2-8]|2[2-69]|3[2-4]|4[1-468]|5[24-689]|6[1-3578]|7[14-7]|8[1-79]|9[145])19"
                    ]
                ],
                [
                    "(\\d{3})(\\d{2})(\\d{2,3})",
                    "$1 $2 $3",
                    [
                        "64"
                    ]
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "21|39|45|5[0137]|6[0469]|7[02389]|8(?:0[14]|8)"
                    ]
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "1[2-8]|[2-7]|8[1-79]|9[145]"
                    ]
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3,4})",
                    "$1 $2 $3",
                    [
                        "8"
                    ]
                ]
            ]
        ],
        "PM": [
            "508",
            "00",
            "[78]\\d{8}|[2-9]\\d{5}",
            [
                6,
                9
            ],
            [
                [
                    "(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3",
                    [
                        "[2-9]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "7"
                    ]
                ],
                [
                    "(\\d{3})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "8"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "PR": [
            "1",
            "011",
            "(?:[589]\\d\\d|787)\\d{7}",
            [
                10
            ],
            0,
            "1",
            0,
            0,
            0,
            0,
            "787|939"
        ],
        "PS": [
            "970",
            "00",
            "[2489]2\\d{6}|(?:1\\d|5)\\d{8}",
            [
                8,
                9,
                10
            ],
            [
                [
                    "(\\d)(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "[2489]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "5"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{4})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "1"
                    ]
                ]
            ],
            "0"
        ],
        "PT": [
            "351",
            "00",
            "1693\\d{5}|(?:[26-9]\\d|30)\\d{7}",
            [
                9
            ],
            [
                [
                    "(\\d{2})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "2[12]"
                    ]
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "16|[236-9]"
                    ]
                ]
            ]
        ],
        "PW": [
            "680",
            "01[12]",
            "(?:[24-8]\\d\\d|345|900)\\d{4}",
            [
                7
            ],
            [
                [
                    "(\\d{3})(\\d{4})",
                    "$1 $2",
                    [
                        "[2-9]"
                    ]
                ]
            ]
        ],
        "PY": [
            "595",
            "00",
            "[36-8]\\d{5,8}|4\\d{6,8}|59\\d{6}|9\\d{5,10}|(?:2\\d|5[0-8])\\d{6,7}",
            [
                6,
                7,
                8,
                9,
                10,
                11
            ],
            [
                [
                    "(\\d{3})(\\d{3,6})",
                    "$1 $2",
                    [
                        "[2-9]0"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{5})",
                    "$1 $2",
                    [
                        "3[289]|4[246-8]|61|7[1-3]|8[1-36]"
                    ],
                    "(0$1)"
                ],
                [
                    "(\\d{3})(\\d{4,5})",
                    "$1 $2",
                    [
                        "2[279]|3[13-5]|4[359]|5|6(?:[34]|7[1-46-8])|7[46-8]|85"
                    ],
                    "(0$1)"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{3,4})",
                    "$1 $2 $3",
                    [
                        "2[14-68]|3[26-9]|4[1246-8]|6(?:1|75)|7[1-35]|8[1-36]"
                    ],
                    "(0$1)"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "87"
                    ]
                ],
                [
                    "(\\d{3})(\\d{6})",
                    "$1 $2",
                    [
                        "9(?:[5-79]|8[1-7])"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "[2-8]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{4})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "9"
                    ]
                ]
            ],
            "0"
        ],
        "QA": [
            "974",
            "00",
            "800\\d{4}|(?:2|800)\\d{6}|(?:0080|[3-7])\\d{7}",
            [
                7,
                8,
                9,
                11
            ],
            [
                [
                    "(\\d{3})(\\d{4})",
                    "$1 $2",
                    [
                        "2[136]|8"
                    ]
                ],
                [
                    "(\\d{4})(\\d{4})",
                    "$1 $2",
                    [
                        "[3-7]"
                    ]
                ]
            ]
        ],
        "RE": [
            "262",
            "00",
            "709\\d{6}|(?:26|[689]\\d)\\d{7}",
            [
                9
            ],
            [
                [
                    "(\\d{3})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "[26-9]"
                    ],
                    "0$1"
                ]
            ],
            "0",
            0,
            0,
            0,
            0,
            0,
            [
                [
                    "2631[0-6]\\d{4}|26(?:2\\d|30|88)\\d{5}"
                ],
                [
                    "(?:69(?:2\\d\\d|3(?:[06][0-6]|1[0-3]|2[0-2]|3[0-39]|4\\d|5[0-5]|7[0-37]|8[0-8]|9[0-479]))|7092[0-3])\\d{4}"
                ],
                [
                    "80\\d{7}"
                ],
                [
                    "89[1-37-9]\\d{6}"
                ],
                0,
                0,
                0,
                0,
                [
                    "9(?:399[0-3]|479[0-6]|76(?:2[278]|3[0-37]))\\d{4}"
                ],
                [
                    "8(?:1[019]|2[0156]|84|90)\\d{6}"
                ]
            ]
        ],
        "RO": [
            "40",
            "00",
            "(?:[236-8]\\d|90)\\d{7}|[23]\\d{5}",
            [
                6,
                9
            ],
            [
                [
                    "(\\d{3})(\\d{3})",
                    "$1 $2",
                    [
                        "2[3-6]",
                        "2[3-6]\\d9"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{4})",
                    "$1 $2",
                    [
                        "219|31"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "[23]1"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "[236-9]"
                    ],
                    "0$1"
                ]
            ],
            "0",
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            " int "
        ],
        "RS": [
            "381",
            "00",
            "38[02-9]\\d{6,9}|6\\d{7,9}|90\\d{4,8}|38\\d{5,6}|(?:7\\d\\d|800)\\d{3,9}|(?:[12]\\d|3[0-79])\\d{5,10}",
            [
                6,
                7,
                8,
                9,
                10,
                11,
                12
            ],
            [
                [
                    "(\\d{3})(\\d{3,9})",
                    "$1 $2",
                    [
                        "(?:2[389]|39)0|[7-9]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{5,10})",
                    "$1 $2",
                    [
                        "[1-36]"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "RU": [
            "7",
            "810",
            "8\\d{13}|[347-9]\\d{9}",
            [
                10,
                14
            ],
            [
                [
                    "(\\d{4})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "7(?:1[0-8]|2[1-9])",
                        "7(?:1(?:[0-356]2|4[29]|7|8[27])|2(?:1[23]|[2-9]2))",
                        "7(?:1(?:[0-356]2|4[29]|7|8[27])|2(?:13[03-69]|62[013-9]))|72[1-57-9]2"
                    ],
                    "8 ($1)",
                    1
                ],
                [
                    "(\\d{5})(\\d)(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "7(?:1[0-68]|2[1-9])",
                        "7(?:1(?:[06][3-6]|[18]|2[35]|[3-5][3-5])|2(?:[13][3-5]|[24-689]|7[457]))",
                        "7(?:1(?:0(?:[356]|4[023])|[18]|2(?:3[013-9]|5)|3[45]|43[013-79]|5(?:3[1-8]|4[1-7]|5)|6(?:3[0-35-9]|[4-6]))|2(?:1(?:3[178]|[45])|[24-689]|3[35]|7[457]))|7(?:14|23)4[0-8]|71(?:33|45)[1-79]"
                    ],
                    "8 ($1)",
                    1
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "7"
                    ],
                    "8 ($1)",
                    1
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{2})(\\d{2})",
                    "$1 $2-$3-$4",
                    [
                        "[349]|8(?:[02-7]|1[1-8])"
                    ],
                    "8 ($1)",
                    1
                ],
                [
                    "(\\d{4})(\\d{4})(\\d{3})(\\d{3})",
                    "$1 $2 $3 $4",
                    [
                        "8"
                    ],
                    "8 ($1)"
                ]
            ],
            "8",
            0,
            0,
            0,
            0,
            "[3489]",
            0,
            "8~10"
        ],
        "RW": [
            "250",
            "00",
            "(?:06|[27]\\d\\d|[89]00)\\d{6}",
            [
                8,
                9
            ],
            [
                [
                    "(\\d{2})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "0"
                    ]
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "2"
                    ]
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "[7-9]"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "SA": [
            "966",
            "00",
            "(?:[15]\\d|800|92)\\d{7}",
            [
                9,
                10
            ],
            [
                [
                    "(\\d{4})(\\d{5})",
                    "$1 $2",
                    [
                        "9"
                    ]
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "1"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "5"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "8"
                    ]
                ]
            ],
            "0"
        ],
        "SB": [
            "677",
            "0[01]",
            "[6-9]\\d{6}|[1-6]\\d{4}",
            [
                5,
                7
            ],
            [
                [
                    "(\\d{2})(\\d{5})",
                    "$1 $2",
                    [
                        "6[89]|7|8[4-9]|9(?:[1-8]|9[0-8])"
                    ]
                ]
            ]
        ],
        "SC": [
            "248",
            "010|0[0-2]",
            "(?:[2489]\\d|64)\\d{5}",
            [
                7
            ],
            [
                [
                    "(\\d)(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "[246]|9[57]"
                    ]
                ]
            ],
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            "00"
        ],
        "SD": [
            "249",
            "00",
            "[19]\\d{8}",
            [
                9
            ],
            [
                [
                    "(\\d{2})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "[19]"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "SE": [
            "46",
            "00",
            "(?:[26]\\d\\d|9)\\d{9}|[1-9]\\d{8}|[1-689]\\d{7}|[1-4689]\\d{6}|2\\d{5}",
            [
                6,
                7,
                8,
                9,
                10,
                12
            ],
            [
                [
                    "(\\d{2})(\\d{2,3})(\\d{2})",
                    "$1-$2 $3",
                    [
                        "20"
                    ],
                    "0$1",
                    0,
                    "$1 $2 $3"
                ],
                [
                    "(\\d{3})(\\d{4})",
                    "$1-$2",
                    [
                        "9(?:00|39|44|9)"
                    ],
                    "0$1",
                    0,
                    "$1 $2"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{2})",
                    "$1-$2 $3",
                    [
                        "[12][136]|3[356]|4[0246]|6[03]|90[1-9]"
                    ],
                    "0$1",
                    0,
                    "$1 $2 $3"
                ],
                [
                    "(\\d)(\\d{2,3})(\\d{2})(\\d{2})",
                    "$1-$2 $3 $4",
                    [
                        "8"
                    ],
                    "0$1",
                    0,
                    "$1 $2 $3 $4"
                ],
                [
                    "(\\d{3})(\\d{2,3})(\\d{2})",
                    "$1-$2 $3",
                    [
                        "1[2457]|2(?:[247-9]|5[0138])|3[0247-9]|4[1357-9]|5[0-35-9]|6(?:[125689]|4[02-57]|7[0-2])|9(?:[125-8]|3[02-5]|4[0-3])"
                    ],
                    "0$1",
                    0,
                    "$1 $2 $3"
                ],
                [
                    "(\\d{3})(\\d{2,3})(\\d{3})",
                    "$1-$2 $3",
                    [
                        "9(?:00|39|44)"
                    ],
                    "0$1",
                    0,
                    "$1 $2 $3"
                ],
                [
                    "(\\d{2})(\\d{2,3})(\\d{2})(\\d{2})",
                    "$1-$2 $3 $4",
                    [
                        "1[13689]|2[0136]|3[1356]|4[0246]|54|6[03]|90[1-9]"
                    ],
                    "0$1",
                    0,
                    "$1 $2 $3 $4"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{2})(\\d{2})",
                    "$1-$2 $3 $4",
                    [
                        "10|7"
                    ],
                    "0$1",
                    0,
                    "$1 $2 $3 $4"
                ],
                [
                    "(\\d)(\\d{3})(\\d{3})(\\d{2})",
                    "$1-$2 $3 $4",
                    [
                        "8"
                    ],
                    "0$1",
                    0,
                    "$1 $2 $3 $4"
                ],
                [
                    "(\\d{3})(\\d{2})(\\d{2})(\\d{2})",
                    "$1-$2 $3 $4",
                    [
                        "[13-5]|2(?:[247-9]|5[0138])|6(?:[124-689]|7[0-2])|9(?:[125-8]|3[02-5]|4[0-3])"
                    ],
                    "0$1",
                    0,
                    "$1 $2 $3 $4"
                ],
                [
                    "(\\d{3})(\\d{2})(\\d{2})(\\d{3})",
                    "$1-$2 $3 $4",
                    [
                        "9"
                    ],
                    "0$1",
                    0,
                    "$1 $2 $3 $4"
                ],
                [
                    "(\\d{3})(\\d{2})(\\d{3})(\\d{2})(\\d{2})",
                    "$1-$2 $3 $4 $5",
                    [
                        "[26]"
                    ],
                    "0$1",
                    0,
                    "$1 $2 $3 $4 $5"
                ]
            ],
            "0"
        ],
        "SG": [
            "65",
            "0[0-3]\\d",
            "(?:(?:1\\d|8)\\d\\d|7000)\\d{7}|[3689]\\d{7}",
            [
                8,
                10,
                11
            ],
            [
                [
                    "(\\d{4})(\\d{4})",
                    "$1 $2",
                    [
                        "[369]|8(?:0[1-9]|[1-9])"
                    ]
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "8"
                    ]
                ],
                [
                    "(\\d{4})(\\d{4})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "7"
                    ]
                ],
                [
                    "(\\d{4})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "1"
                    ]
                ]
            ]
        ],
        "SH": [
            "290",
            "00",
            "(?:[256]\\d|8)\\d{3}",
            [
                4,
                5
            ],
            0,
            0,
            0,
            0,
            0,
            0,
            "[256]"
        ],
        "SI": [
            "386",
            "00|10(?:22|66|88|99)",
            "[1-7]\\d{7}|8\\d{4,7}|90\\d{4,6}",
            [
                5,
                6,
                7,
                8
            ],
            [
                [
                    "(\\d{2})(\\d{3,6})",
                    "$1 $2",
                    [
                        "8[09]|9"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{5})",
                    "$1 $2",
                    [
                        "59|8"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "[37][01]|4[0139]|51|6"
                    ],
                    "0$1"
                ],
                [
                    "(\\d)(\\d{3})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "[1-57]"
                    ],
                    "(0$1)"
                ]
            ],
            "0",
            0,
            0,
            0,
            0,
            0,
            0,
            "00"
        ],
        "SJ": [
            "47",
            "00",
            "0\\d{4}|(?:[489]\\d|79)\\d{6}",
            [
                5,
                8
            ],
            0,
            0,
            0,
            0,
            0,
            0,
            "79"
        ],
        "SK": [
            "421",
            "00",
            "[2-689]\\d{8}|[2-59]\\d{6}|[2-5]\\d{5}",
            [
                6,
                7,
                9
            ],
            [
                [
                    "(\\d)(\\d{2})(\\d{3,4})",
                    "$1 $2 $3",
                    [
                        "21"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{2})(\\d{2,3})",
                    "$1 $2 $3",
                    [
                        "[3-5][1-8]1",
                        "[3-5][1-8]1[67]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d)(\\d{3})(\\d{3})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "2"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "[689]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "[3-5]"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "SL": [
            "232",
            "00",
            "(?:[237-9]\\d|66)\\d{6}",
            [
                8
            ],
            [
                [
                    "(\\d{2})(\\d{6})",
                    "$1 $2",
                    [
                        "[236-9]"
                    ],
                    "(0$1)"
                ]
            ],
            "0"
        ],
        "SM": [
            "378",
            "00",
            "(?:0549|[5-7]\\d)\\d{6}",
            [
                8,
                10
            ],
            [
                [
                    "(\\d{2})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "[5-7]"
                    ]
                ],
                [
                    "(\\d{4})(\\d{6})",
                    "$1 $2",
                    [
                        "0"
                    ]
                ]
            ],
            0,
            0,
            "([89]\\d{5})$",
            "0549$1"
        ],
        "SN": [
            "221",
            "00",
            "(?:[378]\\d|93)\\d{7}",
            [
                9
            ],
            [
                [
                    "(\\d{3})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "8"
                    ]
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "[379]"
                    ]
                ]
            ]
        ],
        "SO": [
            "252",
            "00",
            "[346-9]\\d{8}|[12679]\\d{7}|[1-5]\\d{6}|[1348]\\d{5}",
            [
                6,
                7,
                8,
                9
            ],
            [
                [
                    "(\\d{2})(\\d{4})",
                    "$1 $2",
                    [
                        "8[125]"
                    ]
                ],
                [
                    "(\\d{6})",
                    "$1",
                    [
                        "[134]"
                    ]
                ],
                [
                    "(\\d)(\\d{6})",
                    "$1 $2",
                    [
                        "[15]|2[0-79]|3[0-46-8]|4[0-7]"
                    ]
                ],
                [
                    "(\\d)(\\d{7})",
                    "$1 $2",
                    [
                        "(?:2|90)4|[67]"
                    ]
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "[348]|64|79|90"
                    ]
                ],
                [
                    "(\\d{2})(\\d{5,7})",
                    "$1 $2",
                    [
                        "1|28|6[0-35-9]|7[67]|9[2-9]"
                    ]
                ]
            ],
            "0"
        ],
        "SR": [
            "597",
            "00",
            "(?:[2-5]|[6-9]\\d)\\d{5}",
            [
                6,
                7
            ],
            [
                [
                    "(\\d{2})(\\d{2})(\\d{2})",
                    "$1-$2-$3",
                    [
                        "56"
                    ]
                ],
                [
                    "(\\d{3})(\\d{3})",
                    "$1-$2",
                    [
                        "[2-5]"
                    ]
                ],
                [
                    "(\\d{3})(\\d{4})",
                    "$1-$2",
                    [
                        "[6-9]"
                    ]
                ]
            ]
        ],
        "SS": [
            "211",
            "00",
            "[19]\\d{8}",
            [
                9
            ],
            [
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "[19]"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "ST": [
            "239",
            "00",
            "(?:22|9\\d)\\d{5}",
            [
                7
            ],
            [
                [
                    "(\\d{3})(\\d{4})",
                    "$1 $2",
                    [
                        "[29]"
                    ]
                ]
            ]
        ],
        "SV": [
            "503",
            "00",
            "[25-7]\\d{7}|(?:80\\d|900)\\d{4}(?:\\d{4})?",
            [
                7,
                8,
                11
            ],
            [
                [
                    "(\\d{3})(\\d{4})",
                    "$1 $2",
                    [
                        "[89]"
                    ]
                ],
                [
                    "(\\d{4})(\\d{4})",
                    "$1 $2",
                    [
                        "[25-7]"
                    ]
                ],
                [
                    "(\\d{3})(\\d{4})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "[89]"
                    ]
                ]
            ]
        ],
        "SX": [
            "1",
            "011",
            "7215\\d{6}|(?:[58]\\d\\d|900)\\d{7}",
            [
                10
            ],
            0,
            "1",
            0,
            "(5\\d{6})$|1",
            "721$1",
            0,
            "721"
        ],
        "SY": [
            "963",
            "00",
            "[1-359]\\d{8}|[1-5]\\d{7}",
            [
                8,
                9
            ],
            [
                [
                    "(\\d{2})(\\d{3})(\\d{3,4})",
                    "$1 $2 $3",
                    [
                        "[1-4]|5[1-3]"
                    ],
                    "0$1",
                    1
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "[59]"
                    ],
                    "0$1",
                    1
                ]
            ],
            "0"
        ],
        "SZ": [
            "268",
            "00",
            "0800\\d{4}|(?:[237]\\d|900)\\d{6}",
            [
                8,
                9
            ],
            [
                [
                    "(\\d{4})(\\d{4})",
                    "$1 $2",
                    [
                        "[0237]"
                    ]
                ],
                [
                    "(\\d{5})(\\d{4})",
                    "$1 $2",
                    [
                        "9"
                    ]
                ]
            ]
        ],
        "TA": [
            "290",
            "00",
            "8\\d{3}",
            [
                4
            ],
            0,
            0,
            0,
            0,
            0,
            0,
            "8"
        ],
        "TC": [
            "1",
            "011",
            "(?:[58]\\d\\d|649|900)\\d{7}",
            [
                10
            ],
            0,
            "1",
            0,
            "([2-479]\\d{6})$|1",
            "649$1",
            0,
            "649"
        ],
        "TD": [
            "235",
            "00|16",
            "(?:22|[3689]\\d|77)\\d{6}",
            [
                8
            ],
            [
                [
                    "(\\d{2})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "[236-9]"
                    ]
                ]
            ],
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            "00"
        ],
        "TG": [
            "228",
            "00",
            "[279]\\d{7}",
            [
                8
            ],
            [
                [
                    "(\\d{2})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "[279]"
                    ]
                ]
            ]
        ],
        "TH": [
            "66",
            "00[1-9]",
            "(?:001800|[2-57]|[689]\\d)\\d{7}|1\\d{7,9}",
            [
                8,
                9,
                10,
                13
            ],
            [
                [
                    "(\\d)(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "2"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{3,4})",
                    "$1 $2 $3",
                    [
                        "[13-9]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{4})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "1"
                    ]
                ]
            ],
            "0"
        ],
        "TJ": [
            "992",
            "810",
            "(?:[0-57-9]\\d|66)\\d{7}",
            [
                9
            ],
            [
                [
                    "(\\d{6})(\\d)(\\d{2})",
                    "$1 $2 $3",
                    [
                        "331",
                        "3317"
                    ]
                ],
                [
                    "(\\d{3})(\\d{2})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "44[02-479]|[34]7"
                    ]
                ],
                [
                    "(\\d{4})(\\d)(\\d{4})",
                    "$1 $2 $3",
                    [
                        "3(?:[1245]|3[12])"
                    ]
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "\\d"
                    ]
                ]
            ],
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            "8~10"
        ],
        "TK": [
            "690",
            "00",
            "[2-47]\\d{3,6}",
            [
                4,
                5,
                6,
                7
            ]
        ],
        "TL": [
            "670",
            "00",
            "7\\d{7}|(?:[2-47]\\d|[89]0)\\d{5}",
            [
                7,
                8
            ],
            [
                [
                    "(\\d{3})(\\d{4})",
                    "$1 $2",
                    [
                        "[2-489]|70"
                    ]
                ],
                [
                    "(\\d{4})(\\d{4})",
                    "$1 $2",
                    [
                        "7"
                    ]
                ]
            ]
        ],
        "TM": [
            "993",
            "810",
            "(?:[1-6]\\d|71)\\d{6}",
            [
                8
            ],
            [
                [
                    "(\\d{2})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2-$3-$4",
                    [
                        "12"
                    ],
                    "(8 $1)"
                ],
                [
                    "(\\d{3})(\\d)(\\d{2})(\\d{2})",
                    "$1 $2-$3-$4",
                    [
                        "[1-5]"
                    ],
                    "(8 $1)"
                ],
                [
                    "(\\d{2})(\\d{6})",
                    "$1 $2",
                    [
                        "[67]"
                    ],
                    "8 $1"
                ]
            ],
            "8",
            0,
            0,
            0,
            0,
            0,
            0,
            "8~10"
        ],
        "TN": [
            "216",
            "00",
            "[2-57-9]\\d{7}",
            [
                8
            ],
            [
                [
                    "(\\d{2})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "[2-57-9]"
                    ]
                ]
            ]
        ],
        "TO": [
            "676",
            "00",
            "(?:0800|(?:[5-8]\\d\\d|999)\\d)\\d{3}|[2-8]\\d{4}",
            [
                5,
                7
            ],
            [
                [
                    "(\\d{2})(\\d{3})",
                    "$1-$2",
                    [
                        "[2-4]|50|6[09]|7[0-24-69]|8[05]"
                    ]
                ],
                [
                    "(\\d{4})(\\d{3})",
                    "$1 $2",
                    [
                        "0"
                    ]
                ],
                [
                    "(\\d{3})(\\d{4})",
                    "$1 $2",
                    [
                        "[5-9]"
                    ]
                ]
            ]
        ],
        "TR": [
            "90",
            "00",
            "4\\d{6}|8\\d{11,12}|(?:[2-58]\\d\\d|900)\\d{7}",
            [
                7,
                10,
                12,
                13
            ],
            [
                [
                    "(\\d{3})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "512|8[01589]|90"
                    ],
                    "0$1",
                    1
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "5(?:[0-579]|61)",
                        "5(?:[0-579]|61[06])",
                        "5(?:[0-579]|61[06]1)"
                    ],
                    "0$1",
                    1
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "[24][1-8]|3[1-9]"
                    ],
                    "(0$1)",
                    1
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{6,7})",
                    "$1 $2 $3",
                    [
                        "80"
                    ],
                    "0$1",
                    1
                ]
            ],
            "0"
        ],
        "TT": [
            "1",
            "011",
            "(?:[58]\\d\\d|900)\\d{7}",
            [
                10
            ],
            0,
            "1",
            0,
            "([2-46-8]\\d{6})$|1",
            "868$1",
            0,
            "868"
        ],
        "TV": [
            "688",
            "00",
            "(?:2|7\\d\\d|90)\\d{4}",
            [
                5,
                6,
                7
            ],
            [
                [
                    "(\\d{2})(\\d{3})",
                    "$1 $2",
                    [
                        "2"
                    ]
                ],
                [
                    "(\\d{2})(\\d{4})",
                    "$1 $2",
                    [
                        "90"
                    ]
                ],
                [
                    "(\\d{2})(\\d{5})",
                    "$1 $2",
                    [
                        "7"
                    ]
                ]
            ]
        ],
        "TW": [
            "886",
            "0(?:0[25-79]|19)",
            "[2-689]\\d{8}|7\\d{9,10}|[2-8]\\d{7}|2\\d{6}",
            [
                7,
                8,
                9,
                10,
                11
            ],
            [
                [
                    "(\\d{2})(\\d)(\\d{4})",
                    "$1 $2 $3",
                    [
                        "202"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{5})",
                    "$1 $2",
                    [
                        "826"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{2})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "83"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{2})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "82"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{3,4})",
                    "$1 $2 $3",
                    [
                        "[25]0|37|49|8[09]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d)(\\d{3,4})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "[23568]|4(?:0[02-48]|[1-478])|7[1-9]",
                        "[23568]|4(?:0[2-48]|[1-478])|(?:400|7)[1-9]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "[49]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{4})(\\d{4,5})",
                    "$1 $2 $3",
                    [
                        "7"
                    ],
                    "0$1"
                ]
            ],
            "0",
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            "#"
        ],
        "TZ": [
            "255",
            "00[056]",
            "(?:[25-8]\\d|41|90)\\d{7}",
            [
                9
            ],
            [
                [
                    "(\\d{3})(\\d{2})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "[89]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "[24]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{7})",
                    "$1 $2",
                    [
                        "5"
                    ]
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "[67]"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "UA": [
            "380",
            "00",
            "[89]\\d{9}|[3-9]\\d{8}",
            [
                9,
                10
            ],
            [
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "6[12][29]|(?:3[1-8]|4[136-8]|5[12457]|6[49])2|(?:56|65)[24]",
                        "6[12][29]|(?:35|4[1378]|5[12457]|6[49])2|(?:56|65)[24]|(?:3[1-46-8]|46)2[013-9]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{4})(\\d{5})",
                    "$1 $2",
                    [
                        "3[1-8]|4(?:[1367]|[45][6-9]|8[4-6])|5(?:[1-5]|6[0135689]|7[4-6])|6(?:[12][3-7]|[459])",
                        "3[1-8]|4(?:[1367]|[45][6-9]|8[4-6])|5(?:[1-5]|6(?:[015689]|3[02389])|7[4-6])|6(?:[12][3-7]|[459])"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "[3-7]|89|9[1-9]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3,4})",
                    "$1 $2 $3",
                    [
                        "[89]"
                    ],
                    "0$1"
                ]
            ],
            "0",
            0,
            0,
            0,
            0,
            0,
            0,
            "0~0"
        ],
        "UG": [
            "256",
            "00[057]",
            "800\\d{6}|(?:[29]0|[347]\\d)\\d{7}",
            [
                9
            ],
            [
                [
                    "(\\d{4})(\\d{5})",
                    "$1 $2",
                    [
                        "202",
                        "2024"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{6})",
                    "$1 $2",
                    [
                        "[27-9]|4(?:6[45]|[7-9])"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{7})",
                    "$1 $2",
                    [
                        "[34]"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "US": [
            "1",
            "011",
            "[2-9]\\d{9}|3\\d{6}",
            [
                10
            ],
            [
                [
                    "(\\d{3})(\\d{4})",
                    "$1-$2",
                    [
                        "310"
                    ],
                    0,
                    1
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{4})",
                    "($1) $2-$3",
                    [
                        "[2-9]"
                    ],
                    0,
                    1,
                    "$1-$2-$3"
                ]
            ],
            "1",
            0,
            0,
            0,
            0,
            0,
            [
                [
                    "(?:274[27]|(?:472|983)[2-47-9])\\d{6}|(?:2(?:0[1-35-9]|1[02-9]|2[03-57-9]|3[1459]|4[08]|5[1-46]|6[0279]|7[0269]|8[13])|3(?:0[1-57-9]|1[02-9]|2[013-79]|3[0-24679]|4[167]|5[0-3]|6[01349]|8[056])|4(?:0[124-9]|1[02-579]|2[3-5]|3[0245]|4[023578]|58|6[349]|7[0589]|8[04])|5(?:0[1-57-9]|1[0235-8]|20|3[0149]|4[01]|5[179]|6[1-47]|7[0-5]|8[0256])|6(?:0[1-35-9]|1[024-9]|2[03689]|3[016]|4[0156]|5[01679]|6[0-279]|78|8[0-269])|7(?:0[1-46-8]|1[2-9]|2[04-8]|3[0-2478]|4[0378]|5[47]|6[02359]|7[0-59]|8[156])|8(?:0[1-68]|1[02-8]|2[0168]|3[0-2589]|4[03578]|5[046-9]|6[02-5]|7[028])|9(?:0[1346-9]|1[02-9]|2[0589]|3[0146-8]|4[01357-9]|5[12469]|7[0-3589]|8[04-69]))[2-9]\\d{6}"
                ],
                [
                    ""
                ],
                [
                    "8(?:00|33|44|55|66|77|88)[2-9]\\d{6}"
                ],
                [
                    "900[2-9]\\d{6}"
                ],
                [
                    "52(?:3(?:[2-46-9][02-9]\\d|5(?:[02-46-9]\\d|5[0-46-9]))|4(?:[2-478][02-9]\\d|5(?:[034]\\d|2[024-9]|5[0-46-9])|6(?:0[1-9]|[2-9]\\d)|9(?:[05-9]\\d|2[0-5]|49)))\\d{4}|52[34][2-9]1[02-9]\\d{4}|5(?:00|2[125-9]|3[23]|44|66|77|88)[2-9]\\d{6}"
                ]
            ]
        ],
        "UY": [
            "598",
            "0(?:0|1[3-9]\\d)",
            "0004\\d{2,9}|[1249]\\d{7}|2\\d{3,4}|(?:[49]\\d|80)\\d{5}",
            [
                4,
                5,
                6,
                7,
                8,
                9,
                10,
                11,
                12,
                13
            ],
            [
                [
                    "(\\d{4,5})",
                    "$1",
                    [
                        "21"
                    ]
                ],
                [
                    "(\\d{3})(\\d{3,4})",
                    "$1 $2",
                    [
                        "0"
                    ]
                ],
                [
                    "(\\d{3})(\\d{4})",
                    "$1 $2",
                    [
                        "[49]0|8"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "9"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{4})(\\d{4})",
                    "$1 $2",
                    [
                        "[124]"
                    ]
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{2,4})",
                    "$1 $2 $3",
                    [
                        "0"
                    ]
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})(\\d{2,4})",
                    "$1 $2 $3 $4",
                    [
                        "0"
                    ]
                ]
            ],
            "0",
            0,
            0,
            0,
            0,
            0,
            0,
            "00",
            " int. "
        ],
        "UZ": [
            "998",
            "00",
            "(?:20|33|[5-9]\\d)\\d{7}",
            [
                9
            ],
            [
                [
                    "(\\d{2})(\\d{3})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "[235-9]"
                    ]
                ]
            ]
        ],
        "VA": [
            "39",
            "00",
            "0\\d{5,10}|3[0-8]\\d{7,10}|55\\d{8}|8\\d{5}(?:\\d{2,4})?|(?:1\\d|39)\\d{7,8}",
            [
                6,
                7,
                8,
                9,
                10,
                11,
                12
            ],
            0,
            0,
            0,
            0,
            0,
            0,
            "06698"
        ],
        "VC": [
            "1",
            "011",
            "(?:[58]\\d\\d|784|900)\\d{7}",
            [
                10
            ],
            0,
            "1",
            0,
            "([2-7]\\d{6})$|1",
            "784$1",
            0,
            "784"
        ],
        "VE": [
            "58",
            "00",
            "[68]00\\d{7}|(?:[24]\\d|[59]0)\\d{8}",
            [
                10
            ],
            [
                [
                    "(\\d{3})(\\d{7})",
                    "$1-$2",
                    [
                        "[24-689]"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "VG": [
            "1",
            "011",
            "(?:284|[58]\\d\\d|900)\\d{7}",
            [
                10
            ],
            0,
            "1",
            0,
            "([2-578]\\d{6})$|1",
            "284$1",
            0,
            "284"
        ],
        "VI": [
            "1",
            "011",
            "[58]\\d{9}|(?:34|90)0\\d{7}",
            [
                10
            ],
            0,
            "1",
            0,
            "([2-9]\\d{6})$|1",
            "340$1",
            0,
            "340"
        ],
        "VN": [
            "84",
            "00",
            "[12]\\d{9}|[135-9]\\d{8}|[16]\\d{7}|[16-8]\\d{6}",
            [
                7,
                8,
                9,
                10
            ],
            [
                [
                    "(\\d{2})(\\d{5})",
                    "$1 $2",
                    [
                        "80"
                    ],
                    "0$1",
                    1
                ],
                [
                    "(\\d{4})(\\d{4,6})",
                    "$1 $2",
                    [
                        "1"
                    ],
                    0,
                    1
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "6"
                    ],
                    "0$1",
                    1
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "[357-9]"
                    ],
                    "0$1",
                    1
                ],
                [
                    "(\\d{2})(\\d{4})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "2[48]"
                    ],
                    "0$1",
                    1
                ],
                [
                    "(\\d{3})(\\d{4})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "2"
                    ],
                    "0$1",
                    1
                ]
            ],
            "0"
        ],
        "VU": [
            "678",
            "00",
            "[57-9]\\d{6}|(?:[238]\\d|48)\\d{3}",
            [
                5,
                7
            ],
            [
                [
                    "(\\d{3})(\\d{4})",
                    "$1 $2",
                    [
                        "[57-9]"
                    ]
                ]
            ]
        ],
        "WF": [
            "681",
            "00",
            "(?:40|72|8\\d{4})\\d{4}|[89]\\d{5}",
            [
                6,
                9
            ],
            [
                [
                    "(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3",
                    [
                        "[47-9]"
                    ]
                ],
                [
                    "(\\d{3})(\\d{2})(\\d{2})(\\d{2})",
                    "$1 $2 $3 $4",
                    [
                        "8"
                    ]
                ]
            ]
        ],
        "WS": [
            "685",
            "0",
            "(?:[2-6]|8\\d{5})\\d{4}|[78]\\d{6}|[68]\\d{5}",
            [
                5,
                6,
                7,
                10
            ],
            [
                [
                    "(\\d{5})",
                    "$1",
                    [
                        "[2-5]|6[1-9]"
                    ]
                ],
                [
                    "(\\d{3})(\\d{3,7})",
                    "$1 $2",
                    [
                        "[68]"
                    ]
                ],
                [
                    "(\\d{2})(\\d{5})",
                    "$1 $2",
                    [
                        "7"
                    ]
                ]
            ]
        ],
        "XK": [
            "383",
            "00",
            "2\\d{7,8}|3\\d{7,11}|(?:4\\d\\d|[89]00)\\d{5}",
            [
                8,
                9,
                10,
                11,
                12
            ],
            [
                [
                    "(\\d{3})(\\d{5})",
                    "$1 $2",
                    [
                        "[89]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "[2-4]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "2|39"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{7,10})",
                    "$1 $2",
                    [
                        "3"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "YE": [
            "967",
            "00",
            "(?:1|7\\d)\\d{7}|[1-7]\\d{6}",
            [
                7,
                8,
                9
            ],
            [
                [
                    "(\\d)(\\d{3})(\\d{3,4})",
                    "$1 $2 $3",
                    [
                        "[1-6]|7(?:[24-6]|8[0-7])"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "7"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "YT": [
            "262",
            "00",
            "(?:639\\d|7093)\\d{5}|(?:26|80|9\\d)\\d{7}",
            [
                9
            ],
            0,
            "0",
            0,
            0,
            0,
            0,
            0,
            [
                [
                    "26(?:89\\d|9(?:0[0-467]|15|5[0-4]|6\\d|[78]0))\\d{4}"
                ],
                [
                    "(?:639(?:0[0-79]|1[019]|[267]\\d|3[09]|40|5[05-9]|9[04-79])|7093[5-7])\\d{4}"
                ],
                [
                    "80\\d{7}"
                ],
                0,
                0,
                0,
                0,
                0,
                [
                    "9(?:(?:39|47)8[01]|769\\d)\\d{4}"
                ]
            ]
        ],
        "ZA": [
            "27",
            "00",
            "[1-79]\\d{8}|8\\d{4,9}",
            [
                5,
                6,
                7,
                8,
                9,
                10
            ],
            [
                [
                    "(\\d{2})(\\d{3,4})",
                    "$1 $2",
                    [
                        "8[1-4]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{2,3})",
                    "$1 $2 $3",
                    [
                        "8[1-4]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "860"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "[1-9]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "8"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "ZM": [
            "260",
            "00",
            "800\\d{6}|(?:21|[579]\\d|63)\\d{7}",
            [
                9
            ],
            [
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "[28]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{7})",
                    "$1 $2",
                    [
                        "[579]"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ],
        "ZW": [
            "263",
            "00",
            "2(?:[0-57-9]\\d{6,8}|6[0-24-9]\\d{6,7})|[38]\\d{9}|[35-8]\\d{8}|[3-6]\\d{7}|[1-689]\\d{6}|[1-3569]\\d{5}|[1356]\\d{4}",
            [
                5,
                6,
                7,
                8,
                9,
                10
            ],
            [
                [
                    "(\\d{3})(\\d{3,5})",
                    "$1 $2",
                    [
                        "2(?:0[45]|2[278]|[49]8)|3(?:[09]8|17)|6(?:[29]8|37|75)|[23][78]|(?:33|5[15]|6[68])[78]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d)(\\d{3})(\\d{2,4})",
                    "$1 $2 $3",
                    [
                        "[49]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{4})",
                    "$1 $2",
                    [
                        "80"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{7})",
                    "$1 $2",
                    [
                        "24|8[13-59]|(?:2[05-79]|39|5[45]|6[15-8])2",
                        "2(?:02[014]|4|[56]20|[79]2)|392|5(?:42|525)|6(?:[16-8]21|52[013])|8[13-59]"
                    ],
                    "(0$1)"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "7"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3,4})",
                    "$1 $2 $3",
                    [
                        "2(?:1[39]|2[0157]|[378]|[56][14])|3(?:12|29)",
                        "2(?:1[39]|2[0157]|[378]|[56][14])|3(?:123|29)"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{4})(\\d{6})",
                    "$1 $2",
                    [
                        "8"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3,5})",
                    "$1 $2",
                    [
                        "1|2(?:0[0-36-9]|12|29|[56])|3(?:1[0-689]|[24-6])|5(?:[0236-9]|1[2-4])|6(?:[013-59]|7[0-46-9])|(?:33|55|6[68])[0-69]|(?:29|3[09]|62)[0-79]"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{2})(\\d{3})(\\d{3,4})",
                    "$1 $2 $3",
                    [
                        "29[013-9]|39|54"
                    ],
                    "0$1"
                ],
                [
                    "(\\d{4})(\\d{3,5})",
                    "$1 $2",
                    [
                        "(?:25|54)8",
                        "258|5483"
                    ],
                    "0$1"
                ]
            ],
            "0"
        ]
    },
    "nonGeographic": {
        "800": [
            "800",
            0,
            "(?:00|[1-9]\\d)\\d{6}",
            [
                8
            ],
            [
                [
                    "(\\d{4})(\\d{4})",
                    "$1 $2",
                    [
                        "\\d"
                    ]
                ]
            ],
            0,
            0,
            0,
            0,
            0,
            0,
            [
                0,
                0,
                [
                    "(?:00|[1-9]\\d)\\d{6}"
                ]
            ]
        ],
        "808": [
            "808",
            0,
            "[1-9]\\d{7}",
            [
                8
            ],
            [
                [
                    "(\\d{4})(\\d{4})",
                    "$1 $2",
                    [
                        "[1-9]"
                    ]
                ]
            ],
            0,
            0,
            0,
            0,
            0,
            0,
            [
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                [
                    "[1-9]\\d{7}"
                ]
            ]
        ],
        "870": [
            "870",
            0,
            "7\\d{11}|[235-7]\\d{8}",
            [
                9,
                12
            ],
            [
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "[235-7]"
                    ]
                ]
            ],
            0,
            0,
            0,
            0,
            0,
            0,
            [
                0,
                [
                    "(?:[356]|774[45])\\d{8}|7[6-8]\\d{7}"
                ],
                0,
                0,
                0,
                0,
                0,
                0,
                [
                    "2\\d{8}",
                    [
                        9
                    ]
                ]
            ]
        ],
        "878": [
            "878",
            0,
            "10\\d{10}",
            [
                12
            ],
            [
                [
                    "(\\d{2})(\\d{5})(\\d{5})",
                    "$1 $2 $3",
                    [
                        "1"
                    ]
                ]
            ],
            0,
            0,
            0,
            0,
            0,
            0,
            [
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                [
                    "10\\d{10}"
                ]
            ]
        ],
        "881": [
            "881",
            0,
            "6\\d{9}|[0-36-9]\\d{8}",
            [
                9,
                10
            ],
            [
                [
                    "(\\d)(\\d{3})(\\d{5})",
                    "$1 $2 $3",
                    [
                        "[0-37-9]"
                    ]
                ],
                [
                    "(\\d)(\\d{3})(\\d{5,6})",
                    "$1 $2 $3",
                    [
                        "6"
                    ]
                ]
            ],
            0,
            0,
            0,
            0,
            0,
            0,
            [
                0,
                [
                    "6\\d{9}|[0-36-9]\\d{8}"
                ]
            ]
        ],
        "882": [
            "882",
            0,
            "[13]\\d{6}(?:\\d{2,5})?|[19]\\d{7}|(?:[25]\\d\\d|4)\\d{7}(?:\\d{2})?",
            [
                7,
                8,
                9,
                10,
                11,
                12
            ],
            [
                [
                    "(\\d{2})(\\d{5})",
                    "$1 $2",
                    [
                        "16|342"
                    ]
                ],
                [
                    "(\\d{2})(\\d{6})",
                    "$1 $2",
                    [
                        "49"
                    ]
                ],
                [
                    "(\\d{2})(\\d{2})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "1[36]|9"
                    ]
                ],
                [
                    "(\\d{2})(\\d{4})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "3[23]"
                    ]
                ],
                [
                    "(\\d{2})(\\d{3,4})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "16"
                    ]
                ],
                [
                    "(\\d{2})(\\d{4})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "10|23|3(?:[15]|4[57])|4|5[12]"
                    ]
                ],
                [
                    "(\\d{3})(\\d{4})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "34"
                    ]
                ],
                [
                    "(\\d{2})(\\d{4,5})(\\d{5})",
                    "$1 $2 $3",
                    [
                        "[1-35]"
                    ]
                ]
            ],
            0,
            0,
            0,
            0,
            0,
            0,
            [
                0,
                [
                    "342\\d{4}|(?:337|49)\\d{6}|(?:3(?:2|47|7\\d{3})|5(?:0\\d{3}|2[0-2]))\\d{7}",
                    [
                        7,
                        8,
                        9,
                        10,
                        12
                    ]
                ],
                0,
                0,
                0,
                [
                    "348[57]\\d{7}",
                    [
                        11
                    ]
                ],
                0,
                0,
                [
                    "1(?:3(?:0[0347]|[13][0139]|2[035]|4[013568]|6[0459]|7[06]|8[15-8]|9[0689])\\d{4}|6\\d{5,10})|(?:345\\d|9[89])\\d{6}|(?:10|2(?:3|85\\d)|3(?:[15]|[69]\\d\\d)|4[15-8]|51)\\d{8}"
                ]
            ]
        ],
        "883": [
            "883",
            0,
            "(?:[1-4]\\d|51)\\d{6,10}",
            [
                8,
                9,
                10,
                11,
                12
            ],
            [
                [
                    "(\\d{3})(\\d{3})(\\d{2,8})",
                    "$1 $2 $3",
                    [
                        "[14]|2[24-689]|3[02-689]|51[24-9]"
                    ]
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3",
                    [
                        "510"
                    ]
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "21"
                    ]
                ],
                [
                    "(\\d{4})(\\d{4})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "51[13]"
                    ]
                ],
                [
                    "(\\d{3})(\\d{3})(\\d{3})(\\d{3})",
                    "$1 $2 $3 $4",
                    [
                        "[235]"
                    ]
                ]
            ],
            0,
            0,
            0,
            0,
            0,
            0,
            [
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                [
                    "(?:2(?:00\\d\\d|10)|(?:370[1-9]|51\\d0)\\d)\\d{7}|51(?:00\\d{5}|[24-9]0\\d{4,7})|(?:1[0-79]|2[24-689]|3[02-689]|4[0-4])0\\d{5,9}"
                ]
            ]
        ],
        "888": [
            "888",
            0,
            "\\d{11}",
            [
                11
            ],
            [
                [
                    "(\\d{3})(\\d{3})(\\d{5})",
                    "$1 $2 $3"
                ]
            ],
            0,
            0,
            0,
            0,
            0,
            0,
            [
                0,
                0,
                0,
                0,
                0,
                0,
                [
                    "\\d{11}"
                ]
            ]
        ],
        "979": [
            "979",
            0,
            "[1359]\\d{8}",
            [
                9
            ],
            [
                [
                    "(\\d)(\\d{4})(\\d{4})",
                    "$1 $2 $3",
                    [
                        "[1359]"
                    ]
                ]
            ],
            0,
            0,
            0,
            0,
            0,
            0,
            [
                0,
                0,
                0,
                [
                    "[1359]\\d{8}"
                ]
            ]
        ]
    }
};
}),
"[project]/node_modules/libphonenumber-js/min/exports/withMetadataArgument.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>withMetadataArgument
]);
// Importing from a ".js" file is a workaround for Node.js "ES Modules"
// importing system which is even uncapable of importing "*.json" files.
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$metadata$2e$min$2e$json$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/metadata.min.json.js [app-client] (ecmascript)");
;
function withMetadataArgument(func, _arguments) {
    var args = Array.prototype.slice.call(_arguments);
    args.push(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$metadata$2e$min$2e$json$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
    return func.apply(this, args);
}
}),
"[project]/node_modules/libphonenumber-js/es6/helpers/isObject.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>isObject
]);
var objectConstructor = {}.constructor;
function isObject(object) {
    return object !== undefined && object !== null && object.constructor === objectConstructor;
}
}),
"[project]/node_modules/libphonenumber-js/es6/normalizeArguments.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>normalizeArguments
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$isObject$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/isObject.js [app-client] (ecmascript)");
function _typeof(o) {
    "@babel/helpers - typeof";
    return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
        return typeof o;
    } : function(o) {
        return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
    }, _typeof(o);
}
function ownKeys(e, r) {
    var t = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        r && (o = o.filter(function(r) {
            return Object.getOwnPropertyDescriptor(e, r).enumerable;
        })), t.push.apply(t, o);
    }
    return t;
}
function _objectSpread(e) {
    for(var r = 1; r < arguments.length; r++){
        var t = null != arguments[r] ? arguments[r] : {};
        r % 2 ? ownKeys(Object(t), !0).forEach(function(r) {
            _defineProperty(e, r, t[r]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
            Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
        });
    }
    return e;
}
function _defineProperty(e, r, t) {
    return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
        value: t,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[r] = t, e;
}
function _toPropertyKey(t) {
    var i = _toPrimitive(t, "string");
    return "symbol" == _typeof(i) ? i : i + "";
}
function _toPrimitive(t, r) {
    if ("object" != _typeof(t) || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
        var i = e.call(t, r || "default");
        if ("object" != _typeof(i)) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
}
function _slicedToArray(r, e) {
    return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest();
}
function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(r, a) {
    if (r) {
        if ("string" == typeof r) return _arrayLikeToArray(r, a);
        var t = ({}).toString.call(r).slice(8, -1);
        return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
    }
}
function _arrayLikeToArray(r, a) {
    (null == a || a > r.length) && (a = r.length);
    for(var e = 0, n = Array(a); e < a; e++)n[e] = r[e];
    return n;
}
function _iterableToArrayLimit(r, l) {
    var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
    if (null != t) {
        var e, n, i, u, a = [], f = !0, o = !1;
        try {
            if (i = (t = t.call(r)).next, 0 === l) {
                if (Object(t) !== t) return;
                f = !1;
            } else for(; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);
        } catch (r) {
            o = !0, n = r;
        } finally{
            try {
                if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return;
            } finally{
                if (o) throw n;
            }
        }
        return a;
    }
}
function _arrayWithHoles(r) {
    if (Array.isArray(r)) return r;
}
;
function normalizeArguments(args) {
    var _Array$prototype$slic = Array.prototype.slice.call(args), _Array$prototype$slic2 = _slicedToArray(_Array$prototype$slic, 4), arg_1 = _Array$prototype$slic2[0], arg_2 = _Array$prototype$slic2[1], arg_3 = _Array$prototype$slic2[2], arg_4 = _Array$prototype$slic2[3];
    var text;
    var options;
    var metadata;
    // If the phone number is passed as a string.
    // `parsePhoneNumber('88005553535', ...)`.
    if (typeof arg_1 === 'string') {
        text = arg_1;
    } else throw new TypeError('A text for parsing must be a string.');
    // If "default country" argument is being passed then move it to `options`.
    // `parsePhoneNumber('88005553535', 'RU', [options], metadata)`.
    if (!arg_2 || typeof arg_2 === 'string') {
        if (arg_4) {
            options = arg_3;
            metadata = arg_4;
        } else {
            options = undefined;
            metadata = arg_3;
        }
        if (arg_2) {
            options = _objectSpread({
                defaultCountry: arg_2
            }, options);
        }
    } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$isObject$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(arg_2)) {
        if (arg_3) {
            options = arg_2;
            metadata = arg_3;
        } else {
            metadata = arg_2;
        }
    } else throw new Error("Invalid second argument: ".concat(arg_2));
    return {
        text: text,
        options: options,
        metadata: metadata
    };
}
}),
"[project]/node_modules/libphonenumber-js/es6/constants.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// The minimum length of the national significant number.
__turbopack_context__.s([
    "MAX_LENGTH_COUNTRY_CODE",
    ()=>MAX_LENGTH_COUNTRY_CODE,
    "MAX_LENGTH_FOR_NSN",
    ()=>MAX_LENGTH_FOR_NSN,
    "MIN_LENGTH_FOR_NSN",
    ()=>MIN_LENGTH_FOR_NSN,
    "PLUS_CHARS",
    ()=>PLUS_CHARS,
    "VALID_DIGITS",
    ()=>VALID_DIGITS,
    "VALID_PUNCTUATION",
    ()=>VALID_PUNCTUATION,
    "WHITESPACE",
    ()=>WHITESPACE
]);
var MIN_LENGTH_FOR_NSN = 2;
var MAX_LENGTH_FOR_NSN = 17;
var MAX_LENGTH_COUNTRY_CODE = 3;
var VALID_DIGITS = "0-9\uFF10-\uFF19\u0660-\u0669\u06F0-\u06F9";
// `DASHES` will be right after the opening square bracket of the "character class"
var DASHES = "-\u2010-\u2015\u2212\u30FC\uFF0D";
var SLASHES = "\uFF0F/";
var DOTS = "\uFF0E.";
var WHITESPACE = " \xA0\xAD\u200B\u2060\u3000";
var BRACKETS = "()\uFF08\uFF09\uFF3B\uFF3D\\[\\]";
// export const OPENING_BRACKETS = '(\uFF08\uFF3B\\\['
var TILDES = "~\u2053\u223C\uFF5E";
var VALID_PUNCTUATION = "".concat(DASHES).concat(SLASHES).concat(DOTS).concat(WHITESPACE).concat(BRACKETS).concat(TILDES);
var PLUS_CHARS = "+\uFF0B"; // const LEADING_PLUS_CHARS_PATTERN = new RegExp('^[' + PLUS_CHARS + ']+')
}),
"[project]/node_modules/libphonenumber-js/es6/ParseError.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ParseError
]);
function _typeof(o) {
    "@babel/helpers - typeof";
    return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
        return typeof o;
    } : function(o) {
        return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
    }, _typeof(o);
}
function _defineProperties(e, r) {
    for(var t = 0; t < r.length; t++){
        var o = r[t];
        o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, _toPropertyKey(o.key), o);
    }
}
function _createClass(e, r, t) {
    return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", {
        writable: !1
    }), e;
}
function _toPropertyKey(t) {
    var i = _toPrimitive(t, "string");
    return "symbol" == _typeof(i) ? i : i + "";
}
function _toPrimitive(t, r) {
    if ("object" != _typeof(t) || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
        var i = e.call(t, r || "default");
        if ("object" != _typeof(i)) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
}
function _classCallCheck(a, n) {
    if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function");
}
function _callSuper(t, o, e) {
    return o = _getPrototypeOf(o), _possibleConstructorReturn(t, _isNativeReflectConstruct() ? Reflect.construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e));
}
function _possibleConstructorReturn(t, e) {
    if (e && ("object" == _typeof(e) || "function" == typeof e)) return e;
    if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined");
    return _assertThisInitialized(t);
}
function _assertThisInitialized(e) {
    if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return e;
}
function _inherits(t, e) {
    if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
    t.prototype = Object.create(e && e.prototype, {
        constructor: {
            value: t,
            writable: !0,
            configurable: !0
        }
    }), Object.defineProperty(t, "prototype", {
        writable: !1
    }), e && _setPrototypeOf(t, e);
}
function _wrapNativeSuper(t) {
    var r = "function" == typeof Map ? new Map() : void 0;
    return _wrapNativeSuper = function _wrapNativeSuper(t) {
        if (null === t || !_isNativeFunction(t)) return t;
        if ("function" != typeof t) throw new TypeError("Super expression must either be null or a function");
        if (void 0 !== r) {
            if (r.has(t)) return r.get(t);
            r.set(t, Wrapper);
        }
        function Wrapper() {
            return _construct(t, arguments, _getPrototypeOf(this).constructor);
        }
        return Wrapper.prototype = Object.create(t.prototype, {
            constructor: {
                value: Wrapper,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), _setPrototypeOf(Wrapper, t);
    }, _wrapNativeSuper(t);
}
function _construct(t, e, r) {
    if (_isNativeReflectConstruct()) return Reflect.construct.apply(null, arguments);
    var o = [
        null
    ];
    o.push.apply(o, e);
    var p = new (t.bind.apply(t, o))();
    return r && _setPrototypeOf(p, r.prototype), p;
}
function _isNativeReflectConstruct() {
    try {
        var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
    } catch (t) {}
    return (_isNativeReflectConstruct = function _isNativeReflectConstruct() {
        return !!t;
    })();
}
function _isNativeFunction(t) {
    try {
        return -1 !== Function.toString.call(t).indexOf("[native code]");
    } catch (n) {
        return "function" == typeof t;
    }
}
function _setPrototypeOf(t, e) {
    return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
        return t.__proto__ = e, t;
    }, _setPrototypeOf(t, e);
}
function _getPrototypeOf(t) {
    return _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(t) {
        return t.__proto__ || Object.getPrototypeOf(t);
    }, _getPrototypeOf(t);
}
// https://stackoverflow.com/a/46971044/970769
// "Breaking changes in Typescript 2.1"
// "Extending built-ins like Error, Array, and Map may no longer work."
// "As a recommendation, you can manually adjust the prototype immediately after any super(...) calls."
// https://github.com/Microsoft/TypeScript-wiki/blob/main/Breaking-Changes.md#extending-built-ins-like-error-array-and-map-may-no-longer-work
var ParseError = /*#__PURE__*/ function(_Error) {
    function ParseError(code) {
        var _this;
        _classCallCheck(this, ParseError);
        _this = _callSuper(this, ParseError, [
            code
        ]);
        // Set the prototype explicitly.
        // Any subclass of FooError will have to manually set the prototype as well.
        Object.setPrototypeOf(_this, ParseError.prototype);
        _this.name = _this.constructor.name;
        return _this;
    }
    _inherits(ParseError, _Error);
    return _createClass(ParseError);
}(/*#__PURE__*/ _wrapNativeSuper(Error));
;
}),
"[project]/node_modules/libphonenumber-js/es6/tools/semver-compare.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Copy-pasted from:
// https://github.com/substack/semver-compare/blob/master/index.js
//
// Inlining this function because some users reported issues with
// importing from `semver-compare` in a browser with ES6 "native" modules.
//
// Fixes `semver-compare` not being able to compare versions with alpha/beta/etc "tags".
// https://github.com/catamphetamine/libphonenumber-js/issues/381
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
function __TURBOPACK__default__export__(a, b) {
    a = a.split('-');
    b = b.split('-');
    var pa = a[0].split('.');
    var pb = b[0].split('.');
    for(var i = 0; i < 3; i++){
        var na = Number(pa[i]);
        var nb = Number(pb[i]);
        if (na > nb) return 1;
        if (nb > na) return -1;
        if (!isNaN(na) && isNaN(nb)) return 1;
        if (isNaN(na) && !isNaN(nb)) return -1;
    }
    if (a[1] && b[1]) {
        return a[1] > b[1] ? 1 : a[1] < b[1] ? -1 : 0;
    }
    return !a[1] && b[1] ? 1 : a[1] && !b[1] ? -1 : 0;
}
}),
"[project]/node_modules/libphonenumber-js/es6/metadata.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Metadata,
    "getCountryCallingCode",
    ()=>getCountryCallingCode,
    "getExtPrefix",
    ()=>getExtPrefix,
    "isSupportedCountry",
    ()=>isSupportedCountry,
    "validateMetadata",
    ()=>validateMetadata
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$tools$2f$semver$2d$compare$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/tools/semver-compare.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$isObject$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/isObject.js [app-client] (ecmascript)");
function _readOnlyError(r) {
    throw new TypeError('"' + r + '" is read-only');
}
function _typeof(o) {
    "@babel/helpers - typeof";
    return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
        return typeof o;
    } : function(o) {
        return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
    }, _typeof(o);
}
function _classCallCheck(a, n) {
    if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties(e, r) {
    for(var t = 0; t < r.length; t++){
        var o = r[t];
        o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, _toPropertyKey(o.key), o);
    }
}
function _createClass(e, r, t) {
    return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", {
        writable: !1
    }), e;
}
function _toPropertyKey(t) {
    var i = _toPrimitive(t, "string");
    return "symbol" == _typeof(i) ? i : i + "";
}
function _toPrimitive(t, r) {
    if ("object" != _typeof(t) || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
        var i = e.call(t, r || "default");
        if ("object" != _typeof(i)) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
}
;
;
// Added "possibleLengths" and renamed
// "country_phone_code_to_countries" to "country_calling_codes".
var V2 = '1.0.18';
// Added "idd_prefix" and "default_idd_prefix".
var V3 = '1.2.0';
// Moved `001` country code to "nonGeographic" section of metadata.
var V4 = '1.7.35';
var DEFAULT_EXT_PREFIX = ' ext. ';
var CALLING_CODE_REG_EXP = /^\d+$/;
/**
 * See: https://gitlab.com/catamphetamine/libphonenumber-js/blob/master/METADATA.md
 */ var Metadata = /*#__PURE__*/ function() {
    function Metadata(metadata) {
        _classCallCheck(this, Metadata);
        validateMetadata(metadata);
        this.metadata = metadata;
        setVersion.call(this, metadata);
    }
    return _createClass(Metadata, [
        {
            key: "getCountries",
            value: function getCountries() {
                return Object.keys(this.metadata.countries).filter(function(_) {
                    return _ !== '001';
                });
            }
        },
        {
            key: "getCountryMetadata",
            value: function getCountryMetadata(countryCode) {
                return this.metadata.countries[countryCode];
            }
        },
        {
            key: "nonGeographic",
            value: function nonGeographic() {
                if (this.v1 || this.v2 || this.v3) return;
                // `nonGeographical` was a typo.
                // It's present in metadata generated from `1.7.35` to `1.7.37`.
                // The test case could be found by searching for "nonGeographical".
                return this.metadata.nonGeographic || this.metadata.nonGeographical;
            }
        },
        {
            key: "hasCountry",
            value: function hasCountry(country) {
                return this.getCountryMetadata(country) !== undefined;
            }
        },
        {
            key: "hasCallingCode",
            value: function hasCallingCode(callingCode) {
                if (this.getCountryCodesForCallingCode(callingCode)) {
                    return true;
                }
                if (this.nonGeographic()) {
                    if (this.nonGeographic()[callingCode]) {
                        return true;
                    }
                } else {
                    // A hacky workaround for old custom metadata (generated before V4).
                    var countryCodes = this.countryCallingCodes()[callingCode];
                    if (countryCodes && countryCodes.length === 1 && countryCodes[0] === '001') {
                        return true;
                    }
                }
            }
        },
        {
            key: "isNonGeographicCallingCode",
            value: function isNonGeographicCallingCode(callingCode) {
                if (this.nonGeographic()) {
                    return this.nonGeographic()[callingCode] ? true : false;
                } else {
                    return this.getCountryCodesForCallingCode(callingCode) ? false : true;
                }
            }
        },
        {
            key: "country",
            value: function country(countryCode) {
                return this.selectNumberingPlan(countryCode);
            }
        },
        {
            key: "selectNumberingPlan",
            value: function selectNumberingPlan(countryCode, callingCode) {
                // Supports just passing `callingCode` as the first argument.
                if (countryCode && CALLING_CODE_REG_EXP.test(countryCode)) {
                    callingCode = countryCode;
                    countryCode = null;
                }
                if (countryCode && countryCode !== '001') {
                    if (!this.hasCountry(countryCode)) {
                        throw new Error("Unknown country: ".concat(countryCode));
                    }
                    this.numberingPlan = new NumberingPlan(this.getCountryMetadata(countryCode), this);
                } else if (callingCode) {
                    if (!this.hasCallingCode(callingCode)) {
                        throw new Error("Unknown calling code: ".concat(callingCode));
                    }
                    this.numberingPlan = new NumberingPlan(this.getNumberingPlanMetadata(callingCode), this);
                } else {
                    this.numberingPlan = undefined;
                }
                return this;
            }
        },
        {
            key: "getCountryCodesForCallingCode",
            value: function getCountryCodesForCallingCode(callingCode) {
                var countryCodes = this.countryCallingCodes()[callingCode];
                if (countryCodes) {
                    // Metadata before V4 included "non-geographic entity" calling codes
                    // inside `country_calling_codes` (for example, `"881":["001"]`).
                    // Now the semantics of `country_calling_codes` has changed:
                    // it's specifically for "countries" now.
                    // Older versions of custom metadata will simply skip parsing
                    // "non-geographic entity" phone numbers with new versions
                    // of this library: it's not considered a bug,
                    // because such numbers are extremely rare,
                    // and developers extremely rarely use custom metadata.
                    if (countryCodes.length === 1 && countryCodes[0].length === 3) {
                        return;
                    }
                    return countryCodes;
                }
            }
        },
        {
            key: "getCountryCodeForCallingCode",
            value: function getCountryCodeForCallingCode(callingCode) {
                var countryCodes = this.getCountryCodesForCallingCode(callingCode);
                if (countryCodes) {
                    return countryCodes[0];
                }
            }
        },
        {
            key: "getNumberingPlanMetadata",
            value: function getNumberingPlanMetadata(callingCode) {
                var countryCode = this.getCountryCodeForCallingCode(callingCode);
                if (countryCode) {
                    return this.getCountryMetadata(countryCode);
                }
                if (this.nonGeographic()) {
                    var metadata = this.nonGeographic()[callingCode];
                    if (metadata) {
                        return metadata;
                    }
                } else {
                    // A hacky workaround for old custom metadata (generated before V4).
                    // In that metadata, there was no concept of "non-geographic" metadata
                    // so metadata for `001` country code was stored along with other countries.
                    // The test case can be found by searching for:
                    // "should work around `nonGeographic` metadata not existing".
                    var countryCodes = this.countryCallingCodes()[callingCode];
                    if (countryCodes && countryCodes.length === 1 && countryCodes[0] === '001') {
                        return this.metadata.countries['001'];
                    }
                }
            }
        },
        {
            key: "countryCallingCode",
            value: function countryCallingCode() {
                return this.numberingPlan.callingCode();
            }
        },
        {
            key: "IDDPrefix",
            value: function IDDPrefix() {
                return this.numberingPlan.IDDPrefix();
            }
        },
        {
            key: "defaultIDDPrefix",
            value: function defaultIDDPrefix() {
                return this.numberingPlan.defaultIDDPrefix();
            }
        },
        {
            key: "nationalNumberPattern",
            value: function nationalNumberPattern() {
                return this.numberingPlan.nationalNumberPattern();
            }
        },
        {
            key: "possibleLengths",
            value: function possibleLengths() {
                return this.numberingPlan.possibleLengths();
            }
        },
        {
            key: "formats",
            value: function formats() {
                return this.numberingPlan.formats();
            }
        },
        {
            key: "nationalPrefixForParsing",
            value: function nationalPrefixForParsing() {
                return this.numberingPlan.nationalPrefixForParsing();
            }
        },
        {
            key: "nationalPrefixTransformRule",
            value: function nationalPrefixTransformRule() {
                return this.numberingPlan.nationalPrefixTransformRule();
            }
        },
        {
            key: "leadingDigits",
            value: function leadingDigits() {
                return this.numberingPlan.leadingDigits();
            }
        },
        {
            key: "hasTypes",
            value: function hasTypes() {
                return this.numberingPlan.hasTypes();
            }
        },
        {
            key: "type",
            value: function type(_type) {
                return this.numberingPlan.type(_type);
            }
        },
        {
            key: "ext",
            value: function ext() {
                return this.numberingPlan.ext();
            }
        },
        {
            key: "countryCallingCodes",
            value: function countryCallingCodes() {
                if (this.v1) return this.metadata.country_phone_code_to_countries;
                return this.metadata.country_calling_codes;
            }
        },
        {
            key: "chooseCountryByCountryCallingCode",
            value: function chooseCountryByCountryCallingCode(callingCode) {
                return this.selectNumberingPlan(callingCode);
            }
        },
        {
            key: "hasSelectedNumberingPlan",
            value: function hasSelectedNumberingPlan() {
                return this.numberingPlan !== undefined;
            }
        }
    ]);
}();
;
var NumberingPlan = /*#__PURE__*/ function() {
    function NumberingPlan(metadata, globalMetadataObject) {
        _classCallCheck(this, NumberingPlan);
        this.globalMetadataObject = globalMetadataObject;
        this.metadata = metadata;
        setVersion.call(this, globalMetadataObject.metadata);
    }
    return _createClass(NumberingPlan, [
        {
            key: "callingCode",
            value: function callingCode() {
                return this.metadata[0];
            }
        },
        {
            key: "getDefaultCountryMetadataForRegion",
            value: function getDefaultCountryMetadataForRegion() {
                return this.globalMetadataObject.getNumberingPlanMetadata(this.callingCode());
            }
        },
        {
            key: "IDDPrefix",
            value: function IDDPrefix() {
                if (this.v1 || this.v2) return;
                return this.metadata[1];
            }
        },
        {
            key: "defaultIDDPrefix",
            value: function defaultIDDPrefix() {
                if (this.v1 || this.v2) return;
                return this.metadata[12];
            }
        },
        {
            key: "nationalNumberPattern",
            value: function nationalNumberPattern() {
                if (this.v1 || this.v2) return this.metadata[1];
                return this.metadata[2];
            }
        },
        {
            key: "possibleLengths",
            value: function possibleLengths() {
                if (this.v1) return;
                return this.metadata[this.v2 ? 2 : 3];
            }
        },
        {
            key: "_getFormats",
            value: function _getFormats(metadata) {
                return metadata[this.v1 ? 2 : this.v2 ? 3 : 4];
            }
        },
        {
            key: "formats",
            value: function formats() {
                var _this = this;
                var formats = this._getFormats(this.metadata) || this._getFormats(this.getDefaultCountryMetadataForRegion()) || [];
                return formats.map(function(_) {
                    return new Format(_, _this);
                });
            }
        },
        {
            key: "nationalPrefix",
            value: function nationalPrefix() {
                return this.metadata[this.v1 ? 3 : this.v2 ? 4 : 5];
            }
        },
        {
            key: "_getNationalPrefixFormattingRule",
            value: function _getNationalPrefixFormattingRule(metadata) {
                return metadata[this.v1 ? 4 : this.v2 ? 5 : 6];
            }
        },
        {
            key: "nationalPrefixFormattingRule",
            value: function nationalPrefixFormattingRule() {
                return this._getNationalPrefixFormattingRule(this.metadata) || this._getNationalPrefixFormattingRule(this.getDefaultCountryMetadataForRegion());
            }
        },
        {
            key: "_nationalPrefixForParsing",
            value: function _nationalPrefixForParsing() {
                return this.metadata[this.v1 ? 5 : this.v2 ? 6 : 7];
            }
        },
        {
            key: "nationalPrefixForParsing",
            value: function nationalPrefixForParsing() {
                // If `national_prefix_for_parsing` is not set explicitly,
                // then infer it from `national_prefix` (if any)
                return this._nationalPrefixForParsing() || this.nationalPrefix();
            }
        },
        {
            key: "nationalPrefixTransformRule",
            value: function nationalPrefixTransformRule() {
                return this.metadata[this.v1 ? 6 : this.v2 ? 7 : 8];
            }
        },
        {
            key: "_getNationalPrefixIsOptionalWhenFormatting",
            value: function _getNationalPrefixIsOptionalWhenFormatting() {
                return !!this.metadata[this.v1 ? 7 : this.v2 ? 8 : 9];
            }
        },
        {
            key: "nationalPrefixIsOptionalWhenFormattingInNationalFormat",
            value: function nationalPrefixIsOptionalWhenFormattingInNationalFormat() {
                return this._getNationalPrefixIsOptionalWhenFormatting(this.metadata) || this._getNationalPrefixIsOptionalWhenFormatting(this.getDefaultCountryMetadataForRegion());
            }
        },
        {
            key: "leadingDigits",
            value: function leadingDigits() {
                return this.metadata[this.v1 ? 8 : this.v2 ? 9 : 10];
            }
        },
        {
            key: "types",
            value: function types() {
                return this.metadata[this.v1 ? 9 : this.v2 ? 10 : 11];
            }
        },
        {
            key: "hasTypes",
            value: function hasTypes() {
                // Versions 1.2.0 - 1.2.4: can be `[]`.
                /* istanbul ignore next */ if (this.types() && this.types().length === 0) {
                    return false;
                }
                // Versions <= 1.2.4: can be `undefined`.
                // Version >= 1.2.5: can be `0`.
                return !!this.types();
            }
        },
        {
            key: "type",
            value: function type(_type2) {
                if (this.hasTypes() && getType(this.types(), _type2)) {
                    return new Type(getType(this.types(), _type2), this);
                }
            }
        },
        {
            key: "ext",
            value: function ext() {
                if (this.v1 || this.v2) return DEFAULT_EXT_PREFIX;
                return this.metadata[13] || DEFAULT_EXT_PREFIX;
            }
        }
    ]);
}();
var Format = /*#__PURE__*/ function() {
    function Format(format, metadata) {
        _classCallCheck(this, Format);
        this._format = format;
        this.metadata = metadata;
    }
    return _createClass(Format, [
        {
            key: "pattern",
            value: function pattern() {
                return this._format[0];
            }
        },
        {
            key: "format",
            value: function format() {
                return this._format[1];
            }
        },
        {
            key: "leadingDigitsPatterns",
            value: function leadingDigitsPatterns() {
                return this._format[2] || [];
            }
        },
        {
            key: "nationalPrefixFormattingRule",
            value: function nationalPrefixFormattingRule() {
                return this._format[3] || this.metadata.nationalPrefixFormattingRule();
            }
        },
        {
            key: "nationalPrefixIsOptionalWhenFormattingInNationalFormat",
            value: function nationalPrefixIsOptionalWhenFormattingInNationalFormat() {
                return !!this._format[4] || this.metadata.nationalPrefixIsOptionalWhenFormattingInNationalFormat();
            }
        },
        {
            key: "nationalPrefixIsMandatoryWhenFormattingInNationalFormat",
            value: function nationalPrefixIsMandatoryWhenFormattingInNationalFormat() {
                // National prefix is omitted if there's no national prefix formatting rule
                // set for this country, or when the national prefix formatting rule
                // contains no national prefix itself, or when this rule is set but
                // national prefix is optional for this phone number format
                // (and it is not enforced explicitly)
                return this.usesNationalPrefix() && !this.nationalPrefixIsOptionalWhenFormattingInNationalFormat();
            }
        },
        {
            key: "usesNationalPrefix",
            value: function usesNationalPrefix() {
                return this.nationalPrefixFormattingRule() && // Check that national prefix formatting rule is not a "dummy" one.
                !FIRST_GROUP_ONLY_PREFIX_PATTERN.test(this.nationalPrefixFormattingRule()) ? true : false;
            }
        },
        {
            key: "internationalFormat",
            value: function internationalFormat() {
                return this._format[5] || this.format();
            }
        }
    ]);
}();
/**
 * A pattern that is used to determine if the national prefix formatting rule
 * has the first group only, i.e., does not start with the national prefix.
 * Note that the pattern explicitly allows for unbalanced parentheses.
 */ var FIRST_GROUP_ONLY_PREFIX_PATTERN = /^\(?\$1\)?$/;
var Type = /*#__PURE__*/ function() {
    function Type(type, metadata) {
        _classCallCheck(this, Type);
        this.type = type;
        this.metadata = metadata;
    }
    return _createClass(Type, [
        {
            key: "pattern",
            value: function pattern() {
                if (this.metadata.v1) return this.type;
                return this.type[0];
            }
        },
        {
            key: "possibleLengths",
            value: function possibleLengths() {
                if (this.metadata.v1) return;
                return this.type[1] || this.metadata.possibleLengths();
            }
        }
    ]);
}();
function getType(types, type) {
    switch(type){
        case 'FIXED_LINE':
            return types[0];
        case 'MOBILE':
            return types[1];
        case 'TOLL_FREE':
            return types[2];
        case 'PREMIUM_RATE':
            return types[3];
        case 'PERSONAL_NUMBER':
            return types[4];
        case 'VOICEMAIL':
            return types[5];
        case 'UAN':
            return types[6];
        case 'PAGER':
            return types[7];
        case 'VOIP':
            return types[8];
        case 'SHARED_COST':
            return types[9];
    }
}
function validateMetadata(metadata) {
    if (!metadata) {
        throw new Error('[libphonenumber-js] `metadata` argument not passed. Check your arguments.');
    }
    // `country_phone_code_to_countries` was renamed to `country_calling_codes` in `1.0.18`.
    // For that reason, it's not used in this detection algorithm.
    // Instead, it detects by `countries: {}` property existence.
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$isObject$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(metadata) || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$isObject$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(metadata.countries)) {
        throw new Error("[libphonenumber-js] `metadata` argument was passed but it's not a valid metadata. Must be an object having `.countries` child object property. Got ".concat((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$isObject$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(metadata) ? 'an object of shape: { ' + Object.keys(metadata).join(', ') + ' }' : 'a ' + typeOf(metadata) + ': ' + metadata, "."));
    }
}
// Babel transforms `typeof` into some "branches"
// so istanbul will show this as "branch not covered".
/* istanbul ignore next */ var typeOf = function typeOf(_) {
    return _typeof(_);
};
function getExtPrefix(country, metadata) {
    metadata = new Metadata(metadata);
    if (metadata.hasCountry(country)) {
        return metadata.selectNumberingPlan(country).ext();
    }
    return DEFAULT_EXT_PREFIX;
}
function getCountryCallingCode(country, metadata) {
    metadata = new Metadata(metadata);
    if (metadata.hasCountry(country)) {
        return metadata.selectNumberingPlan(country).countryCallingCode();
    }
    throw new Error("Unknown country: ".concat(country));
}
function isSupportedCountry(country, metadata) {
    // metadata = new Metadata(metadata)
    // return metadata.hasCountry(country)
    return metadata.countries.hasOwnProperty(country);
}
function setVersion(metadata) {
    var version = metadata.version;
    if (typeof version === 'number') {
        this.v1 = version === 1;
        this.v2 = version === 2;
        this.v3 = version === 3;
        this.v4 = version === 4;
    } else {
        if (!version) {
            this.v1 = true;
        } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$tools$2f$semver$2d$compare$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(version, V3) === -1) {
            this.v2 = true;
        } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$tools$2f$semver$2d$compare$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(version, V4) === -1) {
            this.v3 = true;
        } else {
            this.v4 = true;
        }
    }
} // const ISO_COUNTRY_CODE = /^[A-Z]{2}$/
 // function isCountryCode(countryCode) {
 // 	return ISO_COUNTRY_CODE.test(countryCodeOrCountryCallingCode)
 // }
}),
"[project]/node_modules/libphonenumber-js/es6/helpers/extension/createExtensionPattern.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>createExtensionPattern
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/constants.js [app-client] (ecmascript)");
;
// The RFC 3966 format for extensions.
var RFC3966_EXTN_PREFIX = ';ext=';
/**
 * Helper method for constructing regular expressions for parsing. Creates
 * an expression that captures up to max_length digits.
 * @return {string} RegEx pattern to capture extension digits.
 */ var getExtensionDigitsPattern = function getExtensionDigitsPattern(maxLength) {
    return "([".concat(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VALID_DIGITS"], "]{1,").concat(maxLength, "})");
};
function createExtensionPattern(purpose) {
    // We cap the maximum length of an extension based on the ambiguity of the way
    // the extension is prefixed. As per ITU, the officially allowed length for
    // extensions is actually 40, but we don't support this since we haven't seen real
    // examples and this introduces many false interpretations as the extension labels
    // are not standardized.
    /** @type {string} */ var extLimitAfterExplicitLabel = '20';
    /** @type {string} */ var extLimitAfterLikelyLabel = '15';
    /** @type {string} */ var extLimitAfterAmbiguousChar = '9';
    /** @type {string} */ var extLimitWhenNotSure = '6';
    /** @type {string} */ var possibleSeparatorsBetweenNumberAndExtLabel = "[ \xA0\\t,]*";
    // Optional full stop (.) or colon, followed by zero or more spaces/tabs/commas.
    /** @type {string} */ var possibleCharsAfterExtLabel = "[:\\.\uFF0E]?[ \xA0\\t,-]*";
    /** @type {string} */ var optionalExtnSuffix = "#?";
    // Here the extension is called out in more explicit way, i.e mentioning it obvious
    // patterns like "ext.".
    /** @type {string} */ var explicitExtLabels = "(?:e?xt(?:ensi(?:o\u0301?|\xF3))?n?|\uFF45?\uFF58\uFF54\uFF4E?|\u0434\u043E\u0431|anexo)";
    // One-character symbols that can be used to indicate an extension, and less
    // commonly used or more ambiguous extension labels.
    /** @type {string} */ var ambiguousExtLabels = "(?:[x\uFF58#\uFF03~\uFF5E]|int|\uFF49\uFF4E\uFF54)";
    // When extension is not separated clearly.
    /** @type {string} */ var ambiguousSeparator = "[- ]+";
    // This is the same as possibleSeparatorsBetweenNumberAndExtLabel, but not matching
    // comma as extension label may have it.
    /** @type {string} */ var possibleSeparatorsNumberExtLabelNoComma = "[ \xA0\\t]*";
    // ",," is commonly used for auto dialling the extension when connected. First
    // comma is matched through possibleSeparatorsBetweenNumberAndExtLabel, so we do
    // not repeat it here. Semi-colon works in Iphone and Android also to pop up a
    // button with the extension number following.
    /** @type {string} */ var autoDiallingAndExtLabelsFound = "(?:,{2}|;)";
    /** @type {string} */ var rfcExtn = RFC3966_EXTN_PREFIX + getExtensionDigitsPattern(extLimitAfterExplicitLabel);
    /** @type {string} */ var explicitExtn = possibleSeparatorsBetweenNumberAndExtLabel + explicitExtLabels + possibleCharsAfterExtLabel + getExtensionDigitsPattern(extLimitAfterExplicitLabel) + optionalExtnSuffix;
    /** @type {string} */ var ambiguousExtn = possibleSeparatorsBetweenNumberAndExtLabel + ambiguousExtLabels + possibleCharsAfterExtLabel + getExtensionDigitsPattern(extLimitAfterAmbiguousChar) + optionalExtnSuffix;
    /** @type {string} */ var americanStyleExtnWithSuffix = ambiguousSeparator + getExtensionDigitsPattern(extLimitWhenNotSure) + "#";
    /** @type {string} */ var autoDiallingExtn = possibleSeparatorsNumberExtLabelNoComma + autoDiallingAndExtLabelsFound + possibleCharsAfterExtLabel + getExtensionDigitsPattern(extLimitAfterLikelyLabel) + optionalExtnSuffix;
    /** @type {string} */ var onlyCommasExtn = possibleSeparatorsNumberExtLabelNoComma + "(?:,)+" + possibleCharsAfterExtLabel + getExtensionDigitsPattern(extLimitAfterAmbiguousChar) + optionalExtnSuffix;
    // The first regular expression covers RFC 3966 format, where the extension is added
    // using ";ext=". The second more generic where extension is mentioned with explicit
    // labels like "ext:". In both the above cases we allow more numbers in extension than
    // any other extension labels. The third one captures when single character extension
    // labels or less commonly used labels are used. In such cases we capture fewer
    // extension digits in order to reduce the chance of falsely interpreting two
    // numbers beside each other as a number + extension. The fourth one covers the
    // special case of American numbers where the extension is written with a hash
    // at the end, such as "- 503#". The fifth one is exclusively for extension
    // autodialling formats which are used when dialling and in this case we accept longer
    // extensions. The last one is more liberal on the number of commas that acts as
    // extension labels, so we have a strict cap on the number of digits in such extensions.
    return rfcExtn + "|" + explicitExtn + "|" + ambiguousExtn + "|" + americanStyleExtnWithSuffix + "|" + autoDiallingExtn + "|" + onlyCommasExtn;
}
}),
"[project]/node_modules/libphonenumber-js/es6/helpers/isViablePhoneNumber.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "VALID_PHONE_NUMBER",
    ()=>VALID_PHONE_NUMBER,
    "VALID_PHONE_NUMBER_WITH_EXTENSION",
    ()=>VALID_PHONE_NUMBER_WITH_EXTENSION,
    "default",
    ()=>isViablePhoneNumber,
    "isViablePhoneNumberStart",
    ()=>isViablePhoneNumberStart
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$extension$2f$createExtensionPattern$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/extension/createExtensionPattern.js [app-client] (ecmascript)");
;
;
//  Regular expression of viable phone numbers. This is location independent.
//  Checks we have at least three leading digits, and only valid punctuation,
//  alpha characters and digits in the phone number. Does not include extension
//  data. The symbol 'x' is allowed here as valid punctuation since it is often
//  used as a placeholder for carrier codes, for example in Brazilian phone
//  numbers. We also allow multiple '+' characters at the start.
//
//  Corresponds to the following:
//  [digits]{minLengthNsn}|
//  plus_sign*
//  (([punctuation]|[star])*[digits]){3,}([punctuation]|[star]|[digits]|[alpha])*
//
//  The first reg-ex is to allow short numbers (two digits long) to be parsed if
//  they are entered as "15" etc, but only if there is no punctuation in them.
//  The second expression restricts the number of digits to three or more, but
//  then allows them to be in international form, and to have alpha-characters
//  and punctuation. We split up the two reg-exes here and combine them when
//  creating the reg-ex VALID_PHONE_NUMBER_PATTERN itself so we can prefix it
//  with ^ and append $ to each branch.
//
//  "Note VALID_PUNCTUATION starts with a -,
//   so must be the first in the range" (c) Google devs.
//  (wtf did they mean by saying that; probably nothing)
//
var MIN_LENGTH_PHONE_NUMBER_PATTERN = '[' + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VALID_DIGITS"] + ']{' + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MIN_LENGTH_FOR_NSN"] + '}';
var VALID_PHONE_NUMBER = '[' + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PLUS_CHARS"] + ']{0,1}' + '(?:' + '[' + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VALID_PUNCTUATION"] + ']*' + '[' + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VALID_DIGITS"] + ']' + '){3,}' + '[' + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VALID_PUNCTUATION"] + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VALID_DIGITS"] + ']*';
// This regular expression isn't present in Google's `libphonenumber`
// and is only used to determine whether the phone number being input
// is too short for it to even consider it a "valid" number.
// This is just a way to differentiate between a really invalid phone
// number like "abcde" and a valid phone number that a user has just
// started inputting, like "+1" or "1": both these cases would be
// considered `NOT_A_NUMBER` by Google's `libphonenumber`, but this
// library can provide a more detailed error message — whether it's
// really "not a number", or is it just a start of a valid phone number.
var VALID_PHONE_NUMBER_START_REG_EXP = new RegExp('^' + '[' + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PLUS_CHARS"] + ']{0,1}' + '(?:' + '[' + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VALID_PUNCTUATION"] + ']*' + '[' + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VALID_DIGITS"] + ']' + '){1,2}' + '$', 'i');
var VALID_PHONE_NUMBER_WITH_EXTENSION = VALID_PHONE_NUMBER + // Phone number extensions
'(?:' + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$extension$2f$createExtensionPattern$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])() + ')?';
// The combined regular expression for valid phone numbers:
//
var VALID_PHONE_NUMBER_PATTERN = new RegExp(// Either a short two-digit-only phone number
'^' + MIN_LENGTH_PHONE_NUMBER_PATTERN + '$' + '|' + // Or a longer fully parsed phone number (min 3 characters)
'^' + VALID_PHONE_NUMBER_WITH_EXTENSION + '$', 'i');
function isViablePhoneNumber(number) {
    return number.length >= __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MIN_LENGTH_FOR_NSN"] && VALID_PHONE_NUMBER_PATTERN.test(number);
}
function isViablePhoneNumberStart(number) {
    return VALID_PHONE_NUMBER_START_REG_EXP.test(number);
}
}),
"[project]/node_modules/libphonenumber-js/es6/helpers/extension/extractExtension.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>extractExtension
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$extension$2f$createExtensionPattern$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/extension/createExtensionPattern.js [app-client] (ecmascript)");
;
// Regexp of all known extension prefixes used by different regions followed by
// 1 or more valid digits, for use when parsing.
var EXTN_PATTERN = new RegExp('(?:' + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$extension$2f$createExtensionPattern$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])() + ')$', 'i');
function extractExtension(number) {
    var start = number.search(EXTN_PATTERN);
    if (start < 0) {
        return {};
    }
    // If we find a potential extension, and the number preceding this is a viable
    // number, we assume it is an extension.
    var numberWithoutExtension = number.slice(0, start);
    var matches = number.match(EXTN_PATTERN);
    var i = 1;
    while(i < matches.length){
        if (matches[i]) {
            return {
                number: numberWithoutExtension,
                ext: matches[i]
            };
        }
        i++;
    }
}
}),
"[project]/node_modules/libphonenumber-js/es6/helpers/parseDigits.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DIGITS",
    ()=>DIGITS,
    "default",
    ()=>parseDigits,
    "parseDigit",
    ()=>parseDigit
]);
function _createForOfIteratorHelperLoose(r, e) {
    var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
    if (t) return (t = t.call(r)).next.bind(t);
    if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) {
        t && (r = t);
        var o = 0;
        return function() {
            return o >= r.length ? {
                done: !0
            } : {
                done: !1,
                value: r[o++]
            };
        };
    }
    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(r, a) {
    if (r) {
        if ("string" == typeof r) return _arrayLikeToArray(r, a);
        var t = ({}).toString.call(r).slice(8, -1);
        return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
    }
}
function _arrayLikeToArray(r, a) {
    (null == a || a > r.length) && (a = r.length);
    for(var e = 0, n = Array(a); e < a; e++)n[e] = r[e];
    return n;
}
var DIGITS = {
    '0': '0',
    '1': '1',
    '2': '2',
    '3': '3',
    '4': '4',
    '5': '5',
    '6': '6',
    '7': '7',
    '8': '8',
    '9': '9',
    "\uFF10": '0',
    // Fullwidth digit 0
    "\uFF11": '1',
    // Fullwidth digit 1
    "\uFF12": '2',
    // Fullwidth digit 2
    "\uFF13": '3',
    // Fullwidth digit 3
    "\uFF14": '4',
    // Fullwidth digit 4
    "\uFF15": '5',
    // Fullwidth digit 5
    "\uFF16": '6',
    // Fullwidth digit 6
    "\uFF17": '7',
    // Fullwidth digit 7
    "\uFF18": '8',
    // Fullwidth digit 8
    "\uFF19": '9',
    // Fullwidth digit 9
    "\u0660": '0',
    // Arabic-indic digit 0
    "\u0661": '1',
    // Arabic-indic digit 1
    "\u0662": '2',
    // Arabic-indic digit 2
    "\u0663": '3',
    // Arabic-indic digit 3
    "\u0664": '4',
    // Arabic-indic digit 4
    "\u0665": '5',
    // Arabic-indic digit 5
    "\u0666": '6',
    // Arabic-indic digit 6
    "\u0667": '7',
    // Arabic-indic digit 7
    "\u0668": '8',
    // Arabic-indic digit 8
    "\u0669": '9',
    // Arabic-indic digit 9
    "\u06F0": '0',
    // Eastern-Arabic digit 0
    "\u06F1": '1',
    // Eastern-Arabic digit 1
    "\u06F2": '2',
    // Eastern-Arabic digit 2
    "\u06F3": '3',
    // Eastern-Arabic digit 3
    "\u06F4": '4',
    // Eastern-Arabic digit 4
    "\u06F5": '5',
    // Eastern-Arabic digit 5
    "\u06F6": '6',
    // Eastern-Arabic digit 6
    "\u06F7": '7',
    // Eastern-Arabic digit 7
    "\u06F8": '8',
    // Eastern-Arabic digit 8
    "\u06F9": '9' // Eastern-Arabic digit 9
};
function parseDigit(character) {
    return DIGITS[character];
}
function parseDigits(string) {
    var result = '';
    // Using `.split('')` here instead of normal `for ... of`
    // because the importing application doesn't neccessarily include an ES6 polyfill.
    // The `.split('')` approach discards "exotic" UTF-8 characters
    // (the ones consisting of four bytes) but digits
    // (including non-European ones) don't fall into that range
    // so such "exotic" characters would be discarded anyway.
    for(var _iterator = _createForOfIteratorHelperLoose(string.split('')), _step; !(_step = _iterator()).done;){
        var character = _step.value;
        var digit = parseDigit(character);
        if (digit) {
            result += digit;
        }
    }
    return result;
}
}),
"[project]/node_modules/libphonenumber-js/es6/parseIncompletePhoneNumber.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>parseIncompletePhoneNumber,
    "parsePhoneNumberCharacter",
    ()=>parsePhoneNumberCharacter
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$parseDigits$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/parseDigits.js [app-client] (ecmascript)");
function _createForOfIteratorHelperLoose(r, e) {
    var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
    if (t) return (t = t.call(r)).next.bind(t);
    if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) {
        t && (r = t);
        var o = 0;
        return function() {
            return o >= r.length ? {
                done: !0
            } : {
                done: !1,
                value: r[o++]
            };
        };
    }
    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(r, a) {
    if (r) {
        if ("string" == typeof r) return _arrayLikeToArray(r, a);
        var t = ({}).toString.call(r).slice(8, -1);
        return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
    }
}
function _arrayLikeToArray(r, a) {
    (null == a || a > r.length) && (a = r.length);
    for(var e = 0, n = Array(a); e < a; e++)n[e] = r[e];
    return n;
}
;
function parseIncompletePhoneNumber(string) {
    var result = '';
    // Using `.split('')` here instead of normal `for ... of`
    // because the importing application doesn't neccessarily include an ES6 polyfill.
    // The `.split('')` approach discards "exotic" UTF-8 characters
    // (the ones consisting of four bytes) but digits
    // (including non-European ones) don't fall into that range
    // so such "exotic" characters would be discarded anyway.
    for(var _iterator = _createForOfIteratorHelperLoose(string.split('')), _step; !(_step = _iterator()).done;){
        var character = _step.value;
        result += parsePhoneNumberCharacter(character, result) || '';
    }
    return result;
}
function parsePhoneNumberCharacter(character, prevParsedCharacters, eventListener) {
    // Only allow a leading `+`.
    if (character === '+') {
        // If this `+` is not the first parsed character
        // then discard it.
        if (prevParsedCharacters) {
            // `eventListener` argument was added to this `export`ed function on Dec 26th, 2023.
            // Any 3rd-party code that used to `import` and call this function before that
            // won't be passing any `eventListener` argument.
            //
            // The addition of the `eventListener` argument was to fix the slightly-weird behavior
            // of parsing an input string when the user inputs something like `"2+7"
            // https://github.com/catamphetamine/react-phone-number-input/issues/437
            //
            // If the parser encounters an unexpected `+` in a string being parsed
            // then it simply discards that out-of-place `+` and any following characters.
            //
            if (typeof eventListener === 'function') {
                eventListener('end');
            }
            return;
        }
        return '+';
    }
    // Allow digits.
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$parseDigits$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseDigit"])(character);
}
}),
"[project]/node_modules/libphonenumber-js/es6/metadata.js [app-client] (ecmascript) <export getCountryCallingCode as default>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$metadata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCountryCallingCode"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$metadata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/metadata.js [app-client] (ecmascript)");
}),
"[project]/node_modules/libphonenumber-js/es6/helpers/mergeArrays.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>mergeArrays
]);
function _createForOfIteratorHelperLoose(r, e) {
    var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
    if (t) return (t = t.call(r)).next.bind(t);
    if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) {
        t && (r = t);
        var o = 0;
        return function() {
            return o >= r.length ? {
                done: !0
            } : {
                done: !1,
                value: r[o++]
            };
        };
    }
    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(r, a) {
    if (r) {
        if ("string" == typeof r) return _arrayLikeToArray(r, a);
        var t = ({}).toString.call(r).slice(8, -1);
        return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
    }
}
function _arrayLikeToArray(r, a) {
    (null == a || a > r.length) && (a = r.length);
    for(var e = 0, n = Array(a); e < a; e++)n[e] = r[e];
    return n;
}
function mergeArrays(a, b) {
    var merged = a.slice();
    for(var _iterator = _createForOfIteratorHelperLoose(b), _step; !(_step = _iterator()).done;){
        var element = _step.value;
        if (a.indexOf(element) < 0) {
            merged.push(element);
        }
    }
    return merged.sort(function(a, b) {
        return a - b;
    });
// ES6 version, requires Set polyfill.
// let merged = new Set(a)
// for (const element of b) {
// 	merged.add(i)
// }
// return Array.from(merged).sort((a, b) => a - b)
}
}),
"[project]/node_modules/libphonenumber-js/es6/helpers/checkNumberLength.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "checkNumberLengthForType",
    ()=>checkNumberLengthForType,
    "default",
    ()=>checkNumberLength
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$metadata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/metadata.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$mergeArrays$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/mergeArrays.js [app-client] (ecmascript)");
;
;
function checkNumberLength(nationalNumber, country, metadata) {
    return checkNumberLengthForType(nationalNumber, country, undefined, metadata);
}
function checkNumberLengthForType(nationalNumber, country, type, metadata) {
    // If the exact `country` is specified, it's no necessarily already selected in `metadata`.
    // Most likely, in cases when there're multiple countries corresponding to the same
    // "country calling code", the "main" country for that "country calling code" will be selected.
    if (country) {
        metadata = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$metadata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"](metadata.metadata);
        metadata.selectNumberingPlan(country);
    }
    var type_info = metadata.type(type);
    // There should always be "<possiblePengths/>" set for every type element.
    // This is declared in the XML schema.
    // For size efficiency, where a sub-description (e.g. fixed-line)
    // has the same "<possiblePengths/>" as the "general description", this is missing,
    // so we fall back to the "general description". Where no numbers of the type
    // exist at all, there is one possible length (-1) which is guaranteed
    // not to match the length of any real phone number.
    var possible_lengths = type_info && type_info.possibleLengths() || metadata.possibleLengths();
    // let local_lengths = type_info && type.possibleLengthsLocal() || metadata.possibleLengthsLocal()
    // Metadata before version `1.0.18` didn't contain `possible_lengths`.
    if (!possible_lengths) {
        return 'IS_POSSIBLE';
    }
    if (type === 'FIXED_LINE_OR_MOBILE') {
        // No such country in metadata.
        /* istanbul ignore next */ if (!metadata.type('FIXED_LINE')) {
            // The rare case has been encountered where no fixedLine data is available
            // (true for some non-geographic entities), so we just check mobile.
            return checkNumberLengthForType(nationalNumber, country, 'MOBILE', metadata);
        }
        var mobile_type = metadata.type('MOBILE');
        if (mobile_type) {
            // Merge the mobile data in if there was any. "Concat" creates a new
            // array, it doesn't edit possible_lengths in place, so we don't need a copy.
            // Note that when adding the possible lengths from mobile, we have
            // to again check they aren't empty since if they are this indicates
            // they are the same as the general desc and should be obtained from there.
            possible_lengths = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$mergeArrays$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(possible_lengths, mobile_type.possibleLengths());
        // The current list is sorted; we need to merge in the new list and
        // re-sort (duplicates are okay). Sorting isn't so expensive because
        // the lists are very small.
        // if (local_lengths) {
        // 	local_lengths = mergeArrays(local_lengths, mobile_type.possibleLengthsLocal())
        // } else {
        // 	local_lengths = mobile_type.possibleLengthsLocal()
        // }
        }
    } else if (type && !type_info) {
        return 'INVALID_LENGTH';
    }
    var actual_length = nationalNumber.length;
    // In `libphonenumber-js` all "local-only" formats are dropped for simplicity.
    // // This is safe because there is never an overlap beween the possible lengths
    // // and the local-only lengths; this is checked at build time.
    // if (local_lengths && local_lengths.indexOf(nationalNumber.length) >= 0)
    // {
    // 	return 'IS_POSSIBLE_LOCAL_ONLY'
    // }
    var minimum_length = possible_lengths[0];
    if (minimum_length === actual_length) {
        return 'IS_POSSIBLE';
    }
    if (minimum_length > actual_length) {
        return 'TOO_SHORT';
    }
    if (possible_lengths[possible_lengths.length - 1] < actual_length) {
        return 'TOO_LONG';
    }
    // We skip the first element since we've already checked it.
    return possible_lengths.indexOf(actual_length, 1) >= 0 ? 'IS_POSSIBLE' : 'INVALID_LENGTH';
}
}),
"[project]/node_modules/libphonenumber-js/es6/isPossible.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>isPossiblePhoneNumber,
    "isPossibleNumber",
    ()=>isPossibleNumber
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$metadata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/metadata.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$checkNumberLength$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/checkNumberLength.js [app-client] (ecmascript)");
;
;
function isPossiblePhoneNumber(input, options, metadata) {
    /* istanbul ignore if */ if (options === undefined) {
        options = {};
    }
    metadata = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$metadata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"](metadata);
    if (options.v2) {
        if (!input.countryCallingCode) {
            throw new Error('Invalid phone number object passed');
        }
        metadata.selectNumberingPlan(input.countryCallingCode);
    } else {
        if (!input.phone) {
            return false;
        }
        if (input.country) {
            if (!metadata.hasCountry(input.country)) {
                throw new Error("Unknown country: ".concat(input.country));
            }
            metadata.selectNumberingPlan(input.country);
        } else {
            if (!input.countryCallingCode) {
                throw new Error('Invalid phone number object passed');
            }
            metadata.selectNumberingPlan(input.countryCallingCode);
        }
    }
    // Old metadata (< 1.0.18) had no "possible length" data.
    if (metadata.possibleLengths()) {
        return isPossibleNumber(input.phone || input.nationalNumber, input.country, metadata);
    } else {
        // There was a bug between `1.7.35` and `1.7.37` where "possible_lengths"
        // were missing for "non-geographical" numbering plans.
        // Just assume the number is possible in such cases:
        // it's unlikely that anyone generated their custom metadata
        // in that short period of time (one day).
        // This code can be removed in some future major version update.
        if (input.countryCallingCode && metadata.isNonGeographicCallingCode(input.countryCallingCode)) {
            // "Non-geographic entities" did't have `possibleLengths`
            // due to a bug in metadata generation process.
            return true;
        } else {
            throw new Error('Missing "possibleLengths" in metadata. Perhaps the metadata has been generated before v1.0.18.');
        }
    }
}
function isPossibleNumber(nationalNumber, country, metadata) {
    //, isInternational) {
    switch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$checkNumberLength$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(nationalNumber, country, metadata)){
        case 'IS_POSSIBLE':
            return true;
        // This library ignores "local-only" phone numbers (for simplicity).
        // See the readme for more info on what are "local-only" phone numbers.
        // case 'IS_POSSIBLE_LOCAL_ONLY':
        // 	return !isInternational
        default:
            return false;
    }
}
}),
"[project]/node_modules/libphonenumber-js/es6/helpers/matchesEntirely.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Checks whether the entire input sequence can be matched
 * against the regular expression.
 * @return {boolean}
 */ __turbopack_context__.s([
    "default",
    ()=>matchesEntirely
]);
function matchesEntirely(text, regularExpressionText) {
    // If the assigning of the `''` default value is moved to the arguments above,
    // the code coverage would decrease for some weird reason.
    text = text || '';
    return new RegExp('^(?:' + regularExpressionText + ')$').test(text);
}
}),
"[project]/node_modules/libphonenumber-js/es6/helpers/getNumberType.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>getNumberType,
    "isNumberTypeEqualTo",
    ()=>isNumberTypeEqualTo
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$metadata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/metadata.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$matchesEntirely$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/matchesEntirely.js [app-client] (ecmascript)");
function _createForOfIteratorHelperLoose(r, e) {
    var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
    if (t) return (t = t.call(r)).next.bind(t);
    if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) {
        t && (r = t);
        var o = 0;
        return function() {
            return o >= r.length ? {
                done: !0
            } : {
                done: !1,
                value: r[o++]
            };
        };
    }
    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(r, a) {
    if (r) {
        if ("string" == typeof r) return _arrayLikeToArray(r, a);
        var t = ({}).toString.call(r).slice(8, -1);
        return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
    }
}
function _arrayLikeToArray(r, a) {
    (null == a || a > r.length) && (a = r.length);
    for(var e = 0, n = Array(a); e < a; e++)n[e] = r[e];
    return n;
}
;
;
var NON_FIXED_LINE_PHONE_TYPES = [
    'MOBILE',
    'PREMIUM_RATE',
    'TOLL_FREE',
    'SHARED_COST',
    'VOIP',
    'PERSONAL_NUMBER',
    'PAGER',
    'UAN',
    'VOICEMAIL'
];
function getNumberType(input, options, metadata) {
    // If assigning the `{}` default value is moved to the arguments above,
    // code coverage would decrease for some weird reason.
    options = options || {};
    // When `parse()` returns an empty object — `{}` —
    // that means that the phone number is malformed,
    // so it can't possibly be valid.
    if (!input.country && !input.countryCallingCode) {
        return;
    }
    metadata = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$metadata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"](metadata);
    metadata.selectNumberingPlan(input.country, input.countryCallingCode);
    var nationalNumber = options.v2 ? input.nationalNumber : input.phone;
    // The following is copy-pasted from the original function:
    // https://github.com/googlei18n/libphonenumber/blob/3ea547d4fbaa2d0b67588904dfa5d3f2557c27ff/javascript/i18n/phonenumbers/phonenumberutil.js#L2835
    // Is this national number even valid for this country
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$matchesEntirely$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(nationalNumber, metadata.nationalNumberPattern())) {
        return;
    }
    // Is it fixed line number
    if (isNumberTypeEqualTo(nationalNumber, 'FIXED_LINE', metadata)) {
        // Because duplicate regular expressions are removed
        // to reduce metadata size, if "mobile" pattern is ""
        // then it means it was removed due to being a duplicate of the fixed-line pattern.
        //
        if (metadata.type('MOBILE') && metadata.type('MOBILE').pattern() === '') {
            return 'FIXED_LINE_OR_MOBILE';
        }
        // `MOBILE` type pattern isn't included if it matched `FIXED_LINE` one.
        // For example, for "US" country.
        // Old metadata (< `1.0.18`) had a specific "types" data structure
        // that happened to be `undefined` for `MOBILE` in that case.
        // Newer metadata (>= `1.0.18`) has another data structure that is
        // not `undefined` for `MOBILE` in that case (it's just an empty array).
        // So this `if` is just for backwards compatibility with old metadata.
        if (!metadata.type('MOBILE')) {
            return 'FIXED_LINE_OR_MOBILE';
        }
        // Check if the number happens to qualify as both fixed line and mobile.
        // (no such country in the minimal metadata set)
        /* istanbul ignore if */ if (isNumberTypeEqualTo(nationalNumber, 'MOBILE', metadata)) {
            return 'FIXED_LINE_OR_MOBILE';
        }
        return 'FIXED_LINE';
    }
    for(var _iterator = _createForOfIteratorHelperLoose(NON_FIXED_LINE_PHONE_TYPES), _step; !(_step = _iterator()).done;){
        var type = _step.value;
        if (isNumberTypeEqualTo(nationalNumber, type, metadata)) {
            return type;
        }
    }
}
function isNumberTypeEqualTo(nationalNumber, type, metadata) {
    var typeDefinition = metadata.type(type);
    if (!typeDefinition || !typeDefinition.pattern()) {
        return false;
    }
    // Check if any possible number lengths are present;
    // if so, we use them to avoid checking
    // the validation pattern if they don't match.
    // If they are absent, this means they match
    // the general description, which we have
    // already checked before a specific number type.
    if (typeDefinition.possibleLengths() && typeDefinition.possibleLengths().indexOf(nationalNumber.length) < 0) {
        return false;
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$matchesEntirely$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(nationalNumber, typeDefinition.pattern());
}
}),
"[project]/node_modules/libphonenumber-js/es6/isValid.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>isValidNumber
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$metadata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/metadata.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$matchesEntirely$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/matchesEntirely.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$getNumberType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/getNumberType.js [app-client] (ecmascript)");
;
;
;
function isValidNumber(input, options, metadata) {
    // If assigning the `{}` default value is moved to the arguments above,
    // code coverage would decrease for some weird reason.
    options = options || {};
    metadata = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$metadata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"](metadata);
    metadata.selectNumberingPlan(input.country, input.countryCallingCode);
    // By default, countries only have type regexps when it's required for
    // distinguishing different countries having the same `countryCallingCode`.
    if (metadata.hasTypes()) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$getNumberType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(input, options, metadata.metadata) !== undefined;
    }
    // If there are no type regexps for this country in metadata then use
    // `nationalNumberPattern` as a "better than nothing" replacement.
    var nationalNumber = options.v2 ? input.nationalNumber : input.phone;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$matchesEntirely$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(nationalNumber, metadata.nationalNumberPattern());
}
}),
"[project]/node_modules/libphonenumber-js/es6/helpers/getPossibleCountriesForNumber.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>getPossibleCountriesForNumber
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$metadata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/metadata.js [app-client] (ecmascript)");
;
function getPossibleCountriesForNumber(callingCode, nationalNumber, metadata) {
    var _metadata = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$metadata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"](metadata);
    var possibleCountries = _metadata.getCountryCodesForCallingCode(callingCode);
    if (!possibleCountries) {
        return [];
    }
    return possibleCountries.filter(function(country) {
        return couldNationalNumberBelongToCountry(nationalNumber, country, metadata);
    });
}
function couldNationalNumberBelongToCountry(nationalNumber, country, metadata) {
    var _metadata = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$metadata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"](metadata);
    _metadata.selectNumberingPlan(country);
    if (_metadata.numberingPlan.possibleLengths().indexOf(nationalNumber.length) >= 0) {
        return true;
    }
    return false;
}
}),
"[project]/node_modules/libphonenumber-js/es6/helpers/stripIddPrefix.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>stripIddPrefix
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$metadata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/metadata.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/constants.js [app-client] (ecmascript)");
;
;
var CAPTURING_DIGIT_PATTERN = new RegExp('([' + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VALID_DIGITS"] + '])');
function stripIddPrefix(number, country, callingCode, metadata) {
    if (!country) {
        return;
    }
    // Check if the number is IDD-prefixed.
    var countryMetadata = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$metadata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"](metadata);
    countryMetadata.selectNumberingPlan(country, callingCode);
    var IDDPrefixPattern = new RegExp(countryMetadata.IDDPrefix());
    if (number.search(IDDPrefixPattern) !== 0) {
        return;
    }
    // Strip IDD prefix.
    number = number.slice(number.match(IDDPrefixPattern)[0].length);
    // If there're any digits after an IDD prefix,
    // then those digits are a country calling code.
    // Since no country code starts with a `0`,
    // the code below validates that the next digit (if present) is not `0`.
    var matchedGroups = number.match(CAPTURING_DIGIT_PATTERN);
    if (matchedGroups && matchedGroups[1] != null && matchedGroups[1].length > 0) {
        if (matchedGroups[1] === '0') {
            return;
        }
    }
    return number;
}
}),
"[project]/node_modules/libphonenumber-js/es6/helpers/extractNationalNumberFromPossiblyIncompleteNumber.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Strips any national prefix (such as 0, 1) present in a
 * (possibly incomplete) number provided.
 * "Carrier codes" are only used  in Colombia and Brazil,
 * and only when dialing within those countries from a mobile phone to a fixed line number.
 * Sometimes it won't actually strip national prefix
 * and will instead prepend some digits to the `number`:
 * for example, when number `2345678` is passed with `VI` country selected,
 * it will return `{ number: "3402345678" }`, because `340` area code is prepended.
 * @param {string} number — National number digits.
 * @param {object} metadata — Metadata with country selected.
 * @return {object} `{ nationalNumber: string, nationalPrefix: string? carrierCode: string? }`. Even if a national prefix was extracted, it's not necessarily present in the returned object, so don't rely on its presence in the returned object in order to find out whether a national prefix has been extracted or not.
 */ __turbopack_context__.s([
    "default",
    ()=>extractNationalNumberFromPossiblyIncompleteNumber
]);
function extractNationalNumberFromPossiblyIncompleteNumber(number, metadata) {
    if (number && metadata.numberingPlan.nationalPrefixForParsing()) {
        // See METADATA.md for the description of
        // `national_prefix_for_parsing` and `national_prefix_transform_rule`.
        // Attempt to parse the first digits as a national prefix.
        var prefixPattern = new RegExp('^(?:' + metadata.numberingPlan.nationalPrefixForParsing() + ')');
        var prefixMatch = prefixPattern.exec(number);
        if (prefixMatch) {
            var nationalNumber;
            var carrierCode;
            // https://gitlab.com/catamphetamine/libphonenumber-js/-/blob/master/METADATA.md#national_prefix_for_parsing--national_prefix_transform_rule
            // If a `national_prefix_for_parsing` has any "capturing groups"
            // then it means that the national (significant) number is equal to
            // those "capturing groups" transformed via `national_prefix_transform_rule`,
            // and nothing could be said about the actual national prefix:
            // what is it and was it even there.
            // If a `national_prefix_for_parsing` doesn't have any "capturing groups",
            // then everything it matches is a national prefix.
            // To determine whether `national_prefix_for_parsing` matched any
            // "capturing groups", the value of the result of calling `.exec()`
            // is looked at, and if it has non-undefined values where there're
            // "capturing groups" in the regular expression, then it means
            // that "capturing groups" have been matched.
            // It's not possible to tell whether there'll be any "capturing gropus"
            // before the matching process, because a `national_prefix_for_parsing`
            // could exhibit both behaviors.
            var capturedGroupsCount = prefixMatch.length - 1;
            var hasCapturedGroups = capturedGroupsCount > 0 && prefixMatch[capturedGroupsCount];
            if (metadata.nationalPrefixTransformRule() && hasCapturedGroups) {
                nationalNumber = number.replace(prefixPattern, metadata.nationalPrefixTransformRule());
                // If there's more than one captured group,
                // then carrier code is the second one.
                if (capturedGroupsCount > 1) {
                    carrierCode = prefixMatch[1];
                }
            } else {
                // `prefixBeforeNationalNumber` is the whole substring matched by
                // the `national_prefix_for_parsing` regular expression.
                // There seem to be no guarantees that it's just a national prefix.
                // For example, if there's a carrier code, it's gonna be a
                // part of `prefixBeforeNationalNumber` too.
                var prefixBeforeNationalNumber = prefixMatch[0];
                nationalNumber = number.slice(prefixBeforeNationalNumber.length);
                // If there's at least one captured group,
                // then carrier code is the first one.
                if (hasCapturedGroups) {
                    carrierCode = prefixMatch[1];
                }
            }
            // Tries to guess whether a national prefix was present in the input.
            // This is not something copy-pasted from Google's library:
            // they don't seem to have an equivalent for that.
            // So this isn't an "officially approved" way of doing something like that.
            // But since there seems no other existing method, this library uses it.
            var nationalPrefix;
            if (hasCapturedGroups) {
                var possiblePositionOfTheFirstCapturedGroup = number.indexOf(prefixMatch[1]);
                var possibleNationalPrefix = number.slice(0, possiblePositionOfTheFirstCapturedGroup);
                // Example: an Argentinian (AR) phone number `0111523456789`.
                // `prefixMatch[0]` is `01115`, and `$1` is `11`,
                // and the rest of the phone number is `23456789`.
                // The national number is transformed via `9$1` to `91123456789`.
                // National prefix `0` is detected being present at the start.
                // if (possibleNationalPrefix.indexOf(metadata.numberingPlan.nationalPrefix()) === 0) {
                if (possibleNationalPrefix === metadata.numberingPlan.nationalPrefix()) {
                    nationalPrefix = metadata.numberingPlan.nationalPrefix();
                }
            } else {
                nationalPrefix = prefixMatch[0];
            }
            return {
                nationalNumber: nationalNumber,
                nationalPrefix: nationalPrefix,
                carrierCode: carrierCode
            };
        }
    }
    return {
        nationalNumber: number
    };
}
}),
"[project]/node_modules/libphonenumber-js/es6/helpers/getCountryByNationalNumber.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>getCountryByNationalNumber
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$metadata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/metadata.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$getNumberType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/getNumberType.js [app-client] (ecmascript)");
function _createForOfIteratorHelperLoose(r, e) {
    var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
    if (t) return (t = t.call(r)).next.bind(t);
    if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) {
        t && (r = t);
        var o = 0;
        return function() {
            return o >= r.length ? {
                done: !0
            } : {
                done: !1,
                value: r[o++]
            };
        };
    }
    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(r, a) {
    if (r) {
        if ("string" == typeof r) return _arrayLikeToArray(r, a);
        var t = ({}).toString.call(r).slice(8, -1);
        return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
    }
}
function _arrayLikeToArray(r, a) {
    (null == a || a > r.length) && (a = r.length);
    for(var e = 0, n = Array(a); e < a; e++)n[e] = r[e];
    return n;
}
;
;
function getCountryByNationalNumber(nationalPhoneNumber, _ref) {
    var countries = _ref.countries, metadata = _ref.metadata;
    // Re-create `metadata` because it will be selecting a `country`.
    metadata = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$metadata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"](metadata);
    // const matchingCountries = []
    for(var _iterator = _createForOfIteratorHelperLoose(countries), _step; !(_step = _iterator()).done;){
        var country = _step.value;
        metadata.selectNumberingPlan(country);
        // "Leading digits" patterns are only defined for about 20% of all countries.
        // By definition, matching "leading digits" is a sufficient but not a necessary
        // condition for a phone number to belong to a country.
        // The point of "leading digits" check is that it's the fastest one to get a match.
        // https://gitlab.com/catamphetamine/libphonenumber-js/blob/master/METADATA.md#leading_digits
        // I'd suppose that "leading digits" patterns are mutually exclusive for different countries
        // because of the intended use of that feature.
        if (metadata.leadingDigits()) {
            if (nationalPhoneNumber && nationalPhoneNumber.search(metadata.leadingDigits()) === 0) {
                return country;
            }
        } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$getNumberType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
            phone: nationalPhoneNumber,
            country: country
        }, undefined, metadata.metadata)) {
            // When multiple countries share the same "country calling code",
            // type patterns aren't guaranteed to be unique among them.
            // For example, both `US` and `CA` have the same pattern for `toll_free` numbers.
            // https://gitlab.com/catamphetamine/libphonenumber-js/-/issues/103#note_1417147572
            //
            // That means that this `if` condition could be `true` for multiple countries from the list.
            // Currently, it just returns the first one, which is also the "main" country for the "country calling code".
            // In an example with `toll_free` numbers above, `"US"` would be returned even though
            // it could as well be `"CA"`.
            //
            // There was also a time when this attempted to be overly smart
            // and kept track of all such multiple matching countries
            // and then picked the one that matched the `defaultCountry`, if provided.
            // For example, with `toll_free` numbers above, and with `defaultCountry: "CA"`,
            // it would've returned `"CA"` instead of `"US"`.
            // Later it turned out that such "overly smart" behavior turned out to be just confusing,
            // so this "overly smart" country detection was reverted to returning the "main" country
            // for the "country calling code".
            // https://gitlab.com/catamphetamine/libphonenumber-js/-/issues/154
            //
            return country;
        //
        // The "overly smart" behavior code:
        //
        // if (defaultCountry) {
        // 	if (country === defaultCountry) {
        // 		return country
        // 	} else {
        // 		matchingCountries.push(country)
        // 	}
        // } else {
        // 	return country
        // }
        }
    }
// // Return the first ("main") one of the `matchingCountries`.
// if (matchingCountries.length > 0) {
// 	return matchingCountries[0]
// }
}
}),
"[project]/node_modules/libphonenumber-js/es6/helpers/getCountryByCallingCode.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>getCountryByCallingCode
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$getCountryByNationalNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/getCountryByNationalNumber.js [app-client] (ecmascript)");
;
var USE_NON_GEOGRAPHIC_COUNTRY_CODE = false;
function getCountryByCallingCode(callingCode, _ref) {
    var nationalPhoneNumber = _ref.nationalNumber, metadata = _ref.metadata;
    /* istanbul ignore if */ if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    var possibleCountries = metadata.getCountryCodesForCallingCode(callingCode);
    if (!possibleCountries) {
        return;
    }
    // If there's just one country corresponding to the country code,
    // then just return it, without further phone number digits validation.
    if (possibleCountries.length === 1) {
        return possibleCountries[0];
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$getCountryByNationalNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(nationalPhoneNumber, {
        countries: possibleCountries,
        metadata: metadata.metadata
    });
}
}),
"[project]/node_modules/libphonenumber-js/es6/helpers/extractNationalNumber.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>extractNationalNumber
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$extractNationalNumberFromPossiblyIncompleteNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/extractNationalNumberFromPossiblyIncompleteNumber.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$matchesEntirely$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/matchesEntirely.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$checkNumberLength$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/checkNumberLength.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$getCountryByCallingCode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/getCountryByCallingCode.js [app-client] (ecmascript)");
;
;
;
;
function extractNationalNumber(number, country, metadata) {
    // Parsing national prefixes and carrier codes
    // is only required for local phone numbers
    // but some people don't understand that
    // and sometimes write international phone numbers
    // with national prefixes (or maybe even carrier codes).
    // http://ucken.blogspot.ru/2016/03/trunk-prefixes-in-skype4b.html
    // Google's original library forgives such mistakes
    // and so does this library, because it has been requested:
    // https://github.com/catamphetamine/libphonenumber-js/issues/127
    var _extractNationalNumbe = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$extractNationalNumberFromPossiblyIncompleteNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(number, metadata), carrierCode = _extractNationalNumbe.carrierCode, nationalNumber = _extractNationalNumbe.nationalNumber;
    if (nationalNumber !== number) {
        if (!shouldHaveExtractedNationalPrefix(number, nationalNumber, metadata)) {
            // Don't strip the national prefix.
            return {
                nationalNumber: number
            };
        }
        // Check the national (significant) number length after extracting national prefix and carrier code.
        // Legacy generated metadata (before `1.0.18`) didn't support the "possible lengths" feature.
        if (metadata.numberingPlan.possibleLengths()) {
            // If an exact `country` is not specified, attempt to detect it from the assumed national number.
            if (!country) {
                country = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$getCountryByCallingCode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(metadata.numberingPlan.callingCode(), {
                    nationalNumber: nationalNumber,
                    metadata: metadata
                });
            }
            // The number remaining after stripping the national prefix and carrier code
            // should be long enough to have a possible length for the country.
            // Otherwise, don't strip the national prefix and carrier code,
            // since the original number could be a valid number.
            // This check has been copy-pasted "as is" from Google's original library:
            // https://github.com/google/libphonenumber/blob/876268eb1ad6cdc1b7b5bef17fc5e43052702d57/java/libphonenumber/src/com/google/i18n/phonenumbers/PhoneNumberUtil.java#L3236-L3250
            // It doesn't check for the "possibility" of the original `number`.
            // I guess it's fine not checking that one. It works as is anyway.
            if (!isPossibleIncompleteNationalNumber(nationalNumber, country, metadata)) {
                // Don't strip the national prefix.
                return {
                    nationalNumber: number
                };
            }
        }
    }
    return {
        nationalNumber: nationalNumber,
        carrierCode: carrierCode
    };
}
// In some countries, the same digit could be a national prefix
// or a leading digit of a valid phone number.
// For example, in Russia, national prefix is `8`,
// and also `800 555 35 35` is a valid number
// in which `8` is not a national prefix, but the first digit
// of a national (significant) number.
// Same's with Belarus:
// `82004910060` is a valid national (significant) number,
// but `2004910060` is not.
// To support such cases (to prevent the code from always stripping
// national prefix), a condition is imposed: a national prefix
// is not extracted when the original number is "viable" and the
// resultant number is not, a "viable" national number being the one
// that matches `national_number_pattern`.
function shouldHaveExtractedNationalPrefix(nationalNumberBefore, nationalNumberAfter, metadata) {
    // The equivalent in Google's code is:
    // https://github.com/google/libphonenumber/blob/e326fa1fc4283bb05eb35cb3c15c18f98a31af33/java/libphonenumber/src/com/google/i18n/phonenumbers/PhoneNumberUtil.java#L2969-L3004
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$matchesEntirely$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(nationalNumberBefore, metadata.nationalNumberPattern()) && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$matchesEntirely$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(nationalNumberAfter, metadata.nationalNumberPattern())) {
        return false;
    }
    // This "is possible" national number (length) check has been commented out
    // because it's superceded by the (effectively) same check done in the
    // `extractNationalNumber()` function after it calls `shouldHaveExtractedNationalPrefix()`.
    // In other words, why run the same check twice if it could only be run once.
    // // Check the national (significant) number length after extracting national prefix and carrier code.
    // // Fixes a minor "weird behavior" bug: https://gitlab.com/catamphetamine/libphonenumber-js/-/issues/57
    // // (Legacy generated metadata (before `1.0.18`) didn't support the "possible lengths" feature).
    // if (metadata.possibleLengths()) {
    // 	if (isPossibleIncompleteNationalNumber(nationalNumberBefore, metadata) &&
    // 		!isPossibleIncompleteNationalNumber(nationalNumberAfter, metadata)) {
    // 		return false
    // 	}
    // }
    return true;
}
function isPossibleIncompleteNationalNumber(nationalNumber, country, metadata) {
    switch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$checkNumberLength$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(nationalNumber, country, metadata)){
        case 'TOO_SHORT':
        case 'INVALID_LENGTH':
            // This library ignores "local-only" phone numbers (for simplicity).
            // See the readme for more info on what are "local-only" phone numbers.
            // case 'IS_POSSIBLE_LOCAL_ONLY':
            return false;
        default:
            return true;
    }
}
}),
"[project]/node_modules/libphonenumber-js/es6/helpers/extractCountryCallingCodeFromInternationalNumberWithoutPlusSign.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>extractCountryCallingCodeFromInternationalNumberWithoutPlusSign
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$metadata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/metadata.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$matchesEntirely$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/matchesEntirely.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$extractNationalNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/extractNationalNumber.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$checkNumberLength$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/checkNumberLength.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$metadata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__getCountryCallingCode__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/metadata.js [app-client] (ecmascript) <export getCountryCallingCode as default>");
;
;
;
;
;
function extractCountryCallingCodeFromInternationalNumberWithoutPlusSign(number, country, defaultCountry, defaultCallingCode, metadata) {
    var countryCallingCode = country || defaultCountry ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$metadata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__getCountryCallingCode__as__default$3e$__["default"])(country || defaultCountry, metadata) : defaultCallingCode;
    if (number.indexOf(countryCallingCode) === 0) {
        metadata = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$metadata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"](metadata);
        metadata.selectNumberingPlan(country || defaultCountry, countryCallingCode);
        var possibleShorterNumber = number.slice(countryCallingCode.length);
        var _extractNationalNumbe = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$extractNationalNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(possibleShorterNumber, country, metadata), possibleShorterNationalNumber = _extractNationalNumbe.nationalNumber;
        var _extractNationalNumbe2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$extractNationalNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(number, country, metadata), nationalNumber = _extractNationalNumbe2.nationalNumber;
        // If the number was not valid before but is valid now,
        // or if it was too long before, we consider the number
        // with the country calling code stripped to be a better result
        // and keep that instead.
        // For example, in Germany (+49), `49` is a valid area code,
        // so if a number starts with `49`, it could be both a valid
        // national German number or an international number without
        // a leading `+`.
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$matchesEntirely$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(nationalNumber, metadata.nationalNumberPattern()) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$matchesEntirely$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(possibleShorterNationalNumber, metadata.nationalNumberPattern()) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$checkNumberLength$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(nationalNumber, country, metadata) === 'TOO_LONG') {
            return {
                countryCallingCode: countryCallingCode,
                number: possibleShorterNumber
            };
        }
    }
    return {
        number: number
    };
}
}),
"[project]/node_modules/libphonenumber-js/es6/helpers/extractCountryCallingCode.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>extractCountryCallingCode
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$stripIddPrefix$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/stripIddPrefix.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$extractCountryCallingCodeFromInternationalNumberWithoutPlusSign$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/extractCountryCallingCodeFromInternationalNumberWithoutPlusSign.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$metadata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/metadata.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/constants.js [app-client] (ecmascript)");
;
;
;
;
function extractCountryCallingCode(number, country, defaultCountry, defaultCallingCode, metadata) {
    if (!number) {
        return {};
    }
    var isNumberWithIddPrefix;
    // If this is not an international phone number,
    // then either extract an "IDD" prefix, or extract a
    // country calling code from a number by autocorrecting it
    // by prepending a leading `+` in cases when it starts
    // with the country calling code.
    // https://wikitravel.org/en/International_dialling_prefix
    // https://github.com/catamphetamine/libphonenumber-js/issues/376
    if (number[0] !== '+') {
        // Convert an "out-of-country" dialing phone number
        // to a proper international phone number.
        var numberWithoutIDD = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$stripIddPrefix$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(number, country || defaultCountry, defaultCallingCode, metadata);
        // If an IDD prefix was stripped then
        // convert the number to international one
        // for subsequent parsing.
        if (numberWithoutIDD && numberWithoutIDD !== number) {
            isNumberWithIddPrefix = true;
            number = '+' + numberWithoutIDD;
        } else {
            // Check to see if the number starts with the country calling code
            // for the default country. If so, we remove the country calling code,
            // and do some checks on the validity of the number before and after.
            // https://github.com/catamphetamine/libphonenumber-js/issues/376
            if (country || defaultCountry || defaultCallingCode) {
                var _extractCountryCallin = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$extractCountryCallingCodeFromInternationalNumberWithoutPlusSign$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(number, country, defaultCountry, defaultCallingCode, metadata), countryCallingCode = _extractCountryCallin.countryCallingCode, shorterNumber = _extractCountryCallin.number;
                if (countryCallingCode) {
                    return {
                        countryCallingCodeSource: 'FROM_NUMBER_WITHOUT_PLUS_SIGN',
                        countryCallingCode: countryCallingCode,
                        number: shorterNumber
                    };
                }
            }
            return {
                // No need to set it to `UNSPECIFIED`. It can be just `undefined`.
                // countryCallingCodeSource: 'UNSPECIFIED',
                number: number
            };
        }
    }
    // `number` can only be international at this point.
    // Fast abortion: country codes do not begin with a '0'
    if (number[1] === '0') {
        return {};
    }
    metadata = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$metadata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"](metadata);
    // The thing with country phone codes
    // is that they are orthogonal to each other
    // i.e. there's no such country phone code A
    // for which country phone code B exists
    // where B starts with A.
    // Therefore, while scanning digits,
    // if a valid country code is found,
    // that means that it is the country code.
    //
    var i = 2;
    while(i - 1 <= __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MAX_LENGTH_COUNTRY_CODE"] && i <= number.length){
        var _countryCallingCode = number.slice(1, i);
        if (metadata.hasCallingCode(_countryCallingCode)) {
            metadata.selectNumberingPlan(_countryCallingCode);
            return {
                countryCallingCodeSource: isNumberWithIddPrefix ? 'FROM_NUMBER_WITH_IDD' : 'FROM_NUMBER_WITH_PLUS_SIGN',
                countryCallingCode: _countryCallingCode,
                number: number.slice(i)
            };
        }
        i++;
    }
    return {};
} // The possible values for the returned `countryCallingCodeSource` are:
 //
 // Copy-pasted from:
 // https://github.com/google/libphonenumber/blob/master/resources/phonenumber.proto
 //
 // // The source from which the country_code is derived. This is not set in the
 // // general parsing method, but in the method that parses and keeps raw_input.
 // // New fields could be added upon request.
 // enum CountryCodeSource {
 //  // Default value returned if this is not set, because the phone number was
 //  // created using parse, not parseAndKeepRawInput. hasCountryCodeSource will
 //  // return false if this is the case.
 //  UNSPECIFIED = 0;
 //
 //  // The country_code is derived based on a phone number with a leading "+",
 //  // e.g. the French number "+33 1 42 68 53 00".
 //  FROM_NUMBER_WITH_PLUS_SIGN = 1;
 //
 //  // The country_code is derived based on a phone number with a leading IDD,
 //  // e.g. the French number "011 33 1 42 68 53 00", as it is dialled from US.
 //  FROM_NUMBER_WITH_IDD = 5;
 //
 //  // The country_code is derived based on a phone number without a leading
 //  // "+", e.g. the French number "33 1 42 68 53 00" when defaultCountry is
 //  // supplied as France.
 //  FROM_NUMBER_WITHOUT_PLUS_SIGN = 10;
 //
 //  // The country_code is derived NOT based on the phone number itself, but
 //  // from the defaultCountry parameter provided in the parsing function by the
 //  // clients. This happens mostly for numbers written in the national format
 //  // (without country code). For example, this would be set when parsing the
 //  // French number "01 42 68 53 00", when defaultCountry is supplied as
 //  // France.
 //  FROM_DEFAULT_COUNTRY = 20;
 // }
}),
"[project]/node_modules/libphonenumber-js/es6/helpers/applyInternationalSeparatorStyle.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>applyInternationalSeparatorStyle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/constants.js [app-client] (ecmascript)");
;
function applyInternationalSeparatorStyle(formattedNumber) {
    return formattedNumber.replace(new RegExp("[".concat(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VALID_PUNCTUATION"], "]+"), 'g'), ' ').trim();
}
}),
"[project]/node_modules/libphonenumber-js/es6/helpers/formatNationalNumberUsingFormat.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FIRST_GROUP_PATTERN",
    ()=>FIRST_GROUP_PATTERN,
    "default",
    ()=>formatNationalNumberUsingFormat
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$applyInternationalSeparatorStyle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/applyInternationalSeparatorStyle.js [app-client] (ecmascript)");
;
var FIRST_GROUP_PATTERN = /(\$\d)/;
function formatNationalNumberUsingFormat(number, format, _ref) {
    var useInternationalFormat = _ref.useInternationalFormat, withNationalPrefix = _ref.withNationalPrefix, carrierCode = _ref.carrierCode, metadata = _ref.metadata;
    var formattedNumber = number.replace(new RegExp(format.pattern()), useInternationalFormat ? format.internationalFormat() : // This library doesn't use `domestic_carrier_code_formatting_rule`,
    // because that one is only used when formatting phone numbers
    // for dialing from a mobile phone, and this is not a dialing library.
    // carrierCode && format.domesticCarrierCodeFormattingRule()
    // 	// First, replace the $CC in the formatting rule with the desired carrier code.
    // 	// Then, replace the $FG in the formatting rule with the first group
    // 	// and the carrier code combined in the appropriate way.
    // 	? format.format().replace(FIRST_GROUP_PATTERN, format.domesticCarrierCodeFormattingRule().replace('$CC', carrierCode))
    // 	: (
    // 		withNationalPrefix && format.nationalPrefixFormattingRule()
    // 			? format.format().replace(FIRST_GROUP_PATTERN, format.nationalPrefixFormattingRule())
    // 			: format.format()
    // 	)
    withNationalPrefix && format.nationalPrefixFormattingRule() ? format.format().replace(FIRST_GROUP_PATTERN, format.nationalPrefixFormattingRule()) : format.format());
    if (useInternationalFormat) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$applyInternationalSeparatorStyle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(formattedNumber);
    }
    return formattedNumber;
}
}),
"[project]/node_modules/libphonenumber-js/es6/helpers/getIddPrefix.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>getIddPrefix
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$metadata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/metadata.js [app-client] (ecmascript)");
;
/**
 * Pattern that makes it easy to distinguish whether a region has a single
 * international dialing prefix or not. If a region has a single international
 * prefix (e.g. 011 in USA), it will be represented as a string that contains
 * a sequence of ASCII digits, and possibly a tilde, which signals waiting for
 * the tone. If there are multiple available international prefixes in a
 * region, they will be represented as a regex string that always contains one
 * or more characters that are not ASCII digits or a tilde.
 */ var SINGLE_IDD_PREFIX_REG_EXP = /^[\d]+(?:[~\u2053\u223C\uFF5E][\d]+)?$/;
function getIddPrefix(country, callingCode, metadata) {
    var countryMetadata = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$metadata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"](metadata);
    countryMetadata.selectNumberingPlan(country, callingCode);
    if (countryMetadata.defaultIDDPrefix()) {
        return countryMetadata.defaultIDDPrefix();
    }
    if (SINGLE_IDD_PREFIX_REG_EXP.test(countryMetadata.IDDPrefix())) {
        return countryMetadata.IDDPrefix();
    }
}
}),
"[project]/node_modules/libphonenumber-js/es6/helpers/RFC3966.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "formatRFC3966",
    ()=>formatRFC3966,
    "parseRFC3966",
    ()=>parseRFC3966
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$isViablePhoneNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/isViablePhoneNumber.js [app-client] (ecmascript)");
function _slicedToArray(r, e) {
    return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest();
}
function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _iterableToArrayLimit(r, l) {
    var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
    if (null != t) {
        var e, n, i, u, a = [], f = !0, o = !1;
        try {
            if (i = (t = t.call(r)).next, 0 === l) {
                if (Object(t) !== t) return;
                f = !1;
            } else for(; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);
        } catch (r) {
            o = !0, n = r;
        } finally{
            try {
                if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return;
            } finally{
                if (o) throw n;
            }
        }
        return a;
    }
}
function _arrayWithHoles(r) {
    if (Array.isArray(r)) return r;
}
function _createForOfIteratorHelperLoose(r, e) {
    var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
    if (t) return (t = t.call(r)).next.bind(t);
    if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) {
        t && (r = t);
        var o = 0;
        return function() {
            return o >= r.length ? {
                done: !0
            } : {
                done: !1,
                value: r[o++]
            };
        };
    }
    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(r, a) {
    if (r) {
        if ("string" == typeof r) return _arrayLikeToArray(r, a);
        var t = ({}).toString.call(r).slice(8, -1);
        return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
    }
}
function _arrayLikeToArray(r, a) {
    (null == a || a > r.length) && (a = r.length);
    for(var e = 0, n = Array(a); e < a; e++)n[e] = r[e];
    return n;
}
;
function parseRFC3966(text) {
    var number;
    var ext;
    // Replace "tel:" with "tel=" for parsing convenience.
    text = text.replace(/^tel:/, 'tel=');
    for(var _iterator = _createForOfIteratorHelperLoose(text.split(';')), _step; !(_step = _iterator()).done;){
        var part = _step.value;
        var _part$split = part.split('='), _part$split2 = _slicedToArray(_part$split, 2), name = _part$split2[0], value = _part$split2[1];
        switch(name){
            case 'tel':
                number = value;
                break;
            case 'ext':
                ext = value;
                break;
            case 'phone-context':
                // Only "country contexts" are supported.
                // "Domain contexts" are ignored.
                if (value[0] === '+') {
                    number = value + number;
                }
                break;
        }
    }
    // If the phone number is not viable, then abort.
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$isViablePhoneNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(number)) {
        return {};
    }
    var result = {
        number: number
    };
    if (ext) {
        result.ext = ext;
    }
    return result;
}
function formatRFC3966(_ref) {
    var number = _ref.number, ext = _ref.ext;
    if (!number) {
        return '';
    }
    if (number[0] !== '+') {
        throw new Error("\"formatRFC3966()\" expects \"number\" to be in E.164 format.");
    }
    return "tel:".concat(number).concat(ext ? ';ext=' + ext : '');
}
}),
"[project]/node_modules/libphonenumber-js/es6/format.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "chooseFormatForNumber",
    ()=>chooseFormatForNumber,
    "default",
    ()=>formatNumber
]);
// This is a port of Google Android `libphonenumber`'s
// `phonenumberutil.js` of December 31th, 2018.
//
// https://github.com/googlei18n/libphonenumber/commits/master/javascript/i18n/phonenumbers/phonenumberutil.js
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$matchesEntirely$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/matchesEntirely.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$formatNationalNumberUsingFormat$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/formatNationalNumberUsingFormat.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$metadata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/metadata.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$getIddPrefix$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/getIddPrefix.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$RFC3966$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/RFC3966.js [app-client] (ecmascript)");
;
;
;
;
;
var DEFAULT_OPTIONS = {
    formatExtension: function formatExtension(formattedNumber, extension, metadata) {
        return "".concat(formattedNumber).concat(metadata.ext()).concat(extension);
    }
};
function formatNumber(input, format, options, metadata) {
    // Apply default options.
    if (options) {
        // Using ES6 "rest spread" syntax here didn't work with `babel`/`istanbul`
        // for some weird reason: this line of code would cause the code coverage
        // to show as not 100%. That's because `babel`/`istanbul`, for some weird reason,
        // apparently doesn't know how to properly exclude Babel polyfills from code coverage.
        //
        // options = { ...DEFAULT_OPTIONS, ...options }
        //
        options = merge({}, DEFAULT_OPTIONS, options);
    } else {
        options = DEFAULT_OPTIONS;
    }
    metadata = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$metadata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"](metadata);
    // Normally, the `input` object is supposed to be a `PhoneNumber` class instance.
    // Also, according to the `PhoneNumber` class source code, `country` can't be "001".
    // It means that normally `input.country` or `input.countryCallingCode` is supposed
    // to be present because either of the two is always required to exist in a `PhoneNumber` instance.
    // This means that realistically, it's gonna step into either the first `if`
    // or the following `else if`, and normally it won't even reach the legacy-compatibility
    // `else return input.phone || ''` part.
    // So normally, it won't ever return an empty string here.
    if (input.country && input.country !== '001') {
        // Validate `input.country`.
        if (!metadata.hasCountry(input.country)) {
            throw new Error("Unknown country: ".concat(input.country));
        }
        metadata.selectNumberingPlan(input.country);
    } else if (input.countryCallingCode) {
        metadata.selectNumberingPlan(input.countryCallingCode);
    } else return input.phone || '';
    var countryCallingCode = metadata.countryCallingCode();
    var nationalNumber = options.v2 ? input.nationalNumber : input.phone;
    // This variable should have been declared inside `case`s
    // but Babel has a bug and it says "duplicate variable declaration".
    var number;
    switch(format){
        case 'NATIONAL':
            // Normally, the `input` object is supposed to be a `PhoneNumber` class instance,
            // and a `PhoneNumber` class instance is always required to have a `nationalNumber`.
            // This means that the `if (!nationalNumber)` below is just for legacy-compatibility
            // and it normally can't really happen, so normally it won't ever return an empty string here.
            if (!nationalNumber) {
                return '';
            }
            number = formatNationalNumber(nationalNumber, input.carrierCode, 'NATIONAL', metadata, options);
            return addExtension(number, input.ext, metadata, options.formatExtension);
        case 'INTERNATIONAL':
            // Legacy argument support.
            // (`{ country: ..., phone: '' }`)
            if (!nationalNumber) {
                return "+".concat(countryCallingCode);
            }
            number = formatNationalNumber(nationalNumber, null, 'INTERNATIONAL', metadata, options);
            number = "+".concat(countryCallingCode, " ").concat(number);
            return addExtension(number, input.ext, metadata, options.formatExtension);
        case 'E.164':
            // `E.164` doesn't define "phone number extensions".
            return "+".concat(countryCallingCode).concat(nationalNumber);
        case 'RFC3966':
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$RFC3966$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatRFC3966"])({
                number: "+".concat(countryCallingCode).concat(nationalNumber),
                ext: input.ext
            });
        // For reference, here's Google's IDD formatter:
        // https://github.com/google/libphonenumber/blob/32719cf74e68796788d1ca45abc85dcdc63ba5b9/java/libphonenumber/src/com/google/i18n/phonenumbers/PhoneNumberUtil.java#L1546
        // Not saying that this IDD formatter replicates it 1:1, but it seems to work.
        // Who would even need to format phone numbers in IDD format anyway?
        case 'IDD':
            // If the required `fromCountry` parameter is not passed, it will return `undefined`.
            if (!options.fromCountry) {
                return;
            // throw new Error('`fromCountry` option not passed for IDD-prefixed formatting.')
            }
            var formattedNumber = formatIDD(nationalNumber, input.carrierCode, countryCallingCode, options.fromCountry, metadata);
            // If the country of the phone number doesn't support IDD calling, it will return `undefined`.
            if (!formattedNumber) {
                return;
            }
            return addExtension(formattedNumber, input.ext, metadata, options.formatExtension);
        default:
            throw new Error("Unknown \"format\" argument passed to \"formatNumber()\": \"".concat(format, "\""));
    }
}
function formatNationalNumber(number, carrierCode, formatAs, metadata, options) {
    var format = chooseFormatForNumber(metadata.formats(), number);
    if (!format) {
        return number;
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$formatNationalNumberUsingFormat$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(number, format, {
        useInternationalFormat: formatAs === 'INTERNATIONAL',
        withNationalPrefix: format.nationalPrefixIsOptionalWhenFormattingInNationalFormat() && options && options.nationalPrefix === false ? false : true,
        carrierCode: carrierCode,
        metadata: metadata
    });
}
function chooseFormatForNumber(availableFormats, nationalNumber) {
    // Using a `for ... of` loop here didn't work with `babel`/`istanbul`:
    // for some weird reason, it showed code coverage less than 100%.
    // That's because `babel`/`istanbul`, for some weird reason,
    // apparently doesn't know how to properly exclude Babel polyfills from code coverage.
    //
    // for (const format of availableFormats) { ... }
    //
    return pickFirstMatchingElement(availableFormats, function(format) {
        // Validate leading digits.
        // The test case for "else path" could be found by searching for
        // "format.leadingDigitsPatterns().length === 0".
        if (format.leadingDigitsPatterns().length > 0) {
            // The last leading_digits_pattern is used here, as it is the most detailed
            var lastLeadingDigitsPattern = format.leadingDigitsPatterns()[format.leadingDigitsPatterns().length - 1];
            // If leading digits don't match then move on to the next phone number format
            if (nationalNumber.search(lastLeadingDigitsPattern) !== 0) {
                return false;
            }
        }
        // Check that the national number matches the phone number format regular expression
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$matchesEntirely$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(nationalNumber, format.pattern());
    });
}
function addExtension(formattedNumber, ext, metadata, formatExtension) {
    return ext ? formatExtension(formattedNumber, ext, metadata) : formattedNumber;
}
function formatIDD(nationalNumber, carrierCode, countryCallingCode, fromCountry, metadata) {
    var fromCountryCallingCode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$metadata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCountryCallingCode"])(fromCountry, metadata.metadata);
    // When calling within the same country calling code.
    if (fromCountryCallingCode === countryCallingCode) {
        var formattedNumber = formatNationalNumber(nationalNumber, carrierCode, 'NATIONAL', metadata);
        // For NANPA regions, return the national format for these regions
        // but prefix it with the country calling code.
        if (countryCallingCode === '1') {
            return countryCallingCode + ' ' + formattedNumber;
        }
        // If regions share a country calling code, the country calling code need
        // not be dialled. This also applies when dialling within a region, so this
        // if clause covers both these cases. Technically this is the case for
        // dialling from La Reunion to other overseas departments of France (French
        // Guiana, Martinique, Guadeloupe), but not vice versa - so we don't cover
        // this edge case for now and for those cases return the version including
        // country calling code. Details here:
        // http://www.petitfute.com/voyage/225-info-pratiques-reunion
        //
        return formattedNumber;
    }
    var iddPrefix = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$getIddPrefix$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(fromCountry, undefined, metadata.metadata);
    if (iddPrefix) {
        return "".concat(iddPrefix, " ").concat(countryCallingCode, " ").concat(formatNationalNumber(nationalNumber, null, 'INTERNATIONAL', metadata));
    }
}
function merge() {
    var i = 1;
    for(var _len = arguments.length, objects = new Array(_len), _key = 0; _key < _len; _key++){
        objects[_key] = arguments[_key];
    }
    while(i < objects.length){
        if (objects[i]) {
            for(var key in objects[i]){
                objects[0][key] = objects[i][key];
            }
        }
        i++;
    }
    return objects[0];
}
function pickFirstMatchingElement(elements, testFunction) {
    var i = 0;
    while(i < elements.length){
        if (testFunction(elements[i])) {
            return elements[i];
        }
        i++;
    }
}
}),
"[project]/node_modules/libphonenumber-js/es6/PhoneNumber.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PhoneNumber
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$metadata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/metadata.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$isPossible$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/isPossible.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$isValid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/isValid.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$getNumberType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/getNumberType.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$getPossibleCountriesForNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/getPossibleCountriesForNumber.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$extractCountryCallingCode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/extractCountryCallingCode.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$isObject$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/isObject.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/format.js [app-client] (ecmascript)");
function _typeof(o) {
    "@babel/helpers - typeof";
    return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
        return typeof o;
    } : function(o) {
        return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
    }, _typeof(o);
}
function ownKeys(e, r) {
    var t = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        r && (o = o.filter(function(r) {
            return Object.getOwnPropertyDescriptor(e, r).enumerable;
        })), t.push.apply(t, o);
    }
    return t;
}
function _objectSpread(e) {
    for(var r = 1; r < arguments.length; r++){
        var t = null != arguments[r] ? arguments[r] : {};
        r % 2 ? ownKeys(Object(t), !0).forEach(function(r) {
            _defineProperty(e, r, t[r]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
            Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
        });
    }
    return e;
}
function _defineProperty(e, r, t) {
    return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
        value: t,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[r] = t, e;
}
function _classCallCheck(a, n) {
    if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties(e, r) {
    for(var t = 0; t < r.length; t++){
        var o = r[t];
        o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, _toPropertyKey(o.key), o);
    }
}
function _createClass(e, r, t) {
    return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", {
        writable: !1
    }), e;
}
function _toPropertyKey(t) {
    var i = _toPrimitive(t, "string");
    return "symbol" == _typeof(i) ? i : i + "";
}
function _toPrimitive(t, r) {
    if ("object" != _typeof(t) || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
        var i = e.call(t, r || "default");
        if ("object" != _typeof(i)) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
}
;
;
;
;
;
;
;
;
var USE_NON_GEOGRAPHIC_COUNTRY_CODE = false;
var PhoneNumber = /*#__PURE__*/ function() {
    /**
   * @param  {string} countryOrCountryCallingCode
   * @param  {string} nationalNumber
   * @param  {object} metadata — Metadata JSON
   * @return {PhoneNumber}
   */ function PhoneNumber(countryOrCountryCallingCode, nationalNumber, metadata) {
        _classCallCheck(this, PhoneNumber);
        // Validate `countryOrCountryCallingCode` argument.
        if (!countryOrCountryCallingCode) {
            throw new TypeError('First argument is required');
        }
        if (typeof countryOrCountryCallingCode !== 'string') {
            throw new TypeError('First argument must be a string');
        }
        // In case of public API use: `constructor(number, metadata)`.
        // Transform the arguments from `constructor(number, metadata)` to
        // `constructor(countryOrCountryCallingCode, nationalNumber, metadata)`.
        if (countryOrCountryCallingCode[0] === '+' && !nationalNumber) {
            throw new TypeError('`metadata` argument not passed');
        }
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$isObject$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(nationalNumber) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$isObject$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(nationalNumber.countries)) {
            metadata = nationalNumber;
            var e164Number = countryOrCountryCallingCode;
            if (!E164_NUMBER_REGEXP.test(e164Number)) {
                throw new Error('Invalid `number` argument passed: must consist of a "+" followed by digits');
            }
            var _extractCountryCallin = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$extractCountryCallingCode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(e164Number, undefined, undefined, undefined, metadata), _countryCallingCode = _extractCountryCallin.countryCallingCode, number = _extractCountryCallin.number;
            nationalNumber = number;
            countryOrCountryCallingCode = _countryCallingCode;
            if (!nationalNumber) {
                throw new Error('Invalid `number` argument passed: too short');
            }
        }
        // Validate `nationalNumber` argument.
        if (!nationalNumber) {
            throw new TypeError('`nationalNumber` argument is required');
        }
        if (typeof nationalNumber !== 'string') {
            throw new TypeError('`nationalNumber` argument must be a string');
        }
        // Validate `metadata` argument.
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$metadata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateMetadata"])(metadata);
        // Initialize properties.
        var _getCountryAndCountry = getCountryAndCountryCallingCode(countryOrCountryCallingCode, metadata), country = _getCountryAndCountry.country, countryCallingCode = _getCountryAndCountry.countryCallingCode;
        this.country = country;
        this.countryCallingCode = countryCallingCode;
        this.nationalNumber = nationalNumber;
        this.number = '+' + this.countryCallingCode + this.nationalNumber;
        // Exclude `metadata` property output from `PhoneNumber.toString()`
        // so that it doesn't clutter the console output of Node.js.
        // Previously, when Node.js did `console.log(new PhoneNumber(...))`,
        // it would output the whole internal structure of the `metadata` object.
        this.getMetadata = function() {
            return metadata;
        };
    }
    return _createClass(PhoneNumber, [
        {
            key: "setExt",
            value: function setExt(ext) {
                this.ext = ext;
            }
        },
        {
            key: "getPossibleCountries",
            value: function getPossibleCountries() {
                if (this.country) {
                    return [
                        this.country
                    ];
                }
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$getPossibleCountriesForNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(this.countryCallingCode, this.nationalNumber, this.getMetadata());
            }
        },
        {
            key: "isPossible",
            value: function isPossible() {
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$isPossible$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(this, {
                    v2: true
                }, this.getMetadata());
            }
        },
        {
            key: "isValid",
            value: function isValid() {
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$isValid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(this, {
                    v2: true
                }, this.getMetadata());
            }
        },
        {
            key: "isNonGeographic",
            value: function isNonGeographic() {
                var metadata = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$metadata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"](this.getMetadata());
                return metadata.isNonGeographicCallingCode(this.countryCallingCode);
            }
        },
        {
            key: "isEqual",
            value: function isEqual(phoneNumber) {
                return this.number === phoneNumber.number && this.ext === phoneNumber.ext;
            }
        },
        {
            key: "getType",
            value: function getType() {
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$getNumberType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(this, {
                    v2: true
                }, this.getMetadata());
            }
        },
        {
            key: "format",
            value: function format(_format, options) {
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(this, _format, options ? _objectSpread(_objectSpread({}, options), {}, {
                    v2: true
                }) : {
                    v2: true
                }, this.getMetadata());
            }
        },
        {
            key: "formatNational",
            value: function formatNational(options) {
                return this.format('NATIONAL', options);
            }
        },
        {
            key: "formatInternational",
            value: function formatInternational(options) {
                return this.format('INTERNATIONAL', options);
            }
        },
        {
            key: "getURI",
            value: function getURI(options) {
                return this.format('RFC3966', options);
            }
        }
    ]);
}();
;
var isCountryCode = function isCountryCode(value) {
    return /^[A-Z]{2}$/.test(value);
};
function getCountryAndCountryCallingCode(countryOrCountryCallingCode, metadataJson) {
    var country;
    var countryCallingCode;
    var metadata = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$metadata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"](metadataJson);
    // If country code is passed then derive `countryCallingCode` from it.
    // Also store the country code as `.country`.
    if (isCountryCode(countryOrCountryCallingCode)) {
        country = countryOrCountryCallingCode;
        metadata.selectNumberingPlan(country);
        countryCallingCode = metadata.countryCallingCode();
    } else {
        countryCallingCode = countryOrCountryCallingCode;
        /* istanbul ignore if */ if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
    }
    return {
        country: country,
        countryCallingCode: countryCallingCode
    };
}
var E164_NUMBER_REGEXP = /^\+\d+$/;
}),
"[project]/node_modules/libphonenumber-js/es6/helpers/extractPhoneContext.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PLUS_SIGN",
    ()=>PLUS_SIGN,
    "RFC3966_ISDN_SUBADDRESS_",
    ()=>RFC3966_ISDN_SUBADDRESS_,
    "RFC3966_PHONE_CONTEXT_",
    ()=>RFC3966_PHONE_CONTEXT_,
    "RFC3966_PREFIX_",
    ()=>RFC3966_PREFIX_,
    "default",
    ()=>extractPhoneContext,
    "isPhoneContextValid",
    ()=>isPhoneContextValid
]);
// When phone numbers are written in `RFC3966` format — `"tel:+12133734253"` —
// they can have their "calling code" part written separately in a `phone-context` parameter.
// Example: `"tel:12133734253;phone-context=+1"`.
// This function parses the full phone number from the local number and the `phone-context`
// when the `phone-context` contains a `+` sign.
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/constants.js [app-client] (ecmascript)");
;
var PLUS_SIGN = '+';
var RFC3966_VISUAL_SEPARATOR_ = '[\\-\\.\\(\\)]?';
var RFC3966_PHONE_DIGIT_ = '(' + '[' + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VALID_DIGITS"] + ']' + '|' + RFC3966_VISUAL_SEPARATOR_ + ')';
var RFC3966_GLOBAL_NUMBER_DIGITS_ = '^' + '\\' + PLUS_SIGN + RFC3966_PHONE_DIGIT_ + '*' + '[' + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VALID_DIGITS"] + ']' + RFC3966_PHONE_DIGIT_ + '*' + '$';
/**
 * Regular expression of valid global-number-digits for the phone-context
 * parameter, following the syntax defined in RFC3966.
 */ var RFC3966_GLOBAL_NUMBER_DIGITS_PATTERN_ = new RegExp(RFC3966_GLOBAL_NUMBER_DIGITS_, 'g');
// In this port of Google's library, we don't accept alpha characters in phone numbers.
// const ALPHANUM_ = VALID_ALPHA_ + VALID_DIGITS
var ALPHANUM_ = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VALID_DIGITS"];
var RFC3966_DOMAINLABEL_ = '[' + ALPHANUM_ + ']+((\\-)*[' + ALPHANUM_ + '])*';
var VALID_ALPHA_ = 'a-zA-Z';
var RFC3966_TOPLABEL_ = '[' + VALID_ALPHA_ + ']+((\\-)*[' + ALPHANUM_ + '])*';
var RFC3966_DOMAINNAME_ = '^(' + RFC3966_DOMAINLABEL_ + '\\.)*' + RFC3966_TOPLABEL_ + '\\.?$';
/**
 * Regular expression of valid domainname for the phone-context parameter,
 * following the syntax defined in RFC3966.
 */ var RFC3966_DOMAINNAME_PATTERN_ = new RegExp(RFC3966_DOMAINNAME_, 'g');
var RFC3966_PREFIX_ = 'tel:';
var RFC3966_PHONE_CONTEXT_ = ';phone-context=';
var RFC3966_ISDN_SUBADDRESS_ = ';isub=';
function extractPhoneContext(numberToExtractFrom) {
    var indexOfPhoneContext = numberToExtractFrom.indexOf(RFC3966_PHONE_CONTEXT_);
    // If no phone-context parameter is present
    if (indexOfPhoneContext < 0) {
        return null;
    }
    var phoneContextStart = indexOfPhoneContext + RFC3966_PHONE_CONTEXT_.length;
    // If phone-context parameter is empty
    if (phoneContextStart >= numberToExtractFrom.length) {
        return '';
    }
    var phoneContextEnd = numberToExtractFrom.indexOf(';', phoneContextStart);
    // If phone-context is not the last parameter
    if (phoneContextEnd >= 0) {
        return numberToExtractFrom.substring(phoneContextStart, phoneContextEnd);
    } else {
        return numberToExtractFrom.substring(phoneContextStart);
    }
}
function isPhoneContextValid(phoneContext) {
    if (phoneContext === null) {
        return true;
    }
    if (phoneContext.length === 0) {
        return false;
    }
    // Does phone-context value match pattern of global-number-digits or domainname.
    return RFC3966_GLOBAL_NUMBER_DIGITS_PATTERN_.test(phoneContext) || RFC3966_DOMAINNAME_PATTERN_.test(phoneContext);
}
}),
"[project]/node_modules/libphonenumber-js/es6/helpers/extractFormattedPhoneNumberFromPossibleRfc3966NumberUri.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>extractFormattedPhoneNumberFromPossibleRfc3966NumberUri
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$extractPhoneContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/extractPhoneContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$ParseError$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/ParseError.js [app-client] (ecmascript)");
;
;
function extractFormattedPhoneNumberFromPossibleRfc3966NumberUri(numberToParse, _ref) {
    var extractFormattedPhoneNumber = _ref.extractFormattedPhoneNumber;
    var phoneContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$extractPhoneContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(numberToParse);
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$extractPhoneContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPhoneContextValid"])(phoneContext)) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$ParseError$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]('NOT_A_NUMBER');
    }
    var phoneNumberString;
    if (phoneContext === null) {
        // Extract a possible number from the string passed in.
        // (this strips leading characters that could not be the start of a phone number)
        phoneNumberString = extractFormattedPhoneNumber(numberToParse) || '';
    } else {
        phoneNumberString = '';
        // If the phone context contains a phone number prefix, we need to capture
        // it, whereas domains will be ignored.
        if (phoneContext.charAt(0) === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$extractPhoneContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PLUS_SIGN"]) {
            phoneNumberString += phoneContext;
        }
        // Now append everything between the "tel:" prefix and the phone-context.
        // This should include the national number, an optional extension or
        // isdn-subaddress component. Note we also handle the case when "tel:" is
        // missing, as we have seen in some of the phone number inputs.
        // In that case, we append everything from the beginning.
        var indexOfRfc3966Prefix = numberToParse.indexOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$extractPhoneContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RFC3966_PREFIX_"]);
        var indexOfNationalNumber;
        // RFC 3966 "tel:" prefix is preset at this stage because
        // `isPhoneContextValid()` requires it to be present.
        /* istanbul ignore else */ if (indexOfRfc3966Prefix >= 0) {
            indexOfNationalNumber = indexOfRfc3966Prefix + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$extractPhoneContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RFC3966_PREFIX_"].length;
        } else {
            indexOfNationalNumber = 0;
        }
        var indexOfPhoneContext = numberToParse.indexOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$extractPhoneContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RFC3966_PHONE_CONTEXT_"]);
        phoneNumberString += numberToParse.substring(indexOfNationalNumber, indexOfPhoneContext);
    }
    // Delete the isdn-subaddress and everything after it if it is present.
    // Note extension won't appear at the same time with isdn-subaddress
    // according to paragraph 5.3 of the RFC3966 spec.
    var indexOfIsdn = phoneNumberString.indexOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$extractPhoneContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RFC3966_ISDN_SUBADDRESS_"]);
    if (indexOfIsdn > 0) {
        phoneNumberString = phoneNumberString.substring(0, indexOfIsdn);
    }
    // If both phone context and isdn-subaddress are absent but other
    // parameters are present, the parameters are left in nationalNumber.
    // This is because we are concerned about deleting content from a potential
    // number string when there is no strong evidence that the number is
    // actually written in RFC3966.
    if (phoneNumberString !== '') {
        return phoneNumberString;
    }
}
}),
"[project]/node_modules/libphonenumber-js/es6/parse.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>parse
]);
// This is a port of Google Android `libphonenumber`'s
// `phonenumberutil.js` of December 31th, 2018.
//
// https://github.com/googlei18n/libphonenumber/commits/master/javascript/i18n/phonenumbers/phonenumberutil.js
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$ParseError$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/ParseError.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$metadata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/metadata.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$isViablePhoneNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/isViablePhoneNumber.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$extension$2f$extractExtension$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/extension/extractExtension.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$parseIncompletePhoneNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/parseIncompletePhoneNumber.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$metadata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__getCountryCallingCode__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/metadata.js [app-client] (ecmascript) <export getCountryCallingCode as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$isPossible$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/isPossible.js [app-client] (ecmascript)");
// import { parseRFC3966 } from './helpers/RFC3966.js'
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$PhoneNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/PhoneNumber.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$matchesEntirely$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/matchesEntirely.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$extractCountryCallingCode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/extractCountryCallingCode.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$extractNationalNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/extractNationalNumber.js [app-client] (ecmascript)");
// import stripIddPrefix from './helpers/stripIddPrefix.js'
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$getCountryByCallingCode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/getCountryByCallingCode.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$extractFormattedPhoneNumberFromPossibleRfc3966NumberUri$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/helpers/extractFormattedPhoneNumberFromPossibleRfc3966NumberUri.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
// We don't allow input strings for parsing to be longer than 250 chars.
// This prevents malicious input from consuming CPU.
var MAX_INPUT_STRING_LENGTH = 250;
// This consists of the plus symbol, digits, and arabic-indic digits.
var PHONE_NUMBER_START_PATTERN = new RegExp('[' + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PLUS_CHARS"] + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VALID_DIGITS"] + ']');
// Regular expression of trailing characters that we want to remove.
// A trailing `#` is sometimes used when writing phone numbers with extensions in US.
// Example: "+1 (645) 123 1234-910#" number has extension "910".
var AFTER_PHONE_NUMBER_END_PATTERN = new RegExp('[^' + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VALID_DIGITS"] + '#' + ']+$');
var USE_NON_GEOGRAPHIC_COUNTRY_CODE = false;
function parse(text, options, metadata) {
    // If assigning the `{}` default value is moved to the arguments above,
    // code coverage would decrease for some weird reason.
    options = options || {};
    metadata = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$metadata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"](metadata);
    // Validate `defaultCountry`.
    if (options.defaultCountry && !metadata.hasCountry(options.defaultCountry)) {
        if (options.v2) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$ParseError$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]('INVALID_COUNTRY');
        }
        throw new Error("Unknown country: ".concat(options.defaultCountry));
    }
    // Parse the phone number.
    var _parseInput = parseInput(text, options.v2, options.extract), formattedPhoneNumber = _parseInput.number, ext = _parseInput.ext, error = _parseInput.error;
    // If the phone number is not viable then return nothing.
    if (!formattedPhoneNumber) {
        if (options.v2) {
            if (error === 'TOO_SHORT') {
                throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$ParseError$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]('TOO_SHORT');
            }
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$ParseError$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]('NOT_A_NUMBER');
        }
        return {};
    }
    var _parsePhoneNumber = parsePhoneNumber(formattedPhoneNumber, options.defaultCountry, options.defaultCallingCode, metadata), country = _parsePhoneNumber.country, nationalNumber = _parsePhoneNumber.nationalNumber, countryCallingCode = _parsePhoneNumber.countryCallingCode, countryCallingCodeSource = _parsePhoneNumber.countryCallingCodeSource, carrierCode = _parsePhoneNumber.carrierCode;
    if (!metadata.hasSelectedNumberingPlan()) {
        if (options.v2) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$ParseError$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]('INVALID_COUNTRY');
        }
        return {};
    }
    // Validate national (significant) number length.
    if (!nationalNumber || nationalNumber.length < __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MIN_LENGTH_FOR_NSN"]) {
        // Won't throw here because the regexp already demands length > 1.
        /* istanbul ignore if */ if (options.v2) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$ParseError$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]('TOO_SHORT');
        }
        // Google's demo just throws an error in this case.
        return {};
    }
    // Validate national (significant) number length.
    //
    // A sidenote:
    //
    // They say that sometimes national (significant) numbers
    // can be longer than `MAX_LENGTH_FOR_NSN` (e.g. in Germany).
    // https://github.com/googlei18n/libphonenumber/blob/7e1748645552da39c4e1ba731e47969d97bdb539/resources/phonenumber.proto#L36
    // Such numbers will just be discarded.
    //
    if (nationalNumber.length > __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MAX_LENGTH_FOR_NSN"]) {
        if (options.v2) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$ParseError$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]('TOO_LONG');
        }
        // Google's demo just throws an error in this case.
        return {};
    }
    if (options.v2) {
        var phoneNumber = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$PhoneNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"](countryCallingCode, nationalNumber, metadata.metadata);
        if (country) {
            phoneNumber.country = country;
        }
        if (carrierCode) {
            phoneNumber.carrierCode = carrierCode;
        }
        if (ext) {
            phoneNumber.ext = ext;
        }
        phoneNumber.__countryCallingCodeSource = countryCallingCodeSource;
        return phoneNumber;
    }
    // Check if national phone number pattern matches the number.
    // National number pattern is different for each country,
    // even for those ones which are part of the "NANPA" group.
    var valid = (options.extended ? metadata.hasSelectedNumberingPlan() : country) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$matchesEntirely$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(nationalNumber, metadata.nationalNumberPattern()) : false;
    if (!options.extended) {
        return valid ? result(country, nationalNumber, ext) : {};
    }
    // isInternational: countryCallingCode !== undefined
    return {
        country: country,
        countryCallingCode: countryCallingCode,
        carrierCode: carrierCode,
        valid: valid,
        possible: valid ? true : options.extended === true && metadata.possibleLengths() && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$isPossible$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPossibleNumber"])(nationalNumber, country, metadata) ? true : false,
        phone: nationalNumber,
        ext: ext
    };
}
/**
 * Extracts a formatted phone number from text.
 * Doesn't guarantee that the extracted phone number
 * is a valid phone number (for example, doesn't validate its length).
 * @param  {string} text
 * @param  {boolean} [extract] — If `false`, then will parse the entire `text` as a phone number.
 * @param  {boolean} [throwOnError] — By default, it won't throw if the text is too long.
 * @return {string}
 * @example
 * // Returns "(213) 373-4253".
 * extractFormattedPhoneNumber("Call (213) 373-4253 for assistance.")
 */ function _extractFormattedPhoneNumber(text, extract, throwOnError) {
    if (!text) {
        return;
    }
    if (text.length > MAX_INPUT_STRING_LENGTH) {
        if (throwOnError) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$ParseError$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]('TOO_LONG');
        }
        return;
    }
    if (extract === false) {
        return text;
    }
    // Attempt to extract a possible number from the string passed in
    var startsAt = text.search(PHONE_NUMBER_START_PATTERN);
    if (startsAt < 0) {
        return;
    }
    return text// Trim everything to the left of the phone number
    .slice(startsAt)// Remove trailing non-numerical characters
    .replace(AFTER_PHONE_NUMBER_END_PATTERN, '');
}
/**
 * @param  {string} text - Input.
 * @param  {boolean} v2 - Legacy API functions don't pass `v2: true` flag.
 * @param  {boolean} [extract] - Whether to extract a phone number from `text`, or attempt to parse the entire text as a phone number.
 * @return {object} `{ ?number, ?ext }`.
 */ function parseInput(text, v2, extract) {
    // // Parse RFC 3966 phone number URI.
    // if (text && text.indexOf('tel:') === 0) {
    // 	return parseRFC3966(text)
    // }
    // let number = extractFormattedPhoneNumber(text, extract, v2)
    var number = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$extractFormattedPhoneNumberFromPossibleRfc3966NumberUri$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(text, {
        extractFormattedPhoneNumber: function extractFormattedPhoneNumber(text) {
            return _extractFormattedPhoneNumber(text, extract, v2);
        }
    });
    // If the phone number is not viable, then abort.
    if (!number) {
        return {};
    }
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$isViablePhoneNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(number)) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$isViablePhoneNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isViablePhoneNumberStart"])(number)) {
            return {
                error: 'TOO_SHORT'
            };
        }
        return {};
    }
    // Attempt to parse extension first, since it doesn't require region-specific
    // data and we want to have the non-normalised number here.
    var withExtensionStripped = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$extension$2f$extractExtension$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(number);
    if (withExtensionStripped.ext) {
        return withExtensionStripped;
    }
    return {
        number: number
    };
}
/**
 * Creates `parse()` result object.
 */ function result(country, nationalNumber, ext) {
    var result = {
        country: country,
        phone: nationalNumber
    };
    if (ext) {
        result.ext = ext;
    }
    return result;
}
/**
 * Parses a viable phone number.
 * @param {string} formattedPhoneNumber — Example: "(213) 373-4253".
 * @param {string} [defaultCountry]
 * @param {string} [defaultCallingCode]
 * @param {Metadata} metadata
 * @return {object} Returns `{ country: string?, countryCallingCode: string?, nationalNumber: string? }`.
 */ function parsePhoneNumber(formattedPhoneNumber, defaultCountry, defaultCallingCode, metadata) {
    // Extract calling code from phone number.
    var _extractCountryCallin = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$extractCountryCallingCode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$parseIncompletePhoneNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(formattedPhoneNumber), undefined, defaultCountry, defaultCallingCode, metadata.metadata), countryCallingCodeSource = _extractCountryCallin.countryCallingCodeSource, countryCallingCode = _extractCountryCallin.countryCallingCode, number = _extractCountryCallin.number;
    // The exact country of the phone number
    var country;
    // If `formattedPhoneNumber` is passed in "international" format,
    // choose a country by `countryCallingCode`.
    if (countryCallingCode) {
        metadata.selectNumberingPlan(countryCallingCode);
    } else if (number && (defaultCountry || defaultCallingCode)) {
        metadata.selectNumberingPlan(defaultCountry, defaultCallingCode);
        if (defaultCountry) {
            country = defaultCountry;
        } else {
            /* istanbul ignore if */ if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
        }
        countryCallingCode = defaultCallingCode || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$metadata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__getCountryCallingCode__as__default$3e$__["default"])(defaultCountry, metadata.metadata);
    } else return {};
    if (!number) {
        return {
            countryCallingCodeSource: countryCallingCodeSource,
            countryCallingCode: countryCallingCode
        };
    }
    var _extractNationalNumbe = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$extractNationalNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$parseIncompletePhoneNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(number), country, metadata), nationalNumber = _extractNationalNumbe.nationalNumber, carrierCode = _extractNationalNumbe.carrierCode;
    // Sometimes there are several countries
    // corresponding to the same country phone code
    // (e.g. NANPA countries all having `1` country phone code).
    // Therefore, to reliably determine the exact country,
    // national (significant) number should have been parsed first.
    //
    // When `metadata.json` is generated, all "ambiguous" country phone codes
    // get their countries populated with the full set of
    // "phone number type" regular expressions.
    //
    var exactCountry = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$helpers$2f$getCountryByCallingCode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(countryCallingCode, {
        nationalNumber: nationalNumber,
        metadata: metadata
    });
    if (exactCountry) {
        country = exactCountry;
        /* istanbul ignore if */ if (exactCountry === '001') {
        // Can't happen with `USE_NON_GEOGRAPHIC_COUNTRY_CODE` being `false`.
        // If `USE_NON_GEOGRAPHIC_COUNTRY_CODE` is set to `true` for some reason,
        // then remove the "istanbul ignore if".
        } else {
            metadata.selectNumberingPlan(country);
        }
    }
    return {
        country: country,
        countryCallingCode: countryCallingCode,
        countryCallingCodeSource: countryCallingCodeSource,
        nationalNumber: nationalNumber,
        carrierCode: carrierCode
    };
}
}),
"[project]/node_modules/libphonenumber-js/es6/parsePhoneNumberWithError_.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>parsePhoneNumberWithError
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$parse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/parse.js [app-client] (ecmascript)");
function _typeof(o) {
    "@babel/helpers - typeof";
    return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
        return typeof o;
    } : function(o) {
        return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
    }, _typeof(o);
}
function ownKeys(e, r) {
    var t = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        r && (o = o.filter(function(r) {
            return Object.getOwnPropertyDescriptor(e, r).enumerable;
        })), t.push.apply(t, o);
    }
    return t;
}
function _objectSpread(e) {
    for(var r = 1; r < arguments.length; r++){
        var t = null != arguments[r] ? arguments[r] : {};
        r % 2 ? ownKeys(Object(t), !0).forEach(function(r) {
            _defineProperty(e, r, t[r]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
            Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
        });
    }
    return e;
}
function _defineProperty(e, r, t) {
    return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
        value: t,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[r] = t, e;
}
function _toPropertyKey(t) {
    var i = _toPrimitive(t, "string");
    return "symbol" == _typeof(i) ? i : i + "";
}
function _toPrimitive(t, r) {
    if ("object" != _typeof(t) || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
        var i = e.call(t, r || "default");
        if ("object" != _typeof(i)) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
}
;
function parsePhoneNumberWithError(text, options, metadata) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$parse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(text, _objectSpread(_objectSpread({}, options), {}, {
        v2: true
    }), metadata);
}
}),
"[project]/node_modules/libphonenumber-js/es6/parsePhoneNumber_.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>parsePhoneNumber
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$parsePhoneNumberWithError_$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/parsePhoneNumberWithError_.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$ParseError$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/ParseError.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$metadata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/metadata.js [app-client] (ecmascript)");
function _typeof(o) {
    "@babel/helpers - typeof";
    return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
        return typeof o;
    } : function(o) {
        return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
    }, _typeof(o);
}
function ownKeys(e, r) {
    var t = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        r && (o = o.filter(function(r) {
            return Object.getOwnPropertyDescriptor(e, r).enumerable;
        })), t.push.apply(t, o);
    }
    return t;
}
function _objectSpread(e) {
    for(var r = 1; r < arguments.length; r++){
        var t = null != arguments[r] ? arguments[r] : {};
        r % 2 ? ownKeys(Object(t), !0).forEach(function(r) {
            _defineProperty(e, r, t[r]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
            Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
        });
    }
    return e;
}
function _defineProperty(e, r, t) {
    return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
        value: t,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[r] = t, e;
}
function _toPropertyKey(t) {
    var i = _toPrimitive(t, "string");
    return "symbol" == _typeof(i) ? i : i + "";
}
function _toPrimitive(t, r) {
    if ("object" != _typeof(t) || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
        var i = e.call(t, r || "default");
        if ("object" != _typeof(i)) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
}
;
;
;
function parsePhoneNumber(text, options, metadata) {
    // Validate `defaultCountry`.
    if (options && options.defaultCountry && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$metadata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSupportedCountry"])(options.defaultCountry, metadata)) {
        options = _objectSpread(_objectSpread({}, options), {}, {
            defaultCountry: undefined
        });
    }
    // Parse phone number.
    try {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$parsePhoneNumberWithError_$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(text, options, metadata);
    } catch (error) {
        /* istanbul ignore else */ if (error instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$ParseError$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]) {
        //
        } else {
            throw error;
        }
    }
}
}),
"[project]/node_modules/libphonenumber-js/es6/parsePhoneNumber.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>parsePhoneNumber
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$normalizeArguments$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/normalizeArguments.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$parsePhoneNumber_$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/parsePhoneNumber_.js [app-client] (ecmascript)");
;
;
function parsePhoneNumber() {
    var _normalizeArguments = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$normalizeArguments$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(arguments), text = _normalizeArguments.text, options = _normalizeArguments.options, metadata = _normalizeArguments.metadata;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$parsePhoneNumber_$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(text, options, metadata);
}
}),
"[project]/node_modules/libphonenumber-js/min/exports/parsePhoneNumber.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "parsePhoneNumber",
    ()=>parsePhoneNumber
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$min$2f$exports$2f$withMetadataArgument$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/min/exports/withMetadataArgument.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$parsePhoneNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/es6/parsePhoneNumber.js [app-client] (ecmascript)");
;
;
function parsePhoneNumber() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$min$2f$exports$2f$withMetadataArgument$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$es6$2f$parsePhoneNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], arguments);
}
}),
"[project]/node_modules/libphonenumber-js/min/exports/parsePhoneNumber.js [app-client] (ecmascript) <export parsePhoneNumber as parsePhoneNumberFromString>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "parsePhoneNumberFromString",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$min$2f$exports$2f$parsePhoneNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parsePhoneNumber"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libphonenumber$2d$js$2f$min$2f$exports$2f$parsePhoneNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libphonenumber-js/min/exports/parsePhoneNumber.js [app-client] (ecmascript)");
}),
]);

//# sourceMappingURL=node_modules_0tmy6ps._.js.map