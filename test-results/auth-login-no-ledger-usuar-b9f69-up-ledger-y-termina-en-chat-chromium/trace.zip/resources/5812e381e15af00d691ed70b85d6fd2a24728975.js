(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_0x_756y._.js","static/chunks/0h_p_next_dist_compiled_next-devtools_index_0_bgiq6.js","static/chunks/0h_p_next_dist_compiled_react-dom_0m0ubgc._.js","static/chunks/0h_p_next_dist_compiled_react-server-dom-turbopack_09dfqcg._.js","static/chunks/0h_p_next_dist_compiled_0azq26o._.js","static/chunks/0h_p_next_dist_client_0kgy4u9._.js","static/chunks/0h_p_next_dist_10xtx6n._.js","static/chunks/0i4a_@swc_helpers_cjs_0hvz.20._.js"],
    source: "entry"
});
