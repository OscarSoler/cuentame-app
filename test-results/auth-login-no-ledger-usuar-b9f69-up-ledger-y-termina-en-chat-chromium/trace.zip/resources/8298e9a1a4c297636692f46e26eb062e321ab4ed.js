(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_099nd3t._.js","static/chunks/node_modules_next_0mzh.8p._.js","static/chunks/node_modules_zod_050m7l3._.js","static/chunks/node_modules_ai_dist_index_mjs_0ssrqvg._.js","static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_0ezz.e5._.js","static/chunks/node_modules_@base-ui_react_esm_00os.8e._.js","static/chunks/node_modules_0yawt0n._.js"],
    source: "dynamic"
});
