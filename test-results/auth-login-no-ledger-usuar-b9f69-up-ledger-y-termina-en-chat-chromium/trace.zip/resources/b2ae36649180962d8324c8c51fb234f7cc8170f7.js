(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/04y0_streamdown_dist_0b6ar8~._.js","static/chunks/_0nolsj7._.js","static/chunks/0h_p_next_0ispjv_._.js","static/chunks/0t0b_zod_v4_00rel~3._.js","static/chunks/0t0b_zod_v3_0jq-dy.._.js","static/chunks/0a6y_@ai-sdk_gateway_dist_index_mjs_13fmgsw._.js","static/chunks/0a___ai_dist_index_mjs_0924lzs._.js","static/chunks/0fiz_swr_dist_0-re-q8._.js","static/chunks/04np_parse5_dist_0-8qcii._.js","static/chunks/0va7_micromark-core-commonmark_dev_lib_0wf4id_._.js","static/chunks/0995_tailwind-merge_dist_bundle-mjs_mjs_0osztqy._.js","static/chunks/125j_micromark_dev_lib_078ya1m._.js","static/chunks/04y0_streamdown_dist_0.9wuro._.js","static/chunks/0cp._@base-ui_react_esm_007-l5g._.js","static/chunks/node_modules__pnpm_0.yvkz-._.js"],
    source: "dynamic"
});
