(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules__pnpm_0.e~u~1._.js","static/chunks/_1074p9t._.js"],
    source: "dynamic"
});
