(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_0ucv84d._.js","static/chunks/node_modules__pnpm_09swi4o._.js"],
    source: "dynamic"
});
